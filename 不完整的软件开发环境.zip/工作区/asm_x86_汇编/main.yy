子程序 加法器(整数型 a, 整数型 b) 整数型
  返回 a + b
结束子程序

子程序 程序入口()
  置入代码("long long 和 = 0;")
  asm Intel
    mov eax, 15
    add eax, 3
    mov [ebp-8], eax
  结束asm
  置入代码("printf(\"例1：15 + 3 = %lld (内联汇编 mov/add/mov 写变量)\\n\", 和);")

  asm Intel
    mov eax, 7
    test eax, 7
    je skip
    mov eax, 1
    mov [ebp-8], eax
    skip:
  结束asm
  置入代码("printf(\"例2：test/je 条件跳转，结果 = %lld\\n\", 和);")

  置入代码("long long 指针 = (long long)加法器;")
  asm Intel
    mov eax, [ebp-16]
    push 10
    push 20
    call eax
    add esp, 8
    mov [ebp-8], eax
  结束asm
  置入代码("printf(\"例3：call 函数指针加法器(10,20) = %lld\\n\", 和);")
结束子程序
