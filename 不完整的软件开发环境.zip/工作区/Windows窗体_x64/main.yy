' ============================================================
' 云易 示例：用 Windows API 创建窗口（x64 版本）
'   窗口上：一个按钮 + 两个编辑框 + 一个列表框
'   编辑框 1 固定显示 "hello world"
'   点击「显示当前时间」按钮 → 编辑框 2 显示当前时间（年-月-日 时:分:秒）
'   列表框里预先放好两项：「班级一」「班级二」
' ------------------------------------------------------------
' 【重点】本示例针对 x64（64 位）编写：
'   指针/句柄用「长整数型」(8 字节)，WNDCLASSEXW = 80 字节
'   结构体改成 10 个「长整数型」槽（每槽 8 字节）：
'     +0 cbSize+style、+8 lpfnWndProc、+16 cbClsExtra+cbWndExtra、
'     +24 hInstance、+32 hIcon、+40 hCursor、+48 hbrBackground、
'     +56 lpszMenuName、+64 lpszClassName、+72 hIconSm
'   写八字节 用置入代码直接写 8 字节内存
' ============================================================

' ===== Windows API 声明（运行时 LoadLibrary + GetProcAddress 动态调用） =====
API 长整数型 GetModuleHandleW(长整数型 模块名) 在库 "kernel32.dll,GetModuleHandleW"
API 长整数型 LocalAlloc(长整数型 标志, 长整数型 字节数) 在库 "kernel32.dll,LocalAlloc"
API 长整数型 StrCpyW(长整数型 目标缓冲, 文本型 来源) 在库 "shlwapi.dll,StrCpyW"
API 长整数型 LoadCursorW(长整数型 实例句柄, 长整数型 资源名) 在库 "user32.dll,LoadCursorW"
API 长整数型 LoadIconW(长整数型 实例句柄, 长整数型 资源名) 在库 "user32.dll,LoadIconW"
API 长整数型 GetSysColorBrush(长整数型 系统色) 在库 "user32.dll,GetSysColorBrush"
API 长整数型 RegisterClassExW(长整数型 窗口类指针) 在库 "user32.dll,RegisterClassExW"
API 长整数型 CreateWindowExW(长整数型 扩展样式, 长整数型 类名, 文本型 标题, 长整数型 样式, 长整数型 横坐标, 长整数型 纵坐标, 长整数型 宽, 长整数型 高, 长整数型 父窗口, 长整数型 菜单, 长整数型 实例句柄, 长整数型 附加数据) 在库 "user32.dll,CreateWindowExW"
API 长整数型 CreateWindowExW_文本(长整数型 扩展样式, 文本型 类名, 文本型 标题, 长整数型 样式, 长整数型 横坐标, 长整数型 纵坐标, 长整数型 宽, 长整数型 高, 长整数型 父窗口, 长整数型 菜单, 长整数型 实例句柄, 长整数型 附加数据) 在库 "user32.dll,CreateWindowExW"
API 长整数型 SetWindowTextW(长整数型 窗口, 文本型 内容) 在库 "user32.dll,SetWindowTextW"
API 长整数型 ShowWindow(长整数型 窗口, 长整数型 命令) 在库 "user32.dll,ShowWindow"
API 长整数型 UpdateWindow(长整数型 窗口) 在库 "user32.dll,UpdateWindow"
API 长整数型 GetMessageW(长整数型 消息缓冲, 长整数型 窗口, 长整数型 最小, 长整数型 最大) 在库 "user32.dll,GetMessageW"
API 长整数型 TranslateMessage(长整数型 消息缓冲) 在库 "user32.dll,TranslateMessage"
API 长整数型 DispatchMessageW(长整数型 消息缓冲) 在库 "user32.dll,DispatchMessageW"
API 长整数型 DefWindowProcW(长整数型 窗口, 长整数型 消息, 长整数型 参数1, 长整数型 参数2) 在库 "user32.dll,DefWindowProcW"
API 长整数型 PostQuitMessage(长整数型 退出码) 在库 "user32.dll,PostQuitMessage"
API 长整数型 SendMessageW(长整数型 窗口, 长整数型 消息, 长整数型 参数1, 文本型 参数2) 在库 "user32.dll,SendMessageW"
API 整数型 GetLastError() 在库 "kernel32.dll,GetLastError"

' ===== 常量（用中文名，避免与 windows.h 的宏同名） =====
常量 消息_创建 长整数型 = 1                        ' WM_CREATE
常量 消息_销毁 长整数型 = 2                        ' WM_DESTROY
常量 消息_命令 长整数型 = 273                      ' WM_COMMAND
常量 样式_重叠窗口 长整数型 = 13565952              ' WS_OVERLAPPEDWINDOW (0x00CF0000)
常量 样式_子窗口 长整数型 = 1073741824              ' WS_CHILD       (0x40000000)
常量 样式_可见 长整数型 = 268435456                 ' WS_VISIBLE     (0x10000000)
常量 样式_边框 长整数型 = 8388608                   ' WS_BORDER      (0x00800000)
常量 样式_制表 长整数型 = 65536                     ' WS_TABSTOP     (0x00010000)
常量 编辑_只读 长整数型 = 8                         ' ES_READONLY
常量 编辑_自动横滚 长整数型 = 128                   ' ES_AUTOHSCROLL
常量 编号_按钮 长整数型 = 1                         ' 按钮的控件 ID
常量 编号_编辑框1 长整数型 = 2                      ' 编辑框 1 的控件 ID
常量 编号_编辑框2 长整数型 = 3                      ' 编辑框 2 的控件 ID
常量 编号_列表框 长整数型 = 4                       ' 列表框的控件 ID
常量 消息_添加字符串 长整数型 = 384                 ' LB_ADDSTRING (0x0180)
常量 显示_正常 长整数型 = 5                         ' SW_SHOW
常量 色_按钮面 长整数型 = 15                        ' COLOR_BTNFACE
常量 资源_应用图标 长整数型 = 32512                 ' IDI_APPLICATION
常量 资源_箭头光标 长整数型 = 32512                 ' IDC_ARROW
常量 结构_大小 长整数型 = 80                        ' x64 下 sizeof(WNDCLASSEXW)

' ===== 全局变量（句柄 / 地址 / 缓冲） =====
全局变量 长整数型 实例句柄
全局变量 长整数型 窗口句柄
全局变量 长整数型 编辑框1
全局变量 长整数型 编辑框2
全局变量 长整数型 按钮
全局变量 长整数型 列表框
全局变量 长整数型 光标
全局变量 长整数型 图标
全局变量 长整数型 画刷
全局变量 长整数型 类名缓冲        ' 窗口类名（StrCpyW 写入的 C 宽字符串）
全局变量 长整数型 编辑框类缓冲    ' "EDIT"
全局变量 长整数型 按钮类缓冲      ' "BUTTON"
全局变量 长整数型 列表框类缓冲    ' "LISTBOX"
全局变量 长整数型 消息缓冲        ' MSG 结构缓冲区

' ===== 自定义数据类型：窗口类（对应 Win32 的 WNDCLASSEXW，x64 版本） =====
' 成员顺序即内存布局顺序；64 位下指针 8 字节，但 cbSize/style 是 4 字节
' 按 x64 布局：+0 cbSize(4)+style(4)、+8 lpfnWndProc、+16 cbClsExtra(4)+cbWndExtra(4)、
'             +24 hInstance、+32 hIcon、+40 hCursor、+48 hbrBackground、
'             +56 lpszMenuName、+64 lpszClassName、+72 hIconSm
数据类型 窗口类
  长整数型 大小样式        ' +0  cbSize(4 字节) + style(4 字节)
  长整数型 窗口过程        ' +8  lpfnWndProc   窗口过程地址
  长整数型 类额外窗口额外  ' +16 cbClsExtra(4 字节) + cbWndExtra(4 字节)
  长整数型 实例句柄        ' +24 hInstance
  长整数型 图标            ' +32 hIcon
  长整数型 光标            ' +40 hCursor
  长整数型 背景画刷        ' +48 hbrBackground
  长整数型 菜单名          ' +56 lpszMenuName
  长整数型 类名            ' +64 lpszClassName  窗口类名（C 宽字符串指针）
  长整数型 小图标          ' +72 hIconSm
结束数据类型

' ===== 工具：把 8 字节整数写入指定地址 =====
' 64 位下指针与 QWORD 都是 8 字节，用它逐字段填写 Win32 结构体。
' 注意：不能用 InterlockedExchange64 —— 它是编译器内建函数，kernel32.dll
' 并不导出，GetProcAddress 拿到 NULL 会导致写入变成空操作（错误码 87）。
子程序 写八字节(长整数型 地址, 长整数型 值) 空
  置入代码("*(long long*)(地址) = (long long)(值);")
结束子程序

' ===== 工具：把 4 字节整数写入指定地址 =====
' 64 位下 cbSize/style/cbClsExtra/cbWndExtra 都是 4 字节（UINT/int）
子程序 写四字节(长整数型 地址, 长整数型 值) 空
  置入代码("*(DWORD*)(地址) = (DWORD)(值);")
结束子程序

' ===== 工具：把「窗口类」结构体写入内存，返回 WNDCLASSEXW 指针 =====
' 按自定义数据类型的成员顺序，把每个成员依次写进 80 字节的内存块；
' 顺序与偏移一一对应（见 数据类型 窗口类 的注释）。
子程序 窗口类到内存(窗口类 类信息) 长整数型
  变量 长整数型 内存
  内存 = LocalAlloc(0, #结构_大小)
  ' cbSize(4 字节) + style(4 字节)：合并成一个 8 字节写入
  写八字节(内存 + 0, 类信息.大小样式)
  ' lpfnWndProc(8 字节)
  写八字节(内存 + 8, 类信息.窗口过程)
  ' cbClsExtra(4 字节) + cbWndExtra(4 字节)：合并成一个 8 字节写入
  写八字节(内存 + 16, 类信息.类额外窗口额外)
  ' hInstance(8 字节)
  写八字节(内存 + 24, 类信息.实例句柄)
  ' hIcon(8 字节)
  写八字节(内存 + 32, 类信息.图标)
  ' hCursor(8 字节)
  写八字节(内存 + 40, 类信息.光标)
  ' hbrBackground(8 字节)
  写八字节(内存 + 48, 类信息.背景画刷)
  ' lpszMenuName(8 字节)
  写八字节(内存 + 56, 类信息.菜单名)
  ' lpszClassName(8 字节)
  写八字节(内存 + 64, 类信息.类名)
  ' hIconSm(8 字节)
  写八字节(内存 + 72, 类信息.小图标)
  返回 (内存)
结束子程序

' ============================================================
' 窗口过程（回调）：窗口收到的所有消息都送到这里
'   WM_CREATE   → 创建按钮、两个编辑框与列表框（列表框再塞进两项）
'   WM_COMMAND  → 参数1 的低 16 位是控件 ID；点按钮则把当前时间写入编辑框 2
'   WM_DESTROY  → 退出消息循环
'   其它消息    → 交给 DefWindowProcW 默认处理（移动/缩放/关闭/绘制/焦点等）
' ============================================================
子程序 WndProc(长整数型 窗口, 长整数型 消息, 长整数型 参数1, 长整数型 参数2) 长整数型
  变量 长整数型 控件编号

  如果 (消息 = #消息_创建)
    ' 编辑框 1：固定显示 "hello world"（只读 + 内容超长可横向滚动）
    编辑框1 = CreateWindowExW_文本(0, "EDIT", "hello world",
      #样式_子窗口 + #样式_可见 + #样式_边框 + #编辑_只读 + #编辑_自动横滚,
      20, 20, 340, 28, 窗口, #编号_编辑框1, 实例句柄, 0)
    ' 按钮
    按钮 = CreateWindowExW_文本(0, "BUTTON", "显示当前时间",
      #样式_子窗口 + #样式_可见 + #样式_制表,
      20, 64, 130, 32, 窗口, #编号_按钮, 实例句柄, 0)
    ' 编辑框 2：点击按钮后显示当前时间（只读）
    编辑框2 = CreateWindowExW_文本(0, "EDIT", "（点击左侧按钮）",
      #样式_子窗口 + #样式_可见 + #样式_边框 + #编辑_只读 + #编辑_自动横滚,
      160, 64, 200, 28, 窗口, #编号_编辑框2, 实例句柄, 0)
    ' 列表框：按钮下方，显示「班级一」「班级二」
    列表框 = CreateWindowExW_文本(0, "LISTBOX", "",
      #样式_子窗口 + #样式_可见 + #样式_边框 + #样式_制表,
      20, 110, 340, 70, 窗口, #编号_列表框, 实例句柄, 0)
    SendMessageW(列表框, #消息_添加字符串, 0, "班级一")
    SendMessageW(列表框, #消息_添加字符串, 0, "班级二")
    返回 (0)
  结束如果

  如果 (消息 = #消息_命令)
    控件编号 = 位与(参数1, 65535)                  ' 低 16 位 = 控件 ID
    如果 (控件编号 = #编号_按钮)
      SetWindowTextW(编辑框2, 取当前时间())         ' ← 点击按钮：显示当前时间
    结束如果
    返回 (0)
  结束如果

  如果 (消息 = #消息_销毁)
    PostQuitMessage(0)
    返回 (0)
  结束如果

  返回 (DefWindowProcW(窗口, 消息, 参数1, 参数2))
结束子程序

' ============================================================
' 创建窗口：填好「窗口类」结构体 → 注册窗口类 → 创建窗口
' ============================================================
子程序 创建主窗口() 空
  变量 窗口类 类信息                 ' 自定义数据类型变量：一个「窗口类」结构体
  变量 长整数型 窗口类指针

  ' ① 按成员名填写窗口类信息（等价于填 WNDCLASSEXW 的各个字段）
  ' x64 下 cbSize 必须为 80，style 与 cbSize 合并到 +0 槽
  类信息.大小样式 = #结构_大小         ' +0  cbSize(80) + style(0)
  类信息.窗口过程 = WndProc            ' +8  lpfnWndProc
  类信息.类额外窗口额外 = 0            ' +16 cbClsExtra(0) + cbWndExtra(0)
  类信息.实例句柄 = 实例句柄           ' +24 hInstance
  类信息.图标 = 图标                   ' +32 hIcon
  类信息.光标 = 光标                   ' +40 hCursor
  类信息.背景画刷 = 画刷               ' +48 hbrBackground
  类信息.菜单名 = 0                    ' +56 lpszMenuName
  类信息.类名 = 类名缓冲               ' +64 lpszClassName
  类信息.小图标 = 0                    ' +72 hIconSm

  ' ② 转成内存中的 WNDCLASSEXW 并注册窗口类
  窗口类指针 = 窗口类到内存(类信息)
  变量 长整数型 注册结果
  注册结果 = RegisterClassExW(窗口类指针)
  如果 (注册结果 = 0)
    变量 整数型 错误码
    错误码 = GetLastError()
    信息框("RegisterClassExW 失败，错误码 = " + 到文本(错误码), "调试")
    返回
  结束如果

  ' ③ 创建窗口（类名传指针；标题直接传文本）
  ' 注意：宽高是「窗口整体」尺寸（含标题栏 + 边框），客户区要再减去约 80px
  ' 列表框底边在客户区 y=180，所以窗口高度至少 180+80=260，这里给 300 留余量
  窗口句柄 = CreateWindowExW(0, 类名缓冲, "云易 Windows 窗口示例 (x64)",
    #样式_重叠窗口, 240, 180, 420, 300, 0, 0, 实例句柄, 0)
结束子程序

' ============================================================
' 程序入口：准备资源与类名 → 注册窗口类并创建窗口 → 显示 → 消息循环
' ============================================================
子程序 程序入口() 长整数型

  ' 1) 实例句柄与默认资源
  实例句柄 = GetModuleHandleW(0)                   ' 0 = 当前进程主模块
  光标 = LoadCursorW(0, #资源_箭头光标)
  图标 = LoadIconW(0, #资源_应用图标)
  画刷 = GetSysColorBrush(#色_按钮面)               ' 窗口背景色（按钮面色）

  ' 2) 把类名写进内存，作为「C 宽字符串指针」传给 API
  类名缓冲 = LocalAlloc(0, 64)
  StrCpyW(类名缓冲, "云易示例窗口类")

  ' 3) 注册窗口类并创建窗口（内部用自定义数据类型描述窗口类结构体）
  创建主窗口()
  如果 (窗口句柄 = 0)
    信息框("窗口创建失败，请检查系统环境。", "云易示例")
    返回 (1)
  结束如果

  ' 4) 显示窗口
  ShowWindow(窗口句柄, #显示_正常)
  UpdateWindow(窗口句柄)

  ' 5) 消息循环：把消息派发给窗口过程，直到收到退出消息
  消息缓冲 = LocalAlloc(0, 64)
  变量 长整数型 消息结果
  消息结果 = GetMessageW(消息缓冲, 0, 0, 0)
  当循环 消息结果 != 0
    TranslateMessage(消息缓冲)
    DispatchMessageW(消息缓冲)
    消息结果 = GetMessageW(消息缓冲, 0, 0, 0)
  结束循环
  返回 (0)
结束子程序
