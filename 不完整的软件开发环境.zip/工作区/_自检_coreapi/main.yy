' core.api 结构体参数自检：调用类库 API 时，其参数用到的数据类型（POINT_/SYSTEMTIME_）
' 应被自动引入，无需在工程里定义
测试函数 coreapi结构体自检()
  变量 pt POINT_
  断言(GetCursorPos(pt), "GetCursorPos 应返回真")
  断言(pt.x + pt.y != 0 或 (pt.x = 0 且 pt.y = 0), "光标坐标已填充")

  变量 st SYSTEMTIME_
  GetLocalTime(st)
  断言(st.wYear >= 2020, "本地年份应 >= 2020（st.wYear=" + 到文本(st.wYear) + "）")

  断言(GetTickCount() > 0, "GetTickCount 应大于 0")
结束子程序

子程序 程序入口() 整数型
  返回 (0)
结束子程序
