param(
  [string]$exe = 'F:\Workspaces\yunyunide\工作区\图像到窗体\build\debug\图像到窗体.exe',
  [string]$out = 'F:\Workspaces\yunyunide\.temp\yy_shot.png'
)
New-Item -ItemType Directory -Force -Path (Split-Path $out) | Out-Null

$code = @'
using System;using System.Drawing;using System.Runtime.InteropServices;
public class WinCapture{
  public delegate bool EnumWin(IntPtr h,IntPtr p);
  [DllImport("user32.dll")]public static extern bool EnumWindows(EnumWin cb,IntPtr p);
  [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
  [DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")]public static extern bool GetWindowRect(IntPtr h,out RECT r);
  [DllImport("user32.dll")]public static extern bool PrintWindow(IntPtr h,IntPtr dc,int f);
  public struct RECT{public int L,T,R,B;}
}
'@
Add-Type -TypeDefinition $code -ReferencedAssemblies System.Drawing,System.Windows.Forms

$p = Start-Process -FilePath $exe -PassThru
Start-Sleep -Seconds 6
$pid2 = $p.Id
$found = $false
$delegate = [WinCapture+EnumWin]{
  param($h,$p2)
  [uint32]$pp = 0
  [WinCapture]::GetWindowThreadProcessId($h, [ref]$pp) | Out-Null
  if ($pp -eq $pid2 -and [WinCapture]::IsWindowVisible($h)) {
    $r = New-Object WinCapture+RECT
    [WinCapture]::GetWindowRect($h, [ref]$r) | Out-Null
    $w = $r.R - $r.L; $hh = $r.B - $r.T
    if ($w -gt 50 -and $hh -gt 50) {
      $bmp = New-Object System.Drawing.Bitmap($w, $hh)
      $g = [System.Drawing.Graphics]::FromImage($bmp)
      $hdc = $g.GetHdc()
      [WinCapture]::PrintWindow($h, $hdc, 2) | Out-Null
      $g.ReleaseHdc($hdc)
      $bmp.Save($out)
      $g.Dispose(); $bmp.Dispose()
      $script:found = $true
    }
  }
  return $true
}
[WinCapture]::EnumWindows($delegate, [IntPtr]::Zero) | Out-Null
Write-Output ("found=" + $found + " saved=" + $out)
Stop-Process -Id $p.Id -ErrorAction SilentlyContinue
