' ============================================================
' 云易 语法自检 —— API 别名声明（在库 "xxx.dll,真实API名"）
'   · 在库 "user32.dll,DefWindowProcA"：默认窗口过程 是别名，
'     DefWindowProcA 是 user32.dll 里的真实 WinAPI 函数
'   · 声明名与真实名相同时也写成新格式（如 user32.dll,MessageBoxA）
' ============================================================
API 整数型 默认窗口过程(整数型 hwnd, 整数型 wMsg, 整数型 wParam, 整数型 lParam) 在库 "user32.dll,DefWindowProcA"
API 整数型 取开机毫秒() 在库 "kernel32.dll,GetTickCount"
API 整数型 取文本长度W(文本型 s) 在库 "kernel32.dll,lstrlenW"
API 整数型 MessageBoxA(整数型 hWnd, 文本型 lpText, 文本型 lpCaption, 整数型 uType) 在库 "user32.dll,MessageBoxA"
' 别名弹窗 → 真实名 MessageBoxA
API 整数型 弹窗(整数型 hWnd, 文本型 lpText, 文本型 lpCaption, 整数型 uType) 在库 "user32.dll,MessageBoxA"

测试函数 API别名自检()
  断言(默认窗口过程(0, 0, 0, 0) = 0, "默认窗口过程(0,0,0,0) 应为 0（真实名 DefWindowProcA）")
  变量 t 整数型
  t = 取开机毫秒()
  断言(t >= 0, "取开机毫秒 应可调用（真实名 GetTickCount）")
  断言(取文本长度W("云易") = 2, "取文本长度W(云易) 应为 2（真实名 lstrlenW）")
  变量 r 整数型
  r = 弹窗(0, "这是别名调用 MessageBoxA 的弹窗", "API别名自检", 0)
  断言(r = 1, "弹窗(MessageBoxA) 返回 1 表示用户点了确定")
结束子程序

子程序 程序入口() 整数型
  返回 (0)
结束子程序
