@echo off
chcp 65001 >nul
pushd "F:\Workspaces\yunyunide\工作区\test"
"F:\Workspaces\yunyunide\tools\mingw32\bin\mingw32-make.exe" -f Makefile MODE=debug
if errorlevel 1 ( echo 构建失败 & pause & exit /b 1 )
echo 构建完成
popd
pause
