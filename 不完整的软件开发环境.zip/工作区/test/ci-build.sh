#!/usr/bin/env bash
# 云易IDE 自动生成 —— 通用 CI 构建脚本（Gitea Actions / 自建 CI 可用）
set -e
echo "== 构建 test =="
GXX_ARG=""
if [ -n "$YUNYI_GXX" ]; then GXX_ARG="--gxx $YUNYI_GXX"; fi
python3 server/yunyi_cli.py build "工作区/test" --mode release $GXX_ARG
python3 server/yunyi_cli.py test "工作区/test" --mode debug $GXX_ARG
echo "== 构建完成，产物：工作区/test/build/release/ =="
