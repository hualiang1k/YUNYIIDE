@echo off
chcp 65001 >nul
rem 双击运行：默认只预览；要真正删除，请加 -Force 参数
rem 用相对路径调用同目录下的 ps1：先 pushd 到本文件所在目录，再按相对名执行
pushd "%~dp0"
echo [%~nx0] 仓库根目录: %CD%
echo %* | findstr /i "Force" >nul
if not errorlevel 1 (
    echo [%~nx0] 模式: 实际删除 ^(-Force^)
) else (
    echo [%~nx0] 模式: 仅预览，不删除 ^(加 -Force 参数才会真正删除^)
)
echo ----------------------------------------------------------
powershell -ExecutionPolicy Bypass -NoProfile -File "清理缓存.ps1" %*
popd
pause
