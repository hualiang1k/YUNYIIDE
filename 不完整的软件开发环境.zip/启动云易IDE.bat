@echo off
chcp 65001 >nul
rem 云易IDE 一键启动：优先使用 IDE 自带的 Python（tools\python），无需安装任何依赖
rem 端口见 config\settings.json（默认 8405），启动后浏览器会自动打开
rem 编码：本脚本自身是 UTF-8 并在开头切到 65001（内容与代码页一致，中文路径不乱码）；
rem       再给服务进程设 PYTHONUTF8 / PYTHONIOENCODING，全链路（编译器、脚本、智能体）统一 UTF-8
rem
rem 重复运行本脚本 = 重启 IDE：server.py 启动时会先结束上一次残留的服务进程
rem （Windows 的 SO_REUSEADDR 允许两个进程绑同一端口，旧进程会继续接收请求，
rem   不清理就会出现「代码改了、也重启了，行为却没变」，很难排查）。
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

set PY=tools\python\bin\python3.14.exe
if not exist "%PY%" (
    rem 回退到系统 Python
    set PY=python
)

echo 正在启动云易IDE...
start "云易IDE服务" /min "%PY%" server\server.py
