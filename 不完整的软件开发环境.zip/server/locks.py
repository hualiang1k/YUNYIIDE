# -*- coding: utf-8 -*-
"""共享锁：手动编译/运行与 AI 智能体的编译/运行共用同一把锁，避免并发构建冲突。"""
from __future__ import annotations
import threading

BUILD_LOCK = threading.Lock()
