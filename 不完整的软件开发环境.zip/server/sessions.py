# -*- coding: utf-8 -*-
"""程序运行会话（后台进程 + 增量输出 + 标准输入）。"""
from __future__ import annotations
import itertools
import os
import subprocess
import threading

from yunyi import codec as CODEC
from yunyi.toolchain import runtime_env

SESSIONS: dict = {}


# ---------------- 窗口前置监视（运行/测试时把程序窗口、信息框弹到最前端） ----------------
# 背景：程序由服务端（隐藏的后台进程）启动，Windows 不允许后台进程把窗口抢到前台，
#       用户程序的信息框（MessageBox）、控制台窗口很容易被浏览器等窗口盖住。
# 实现：会话存续期间由监视线程周期扫描「会话进程树」拥有的可见顶层窗口，
#       新窗口出现时用 TOPMOST→NOTOPMOST 两连 SetWindowPos 抬到最前端（不驻留置顶）。
#       该技巧不要求调用方具备前台权限，后台进程也生效。

try:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.windll.user32
    _kernel32 = ctypes.windll.kernel32

    _GW_OWNER = 4
    _SWP_NOSIZE = 0x0001
    _SWP_NOMOVE = 0x0002
    _SWP_NOACTIVATE = 0x0010
    _HWND_TOPMOST = wintypes.HWND(-1)
    _HWND_NOTOPMOST = wintypes.HWND(-2)

    _WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    _user32.EnumWindows.argtypes = [_WNDENUMPROC, wintypes.LPARAM]
    _user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                                  ctypes.POINTER(wintypes.DWORD)]
    _user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND,
                                     ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, ctypes.c_int,
                                     ctypes.c_uint]
    _WIN_FW_AVAIL = True
except Exception:                                        # 非 Windows 环境降级为空操作
    _WIN_FW_AVAIL = False


def _list_pids(root_pid: int) -> set:
    """收集进程树（root 及其全部后代）的 PID 集合。

    快照式自顶向下扫描：每轮把已知父 PID 集合的子进程并入，直到不再增长。
    （避免 psutil 依赖；用 toolhelp32 快照遍历。）
    """
    import ctypes.wintypes as wt
    cr = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD),
                    ("th32ProcessID", wt.DWORD),
                    ("th32DefaultHeapID", ctypes.POINTER(wt.ULONG)),
                    ("th32ModuleID", wt.DWORD), ("cntThreads", wt.DWORD),
                    ("th32ParentProcessID", wt.DWORD), ("pcPriClassBase", ctypes.c_long),
                    ("dwFlags", wt.DWORD), ("szExeFile", ctypes.c_char * 260)]

    class SN(ctypes.Structure):
        _fields_ = [("dwSize", wt.DWORD), ("cnt", wt.DWORD),
                    ("th32ProcessID", wt.DWORD)]

    snap = _kernel32.CreateToolhelp32Snapshot(0x2, 0)     # TH32CS_SNAPPROCESS
    if snap == -1 or snap == 0xFFFFFFFF:
        return {root_pid}
    try:
        entries = []
        pe = PE(); pe.dwSize = ctypes.sizeof(PE)
        ok = _kernel32.Process32First(snap, ctypes.byref(pe))
        while ok:
            entries.append((pe.th32ProcessID, pe.th32ParentProcessID))
            ok = _kernel32.Process32Next(snap, ctypes.byref(pe))
    finally:
        _kernel32.CloseHandle(snap)
    # 自顶向下收敛进程树
    known = {root_pid}
    grew = True
    while grew:
        grew = False
        for pid, ppid in entries:
            if ppid in known and pid not in known:
                known.add(pid)
                grew = True
    return known


def _foreground_pid_tree_windows(pids: set) -> list:
    """枚举属于给定 PID 集合的可见顶层窗口，返回 [(hwnd, pid), ...]。"""
    result = []

    @ _WNDENUMPROC
    def _cb(hwnd, _lparam):
        if not _user32.IsWindowVisible(hwnd):
            return True
        # 跳过有属主的窗口（信息框/对话框的属主是主窗口，抬主窗口时会连带置前；
        # 但信息框若无属主则独立抬前，避免重复处理）
        pid = wintypes.DWORD(0)
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids:
            result.append((hwnd, pid.value))
        return True

    _user32.EnumWindows(_cb, 0)
    return result


def _bring_to_front(hwnd) -> None:
    """把窗口抬到最前端：先短暂 TOPMOST 再取消，等效 SetForegroundWindow 但不需要前台权限。"""
    _user32.SetWindowPos(hwnd, _HWND_TOPMOST, 0, 0, 0, 0,
                         _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOACTIVATE)
    _user32.SetWindowPos(hwnd, _HWND_NOTOPMOST, 0, 0, 0, 0,
                         _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOACTIVATE)


def _watch_foreground(proc, stop_event: threading.Event, interval: float = 0.25):
    """会话监视线程主体：进程存续期间，把进程树新出现的窗口抬到最前端。

    - 首轮把启动时已存在的窗口抬前（运行/测试的启动瞬间）
    - 之后每轮只抬「新出现」的窗口（信息框弹出、控制台窗口打开等），
      避免反复抢焦点干扰用户操作
    - 进程退出后结束监视
    """
    if not _WIN_FW_AVAIL:
        return
    raised: set = set()                                   # 已抬前过的 hwnd
    try:
        while not stop_event.is_set():
            try:
                if proc.poll() is not None:
                    return
                pids = _list_pids(proc.pid)
                for hwnd, _pid in _foreground_pid_tree_windows(pids):
                    if hwnd not in raised:
                        raised.add(hwnd)
                        _bring_to_front(hwnd)
            except Exception:
                pass                                      # 单轮失败不影响后续
            stop_event.wait(interval)
    except Exception:
        pass


def _sid():
    return next(itertools.count(1))


class BaseSession:
    kind = "base"

    def __init__(self, title: str = ""):
        self.id = _sid()
        self.title = title
        self.proc: subprocess.Popen = None
        self.lines: list = []          # 已累积的输出行
        self.running = False
        self.exit_code = None
        self._lock = threading.Lock()
        self._reader_t = None
        self._fg_stop = threading.Event()      # 窗口前置监视线程的停止信号
        self._fg_t = None
        SESSIONS[self.id] = self

    def start(self, cmd: list, cwd=None):
        cr = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, cwd=cwd, creationflags=cr,
            bufsize=0, env=runtime_env())
        self.running = True
        self._reader_t = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_t.start()
        # 运行/测试：把程序窗口、信息框自动抬到最前端
        self._start_foreground_watch()
        return self

    def _start_foreground_watch(self):
        """启动窗口前置监视线程（仅 Windows；进程退出后自动结束）。"""
        if os.name == "nt" and self.proc is not None:
            self._fg_stop.clear()
            self._fg_t = threading.Thread(
                target=_watch_foreground,
                args=(self.proc, self._fg_stop), daemon=True)
            self._fg_t.start()

    def _read_loop(self):
        buf = b""
        try:
            while True:
                chunk = self.proc.stdout.read(4096)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    # runner 通道：运行库已把控制台切 UTF-8（yunyi/runtime/yunyi_rt.hpp）
                    self._emit(CODEC.decode("runner", line.rstrip(b"\r")))
        except Exception:
            pass
        if buf:
            self._emit(CODEC.decode("runner", buf.rstrip(b"\r")))
        self.exit_code = self.proc.wait()
        self.running = False
        self._fg_stop.set()                   # 进程结束：停止窗口前置监视

    def _emit(self, text: str):
        with self._lock:
            self.lines.append(text)

    def poll(self, since: int):
        with self._lock:
            new = list(self.lines[since:])
        return {"sid": self.id, "lines": new, "running": self.running,
                "exitCode": self.exit_code, "since": since + len(new)}

    def send_input(self, data: str):
        if not self.running or not self.proc or self.proc.stdin is None:
            return False
        try:
            self.proc.stdin.write((data + "\r\n").encode("utf-8"))
            self.proc.stdin.flush()
            return True
        except Exception:
            return False

    def kill(self):
        self._fg_stop.set()                   # 先停监视，避免抢回已结束进程的窗口
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=3)
                except Exception:
                    self.proc.kill()
        except Exception:
            pass


def new_run_session(cmd, cwd=None, title="运行"):
    s = BaseSession(title)
    s.start(cmd, cwd)
    return s
