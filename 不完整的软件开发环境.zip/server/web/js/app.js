// 云易IDE 前端主逻辑
'use strict';

/* ================= 基础工具 ================= */
const $ = (id) => document.getElementById(id);
let LINE_H = 21;               // 编辑器行高（随字号联动，默认 13px 字号对应 21px）

/* ================= 编辑器字号（右下角 ＋/－ 调节，保存到 localStorage） ================= */
const FONT_KEY = 'yyEditorFontSize';
let editorFont = 13;             // 当前字号（px）
function lineHOf(fontSize) { return Math.round(fontSize * 21 / 13); }
function applyEditorFont() {
  const root = document.documentElement;
  root.style.setProperty('--ed-font', editorFont + 'px');
  root.style.setProperty('--ed-lh', LINE_H + 'px');
  const lab = $('fontSizeLabel');
  if (lab) lab.textContent = editorFont;
  _measureCtx = null;            // 下次测量重建（字号已变）
  const t = activeTab();
  if (t) drawOverlay(t);
}
function initEditorFont() {
  let f = 13;
  try {
    const v = parseInt(localStorage.getItem(FONT_KEY), 10);
    if (v >= 9 && v <= 32) f = v;
  } catch (e) { /* 忽略 */ }
  editorFont = f;
  LINE_H = lineHOf(f);
}
function adjustFont(delta) {
  let f = editorFont + delta;
  if (f < 9) f = 9;
  if (f > 32) f = 32;
  editorFont = f;
  LINE_H = lineHOf(f);
  applyEditorFont();
  saveFontPref('editor', FONT_KEY, f);
}

/* ================= 侧栏（工程/核心/类/函数）字号（右下角 ＋/－ 调节，保存到 localStorage） ================= */
const SIDE_FONT_KEY = 'yySideFontSize';
let sideFont = 12;               // 当前字号（px），默认与原固定字号一致
function applySideFont() {
  document.documentElement.style.setProperty('--side-font', sideFont + 'px');
  const lab = $('sideFontSizeLabel');
  if (lab) lab.textContent = sideFont;
}
function initSideFont() {
  let f = 12;
  try {
    const v = parseInt(localStorage.getItem(SIDE_FONT_KEY), 10);
    if (v >= 9 && v <= 32) f = v;
  } catch (e) { /* 忽略 */ }
  sideFont = f;
}
function adjustSideFont(delta) {
  let f = sideFont + delta;
  if (f < 9) f = 9;
  if (f > 32) f = 32;
  sideFont = f;
  applySideFont();
  saveFontPref('side', SIDE_FONT_KEY, f);
}

/* ================= 底部控制台（控制台/问题）字号（右下角 ＋/－ 调节，保存到 localStorage） ================= */
const CON_FONT_KEY = 'yyConsoleFontSize';
let conFont = 13;                // 当前字号（px），默认与原固定字号一致
function applyConFont() {
  document.documentElement.style.setProperty('--con-font', conFont + 'px');
  const lab = $('consoleFontSizeLabel');
  if (lab) lab.textContent = conFont;
}
function initConFont() {
  let f = 13;
  try {
    const v = parseInt(localStorage.getItem(CON_FONT_KEY), 10);
    if (v >= 9 && v <= 32) f = v;
  } catch (e) { /* 忽略 */ }
  conFont = f;
}
function adjustConFont(delta) {
  let f = conFont + delta;
  if (f < 9) f = 9;
  if (f > 32) f = 32;
  conFont = f;
  applyConFont();
  saveFontPref('console', CON_FONT_KEY, f);
}

/* ================= 顶部菜单栏字号（顶栏右上角 ＋/－ 调节，保存到 localStorage） ================= */
const TOP_FONT_KEY = 'yyTopFontSize';
let topFont = 13;                // 当前字号（px），与 button / select 的默认 13px 一致
function applyTopFont() {
  document.documentElement.style.setProperty('--top-font', topFont + 'px');
  const lab = $('topFontSizeLabel');
  if (lab) lab.textContent = topFont;
}
function initTopFont() {
  let f = 13;
  try {
    const v = parseInt(localStorage.getItem(TOP_FONT_KEY), 10);
    if (v >= 9 && v <= 32) f = v;
  } catch (e) { /* 忽略 */ }
  topFont = f;
}
function adjustTopFont(delta) {
  let f = topFont + delta;
  if (f < 9) f = 9;
  if (f > 32) f = 32;
  topFont = f;
  applyTopFont();
  saveFontPref('top', TOP_FONT_KEY, f);
}

async function api(method, url, body, _retry) {
  const opt = { method, headers: {} };
  if (body !== undefined) {
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  let resp, text = '';
  try {
    resp = await fetch(url, opt);
    text = await resp.text();
  } catch (e) {
    // 网络级错误（连接被中断等）：GET 是幂等请求，自动重试一次
    if ((_retry === undefined ? 1 : _retry) > 0 && method === 'GET') {
      await new Promise((r) => setTimeout(r, 400));
      return api(method, url, body, 0);
    }
    throw new Error('网络请求失败（服务器未响应或连接中断）：' + e.message);
  }
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (e) {
    // HTTP 200 但内容不是有效 JSON：一般是响应被中途截断（刷新页面 / 连接中断）
    if (resp.ok && (_retry === undefined ? 1 : _retry) > 0 && method === 'GET') {
      await new Promise((r) => setTimeout(r, 400));
      return api(method, url, body, 0);
    }
    throw new Error(resp.ok
      ? '服务器响应异常（HTTP ' + resp.status + '，内容不是有效 JSON）：' + text.slice(0, 120)
      : '请求失败 ' + resp.status + '：' + text.slice(0, 120));
  }
  // 非 2xx：请求级错误；2xx 且带 error 字段：业务拒绝（如工程不存在）
  // 注意：/api/build、/api/run 等编译失败时返回 {ok:false, result:{messages}}（HTTP 200），
  // 错误详情在 result 中，由调用方 showProblems 展示，这里不能当请求错误抛出
  if (!resp.ok) throw new Error(data.error || data.message || ('请求失败 ' + resp.status));
  if (data.ok === false && data.error) throw new Error(data.error);
  return data;
}

/* ================= IDE 界面设置同步（服务端 config/ide_settings.json） =================
   「设置选项」类的内容——IDE配色、主题、各处字号——统一落到服务端 config 目录
   （config/ide_settings.json，与 settings.json / ai_agent.json 同目录），
   刷新 / 换浏览器不再丢；localStorage 里只留一份即时缓存：
   启动先按缓存上屏（避免闪变），随后用服务端配置覆盖。
   界面状态类（快照 yyIdeState、面板折叠、控制台选项卡等）不算设置，仍留 localStorage；
   工程级设置（.yyproj）不在此列。 */
let _ideCfg = {};                // 服务端配置的本地镜像（最近一次已知内容）
let _ideCfgTimer = null;         // 防抖合并写盘（拖动字号 / 连续取色时不会每下都发请求）
const _IDE_CFG_VALID = {
  fonts: ['editor', 'side', 'console', 'ai', 'top'],
};
function ideCfgQueueSave(patch) {
  try {
    Object.keys(patch || {}).forEach((k) => {
      const v = patch[k];
      const keys = _IDE_CFG_VALID[k];
      if (keys && v && typeof v === 'object') {           // fonts：白名单键逐个合并
        _ideCfg[k] = _ideCfg[k] && typeof _ideCfg[k] === 'object' ? _ideCfg[k] : {};
        keys.forEach((kk) => { if (v[kk] !== undefined) _ideCfg[k][kk] = v[kk]; });
      } else if (k === 'tokColors' || k === 'theme') {    // 整包覆盖
        _ideCfg[k] = v;
      }
    });
  } catch (e) { return; }
  if (_ideCfgTimer) clearTimeout(_ideCfgTimer);
  _ideCfgTimer = setTimeout(() => {
    _ideCfgTimer = null;
    api('POST', '/api/ideconfig', _ideCfg).catch(() => { /* 落盘失败：下次改动再试 */ });
  }, 400);
}
function ideCfgApplyRemote(cfg) {
  if (!cfg || typeof cfg !== 'object') return;
  // 主题（dark / light）
  if (cfg.theme === 'light' || cfg.theme === 'dark') applyTheme(cfg.theme === 'dark');
  // 字号（合法性同各 initXxxFont：9~32）
  const F = cfg.fonts || {};
  const num = (v) => { const n = parseInt(v, 10); return (n >= 9 && n <= 32) ? n : null; };
  const ed = num(F.editor);
  if (ed != null) { editorFont = ed; LINE_H = lineHOf(ed); applyEditorFont(); }
  const sd = num(F.side);
  if (sd != null) { sideFont = sd; applySideFont(); }
  const cf = num(F.console);
  if (cf != null) { conFont = cf; applyConFont(); }
  const af = num(F.ai);
  if (af != null) { aiFont = af; applyAiFont(); }
  const tf = num(F.top);
  if (tf != null) { topFont = tf; applyTopFont(); }
  // IDE配色（结构同 localStorage 缓存：{dark:{…}, light:{…}}）
  const tc = cfg.tokColors;
  if (tc && tc.dark && tc.light && typeof tc.dark === 'object' && typeof tc.light === 'object') {
    userTokColors = { dark: Object.assign({}, tc.dark), light: Object.assign({}, tc.light) };
    applyTokColors();
  }
}
async function syncIdeConfigLoad() {
  try {
    const d = await api('GET', '/api/ideconfig');
    _ideCfg = (d && d.config) || {};
    ideCfgApplyRemote(_ideCfg);
  } catch (e) { /* 服务端不可用：继续用 localStorage 缓存 */ }
}
/* 字号保存：localStorage 即时缓存 + 并入 config/ide_settings.json */
function saveFontPref(cfgKey, lsKey, px) {
  try { localStorage.setItem(lsKey, String(px)); } catch (e) { /* 忽略 */ }
  ideCfgQueueSave({ fonts: { [cfgKey]: px } });
}

/* ================= 多语言（i18n：config\*.lng 语言包） =================
   语言包是「键=值」文本文件：键 = 界面中文原文，值 = 译文（值留空表示保持原文）；
   行首 # / ; 为注释，@label=… 是语言包在 IDE设置-工作区 下拉框里的显示名。
   当前语言存服务端 config/settings.json 的 "language"（文件主名，如 zh_cn）。
   上屏机制有两个：
   ① applyI18n()：启动 / 切语言后对整棵 DOM 扫描一遍；
   ② MutationObserver：之后动态生成的界面（菜单 / 对话框 / 列表…）增量翻译。
   只做「整段文本精确匹配」替换，不会碰代码、控制台输出、文件名这类内容
   （编辑器 / 控制台 / AI 消息 / 文件树 / 标签页在 I18N_SKIP 里排除）。 */
const I18N_SKIP = '#codeHost, #gutter, #foldLayer, #highlight, #acBox,'
  + ' .aiMsgsWrap .bubble, #tree, #tabs';
const I18N = { lang: 'zh_cn', langs: [], dict: null, observer: null };

function i18nSkipped(el) {
  return !el || el.closest(I18N_SKIP) || el.closest('[data-noi18n]');
}

/* 通配符模板：语言包里键含 * 的条目（如「行 * : 列 *」→「Line $1 : Col $2」），
   用于状态栏 / 控制台 / 对话框标题这类拼接字符串。按键长降序逐个试，最具体的先命中。 */
function i18nBuildTemplates() {
  I18N.tpl = Object.keys(I18N.dict).filter((k) => k.indexOf('*') >= 0)
    .sort((a, b) => b.length - a.length)
    .map((k) => ({
      re: new RegExp('^' + k.split('*')
        .map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('(.*?)') + '$'),
      to: I18N.dict[k],
    }));
}

/* 查一个界面文案的译文：先整段精确匹配，再试通配符模板（$1/$2… 回填；
   捕获到的片段会递归查一遍——「模式：调试版 · x64」里的「调试版」也翻成英文）。 */
function i18nLookup(s, depth) {
  if (!I18N.dict || !s) return null;
  const v = I18N.dict[s];
  if (v != null && v !== '') return v;
  if (!I18N.tpl || !s || s.length > 160) return null;   // 长文本不跑模板（性能 + 误伤面）
  if (depth == null) depth = 0;
  for (let i = 0; i < I18N.tpl.length; i++) {
    const m = s.match(I18N.tpl[i].re);
    if (!m) continue;
    let out = I18N.tpl[i].to;
    for (let g = 1; g < m.length; g++) {
      const cap = depth < 3 ? (i18nLookup(m[g], depth + 1) || m[g]) : m[g];
      out = out.split('$' + g).join(cap);
    }
    return out;
  }
  return null;
}

/* 扫描 root（默认整个文档）：文本节点整段精确匹配替换；title / placeholder 属性同样处理 */
function applyI18n(root) {
  if (!I18N.dict) return;
  root = root || document;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (i18nSkipped(n.parentElement)) return NodeFilter.FILTER_REJECT;
      return i18nLookup(n.nodeValue.trim()) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    },
  });
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach((n) => {
    const v = n.nodeValue.trim();
    n.nodeValue = n.nodeValue.split(v).join(i18nLookup(v));
  });
  if (root.querySelectorAll) {
    /* data-i18n：整块 HTML 替换（词典键 = '@html:' + 属性值）。
       用于内嵌代码 span 导致文本节点碎片化的段落（如设计器的接口说明）。
       一次性：替换后打 i18nDone 标记，观察器重复扫描不会反复改 DOM。 */
    root.querySelectorAll('[data-i18n]').forEach((el) => {
      if (i18nSkipped(el) || el.dataset.i18nDone) return;
      const t = I18N.dict['@html:' + el.getAttribute('data-i18n')];
      if (t) {
        el.innerHTML = t;
        el.dataset.i18nDone = '1';
      }
    });
    root.querySelectorAll('[title],[placeholder]').forEach((el) => {
      if (i18nSkipped(el)) return;
      ['title', 'placeholder'].forEach((a) => {
        const v = el.getAttribute(a);
        if (!v) return;
        const t = i18nLookup(v.trim());
        if (t) el.setAttribute(a, t);
      });
    });
  }
}

/* 代码里拼字符串用的翻译助手：词典命中（含通配符模板）就返回译文，否则原样返回。
   用于「来源：」「当前来源：」这类前缀片段与 pip / bash 帮助的固定段落。 */
function tr(s) {
  if (!I18N.dict || !s) return s;
  return i18nLookup(s) || s;
}

/* 动态内容的增量翻译：DOM 变更先攒起来，50ms 防抖后对新节点各扫一遍。
   自己替换文本也会触发本观察器，但译文不再命中词典 → 不会死循环。 */
function i18nStartObserver() {
  if (I18N.observer || !I18N.dict) return;
  let pending = [];
  let timer = null;
  const flush = () => {
    timer = null;
    const roots = pending;
    pending = [];
    roots.forEach((n) => applyI18n(n.nodeType === 1 ? n : n.parentElement));
  };
  I18N.observer = new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === 'characterData') {
        if (m.target.parentElement && !i18nSkipped(m.target.parentElement)) {
          pending.push(m.target.parentElement);
        }
      } else {
        m.addedNodes.forEach((n) => {
          if (n.nodeType === 1 && !i18nSkipped(n)) pending.push(n);
          else if (n.nodeType === 3 && n.parentElement && !i18nSkipped(n.parentElement)) {
            pending.push(n.parentElement);
          }
        });
      }
    }
    if (pending.length && !timer) timer = setTimeout(flush, 50);
  });
  I18N.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
}

/* 启动加载：GET /api/langs 拿列表与当前语言；不是 zh_cn 时再拉词典并开始翻译。
   失败一律静默保持中文界面（语言包缺失 / 损坏只影响这一项）。 */
async function loadI18n() {
  try {
    const d = await api('GET', '/api/langs');
    I18N.langs = (d && d.langs) || [];
    I18N.lang = (d && d.current) || 'zh_cn';
  } catch (e) { return; }
  if (I18N.lang === 'zh_cn') return;
  try {
    const d2 = await api('GET', '/api/lang?name=' + encodeURIComponent(I18N.lang));
    if (d2 && d2.dict && Object.keys(d2.dict).length) {
      I18N.dict = d2.dict;
      i18nBuildTemplates();
      applyI18n(document);
      i18nStartObserver();
    }
  } catch (e) { /* 语言包读取失败：保持中文界面 */ }
}


function toast(msg, ms) {
  let t = $('_toast');
  if (!t) {
    t = document.createElement('div');
    t.id = '_toast';
    t.style.cssText = 'position:fixed;right:16px;bottom:64px;background:var(--bg3);border:1px solid var(--accent);color:var(--fg);padding:8px 14px;border-radius:8px;z-index:200;font-size:13px;max-width:420px;box-shadow:0 6px 20px var(--shadow-panel)';
    document.body.appendChild(t);
  }
  toastPlace(t);                     // 定位：代码编辑框左下角（左对齐 + 底部对齐）
  t.textContent = msg;
  clearTimeout(t._timer);
  t.style.display = 'block';
  t._timer = setTimeout(() => { t.style.display = 'none'; }, ms || 2600);
}

/* 提示悬浮框的定位：贴在**代码编辑框**（#editorBox）的左下角 ——
   左边缘与编辑框左侧对齐（内缩 12px），底边与编辑框底边对齐（内缩 8px，
   与右下角字号条的 bottom 一致），宽度不超过编辑框宽度。
   编辑框不可用时退回默认的屏幕左下角。
   窗口尺寸变化时若正显示着，跟着重新定位。 */
function toastPlace(t) {
  if (!t) return;
  const box = $('editorBox');
  const br = (box && box.getBoundingClientRect) ? box.getBoundingClientRect() : null;
  const hasEd = !!(br && br.width > 1 && br.height > 1);
  const left = hasEd ? Math.round(br.left) + 12 : 16;
  const bottom = hasEd ? Math.round(window.innerHeight - br.bottom) + 8 : 64;
  const maxW = hasEd ? Math.max(220, Math.min(420, Math.round(br.width) - 24)) : 420;
  t.style.left = left + 'px';
  t.style.right = 'auto';            // 基础样式里带 right:16px，这里要用 left 定位
  t.style.bottom = bottom + 'px';
  t.style.maxWidth = maxW + 'px';
  if (!toastPlace._bound) {          // 只绑一次：窗口变化时把还在显示的提示挪回原位
    toastPlace._bound = true;
    window.addEventListener('resize', () => {
      const el = $('_toast');
      if (el && el.style.display === 'block') toastPlace(el);
    });
  }
}

function clsOf(kind) {
  return { error: 'cl-err', warning: 'cl-warn', ok: 'cl-ok', cmd: 'cl-cmd' }[kind] || 'cl-run';
}

/* 通用模态：表单（支持 input / textarea / select / radio）
   第 4 个参数 extraButtons：**关闭按钮右侧**的追加按钮，用于「删除工程」这类
   顺手就能点、但后果很重的动作 —— [{ text, className, title, danger, onClick(hide) }]。
   排在「✗ 关闭」右边（一组靠左），「确定」仍留在最右：危险动作不与「确定/保存」挤在一起。
   onClick 里干完活自己调 hide() 关对话框（如删除成功）；不调就留在原地（如确认框里取消）。 */
function modalForm(title, fields, okText, extraButtons) {
  return new Promise((resolve) => {
    setModalWide(false);
    const mask = $('modalMask');
    $('modalHead').textContent = title;
    const body = $('modalBody');
    body.innerHTML = '';
    const values = {};
    fields.forEach((f) => {
      const row = document.createElement('div');
      // full = 整行控件（如控制台「请输入内容」）：左右不写文字，控件占满这一行的可用宽度
      row.className = 'row' + (f.full ? ' rowFull' : '');
      const lab = document.createElement('label');
      lab.textContent = f.label || '';
      row.appendChild(lab);
      if (f.type === 'textarea') {
        const ta = document.createElement('textarea');
        ta.className = f.full ? 'mfFull' : '';
        // 整行文本框的样式走 CSS（.mfFull），这里不写行内样式，免得互相盖住
        ta.style.cssText = f.full ? ''
          : 'flex:1;min-height:110px;background:var(--bg);color:var(--fg);border:1px solid var(--line);border-radius:5px;padding:6px;font:12px/1.5 Consolas,monospace;';
        ta.value = f.value || '';
        row.appendChild(ta);
        values[f.key] = ta;
      } else if (f.type === 'select') {
        const sel = document.createElement('select');
        (f.options || []).forEach((o) => {
          const op = document.createElement('option');
          op.value = o;
          op.textContent = o;
          sel.appendChild(op);
        });
        sel.value = f.value || ((f.options || [])[0] || '');
        row.appendChild(sel);
        values[f.key] = sel;
      } else if (f.type === 'radio') {
        row.classList.add('rowRadio');                 // 选项竖排占满右侧，帮助文字换行到下一行
        const group = document.createElement('div');
        group.className = 'radioGroup';
        const holder = document.createElement('input');
        holder.type = 'hidden';
        const opts = (f.options || []).map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
        holder.value = f.value || ((opts[0] && opts[0].value) || '');
        opts.forEach((o) => {
          const item = document.createElement('label');
          const r = document.createElement('input');
          r.type = 'radio';
          r.name = 'mf_' + f.key;
          r.value = o.value;
          r.checked = (o.value === holder.value);
          r.onchange = () => { holder.value = o.value; };
          const tx = document.createElement('span');
          tx.textContent = o.label + (o.help ? ' — ' + o.help : '');
          item.title = o.help || o.label;
          item.appendChild(r);
          item.appendChild(tx);
          group.appendChild(item);
        });
        row.appendChild(group);
        values[f.key] = holder;
      } else {
        const inp = document.createElement('input');
        inp.type = f.type || 'text';
        inp.placeholder = f.placeholder || '';
        inp.value = f.value || '';
        if (f.password) inp.type = 'password';
        row.appendChild(inp);
        values[f.key] = inp;
      }
      if (f.help) {
        const hp = document.createElement('div');
        hp.className = 'help';
        hp.textContent = f.help;
        row.appendChild(hp);
      }
      body.appendChild(row);
    });
    const foot = $('modalFoot');
    foot.innerHTML = '';
    const cancel = document.createElement('button');
    cancel.className = 'btnClose';    // 统一关闭按钮外观（普通文字按钮），并由 CSS 顶到最左
    cancel.title = '关闭对话框（不保存）';
    cancel.textContent = '✗ 关闭';     // 与「环境设置 / 工具链」的关闭按钮同款
    cancel.onclick = () => { mask.classList.add('hidden'); resolve(null); };
    const ok = document.createElement('button');
    ok.textContent = okText || '确定';
    ok.className = 'accent';
    ok.onclick = () => {
      const out = {};
      fields.forEach((f) => { out[f.key] = values[f.key].value; });
      mask.classList.add('hidden');
      resolve(out);
    };
    foot.appendChild(cancel);
    // 追加按钮紧跟「关闭」：把 .btnClose 那条 margin-right:auto 挪到这一组的最后一个上，
    // 于是「关闭 + 追加按钮」整体靠左，后面的「确定」照旧顶到最右。
    let leftLast = cancel;
    (extraButtons || []).forEach((b) => {
      const btn = document.createElement('button');
      btn.className = b.className || (b.danger ? 'btnDanger' : '');
      btn.textContent = b.text || '';
      btn.title = b.title || '';
      const hide = () => { mask.classList.add('hidden'); resolve(null); };
      btn.onclick = () => {
        Promise.resolve(b.onClick(hide)).catch((e) => reportError(String((e && e.message) || e)));
      };
      foot.appendChild(btn);
      leftLast = btn;
    });
    if (leftLast !== cancel) {
      cancel.style.marginRight = '0';
      leftLast.style.marginRight = 'auto';
    }
    foot.appendChild(ok);
    mask.classList.remove('hidden');
    ok.focus();
    // 整行文本框（控制台「请输入内容」）：光标直接落进文本框，弹出来就能输入
    const fk = (fields.find((f) => f.full) || {}).key;
    if (fk && values[fk] && values[fk].focus) values[fk].focus();
  });
}

/* ================= 字体 / 字号选择对话框（都带预览） =================
   设计器与属性面板里的「字体」「字号」栏现在都是「点一下弹选择框」（见 bindFontPickers）：
     · 字体：列出**系统已安装**的字体（服务端 /api/fonts，用 GDI 枚举，中文系统上就是
       「微软雅黑」「宋体」这些本地化族名）；每一项用它自己的字体渲染（行本身即预览），
       下面再配一行大号预览；上面的输入框就是搜索框，写一个列表里没有的名字
       会多出一条「使用「xxx」」——自定义字体名照样能用；
     · 字号：常用字号网格 + 自定义数字，下面一行按选中字号渲染的预览。
   resolve 选中的值；点「✗ 关闭」→ null（调用方保持原值不动）。
   服务端拿不到字体表（非 Windows / 出错）就退回下面这份常用字体表。 */
const FONT_FALLBACK = ['微软雅黑', 'Microsoft YaHei', '宋体', 'SimSun', '新宋体', 'NSimSun',
  '黑体', 'SimHei', '楷体', 'KaiTi', '仿宋', 'FangSong', '等线', 'DengXian',
  'Segoe UI', 'Arial', 'Tahoma', 'Verdana', 'Times New Roman', 'Georgia',
  'Consolas', 'Courier New', 'Cambria', 'Calibri'];
let FONT_LIST = null;                  // 已安装字体（读一次缓存；null = 还没读）
let FONT_LIST_LOADING = null;

function loadFontList() {
  if (FONT_LIST) return Promise.resolve(FONT_LIST);
  if (!FONT_LIST_LOADING) {
    FONT_LIST_LOADING = api('GET', '/api/fonts')
      .then((d) => {
        FONT_LIST = (d && d.fonts && d.fonts.length) ? d.fonts : FONT_FALLBACK.slice();
        return FONT_LIST;
      })
      .catch(() => { FONT_LIST = FONT_FALLBACK.slice(); return FONT_LIST; });
  }
  return FONT_LIST_LOADING;
}

/* 字体名进 CSS 前先去掉引号，避免把 font-family 写坏 */
function cssFontName(s) { return String(s == null ? '' : s).replace(/["'\\;{}]/g, ''); }

/* 字体选择框：resolve 字体族名（可能是空串 = 系统默认）；关闭 → null */
function fontDialog(current, opts) {
  opts = opts || {};
  return new Promise((resolve) => {
    const mask = $('modalMask');
    setModalWide(true);                       // 字体列表宽一点好看
    $('modalHead').textContent = opts.title || '选择字体';
    $('modalBody').innerHTML = ''
      + '<div class="fdlg">'
      + '<input id="fdlgSearch" type="text" placeholder="搜索字体（也可以直接输入字体名，如 思源黑体）">'
      + '<div class="fdlgList" id="fdlgList"><div class="fdlgItem fdlgEmpty">正在读取系统字体…</div></div>'
      + '<div class="fdlgCap">预览</div>'
      + '<div class="fdlgPrev" id="fdlgPrev"></div>'
      + '</div>';
    const foot = $('modalFoot');
    foot.innerHTML = '';
    const cancel = document.createElement('button');
    cancel.className = 'btnClose';
    cancel.title = '关闭对话框（不改动）';
    cancel.textContent = '✗ 关闭';
    const ok = document.createElement('button');
    ok.className = 'accent';
    ok.textContent = '确定';
    foot.appendChild(cancel);
    foot.appendChild(ok);
    mask.classList.remove('hidden');

    const listEl = $('fdlgList'), searchEl = $('fdlgSearch'), prevEl = $('fdlgPrev');
    const sample = opts.sample || '云易中文编程 ABC abc 0123';
    let all = [];
    let sel = String(current == null ? '' : current).trim();

    const paintPrev = () => {
      const f = cssFontName(sel);
      prevEl.style.fontFamily = f ? ('"' + f + '", sans-serif') : '';
      prevEl.textContent = sample + (sel ? '　—　' + sel : '　—　（系统默认字体）');
    };
    const paintList = () => {
      const q = (searchEl.value || '').trim();
      const low = q.toLowerCase();
      const matches = all.filter((n) => !low || n.toLowerCase().indexOf(low) >= 0);
      // 搜索词直接当字体名用（列表里没有它）；有匹配就顺手选中第一条，省得再点一下
      const custom = q && !all.some((n) => n.toLowerCase() === low);
      if (custom) sel = q;
      else if (q && matches.length && matches.indexOf(sel) < 0) sel = matches[0];
      const useRow = custom
        ? '<div class="fdlgItem fdlgUse' + (sel === q ? ' on' : '') + '" data-f="' + escHtml(q)
          + '" style="font-family:\'' + cssFontName(q) + '\'">使用「' + escHtml(q) + '」</div>'
        : '';
      const rows = matches.map((n) => '<div class="fdlgItem' + (n === sel ? ' on' : '')
        + '" data-f="' + escHtml(n) + '" style="font-family:\'' + cssFontName(n) + '\'">'
        + escHtml(n) + '</div>').join('');
      listEl.innerHTML = (useRow + rows) || '<div class="fdlgItem fdlgEmpty">没有匹配的字体</div>';
      listEl.querySelectorAll('.fdlgItem[data-f]').forEach((el) => {
        el.onclick = () => { sel = el.dataset.f; paintList(); };
        el.ondblclick = () => { sel = el.dataset.f; done(); };
      });
      paintPrev();
    };
    const done = () => { mask.classList.add('hidden'); resolve(sel || ''); };
    cancel.onclick = () => { mask.classList.add('hidden'); resolve(null); };
    ok.onclick = done;
    searchEl.oninput = paintList;
    searchEl.focus();

    loadFontList().then((list) => {
      all = list.slice();
      if (sel && !all.some((n) => n.toLowerCase() === sel.toLowerCase())) all.unshift(sel);
      paintList();
      const on = listEl.querySelector('.fdlgItem.on');
      if (on && on.scrollIntoView) on.scrollIntoView({ block: 'center' });
    });
  });
}

/* 字号选择框：resolve 字号（px 数字）；关闭 → null
   opts.preview(px)：每次选中都调用 —— 调用方可以现场把字号应用上去做「真·所见即所得」，
   取消时自己负责还原。 */
const FONT_SIZES = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  22, 24, 26, 28, 30, 32, 36, 40, 44, 48, 54, 60, 72, 96];
function fontSizeDialog(current, opts) {
  opts = opts || {};
  const min = opts.min || 6;
  const max = opts.max || 200;
  return new Promise((resolve) => {
    const mask = $('modalMask');
    setModalWide(false);
    $('modalHead').textContent = opts.title || '选择字号';
    const cur = Math.max(min, Math.min(max, parseInt(current, 10) || opts.def || 14));
    const list = FONT_SIZES.filter((s) => s >= min && s <= max);
    $('modalBody').innerHTML = ''
      + '<div class="fsdlg">'
      + '<div class="fsdlgGrid" id="fsdlgGrid">'
      + (list.map((s) => '<button type="button" data-s="' + s + '">' + s + '</button>').join('')
         || '<div class="fdlgEmpty">在下面直接填一个字号</div>')
      + '</div>'
      + '<div class="dsgRow"><label>字号（px）</label>'
      + '<input id="fsdlgNum" type="number" min="' + min + '" max="' + max + '" value="' + cur + '"></div>'
      + '<div class="fdlgCap">预览</div>'
      + '<div class="fdlgPrev" id="fsdlgPrev"></div>'
      + '</div>';
    const foot = $('modalFoot');
    foot.innerHTML = '';
    const cancel = document.createElement('button');
    cancel.className = 'btnClose';
    cancel.title = '关闭对话框（不改动）';
    cancel.textContent = '✗ 关闭';
    const ok = document.createElement('button');
    ok.className = 'accent';
    ok.textContent = '确定';
    foot.appendChild(cancel);
    foot.appendChild(ok);
    mask.classList.remove('hidden');

    const grid = $('fsdlgGrid'), num = $('fsdlgNum'), prev = $('fsdlgPrev');
    const sample = opts.sample || '云易中文编程 AaBbCc 0123456789';
    let val = cur;
    const paint = () => {
      prev.style.fontSize = val + 'px';
      prev.textContent = sample + '　—　' + val + 'px';
      grid.querySelectorAll('button[data-s]').forEach((b) => {
        b.classList.toggle('on', parseInt(b.dataset.s, 10) === val);
      });
      if (String(val) !== num.value) num.value = val;
      if (opts.preview) opts.preview(val);
    };
    const set = (v) => {
      const n = parseInt(v, 10);
      if (!isFinite(n)) return;                 // 输入中途（空串等）先不处理
      val = Math.max(min, Math.min(max, n));
      paint();
    };
    const done = () => { mask.classList.add('hidden'); resolve(val); };
    grid.querySelectorAll('button[data-s]').forEach((b) => {
      b.onclick = () => set(b.dataset.s);
      b.ondblclick = () => { set(b.dataset.s); done(); };
    });
    num.oninput = () => set(num.value);
    cancel.onclick = () => { mask.classList.add('hidden'); resolve(null); };
    ok.onclick = done;
    paint();
  });
}

/* 把选中的值写回输入框，并按「用户手输」派发 input / change ——
   设计器原有的绑定（写入 DSG / QD、刷新画布预览、自动落盘）照常跑，不用重写一遍 */
function pickerSetValue(el, v) {
  if (!el) return;
  el.value = v;
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

/* 把一个输入框变成「点一下弹选择框」：readonly（值只在弹窗里挑，避免手输出错） */
function makeFontField(el, opts) {
  if (!el) return;
  el.readOnly = true;
  el.classList.add('fpick');
  el.title = opts.title || '点击选择（带预览）';
  el.onclick = async () => {
    const v = opts.kind === 'font'
      ? await fontDialog(el.value, { title: opts.dlgTitle, sample: opts.sample })
      : await fontSizeDialog(el.value, { min: opts.min, max: opts.max, sample: opts.sample,
                                         title: opts.dlgTitle, def: opts.def });
    if (v == null) return;                      // 关闭 → 保持原值
    pickerSetValue(el, opts.kind === 'font' ? v : (opts.fmt ? opts.fmt(v) : String(v)));
  };
}

/* 绑定全 IDE 的字体 / 字号栏（bindAll 里调一次） */
function bindFontPickers() {
  const SAMPLE = '云易中文编程 AaBbCc 0123456789';
  const field = (id, opts) => makeFontField($(id), Object.assign({ sample: SAMPLE }, opts));

  // ① 设计器：窗口「字体」「字号」（Sciter 版 + Qt 版）
  field('dsgWinFont', { kind: 'font', dlgTitle: '选择窗口字体', title: '点击选择字体（带预览）' });
  field('dsgWinFontSize', { kind: 'size', min: 6, max: 72, def: 14,
    dlgTitle: '选择窗口字号', title: '点击选择字号（带预览）' });
  field('qdsgWinFont', { kind: 'font', dlgTitle: '选择窗口字体', title: '点击选择字体（带预览）' });
  field('qdsgWinFontSize', { kind: 'size', min: 6, max: 72, def: 14,
    dlgTitle: '选择窗口字号', title: '点击选择字号（带预览）' });

  // ② 属性面板里的「字号」栏：面板内容是动态重建的 → 事件委托
  //    Sciter 版存的是 CSS 值（"14px"），Qt 版存的是数字
  [['dsgCtlPane', 'px'], ['qdsgCtlPane', '']].forEach((pair) => {
    const pane = $(pair[0]);
    const unit = pair[1];
    if (!pane) return;
    pane.addEventListener('click', async (e) => {
      const el = (e.target && e.target.closest) ? e.target.closest('input[data-k="fontSize"]') : null;
      if (!el || el.dataset.picking) return;
      el.dataset.picking = '1';
      const v = await fontSizeDialog(el.value, { min: 6, max: 200, sample: SAMPLE,
                                                title: '选择字号' });
      delete el.dataset.picking;
      if (v == null) return;
      pickerSetValue(el, unit === 'px' ? (v + 'px') : String(v));
    });
  });

  // ③ IDE 自身字号（编辑器 / 侧栏 / 控制台 / 智能体）：点数字也能弹选择框
  //    选中即现场预览（真·所见即所得），点「关闭」还原
  const idePicker = (labelId, getCur, setCur) => {
    const lab = $(labelId);
    if (!lab) return;
    lab.classList.add('fpickNum');
    lab.title = '点击选择字号（带预览）';
    lab.onclick = async () => {
      const before = getCur();
      const v = await fontSizeDialog(before, { min: 9, max: 32, sample: SAMPLE,
        title: '选择字号（IDE 文字大小）', preview: (px) => setCur(px) });
      if (v == null) setCur(before);            // 取消 → 还原
    };
  };
  idePicker('fontSizeLabel', () => editorFont, (px) => {
    editorFont = px; LINE_H = lineHOf(px); applyEditorFont();
    saveFontPref('editor', FONT_KEY, px);
  });
  idePicker('sideFontSizeLabel', () => sideFont, (px) => {
    sideFont = px; applySideFont();
    saveFontPref('side', SIDE_FONT_KEY, px);
  });
  idePicker('consoleFontSizeLabel', () => conFont, (px) => {
    conFont = px; applyConFont();
    saveFontPref('console', CON_FONT_KEY, px);
  });
  idePicker('aiFontSizeLabel', () => aiFont, (px) => {
    aiFont = px; applyAiFont();
    saveFontPref('ai', AI_FONT_KEY, px);
  });
  idePicker('topFontSizeLabel', () => topFont, (px) => {
    topFont = px; applyTopFont();
    saveFontPref('top', TOP_FONT_KEY, px);
  });
}

function modalInfo(title, text) {
  return new Promise((resolve) => {
    setModalWide(false);
    $('modalHead').textContent = title;
    $('modalBody').innerHTML = '<div style="white-space:pre-wrap">' + escHtml(text) + '</div>';
    const foot = $('modalFoot');
    foot.innerHTML = '';
    const b = document.createElement('button');
    b.className = 'accent';
    b.textContent = '好的';
    b.onclick = () => { $('modalMask').classList.add('hidden'); resolve(true); };
    foot.appendChild(b);
    $('modalMask').classList.remove('hidden');
  });
}

function hideModal() {
  $('modalMask').classList.add('hidden');
  setModalWide(false);
  setModalSize(false);
}

/* 弹窗宽度：环境设置 / 工具链用宽版（底部按钮多），其余对话框保持默认宽度 */
function setModalWide(on) {
  const b = $('modalBox');
  if (b) b.classList.toggle('wide', !!on);
}
/* 「IDE设置」对话框：宽度固定 800、高度自适应内容（配套样式见 style.css 的 .modalBox.setDlg） */
function setModalSize(on) {
  const b = $('modalBox');
  if (b) b.classList.toggle('setDlg', !!on);
}

/* ================= 界面设计器（拖放式创建窗口与控件 → 生成云易代码） =================
   配合 lib\sciter.class：Sciter 的界面就是 HTML/CSS，所以设计器用**同样的标签**渲染预览，
   生成的代码是「界面.新建窗口 + 界面控件.新建控件 + 置位置 + 置样式」，
   布局方式为绝对定位（与 界面控件.置位置 完全一致），所见即所得。
   设计文件（.yydesign，JSON）保存在当前工程根目录，随时可再打开继续改。 */

const DSG_FILE = '界面设计.yydesign';

/* 控件类型改名（旧名仍然完全可用）：
   「输入框」→「编辑框」、「多行文本」→「文本域」。
   老设计文件（.yydesign）与老工程代码里的旧名一律按新名读进来；
   类库（lib\qt.class / lib\sciter.class）与 yysciter.dll 里新旧名都在，老代码照常编译运行。 */
const CTL_ALIAS = { '输入框': '编辑框', '多行文本': '文本域' };
function ctlType(t) { return CTL_ALIAS[String(t || '')] || String(t || ''); }

/* 工具箱：分类 → [类型, 默认宽, 默认高, 默认文本]（类型名与 界面控件.新建控件 的「控件类型」一致） */
const DSG_TYPES = [
  ['文本', [['标签', 100, 24, '标签'], ['编辑框', 180, 28, ''],
            ['密码框', 180, 28, ''], ['文本域', 220, 96, ''], ['富文本', 220, 96, '']]],
  ['选择', [['按钮', 100, 32, '按钮'], ['复选框', 110, 24, '复选框'], ['单选框', 110, 24, '单选框'],
            ['下拉框', 160, 28, '选项一|选项二'], ['列表框', 160, 96, '第一项|第二项'],
            ['滑块', 200, 24, ''], ['微调', 90, 28, '']]],
  ['展示', [['进度条', 200, 20, ''], ['表格', 320, 110, '列一'], ['树', 180, 110, '根节点'],
            ['图片', 120, 90, ''], ['超链接', 160, 24, 'https://example.com'],
            ['画布', 200, 120, ''], ['视频', 200, 120, '']]],
  ['容器', [['分组框', 260, 140, '分组'], ['容器', 240, 140, ''], ['滚动区', 240, 140, ''],
            ['分隔线', 320, 12, '']]],
  ['其它', [['日期', 150, 28, ''], ['时间', 150, 28, ''], ['文件', 220, 28, ''], ['颜色', 60, 28, '']]],
];

/* 设计态（只存当前这次打开的设计；保存到 .yydesign 后可再载入）
   前 6 项是画布 / 控件状态；后面是右侧「窗口」页签里的窗体设置 ——
   每一项都对应 lib\sciter.class 里**真实存在**的窗口接口
   （新建窗口 / 显示 / 隐藏 / 窗口居中 / 最小化 / 最大化 / 全屏 / 置图标，
    背景色·字体·字号走页面 CSS 的 加页面样式）。 */
const DSG = {
  w: 760, h: 520, items: [], sel: '', seq: 0, drag: null,
  title: '我的程序', icon: '',
  center: true, x: '', y: '',
  max: false, min: false, full: false, hide: false,
  top: false, noFrame: false, resizable: true, opacity: '',
  btnMax: true, btnMin: true,            // 标题栏最大化 / 最小化按钮
  bg: '#ffffff', font: 'Microsoft YaHei', fontSize: 14, css: '',
  genVars: true, genLoop: true,
};

function dsgEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
/* 生成云易字符串字面量（lexer 支持 \" \\ \n \t \r \0 转义） */
function dsgStr(s) {
  return '"' + String(s == null ? '' : s)
    .replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, '\\n') + '"';
}
function dsgTypeInfo(type) {
  for (const g of DSG_TYPES) for (const t of g[1]) if (t[0] === type) return t;
  return null;
}
/* 控件本体 HTML（与 tools\yysciter\云易Sciter.cpp 里的模板一致，便于「所见即所得」） */
function dsgInner(it) {
  const x = dsgEsc(it.text);
  const opts = (t) => String(t || '').split('|').filter((s) => s !== '')
    .map((s) => '<option>' + dsgEsc(s) + '</option>').join('');
  switch (it.type) {
    case '按钮': return '<button>' + x + '</button>';
    case '标签': return '<label>' + x + '</label>';
    case '文本': return '<span>' + x + '</span>';      // 已从工具箱隐藏，老设计里的仍照常显示
    case '编辑框': return '<input type="text" value="' + x + '">';
    case '密码框': return '<input type="password" value="' + x + '">';
    case '文本域': return '<textarea>' + x + '</textarea>';
    case '富文本': return '<div class="dsgRich" contenteditable="true">' + x + '</div>';
    case '复选框': return '<label><input type="checkbox">' + x + '</label>';
    case '单选框': return '<label><input type="radio">' + x + '</label>';
    case '下拉框': return '<select>' + opts(it.text) + '</select>';
    case '列表框': return '<select size="6">' + opts(it.text) + '</select>';
    case '进度条': return '<progress max="100" value="0"></progress>';
    case '滑块': return '<input type="range" min="0" max="100" value="0">';
    case '微调': return '<input type="number" value="0">';
    case '表格':
      return '<table><thead><tr><th>' + x + '</th><th>列二</th></tr></thead>'
        + '<tbody><tr><td>张三</td><td>18</td></tr><tr><td>李四</td><td>20</td></tr></tbody></table>';
    case '树': return '<ul><li>' + x + '</li><li>子项</li></ul>';
    case '分组框': return '<fieldset><legend>' + x + '</legend></fieldset>';
    case '容器': case '滚动区': return '<div></div>';
    case '分隔线': return '<hr>';
    case '图片': return '<img alt="（图片）">';
    case '超链接': return '<a href="' + x + '">' + x + '</a>';
    case '日期': return '<input type="date">';
    case '时间': return '<input type="time">';
    case '文件': return '<input type="file">';
    case '颜色': return '<input type="color" value="#3399ff">';
    case '画布': return '<canvas></canvas>';
    case '视频': return '<video></video>';
    default: return '<div></div>';
  }
}
/* 工程文件树（S.tree，选工程时读一次、保存后刷新）里有没有这个文件 */
function treeHasFile(rel) {
  const want = String(rel || '').replace(/\\/g, '/');
  let hit = false;
  const walk = (list) => (list || []).forEach((n) => {
    if (hit || !n) return;
    if (String(n.path || '').replace(/\\/g, '/') === want) { hit = true; return; }
    if (n.children) walk(n.children);
  });
  walk(S.tree);
  return hit;
}

/* 设计态初值快照：打开设计器时当前工程**没有**设计文件 → 重置成这个（免得看到上一个工程的控件） */
const DSG_INIT = Object.assign({}, DSG);
function dsgResetDesign() {
  Object.assign(DSG, DSG_INIT, { items: [], sel: '', seq: 0, drag: null });
  dsgSyncWinPane();
  dsgSelect('');
  DSG_AUTO.last = dsgDesignJson();     // 空设计 = 「已落盘」状态：不白写文件
}

/* ================= 设计自动落盘：颜色等全部设计设置都写进 .yydesign =================
   每个控件的颜色 / 字号 / 圆角 / 边框、窗体的颜色与其它设置都在设计文件里。
   设计一改动就**防抖写盘**，点「保存到工程」与关闭设计器时再立刻补写一次
   （以前靠底部「保存设计」按钮手动写盘，该按钮已移除，现在全自动）。
   · 与上次写入的内容完全一致 → 不写（选中 / 重绘 / 拖动中间态不会白写盘）；
   · 工程里本来没有设计文件、画布也还是空的 → 不建文件（随手打开看看不留垃圾）。 */
const DSG_AUTO = { timer: 0, last: '' };

/* 设计内容（与写盘内容完全一致，两边共用这一个构造） */
function dsgDesignData() {
  return {
    type: 'yunyi-designer', version: 2,
    // 窗体设置全部放在 win 里（version 1 的老文件是扁平的 w/h/title/genLoop，载入时兼容）
    win: {
      w: DSG.w, h: DSG.h, title: DSG.title, icon: DSG.icon,
      center: DSG.center, x: DSG.x, y: DSG.y,
      max: DSG.max, min: DSG.min, full: DSG.full, hide: DSG.hide,
      top: DSG.top, noFrame: DSG.noFrame, resizable: DSG.resizable, opacity: DSG.opacity,
      bg: DSG.bg, font: DSG.font, fontSize: DSG.fontSize, css: DSG.css,
      genVars: DSG.genVars, genLoop: DSG.genLoop,
    },
    items: DSG.items,
  };
}
function dsgDesignJson() { return JSON.stringify(dsgDesignData(), null, 2); }

/* 设计有改动 → 防抖（800ms）后写盘 */
function dsgDesignTouch() {
  clearTimeout(DSG_AUTO.timer);
  DSG_AUTO.timer = setTimeout(dsgDesignFlush, 800);
}
/* 立刻写盘（静默：不弹提示，失败也不打断，下次改动会再写一次） */
async function dsgDesignFlush() {
  clearTimeout(DSG_AUTO.timer);
  if (!S.project) return;
  const json = dsgDesignJson();
  if (json === DSG_AUTO.last) return;                      // 没有真改动
  const had = treeHasFile(DSG_FILE);
  if (!DSG.items.length && !had) return;                   // 空设计 + 还没设计文件 → 不建文件
  DSG_AUTO.last = json;
  try {
    await api('POST', '/api/file', { project: S.project, path: DSG_FILE, content: json });
    if (!had) await refreshTree().catch(() => { });         // 新建的文件：刷新文件树（自动载入要认它）
  } catch (e) { /* 忽略：下次改动会再写一次 */ }
}

/* 该控件的「文本」参数在生成代码里怎么用（提示用） */
function dsgTextLabel(type) {
  if (type === '下拉框' || type === '列表框') return '各项（用 | 分隔）';
  if (type === '表格') return '首列表头';
  if (type === '树') return '首个节点';
  if (type === '分组框') return '标题';
  if (type === '图片') return '图片地址';
  if (type === '超链接') return '网址';
  if (type === '视频') return '视频地址';
  if (type === '文本域') return '初始内容';
  return '文本';
}

function dsgStatus() {
  const el = $('dsgStatus');
  if (el) el.textContent = DSG.items.length + ' 个控件' + (DSG.sel ? '（已选中）' : '');
}

/* 把焦点落到画布（预览窗口）上。
   加 / 删控件后焦点必须留在设计器里 —— 否则会被代码编辑器的 focus() 抢走，
   接着敲方向键 / Delete 就作用在代码上。画布用 tabindex="-1"（只接受程序化聚焦，
   不打扰 Tab 顺序）；方向键微调仍由 document 上的全局监听处理，不依赖这里。 */
function dsgFocusStage(id) {
  const st = $(id);
  if (!st || !st.focus) return;
  try { st.focus({ preventScroll: true }); } catch (e) { st.focus(); }
}

/* 重绘画布（只重画画布，不动右侧属性面板，免得输入时丢焦点）。
   画布一动就说明设计可能变了 → 顺带触发一次设计落盘（内容相同不会真写盘）。 */
function dsgRender() {
  dsgDesignTouch();
  const stage = $('dsgStage');
  if (!stage) return;
  stage.style.width = DSG.w + 'px';
  stage.style.height = DSG.h + 'px';
  stage.innerHTML = '';
  if (!DSG.items.length) {
    const tip = document.createElement('div');
    tip.className = 'dsgEmpty';
    tip.textContent = '把左边的控件拖到这里（也可以单击工具箱里的控件）';
    stage.appendChild(tip);
  }
  DSG.items.forEach((it) => {
    const box = document.createElement('div');
    box.className = 'dsgItem' + (DSG.sel === it.id ? ' sel' : '');
    box.dataset.id = it.id;
    box.style.cssText = 'left:' + it.x + 'px;top:' + it.y + 'px;width:' + it.w
      + 'px;height:' + it.h + 'px';
    box.innerHTML = dsgInner(it);
    const inner = box.firstElementChild;
    if (inner) {
      // 样式施加在控件本体上（与生成的 界面控件.置样式 目标一致）
      inner.style.cssText += ';width:100%;height:100%;box-sizing:border-box;margin:0;';
      if (it.color) inner.style.color = it.color;
      if (it.bg) inner.style.background = it.bg;
      if (it.fontSize) inner.style.fontSize = it.fontSize;
      if (it.radius) inner.style.borderRadius = it.radius;
      if (it.border) inner.style.border = it.border;
    }
    if (DSG.sel === it.id) {
      const h = document.createElement('i');
      h.className = 'dsgHandle';
      h.dataset.handle = '1';
      box.appendChild(h);
    }
    stage.appendChild(box);
  });
  dsgStatus();
}

/* ---------- 右侧「窗口 / 控件」页签 ---------- */
function dsgShowTab(which) {
  const win = which !== 'ctl';
  const tw = $('dsgTabWin'), tc = $('dsgTabCtl');
  if (tw) tw.classList.toggle('on', win);
  if (tc) tc.classList.toggle('on', !win);
  if ($('dsgWinPane')) $('dsgWinPane').classList.toggle('hidden', !win);
  if ($('dsgCtlPane')) $('dsgCtlPane').classList.toggle('hidden', win);
}

/* 判断颜色深浅（决定画布上的文字/描边/网格线用深色还是浅色） */
function dsgIsDark(col) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(col || '').trim());
  if (!m) return false;
  const n = parseInt(m[1], 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  // 相对亮度（sRGB 近似）：< 128 认为是深底
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 128;
}

/* 把颜色写法规整成 "#rrggbb"（原生取色器只认这个格式）：
   认 #abc / #aabbcc / aabbcc；"red"、空串等认不出的返回 ''（此时不动取色器）。 */
function dsgHexOf(v) {
  const s = String(v == null ? '' : v).trim();
  let m = /^#([0-9a-f]{3})$/i.exec(s) || /^([0-9a-f]{3})$/i.exec(s);
  if (m) {
    const c = m[1];
    return ('#' + c[0] + c[0] + c[1] + c[1] + c[2] + c[2]).toLowerCase();
  }
  m = /^#([0-9a-f]{6})$/i.exec(s) || /^([0-9a-f]{6})$/i.exec(s);
  return m ? ('#' + m[1]).toLowerCase() : '';
}

/* 颜色行：**上面一个原生取色器 + 下面一个颜色编辑框**（两套设计器的所有颜色设置都用它）。
   · 取色器选色 → 自动填进下面那个编辑框；
   · 编辑框里写了合法颜色 → 取色器跟着变（写别的写法也不拦，照原样交给生成代码）。
   取色器带 data-c="字段名"、编辑框带 data-k="字段名"（沿用属性面板已有的 [data-k] 绑定）。 */
function dsgColorRow(label, key, value, placeholder, pickDefault) {
  const v = String(value == null ? '' : value).trim();
  const pick = dsgHexOf(v) || (pickDefault || '#ffffff');
  return '<div class="dsgRow dsgRowTop"><label>' + label + '</label>'
    + '<div class="dsgColorBox">'
    + '<input type="color" data-c="' + key + '" value="' + pick + '">'
    + '<input type="text" data-k="' + key + '" value="' + dsgEsc(v) + '" placeholder="'
    + (placeholder || '#ffffff') + '">'
    + '</div></div>';
}

/* 把「窗口属性」里的 背景色 / 字体 / 字号 立刻反映到画布上（所见即所得）。
   改一下马上变，不用关掉设计器再打开；底色选了深的，
   同时把文字/描边/网格线/表头翻成浅色，否则又会变成「深字压深底」看不清。 */
function dsgApplyWinPreview() {
  dsgDesignTouch();                     // 窗体外观变了 → 设计要落盘
  const st = $('dsgStage');
  if (!st) return;
  const bg = DSG.bg || '#ffffff';
  const dark = dsgIsDark(bg);
  st.style.setProperty('--cv-bg', bg);
  st.style.setProperty('--cv-fg', dark ? '#e9edf4' : '#1f2430');
  st.style.setProperty('--cv-line', dark ? 'rgba(255,255,255,.38)' : '#c2c9d6');
  st.style.setProperty('--cv-grid', dark ? 'rgba(255,255,255,.10)' : '#eef1f6');
  st.style.setProperty('--cv-th', dark ? 'rgba(255,255,255,.12)' : '#eef1f6');
  st.style.setProperty('--cv-dim', dark ? 'rgba(255,255,255,.55)' : '#6b7484');
  st.style.fontFamily = DSG.font ? ("'" + DSG.font + "', sans-serif") : '';
  st.style.fontSize = DSG.fontSize ? (DSG.fontSize + 'px') : '';
}

/* 「窗口」页签：把表单和 DSG 绑起来（只绑一次，在 openDesigner 里调用）。
   窗口属性面板是 index.html 里的静态结构，不用 innerHTML 重建 ——
   这样输入时 DOM 不重建、不会丢焦点。 */
function dsgBindWinPane() {
  const txt = (id, k, after) => {
    const el = $(id);
    if (el) el.oninput = () => { DSG[k] = el.value; if (after) after(); dsgDesignTouch(); };
  };
  const num = (id, k, min, max, after) => {
    const el = $(id);
    if (!el) return;
    el.oninput = () => {
      const v = parseInt(el.value, 10);
      if (!isFinite(v)) return;                 // 输入中途（空串等）先不处理
      DSG[k] = Math.max(min, Math.min(max, v));
      if (after) after();
      dsgDesignTouch();
    };
  };
  /* 可选数字：清空就存 ''（表示「不设置」→ 不生成那行代码），否则按区间夹住 */
  const opt = (id, k, min, max) => {
    const el = $(id);
    if (!el) return;
    el.oninput = () => {
      const t = el.value.trim();
      if (t === '') { DSG[k] = ''; dsgDesignTouch(); return; }
      const v = parseInt(t, 10);
      DSG[k] = isFinite(v) ? Math.max(min, Math.min(max, v)) : '';
      dsgDesignTouch();
    };
  };
  const chk = (id, k) => {
    const el = $(id);
    if (el) el.onchange = () => { DSG[k] = el.checked; dsgDesignTouch(); };
  };
  txt('dsgWinTitle', 'title');
  txt('dsgWinIcon', 'icon');
  txt('dsgWinFont', 'font', dsgApplyWinPreview);        // 字体：立即生效
  txt('dsgWinCss', 'css');                              // 额外 CSS 只写进生成代码（不注入本页，避免影响 IDE 自身）
  num('dsgWinW', 'w', 120, 4000, dsgRender);            // 宽高：立即改画布尺寸
  num('dsgWinH', 'h', 120, 4000, dsgRender);
  num('dsgWinFontSize', 'fontSize', 6, 72, dsgApplyWinPreview);   // 字号：立即生效
  opt('dsgWinX', 'x', -20000, 20000);
  opt('dsgWinY', 'y', -20000, 20000);
  opt('dsgWinOpacity', 'opacity', 0, 100);
  // 背景色：取色器（上）+ 颜色编辑框（下），两者写同一个 DSG.bg；改动立刻反映到画布
  const bgPick = $('dsgWinBg'), bgHex = $('dsgWinBgHex');
  const applyWinBg = (v) => {
    DSG.bg = String(v == null ? '' : v).trim() || '#ffffff';
    dsgApplyWinPreview();
  };
  if (bgPick) bgPick.oninput = () => {
    if (bgHex) bgHex.value = bgPick.value;        // 取色器选色 → 自动填进颜色编辑框
    applyWinBg(bgPick.value);
  };
  if (bgHex) bgHex.oninput = () => {
    const hex = dsgHexOf(bgHex.value);
    if (hex && bgPick) bgPick.value = hex;        // 编辑框里写了合法色值 → 取色器跟着变
    applyWinBg(bgHex.value);
  };
  chk('dsgWinCenter', 'center'); chk('dsgWinMax', 'max'); chk('dsgWinMin', 'min');
  chk('dsgWinFull', 'full'); chk('dsgWinHide', 'hide');
  chk('dsgWinTop', 'top'); chk('dsgWinNoFrame', 'noFrame');
  chk('dsgWinResizable', 'resizable');
  chk('dsgWinBtnMax', 'btnMax'); chk('dsgWinBtnMin', 'btnMin');
  chk('dsgGenVars', 'genVars'); chk('dsgGenLoop', 'genLoop');
  if ($('dsgTabWin')) $('dsgTabWin').onclick = () => dsgShowTab('win');
  if ($('dsgTabCtl')) $('dsgTabCtl').onclick = () => dsgShowTab('ctl');
  dsgSyncWinPane();
}
/* 把 DSG 里的窗口设置写回表单（打开设计器 / 载入设计后调用），并刷新画布外观 */
function dsgSyncWinPane() {
  const set = (id, v) => { const el = $(id); if (el) el.value = (v == null ? '' : v); };
  const chk = (id, v) => { const el = $(id); if (el) el.checked = !!v; };
  set('dsgWinTitle', DSG.title); set('dsgWinW', DSG.w); set('dsgWinH', DSG.h);
  set('dsgWinIcon', DSG.icon);
  set('dsgWinX', DSG.x); set('dsgWinY', DSG.y);
  set('dsgWinOpacity', DSG.opacity);
  set('dsgWinBg', DSG.bg || '#ffffff');
  set('dsgWinBgHex', DSG.bg || '#ffffff');
  set('dsgWinFont', DSG.font);
  set('dsgWinFontSize', DSG.fontSize); set('dsgWinCss', DSG.css);
  chk('dsgWinCenter', DSG.center); chk('dsgWinMax', DSG.max); chk('dsgWinMin', DSG.min);
  chk('dsgWinFull', DSG.full); chk('dsgWinHide', DSG.hide);
  chk('dsgWinTop', DSG.top); chk('dsgWinNoFrame', DSG.noFrame);
  chk('dsgWinResizable', DSG.resizable);
  chk('dsgWinBtnMax', DSG.btnMax); chk('dsgWinBtnMin', DSG.btnMin);
  chk('dsgGenVars', DSG.genVars); chk('dsgGenLoop', DSG.genLoop);
  dsgApplyWinPreview();          // 打开设计器 / 载入设计后，画布外观也要跟上
}

/* 右侧「控件」页签（由 dsgRenderProps 填充） */
function dsgRenderProps() {
  const box = $('dsgCtlPane');
  if (!box) return;
  const it = DSG.items.find((x) => x.id === DSG.sel);
  if (!it) {
    box.innerHTML = '<div class="dsgTip">先在画布上选中一个控件，这里会列出它的属性。<br><br>'
      + '常用操作：<br>· 拖动 = 移动<br>· 右下角小方块 = 缩放<br>'
      + '· 方向键 = 微调 1px（按住 Shift = 10px）<br>· Delete = 删除<br>'
      + '· 点画布空白处 = 切回「窗口」设置</div>';
    return;
  }
  const row = (label, key, type, extra) => {
    const v = type === 'number' ? it[key] : (it[key] || '');
    return '<div class="dsgRow"><label>' + label + '</label>'
      + '<input data-k="' + key + '" type="' + (type || 'text') + '" value="' + dsgEsc(v) + '"'
      + (extra || '') + '></div>';
  };
  let h = '<div class="dsgPTitle">属性 · ' + dsgEsc(it.type) + ' <span class="dsgCode">'
    + dsgEsc(it.name) + '</span></div>';
  h += row('名称', 'name');
  h += '<div class="dsgRow"><label>' + dsgTextLabel(it.type) + '</label>'
    + '<input data-k="text" type="text" value="' + dsgEsc(it.text) + '"></div>';
  h += row('横', 'x', 'number') + row('纵', 'y', 'number');
  h += row('宽', 'w', 'number') + row('高', 'h', 'number');
  h += row('字号', 'fontSize', 'text', ' readonly class="fpick" title="点击选择字号（带预览）" placeholder="14px"');
  h += dsgColorRow('文字色', 'color', it.color, '#333333', '#333333');
  h += dsgColorRow('背景色', 'bg', it.bg, '#ffffff', '#ffffff');
  h += row('圆角', 'radius', 'text', ' placeholder="4px"');
  h += row('边框', 'border', 'text', ' placeholder="1px solid #cccccc"');
  h += '<div class="dsgTip" style="margin-top:10px">生成的行：<br><span class="dsgCode">'
    + dsgEsc('界面控件.新建控件(主窗, ' + dsgStr(it.type) + ', ' + dsgStr(it.name) + ')')
    + '</span></div>';
  box.innerHTML = h;
  /* 写入一个设计字段（属性面板的编辑框与取色器共用同一套赋值 + 重绘） */
  const setKey = (k, val) => {
    const cur = DSG.items.find((x) => x.id === DSG.sel);
    if (!cur) return;
    if (k === 'x' || k === 'y' || k === 'w' || k === 'h') {
      cur[k] = parseInt(val, 10) || 0;
      if (cur.w < 8) cur.w = 8;
      if (cur.h < 8) cur.h = 8;
    } else if (k === 'text') {
      cur.text = String(val);
    } else {
      cur[k] = String(val == null ? '' : val).trim();
    }
    dsgRender();                       // 只重画画布，属性面板保持焦点
    // 属性改动**不**即时写代码：等点「保存到工程」时统一写回（与窗口设置、拖动一致）
    if (k === 'name') {
      const code = box.querySelector('.dsgCode');
      if (code) {
        code.textContent = '界面控件.新建控件(主窗, ' + dsgStr(cur.type) + ', ' + dsgStr(cur.name) + ')';
      }
    }
  };
  box.querySelectorAll('input[data-k]').forEach((inp) => {
    const k = inp.dataset.k;
    inp.oninput = () => {
      setKey(k, inp.value);
      // 颜色编辑框里写了合法颜色 → 同一行的取色器跟着变
      const pick = box.querySelector('input[data-c="' + k + '"]');
      if (pick) { const hex = dsgHexOf(inp.value); if (hex) pick.value = hex; }
    };
  });
  // 取色器：选色 → 自动填进下面那个颜色编辑框（并同步设计字段）
  box.querySelectorAll('input[data-c]').forEach((pick) => {
    pick.oninput = () => {
      const k = pick.dataset.c;
      const tx = box.querySelector('input[data-k="' + k + '"]');
      if (tx) tx.value = pick.value;
      setKey(k, pick.value);
    };
  });
}

function dsgSelect(id) {
  DSG.sel = id || '';
  dsgShowTab(id ? 'ctl' : 'win');       // 选中控件 → 「控件」页签；点空白 → 回「窗口」
  dsgRender();
  dsgRenderProps();
}
function dsgNextName(type) {
  let n = 0;
  const used = new Set(DSG.items.map((x) => x.name));
  do { n++; } while (used.has(type + n));
  return type + n;
}
/* 新控件：不给坐标时放到画布中间并逐个错开，免得叠在一起 */
function dsgAdd(type, x, y) {
  const info = dsgTypeInfo(type) || [type, 120, 30, ''];
  DSG.seq = (DSG.seq || 0) + 1;
  const off = (DSG.items.length % 8) * 14;
  const it = {
    id: 'w' + Date.now() + '_' + DSG.seq,
    type,
    name: dsgNextName(type),
    text: info[3] || '',
    w: info[1], h: info[2],
    x: (typeof x === 'number') ? Math.max(0, Math.round(x)) : 20 + off,
    y: (typeof y === 'number') ? Math.max(0, Math.round(y)) : 20 + off,
    fontSize: '', color: '', bg: '', radius: '', border: '',
  };
  DSG.items.push(it);
  dsgSelect(it.id);
  dsgSyncSchedule('sciter');            // 加控件 → 代码同步加一行
  dsgFocusStage('dsgStage');            // 焦点留在画布上，别被代码编辑器抢走
  return it;
}
function dsgDelete() {
  if (!DSG.sel) { toast('先在画布上选中一个控件'); return; }
  DSG.items = DSG.items.filter((x) => x.id !== DSG.sel);
  dsgSelect('');
  // 删控件只在画布（预览）上生效，**不即时写代码** —— 要写进代码请点「保存到工程」
  dsgFocusStage('dsgStage');
}
function dsgClear() {
  if (!DSG.items.length) return;
  if (!confirm('清空画布上的全部控件？')) return;
  DSG.items = [];
  dsgSelect('');
  // 清空同理：只在画布上生效，点「保存到工程」时才写回代码
  dsgFocusStage('dsgStage');
}
function dsgNudge(dx, dy) {
  const it = DSG.items.find((x) => x.id === DSG.sel);
  if (!it) return;
  it.x = Math.max(0, it.x + dx);
  it.y = Math.max(0, it.y + dy);
  dsgRender();
  dsgRenderProps();
  // 位置属于「属性」：不即时写代码，点「保存到工程」时统一写回
}

/* ---------- 生成云易代码 ---------- */
function dsgGenerate() {
  const L = [];
  const title = (DSG.title || '').trim() || '我的程序';
  const genVars = DSG.genVars !== false;
  const genLoop = DSG.genLoop !== false;
  L.push("' ══════════ 由「界面设计」生成 ══════════");
  L.push("' 界面库：lib\\sciter.class（侧栏「UI → sciter」栏）；运行前把 yysciter.dll + sciter.dll");
  L.push("' 拷到 exe 同目录：tools\\yysciter\\复制运行库.bat \"工程目录\\build\\debug\"");
  L.push('');
  if (genVars) {
    L.push('变量 整数型 主窗');
    L.push('变量 文本型 命中');
    if (genLoop) L.push('变量 整数型 事件类型');
    L.push('');
  }
  L.push('主窗 = 界面.新建窗口(' + dsgStr(title) + ', ' + DSG.w + ', ' + DSG.h + ')');
  // body 样式：margin/position 必须留着（控件是绝对定位的），其余按「窗口属性」里的设置拼
  const bodyCss = ['margin:0', 'position:relative'];
  if (DSG.bg) bodyCss.push('background:' + DSG.bg);
  if (DSG.font) bodyCss.push("font-family:'" + DSG.font + "',sans-serif");
  if (DSG.fontSize) bodyCss.push('font-size:' + DSG.fontSize + 'px');
  L.push('界面.加页面样式(主窗, ' + dsgStr('body{' + bodyCss.join(';') + '}') + ')');
  if ((DSG.css || '').trim()) {
    L.push('界面.加页面样式(主窗, ' + dsgStr(DSG.css.trim()) + ')');
  }
  if ((DSG.icon || '').trim()) {
    L.push('界面.置图标(主窗, ' + dsgStr(DSG.icon.trim()) + ')');
  }
  DSG.items.forEach((it) => {
    L.push('');
    L.push('界面控件.新建控件(主窗, ' + dsgStr(it.type) + ', ' + dsgStr(it.name) + ', '
      + dsgStr(it.text) + ')');
    L.push('界面控件.置位置(主窗, ' + dsgStr(it.name) + ', ' + it.x + ', ' + it.y
      + ', ' + it.w + ', ' + it.h + ')');
    if (it.fontSize) L.push('界面控件.置样式(主窗, ' + dsgStr(it.name) + ', "font-size", ' + dsgStr(it.fontSize) + ')');
    if (it.color) L.push('界面控件.置样式(主窗, ' + dsgStr(it.name) + ', "color", ' + dsgStr(it.color) + ')');
    if (it.bg) L.push('界面控件.置样式(主窗, ' + dsgStr(it.name) + ', "background", ' + dsgStr(it.bg) + ')');
    if (it.radius) L.push('界面控件.置样式(主窗, ' + dsgStr(it.name) + ', "border-radius", ' + dsgStr(it.radius) + ')');
    if (it.border) L.push('界面控件.置样式(主窗, ' + dsgStr(it.name) + ', "border", ' + dsgStr(it.border) + ')');
    if ((it.type === '下拉框' || it.type === '列表框')
      && (it.text || '').indexOf('|') >= 0) {
      L.push('界面控件.加多项(主窗, ' + dsgStr(it.name) + ', ' + dsgStr(it.text) + ')');
    }
    if (it.type === '表格') {
      L.push('界面控件.表格加列(主窗, ' + dsgStr(it.name) + ', "列二")');
    }
  });
  // 窗口收尾：位置 → 居中 → 行为 → 显示（或按设置先隐藏）→ 最大化 / 最小化 / 全屏。
  // 特意放在 genLoop 之外：就算不生成主循环骨架，这些窗口设置也必须生成。
  L.push('');
  if (DSG.x !== '' || DSG.y !== '') {
    L.push('界面.置位置(主窗, ' + (DSG.x === '' ? 0 : DSG.x) + ', '
      + (DSG.y === '' ? 0 : DSG.y) + ')');
  }
  if (DSG.center) L.push('界面.窗口居中(主窗)');
  if (DSG.top) L.push('界面.置置顶(主窗, 1)');
  if (DSG.noFrame) L.push('界面.置无边框(主窗, 1)');
  if (DSG.resizable === false) L.push('界面.置可调边框(主窗, 0)');
  if (DSG.btnMax === false) L.push('界面.置最大化按钮(主窗, 0)');
  if (DSG.btnMin === false) L.push('界面.置最小化按钮(主窗, 0)');
  if (DSG.opacity !== '' && parseInt(DSG.opacity, 10) !== 100) {
    L.push('界面.置透明度(主窗, ' + DSG.opacity + ')');
  }
  if (DSG.hide) {
    L.push("界面.隐藏(主窗)          ' 按窗口设置：先不显示，需要时自己调 界面.显示(主窗)");
  } else {
    L.push('界面.显示(主窗)');
  }
  if (DSG.max) L.push('界面.最大化(主窗)');
  if (DSG.min) L.push('界面.最小化(主窗)');
  if (DSG.full) L.push('界面.全屏(主窗)');

  if (genLoop) {
    const hot = DSG.items.filter((x) => ['按钮', '复选框', '单选框', '下拉框', '列表框',
      '编辑框', '文本域', '超链接', '滑块', '微调'].indexOf(x.type) >= 0);
    L.push('');
    L.push('当循环 界面.窗口可见(主窗) != 0');
    L.push('    界面.处理事件()');
    L.push('    命中 = 界面.取事件(主窗)');
    L.push('    如果 (命中 != "")');
    L.push('        事件类型 = 界面.事件类型()');
    L.push("        ' 事件类型：1 点击 2 文本改变 3 值改变 4 选中改变 5 窗口关闭");
    L.push("        '          6 按键 10 回车 11 勾选改变；附带内容用 界面.事件文本()");
    if (hot.length) {
      L.push("        ' 可用的控件名（按「命中」分发）：");
      hot.forEach((it) => {
        L.push("        '   " + it.name + '（' + it.type + '）'
          + '  →  如果 (命中 = ' + dsgStr(it.name) + ') … 结束如果');
      });
    }
    L.push('    结束如果');
    L.push('    延时(10)');
    L.push('结束循环');
  }
  L.push('');
  return L.join('\n');
}

/* ========================= 界面段的识别（Sciter / Qt 共用这一套） =========================
   保存到工程 = 把源码里那段「界面代码」换掉，难点全在「哪几行算这一段」：

   · 起点：生成标记那行 → 「主窗 = 界面.新建窗口(…)」（Qt：主窗 = 窗口.新建(…)）
     → 老规则（第一句界面构建语句）—— 给没有标记、也不是主窗赋值写法的手写代码兜底；
   · 终点：向下扫到**顶层结构边界**（子程序 / 结束子程序 / 类 / 数据类型 …）为止 ——
     中间的空行、注释、你自己写的语句、主循环都算段内；最后再回退到最后一句**生成行**，
     于是段尾的用户行（注释 / `返回 (0)` …）让出去、一行不动；
   · 段内分两类：**生成行**（设计器会生成的语句，白名单见 DSG_GEN_LINE，会被新设计替换掉）
     与**用户行**（你自己写的变量声明 / 开定时器 / `计数 = 0` / 主循环整段 …，**原样保留**）。

   老实现为什么「有时候检查会失败」：它碰到段内任何一句「别的代码」就收段 —— 比如你在生成标记
   下面接着写 `变量 文本型 提示行`，段就只剩开头那几行变量声明，保存时在下面又插一份完整的界面
   代码，于是同一份源码里出现两套窗口与控件；手写工程（没有生成标记）还会把子程序里的
   `界面控件.置文本(…)` 当成段起点。现在这两类都不会再发生。 */

const DSG_MARK_SCITER = '由「界面设计」生成';
const DSG_MARK_QT = '由「Qt 界面设计」生成';

/* 段内「生成行」白名单（kind → 正则表）：只有这些行算设计器生成的，会被新设计替换掉 */
const DSG_GEN_LINE = {
  sciter: [
    /^变量[ \t]+(整数型|文本型)[ \t]+(主窗|命中|事件类型)[ \t]*$/,
    /^主窗[ \t]*=[ \t]*界面\.新建窗口[ \t]*\(/,
    /^界面\.(加页面样式|置图标|置位置|窗口居中|置置顶|置无边框|置可调边框|置最大化按钮|置最小化按钮|置透明度|显示|隐藏|最大化|最小化|全屏)[ \t]*\(/,
    /^界面控件\.(新建控件|新建控件到|置位置|置样式|加多项|表格加列)[ \t]*\(/,
  ],
  qt: [
    /^主窗[ \t]*=[ \t]*窗口\.新建[ \t]*\(/,
    /^窗口\.(置样式|置字体|置底色|置字色|置图标|置大小限制|置位置|居中|置置顶|置无边框|置可调边框|置最大化按钮|置最小化按钮|置透明度|显示|隐藏|最大化|最小化|全屏)[ \t]*\(/,
    /^控件\.(置位置|置字体|置字色|置底色|置样式|置提示)[ \t]*\(/,
    /^(编辑框|文本域)\.置文本[ \t]*\(/,
    /^编辑框\.置密码[ \t]*\(/,
    /^(复选框|单选框)\.置选中[ \t]*\(/,
    /^(下拉框|列表框)\.加多项[ \t]*\(/,
    /^(表格|树)\.置表头[ \t]*\(/,
    /^选项卡\.加页[ \t]*\(/,
    /^(进度条|滑块|微调)\.置范围[ \t]*\(/,
    /^分隔线\.新建(竖线)?[ \t]*\(/,
    /^图片\.新建[ \t]*\(/,
    /^链接\.新建[ \t]*\(/,
    /^容器\.新建[ \t]*\(/,
  ],
};
/* 设计器生成的注释行（生成标记与紧跟的说明；选项卡那几行页注释也是），一并替换掉 */
const DSG_GEN_NOTE = /(由「(Qt )?界面设计」生成|界面库：lib\\sciter\.class|控件库：lib\\qt\.class|拷到 exe 同目录：|运行前把 云易Qt\.dll|tools\\yyqt\\复制运行库\.bat|要求：窗口程序；架构|第 [0-9]+ 页：先建一个容器当页面)/;

/* 这一行是不是「生成行」。names = Qt 的控件变量名集合（Sciter 用不到） */
function dsgIsGenLine(raw, kind, names) {
  const s = String(raw == null ? '' : raw).trim();
  if (!s) return true;                                       // 空行：排版用的，跟着一起清掉
  if (s.charAt(0) === "'") return DSG_GEN_NOTE.test(s);
  const re = DSG_GEN_LINE[kind === 'qt' ? 'qt' : 'sciter'];
  for (let i = 0; i < re.length; i++) if (re[i].test(s)) return true;
  if (kind === 'qt') {
    if (/^[\w\u4e00-\u9fa5]+[ \t]*=[ \t]*[\w\u4e00-\u9fa5]+\.[^\s(]+[ \t]*\(主窗/.test(s)) {
      return true;                                           // 按钮1 = 按钮.新建(主窗, "…")
    }
    const m = /^变量[ \t]+整数型[ \t]+([\w\u4e00-\u9fa5]+)[ \t]*$/.exec(s);
    if (m && (m[1] === '主窗' || m[1] === '命中' || m[1] === '事件类型'
      || (names && names.has(m[1])))) return true;           // 每个控件（含选项卡页面容器）都会声明一个整数
  }
  return false;
}

/* 块结构配平：+1 进入一层 / -1 退出一层 / 0 无关（否则如果 / 否则 不算层） */
const DSG_OPEN_KW = ['当循环', '计次循环', '判断循环首', '循环判断首', '如果', '如果真'];
const DSG_CLOSE_KW = ['结束循环', '判断循环尾', '循环判断尾', '结束如果', '结束如果真'];
function dsgBlockDelta(s) {
  for (let i = 0; i < DSG_CLOSE_KW.length; i++) if (s.startsWith(DSG_CLOSE_KW[i])) return -1;
  for (let i = 0; i < DSG_OPEN_KW.length; i++) if (s.startsWith(DSG_OPEN_KW[i])) return 1;
  return 0;
}
/* 主循环的开头（这类行往下的整段算一段「块」） */
function dsgIsLoopStart(s) {
  return s.startsWith('当循环') || s.startsWith('计次循环')
    || s.startsWith('判断循环首') || s.startsWith('循环判断首');
}
/* 顶层结构边界：界面段到这里为止（段外代码一行不动） */
const DSG_EDGE_KW = ['结束子程序', '结束测试函数', '结束数据类型', '结束类函数', '导出子程序',
  '子程序', '测试函数', '数据类型', '类函数', 'API', '常量', '全局变量', '导出'];
function dsgIsEdge(s) {
  for (let i = 0; i < DSG_EDGE_KW.length; i++) if (s.startsWith(DSG_EDGE_KW[i])) return true;
  return false;
}
/* 段的可靠起点：主窗赋值（Sciter / Qt 各一种写法） */
function dsgAnchorRe(kind) {
  return kind === 'qt' ? /^主窗[ \t]*=[ \t]*窗口\.新建[ \t]*\(/
    : /^主窗[ \t]*=[ \t]*界面\.新建窗口[ \t]*\(/;
}
/* 源码里是否已经有界面主循环（有就不再生成一份新的，免得两个循环并存）。
   带 m：既能对整份源码 test，也能对单行 test */
function dsgLoopRe(kind) {
  return kind === 'qt' ? /^[ \t]*当循环[ \t]*\(?[ \t]*窗口\.可见[ \t]*\(主窗\)/m
    : /^[ \t]*当循环[ \t]*\(?[ \t]*界面\.窗口可见[ \t]*\(主窗\)/m;
}
/* Qt 的控件变量名（`按钮1 = 按钮.新建(主窗, …)` 里的 按钮1），判定「变量 整数型 按钮1」用 */
function dsgQtCtlNames(lines, kind) {
  const set = new Set();
  if (kind !== 'qt') return set;
  for (let i = 0; i < lines.length; i++) {
    const m = /^([\w\u4e00-\u9fa5]+)[ \t]*=[ \t]*[\w\u4e00-\u9fa5]+\.[^\s(]+[ \t]*\(主窗/
      .exec(String(lines[i] || '').trim());
    if (m) set.add(m[1]);
  }
  return set;
}
/* 源码里第一个主循环整段（补变量声明时看它用到哪些变量） */
function dsgFileLoopText(lines, kind) {
  const re = dsgLoopRe(kind);
  for (let i = 0; i < lines.length; i++) {
    if (!re.test(lines[i])) continue;
    const out = [];
    let depth = 0;
    for (let j = i; j < lines.length; j++) {
      out.push(lines[j]);
      depth += dsgBlockDelta(String(lines[j] || '').trim());
      if (depth <= 0) break;
    }
    return out.join('\n');
  }
  return '';
}
/* 拿某份源码的界面段（两个设计器各有一套起点兜底规则） */
function dsgFindBlockOf(txt, kind) {
  return kind === 'qt' ? qdsgFindBlock(txt) : dsgFindDesignBlock(txt);
}

/* 「界面构建语句」：建窗口 / 建控件。段里连这些都没有 → 这段根本不是界面段
   （只是子程序里在调用 界面控件.置文本 之类的处理逻辑），调用方可以放心去插新代码 */
const DSG_BUILD_RE = {
  sciter: /(界面控件\.新建控件|界面\.新建窗口)[ \t]*\(/,
  qt: /(\.[^\s(]+[ \t]*\(主窗)|(主窗[ \t]*=[ \t]*窗口\.新建[ \t]*\()/,
};

/* 找出源码里「界面代码」占的行区间（1 基行号，闭区间；找不到返回 null） */
function dsgFindDesignBlock(text, opt) {
  const O = opt || {};
  const kind = O.kind === 'qt' ? 'qt' : 'sciter';
  const marker = O.marker || DSG_MARK_SCITER;
  const lines = String(text == null ? '' : text).split('\n');
  const anchor = O.anchorRe || dsgAnchorRe(kind);
  const isCtl = O.isCtl || ((s) => /^(界面|界面控件)\.[\u4e00-\u9fffA-Za-z0-9_]+[ \t]*\(/.test(s));
  const isAsg = O.isAsg || ((s) => /^主窗[ \t]*=/.test(s)
    || /^变量[ \t]+(整数型|文本型)[ \t]+(主窗|命中|事件类型)[ \t]*$/.test(s));
  const names = dsgQtCtlNames(lines, kind);
  const isGen = O.isGen || ((s) => dsgIsGenLine(s, kind, names));
  // 从某一行起向下扫一段：到顶层结构边界为止（块内整段算，重复插入的多份也一并吃进来）。
  // 顺便记下段里有没有「主窗赋值」与「建窗口 / 建控件」——用来判断这个起点靠不靠谱。
  const scanFrom = (start) => {
    let depth = 0, lastGen = -1, end = start, hasAnchor = false, hasBuild = false;
    for (let i = start; i < lines.length; i++) {
      const s = lines[i].trim();
      if (depth > 0) {                                // 块内（主循环 / 如果…）：整段都算
        depth += dsgBlockDelta(s);
        end = i;
        continue;
      }
      if (i > start && dsgIsEdge(s)) break;           // 子程序 / 结束子程序 … → 界面段到此为止
      const d = dsgBlockDelta(s);
      if (d !== 0) { depth = Math.max(0, d); end = i; continue; }
      if (s && isGen(s)) lastGen = i;
      if (anchor.test(s)) hasAnchor = true;
      if (DSG_BUILD_RE[kind].test(s)) hasBuild = true;
      end = i;
    }
    if (lastGen >= 0) end = lastGen;                  // 段尾的用户行（注释 / 返回 …）让出去
    if (end < start) end = start;
    return { end, hasAnchor, hasBuild };
  };

  // 起点候选：所有生成标记行 → 所有主窗赋值行 → 所有界面语句行（手写代码兜底）。
  // 挑**段里含主窗赋值**的那个：文件里若留着孤立的生成标记（复制粘贴的残渣），
  // 或者第一句界面语句其实是子程序里的处理逻辑，都不会再把起点带偏。
  const cands = [], seen = new Set();
  const pushCand = (i) => { if (!seen.has(i)) { seen.add(i); cands.push(i); } };
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].indexOf(marker) >= 0) pushCand(i);
  }
  for (let i = 0; i < lines.length; i++) {
    if (anchor.test(lines[i].trim())) pushCand(i);
  }
  for (let i = 0; i < lines.length && cands.length < 400; i++) {
    const s = lines[i].trim();
    if (isCtl(s) || isAsg(s)) pushCand(i);
  }
  let fallback = null;
  for (let k = 0; k < cands.length; k++) {
    const r = scanFrom(cands[k]);
    if (r.hasAnchor) return { start: cands[k] + 1, end: r.end + 1 };
    if (!fallback) fallback = { start: cands[k], r };
  }
  if (fallback) return { start: fallback.start + 1, end: fallback.r.end + 1 };
  return null;
}

/* 把生成的代码拆成「界面构建部分」与「主循环骨架」两段 */
function dsgSplitCode(code, needle) {
  const i = code.indexOf(needle || '当循环 界面.窗口可见');
  if (i < 0) return { head: code, loop: '' };
  const bol = code.lastIndexOf('\n', i) + 1;
  return { head: code.slice(0, bol).replace(/\s+$/, ''), loop: code.slice(bol) };
}

/* 保留用户原有的主循环时，补上它用到的变量声明（生成的界面部分可能没声明） */
function dsgEnsureVars(head, loopText, anchor) {
  const has = (nm) => head.indexOf('变量 整数型 ' + nm) >= 0 || head.indexOf('变量 文本型 ' + nm) >= 0;
  const adds = [];
  if (loopText.indexOf('主窗') >= 0 && !has('主窗')) adds.push('变量 整数型 主窗');
  if (loopText.indexOf('命中') >= 0 && !has('命中')) adds.push('变量 文本型 命中');
  if (loopText.indexOf('事件类型') >= 0 && !has('事件类型')) adds.push('变量 整数型 事件类型');
  if (!adds.length) return head;
  const i = head.indexOf(anchor || '主窗 = 界面.新建窗口');
  if (i < 0) return adds.join('\n') + '\n' + head;
  return head.slice(0, i) + adds.join('\n') + '\n' + head.slice(i);
}

/* ================= 设计器 → 代码：改动自动同步 =================
   在画布上删控件 / 加控件 / 拖位置 / 改属性 / 改窗口设置时，自动把工程里那段界面代码
   **就地更新**（不用再点「保存到工程」）。规则与保存时完全一致：
   · 只替换**已经存在**的界面段，绝不凭空插入新代码（还没有界面段时静默跳过，去点保存）；
   · 界面段里用户自己写的主循环原样保留；
   · 连续改动按 350ms 防抖合并成一次，且合并进撤销历史（不会刷满 Ctrl+Z）。
   目标文件优先：当前打开的标签（里面就有界面段）→ 其它已打开的标签 → 工程里没打开的文件。 */

/* 算出「把某份源码里的界面段换成新设计」的替换计划（两个设计器共用这一套规则）。
   返回 null = 这份源码里没有界面段（调用方去找下一个目标文件）；
   返回 plan.suspect = 认出来的段可疑（段内没有「主窗 = …新建窗口」）→ 调用方**不要改代码**。

   替换规则：只换段内的「生成行」，段内你自己写的用户行（变量声明 / 定时器 / `计数 = 0` /
   主循环整段 …）原样留在新代码后面 —— 老实现只保留主循环、别的段内内容一律覆盖，
   所以段识别差一点就会把用户代码吃掉，或者在下面再插一份完整的界面代码。 */
function dsgPlanReplace(txt, kind, code) {
  const isQt = kind === 'qt';
  const blk = dsgFindBlockOf(txt, kind);
  if (!blk) return null;
  const L = String(txt).split('\n');
  const seg = L.slice(blk.start - 1, blk.end);
  const anchor = dsgAnchorRe(kind);
  const s = offsetOfLine(txt, blk.start);
  const e = offsetOfLine(txt, blk.end) + (L[blk.end - 1] || '').length;
  if (!seg.some((ln) => anchor.test(String(ln).trim()))) {
    // 段里连「建窗口 / 建控件」都没有 → 这不是界面段（比如只是子程序里的 置文本 调用）
    if (!seg.some((ln) => DSG_BUILD_RE[kind].test(String(ln)))) return null;
    // 有界面构建语句、却没有「主窗 = …新建窗口」→ 段被截断了、认不准：宁可不改代码
    return { s, e, blk, suspect: true, text: '', keptUser: 0, hasLoop: false };
  }
  const names = dsgQtCtlNames(L, kind);
  // 段内用户行：生成行丢掉、连续空行压成一个、主循环整段原样（缩进与循环里的空行都不动）
  const kept = [];
  let blank = false, inLoop = false, loopDepth = 0;
  for (let i = 0; i < seg.length; i++) {
    const raw = seg[i], t = String(raw).trim();
    if (inLoop) {
      kept.push(raw);
      loopDepth += dsgBlockDelta(t);
      if (loopDepth <= 0) inLoop = false;
      continue;
    }
    if (dsgIsLoopStart(t) && !dsgIsGenLine(t, kind, names)) {
      if (kept.length && blank) kept.push('');
      blank = false;
      kept.push(raw);
      inLoop = true;
      loopDepth = 1;
      continue;
    }
    if (!t) { blank = true; continue; }
    if (dsgIsGenLine(raw, kind, names)) continue;
    if (kept.length && blank) kept.push('');
    blank = false;
    kept.push(raw);
  }
  const hasLoop = dsgLoopRe(kind).test(String(txt));
  const spl = dsgSplitCode(code, isQt ? '当循环 窗口.可见(主窗)' : '当循环 界面.窗口可见');
  // 源码里已经有主循环 → 只用新代码的「界面构建部分」（用户的主循环留在原地，不再生成一份）
  const head = hasLoop
    ? dsgEnsureVars(spl.head, dsgFileLoopText(L, kind) || kept.join('\n'),
        isQt ? '主窗 = 窗口.新建(' : '主窗 = 界面.新建窗口')
    : code;
  let text = String(head).replace(/\s+$/, '') + '\n';
  if (kept.length) text += '\n' + kept.join('\n') + '\n';
  return { s, e, blk, suspect: false, text, keptUser: kept.length, hasLoop };
}

/* ---------- 工程里还没有界面代码时：把新代码插到「程序入口」子程序体内 ----------
   以前是插到当前光标处 —— 光标若停在文件末尾（所有子程序之外），生成的界面代码就落在
   子程序外面，编译器会报「语句必须写在子程序体内」。现在统一插到
   `子程序 程序入口()`（或 `子程序 _启动子程序()`）的下一行，并对齐该处的缩进；
   工程里确实没有入口子程序（如纯 DLL 模块）时才回退到光标处插入。 */
const DSG_ENTRY_RE = /^[ \t]*(?:导出[ \t]*)?子程序[ \t]+(程序入口|_启动子程序)[ \t]*\(/;

/* 入口子程序体的插入点：{ line（1 基行号）, off（字符偏移）, indent }；没有入口返回 null */
function dsgEntryPos(txt) {
  const L = String(txt == null ? '' : txt).split('\n');
  for (let i = 0; i < L.length; i++) {
    if (!DSG_ENTRY_RE.test(L[i])) continue;
    const base = (/^[ \t]*/.exec(L[i]) || [''])[0];
    const nxt = L[i + 1] || '';
    const ns = nxt.trim();
    // 下一行是正常语句就用它的缩进；入口体是空的 / 紧跟「结束子程序」就缩进一层
    const indent = (ns && !/^结束/.test(ns))
      ? (/^[ \t]*/.exec(nxt) || [''])[0] : base + INDENT;
    return { line: i + 1, off: offsetOfLine(txt, i + 1) + L[i].length, indent };
  }
  return null;
}

/* 生成代码整体加一层缩进（空行不加），与程序入口里的其它语句对齐 */
function dsgIndent(text, ind) {
  if (!ind) return String(text);
  return String(text).split('\n').map((s) => (s ? ind + s : '')).join('\n');
}

/* 把新生成的界面代码插进「程序入口」：当前编辑框 → 其它已打开标签 → 工程里没打开的文件。
   成功返回插入位置的说明（用于提示），失败返回 null（调用方回退到光标处插入）。 */
async function dsgInsertIntoEntry(code, kind) {
  const isQt = kind === 'qt';
  const OK = (t) => !!t && t.project === S.project && !t.readonly && !t.gen
    && /\.yy$/i.test(t.path || '');
  // 目标文件里已经有主循环 → 只插「界面构建部分」，免得再来一个循环
  const bodyOf = (txt) => {
    if (!dsgLoopRe(kind).test(String(txt))) return code;
    return dsgSplitCode(code, isQt ? '当循环 窗口.可见(主窗)' : '当循环 界面.窗口可见').head + '\n';
  };
  const textAt = (txt, pos) => '\n' + dsgIndent(bodyOf(txt), pos.indent);

  // ① 当前编辑框
  const t = activeTab();
  const ta = $('codeInput');
  if (ta && t && ta.value !== t.content) t.content = ta.value;
  if (OK(t)) {
    const pos = dsgEntryPos(t.content);
    if (pos) {
      editorReplaceRange(pos.off, pos.off, textAt(t.content, pos));
      return '「' + t.path + '」的子程序 程序入口（第 ' + pos.line + ' 行之后）';
    }
  }
  // ② 其它已打开的标签
  const other = S.tabs.find((x) => OK(x) && dsgEntryPos(x.content));
  if (other) {
    activateTab(S.tabs.indexOf(other));
    const t2 = activeTab() || other;
    const pos = dsgEntryPos(t2.content);
    if (pos) {
      editorReplaceRange(pos.off, pos.off, textAt(t2.content, pos));
      return '「' + t2.path + '」的子程序 程序入口（第 ' + pos.line + ' 行之后）';
    }
  }
  // ③ 工程里没打开的文件
  let rels = [];
  try { rels = projectYyPaths() || []; } catch (e) { rels = []; }
  for (const rel of rels) {
    let txt = null;
    try {
      const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
        + '&path=' + encodeURIComponent(rel));
      if (!d.binary) txt = d.text;
    } catch (e) { continue; }
    if (txt == null) continue;
    const norm = txt.replace(/\r\n?/g, '\n');
    const pos = dsgEntryPos(norm);
    if (!pos) continue;
    try {
      await api('POST', '/api/file', { project: S.project, path: rel,
        content: norm.slice(0, pos.off) + textAt(norm, pos) + norm.slice(pos.off) });
      await refreshTree().catch(() => { });
      return '「' + rel + '」的子程序 程序入口（第 ' + pos.line + ' 行之后；该文件未打开，已直接写盘）';
    } catch (e) { break; }
  }
  return null;
}

const DSG_SYNC = { timer: 0, busy: false, kind: 'sciter', told: {} };

/* 触发一次自动同步（防抖；kind = 'sciter' | 'qt'） */
function dsgSyncSchedule(kind) {
  if (!S.project) return;
  DSG_SYNC.kind = (kind === 'qt') ? 'qt' : 'sciter';
  clearTimeout(DSG_SYNC.timer);
  DSG_SYNC.timer = setTimeout(() => { dsgSyncNow(DSG_SYNC.kind); }, 350);
}

/* 立刻把当前设计写回它所在的那段界面代码（没有界面段就什么都不做） */
async function dsgSyncNow(kind) {
  if (!S.project || DSG_SYNC.busy) return;
  const isQt = kind === 'qt';
  const code = isQt ? qdsgGenerate() : dsgGenerate();
  const label = isQt ? 'Qt 界面' : '界面';
  const okFiles = (t) => t.project === S.project && !t.readonly && !t.gen;

  // ① 已打开的标签（当前标签优先）
  const cands = [];
  const cur = activeTab();
  if (cur && okFiles(cur)) cands.push(cur);
  S.tabs.forEach((t) => { if (okFiles(t) && cands.indexOf(t) < 0) cands.push(t); });
  for (const t of cands) {
    const pl = dsgPlanReplace(t.content, kind, code);
    if (!pl || pl.suspect) continue;                 // 段认不准就静默跳过（宁可不改，别乱改）
    const out = t.content.slice(0, pl.s) + pl.text + t.content.slice(pl.e);
    if (out === t.content) return;                   // 内容没变：不动
    DSG_SYNC.busy = true;
    try {
      if (activeTab() === t && $('codeInput')) {
        editorReplaceRange(pl.s, pl.e, pl.text, null, null, { coalesce: true });
      } else {                                       // 后台标签：直接改内容，撤销历史重置
        t.content = out;
        t.dirty = true;
        t.hist = null;
        renderTabs();
      }
      if (!DSG_SYNC.told[kind]) {
        DSG_SYNC.told[kind] = true;
        toast('改动已自动同步到「' + t.path + '」的' + label + '代码（第 '
          + pl.blk.start + '-' + pl.blk.end + ' 行那一段）', 4600);
      }
    } finally { DSG_SYNC.busy = false; }
    return;
  }

  // ② 工程里没打开的文件：读出来改掉再写回
  let rels = [];
  try { rels = projectYyPaths() || []; } catch (e) { rels = []; }
  for (const rel of rels) {
    let txt = null;
    try {
      const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
        + '&path=' + encodeURIComponent(rel));
      if (!d.binary) txt = d.text;
    } catch (e) { continue; }
    if (txt == null) continue;
    const norm = txt.replace(/\r\n?/g, '\n');
    const pl = dsgPlanReplace(norm, kind, code);
    if (!pl || pl.suspect) continue;
    const out = norm.slice(0, pl.s) + pl.text + norm.slice(pl.e);
    if (out === norm) return;
    DSG_SYNC.busy = true;
    try {
      await api('POST', '/api/file', { project: S.project, path: rel, content: out });
      if (!DSG_SYNC.told[kind]) {
        DSG_SYNC.told[kind] = true;
        toast('改动已自动同步到「' + rel + '」的' + label + '代码（该文件未打开，已直接写盘）', 5000);
      }
    } catch (e) { /* 写盘失败就算了，用户可以点「保存到工程」 */ } finally { DSG_SYNC.busy = false; }
    return;
  }
  // 哪里都没有界面段 → 静默跳过（第一次写代码请点「保存到工程」）
}

/* 「保存到工程」：把画布上的界面**就地替换**工程里原有的界面代码 ——
   只动界面段里的「生成行」，其它代码与段内你自己写的行一行不改；
   工程里还没有界面代码时才插入一份新的。 */
async function dsgInsert() {
  if (!DSG.items.length) { toast('画布上还没有控件'); return; }
  if (!S.project) { toast('请先在上方选择一个工程'); return; }
  dsgDesignFlush();                      // 保存到工程时把设计（含颜色）也落盘 → 下次打开自动载入
  const code = dsgGenerate();
  const n = DSG.items.length;
  const suspect = [];                    // 认出来的界面段可疑的文件（只提示，绝不乱改）
  const tail = (pl) => (pl.hasLoop
    ? '；你写在主循环里的处理逻辑、以及段内你自己写的行都原样保留' : '');
  // 能当目标的标签：当前工程的 .yy 源码（只读 / 生成物 / 其它工程一律不算）
  const OK = (t) => !!t && t.project === S.project && !t.readonly && !t.gen
    && /\.yy$/i.test(t.path || '');

  // ① 当前编辑框：编辑框里的**实时内容**优先（别拿过期的内存副本去对行号）
  const t = activeTab();
  const ta = $('codeInput');
  if (ta && t && ta.value !== t.content) t.content = ta.value;
  if (OK(t)) {
    const pl = dsgPlanReplace(t.content, 'sciter', code);
    if (pl && pl.suspect) {
      suspect.push(t.path);
    } else if (pl) {
      closeDesigner();
      editorReplaceRange(pl.s, pl.e, pl.text);
      toast('已就地更新「' + t.path + '」的界面代码（' + n + ' 个控件，原在第 '
        + pl.blk.start + '-' + pl.blk.end + ' 行）' + tail(pl) + '，其它代码未改动', 6400);
      return;
    }
  }
  // ② 其它已打开的标签里有界面代码 → 切过去就地替换
  const other = S.tabs.find((x) => OK(x) && x !== t && dsgFindDesignBlock(x.content));
  if (other) {
    activateTab(S.tabs.indexOf(other));
    const t2 = activeTab() || other;
    const pl2 = dsgPlanReplace(t2.content, 'sciter', code);
    if (pl2 && pl2.suspect) suspect.push(t2.path);
    else if (pl2) {
      closeDesigner();
      editorReplaceRange(pl2.s, pl2.e, pl2.text);
      toast('界面代码在「' + t2.path + '」，已就地更新（' + n + ' 个控件' + tail(pl2) + '）', 6000);
      return;
    }
  }
  // ③ 工程里有界面代码但文件没打开 → 读盘改写后写回
  const rels = (function () { try { return projectYyPaths() || []; } catch (e) { return []; } })();
  for (const rel of rels) {
    let txt = null;
    try {
      const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
        + '&path=' + encodeURIComponent(rel));
      if (!d.binary) txt = d.text;
    } catch (e) { continue; }
    if (txt == null) continue;
    const norm = txt.replace(/\r\n?/g, '\n');
    const pl = dsgPlanReplace(norm, 'sciter', code);
    if (!pl) continue;
    if (pl.suspect) { suspect.push(rel); continue; }
    try {
      await api('POST', '/api/file', { project: S.project, path: rel,
                                       content: norm.slice(0, pl.s) + pl.text + norm.slice(pl.e) });
      closeDesigner();
      await refreshTree().catch(() => { });
      toast('界面代码在「' + rel + '」，已就地更新（' + n + ' 个控件' + tail(pl)
        + '；该文件未打开，已直接写盘）', 6400);
      return;
    } catch (e) { break; }
  }
  // ④ 认出了界面段但认不准（段内没有「主窗 = 界面.新建窗口(…)」）→ 不替换、也不插新代码，
  //    提示用户去确认 —— 静默再插一份正是「代码里冒出两套界面」的老毛病
  if (suspect.length) {
    toast('「' + suspect[0] + '」里那段界面代码认不准（段内没找到「主窗 = 界面.新建窗口(…)」），'
      + '为免重复或错位，既没就地替换也没插入新代码。请确认那段是设计器生成的界面段'
      + '（带「由「界面设计」生成」标记），或先用「导入工程设计」看看画布', 9000);
    return;
  }
  // ⑤ 工程里还没有界面代码 → 插到「程序入口」子程序体内（没找到入口才插到光标处）
  closeDesigner();
  const where = await dsgInsertIntoEntry(code, 'sciter').catch(() => null);
  if (where) {
    toast('工程里还没有界面代码，已插入到 ' + where + '（' + n + ' 个控件）', 6400);
    return;
  }
  insertAtCursor(code, { block: true });
  toast('工程里还没有界面代码，也没找到「子程序 程序入口()」，已在当前光标处插入一份新的（'
    + n + ' 个控件）', 6200);
}

/* 载入设计文件。quiet = 打开设计器时自动载入：没工程 / 没保存过设计就悄悄跳过，不弹提示。
   底部「载入设计」按钮已移除，现在只由「打开设计器」自动调用（quiet 恒为 true）。 */
async function dsgLoad(quiet) {
  if (!S.project) { if (!quiet) toast('请先在上方选择一个工程'); return; }
  // 自动载入：文件树里根本没有这个设计文件 → 画布重置为空，别发无谓请求（也不会在控制台留下 404）
  if (quiet && !treeHasFile(DSG_FILE)) { dsgResetDesign(); return; }
  try {
    const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
      + '&path=' + encodeURIComponent(DSG_FILE));
    const data = JSON.parse(d.text || '{}');
    if (!data || !Array.isArray(data.items)) throw new Error('不是有效的设计文件');
    // 窗体设置：version 2 在 data.win 里；version 1 的老文件是扁平的 w/h/title/genLoop
    const w = data.win || {};
    const numOrBlank = (v) => (v === '' || v == null ? '' : (isFinite(Number(v)) ? Number(v) : ''));
    DSG.w = Number(w.w != null ? w.w : data.w) || 760;
    DSG.h = Number(w.h != null ? w.h : data.h) || 520;
    if (w.title != null) DSG.title = w.title;
    else if (data.title != null) DSG.title = data.title;
    if (w.icon != null) DSG.icon = w.icon;
    if (w.center != null) DSG.center = !!w.center;
    if (w.x !== undefined) DSG.x = numOrBlank(w.x);
    if (w.y !== undefined) DSG.y = numOrBlank(w.y);
    DSG.max = !!w.max; DSG.min = !!w.min; DSG.full = !!w.full; DSG.hide = !!w.hide;
    if (w.top !== undefined) DSG.top = !!w.top;
    if (w.noFrame !== undefined) DSG.noFrame = !!w.noFrame;
    if (w.resizable !== undefined) DSG.resizable = !!w.resizable;
    if (w.opacity !== undefined) DSG.opacity = numOrBlank(w.opacity);
    if (w.bg) DSG.bg = w.bg;
    if (w.font != null) DSG.font = w.font;
    if (w.fontSize != null) DSG.fontSize = w.fontSize;
    if (w.css != null) DSG.css = w.css;
    if (w.genVars != null) DSG.genVars = !!w.genVars;
    if (w.genLoop != null) DSG.genLoop = !!w.genLoop;
    else if (data.genLoop != null) DSG.genLoop = data.genLoop !== false;
    DSG.items = data.items.map((it, i) => Object.assign({
      id: 'w' + Date.now() + '_' + i, type: '标签', name: '控件' + i, text: '',
      x: 10, y: 10, w: 100, h: 24, fontSize: '', color: '', bg: '', radius: '', border: '',
    }, it, { type: ctlType(it.type || '标签'), id: 'w' + Date.now() + '_' + i }));
    DSG.seq = DSG.items.length;
    dsgSyncWinPane();
    dsgSelect('');
    DSG_AUTO.last = dsgDesignJson();         // 刚载入 = 与磁盘一致：没改动就不回写
    if (!quiet) toast('已载入设计（' + DSG.items.length + ' 个控件）');
  } catch (e) {
    // 打开设计器时自动载入：本工程还没有设计文件 → 画布重置为空，别让上一个工程的设计留在画布上
    if (quiet) { dsgResetDesign(); return; }
    toast('载入失败：' + e.message + '（若还没保存过设计，直接拖控件即可）', 4200);
  }
}

/* ---------- 导入工程设计：把工程里已有的界面代码还原到画布（dsgGenerate 的逆运算） ---------- */

/* 从 src[open]（'(' 的下标）起，扫到配对的 ')'，返回 {args, end}（跳过字符串里的括号 / 逗号） */
function dsgCallArgs(src, open) {
  let depth = 0, q = false;
  for (let i = open; i < src.length; i++) {
    const c = src[i];
    if (q) {
      if (c === '\\') { i++; continue; }
      if (c === '"') q = false;
      continue;
    }
    if (c === '"') { q = true; continue; }
    if (c === '(') depth++;
    else if (c === ')') { depth--; if (!depth) return { args: src.slice(open + 1, i), end: i }; }
  }
  return null;
}

/* 按顶层逗号切参数（字符串里的逗号不算） */
function dsgSplitArgs(s) {
  const out = [];
  let cur = '', q = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      cur += c;
      if (c === '\\') { cur += (s[i + 1] || ''); i++; continue; }
      if (c === '"') q = false;
      continue;
    }
    if (c === '"') { q = true; cur += c; continue; }
    if (c === ',') { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() || out.length) out.push(cur.trim());
  return out;
}

/* 反向解析界面代码 → 设计模型 {title,w,h,x,y,…,items}；不是界面代码返回 null。
   认得 dsgGenerate 生成的那几行（顺序无关，允许缩进 / 行尾注释），识别不到的行忽略，
   所以手写的界面代码也能导入。 */
function dsgParseDesign(text) {
  const src = String(text || '').replace(/\r\n?/g, '\n');
  if (src.indexOf('界面.新建窗口') < 0 && src.indexOf('界面控件.新建控件') < 0) return null;
  const out = { items: [], w: 0, h: 0, css: '' };
  const byName = {};
  const unq = (s) => {
    const m = /^\s*"((?:[^"\\]|\\.)*)"/.exec(s || '');
    return m ? m[1].replace(/\\(.)/g, '$1') : String(s || '').trim().replace(/^"|"$/g, '');
  };
  const num = (s) => { const n = parseInt(String(s || '').trim(), 10); return isFinite(n) ? n : 0; };
  const STYLE_MAP = { 'font-size': 'fontSize', 'color': 'color', 'background': 'bg',
                      'border-radius': 'radius', 'border': 'border' };
  const calls = /(界面控件|界面)\.([\u4e00-\u9fffA-Za-z0-9_]+)[ \t]*\(/g;
  let m;
  while ((m = calls.exec(src))) {
    const got = dsgCallArgs(src, m.index + m[0].length - 1);
    if (!got) continue;
    calls.lastIndex = got.end;                    // 跳过参数区，别把字符串里的内容当调用
    const ns = m[1], fn = m[2];
    const a = dsgSplitArgs(got.args);
    if (ns === '界面') {                          // ---- 窗口级 ----
      if (fn === '新建窗口') {
        out.title = unq(a[0]);
        out.w = num(a[1]) || out.w;
        out.h = num(a[2]) || out.h;
      } else if (fn === '加页面样式') {
        const css = unq(a[1]);
        if (/^body\s*\{/i.test(css)) {            // 生成器写的 body 样式 → 拆成窗口属性
          const g = (k) => {
            const r = new RegExp('(?:^|[;{\\s])' + k + '\\s*:\\s*([^;}]+)', 'i').exec(css);
            return r ? r[1].trim() : '';
          };
          const bg = g('background') || g('background-color');
          if (bg) out.bg = bg;
          const ff = g('font-family');
          if (ff) out.font = ff.split(',')[0].replace(/^['"]|['"]$/g, '').trim();
          const fs = g('font-size');
          if (fs) out.fontSize = fs.replace(/px$/i, '').trim();
        } else if (css) {
          out.css = (out.css ? out.css + '\n' : '') + css;
        }
      } else if (fn === '置图标') {
        out.icon = unq(a[1]);
      } else if (fn === '置位置') {
        out.x = num(a[1]); out.y = num(a[2]);
      } else if (fn === '窗口居中') { out.center = true;
      } else if (fn === '置置顶') { out.top = num(a[1]) !== 0;
      } else if (fn === '置无边框') { out.noFrame = num(a[1]) !== 0;
      } else if (fn === '置可调边框') { out.resizable = num(a[1]) !== 0;
      } else if (fn === '置最大化按钮') { out.btnMax = num(a[1]) !== 0;
      } else if (fn === '置最小化按钮') { out.btnMin = num(a[1]) !== 0;
      } else if (fn === '置透明度') { out.opacity = num(a[1]);
      } else if (fn === '隐藏') { out.hide = true;
      } else if (fn === '显示') { out.hide = false;
      } else if (fn === '最大化') { out.max = true;
      } else if (fn === '最小化') { out.min = true;
      } else if (fn === '全屏') { out.full = true;
      }
      continue;
    }
    // ---- 控件级 ----
    if (fn === '新建控件' || fn === '新建控件到') {   // 「新建控件到(…, "#容器")」也认
      const type = ctlType(unq(a[1]) || '标签');      // 老代码里的「输入框」→「编辑框」
      const def = dsgTypeDefaults(type) || { w: 100, h: 24, text: '' };
      const it = { type, name: unq(a[2]), text: unq(a[3]) || def.text || '',
                   x: 0, y: 0, w: def.w, h: def.h, hasPos: false,
                   fontSize: '', color: '', bg: '', radius: '', border: '' };
      byName[it.name] = it;
      out.items.push(it);
    } else if (fn === '置位置') {
      const it = byName[unq(a[1])];
      if (it) {
        it.x = num(a[2]); it.y = num(a[3]);
        it.w = num(a[4]) || it.w; it.h = num(a[5]) || it.h;
        it.hasPos = true;
      }
    } else if (fn === '置样式') {
      const it = byName[unq(a[1])];
      const k = STYLE_MAP[unq(a[2])];
      if (it && k) it[k] = unq(a[3]);
    } else if (fn === '置文本' || fn === '加多项') {
      const it = byName[unq(a[1])];
      if (it && !it.text) it.text = unq(a[2]);
    }
  }
  out.items = out.items.filter((it) => it.name);
  // 手写界面常用「界面.加HTML(...)」摆骨架 —— 设计器没有对应控件，只统计条数并提示
  out.htmlCount = (src.match(/界面\.加HTML[ \t]*\(/g) || []).length;
  // 没有「置位置」的控件（HTML 流式布局写的）→ 自动排成流式，免得全堆在原点
  out.autoPlaced = out.items.filter((it) => !it.hasPos).length;
  let ax = 16, ay = 16, rowH = 0;
  out.items.forEach((it) => {
    if (it.hasPos) return;
    it.x = ax; it.y = ay;
    ax += it.w + 10;
    rowH = Math.max(rowH, it.h);
    if (out.w && ax + it.w > out.w) { ax = 16; ay += rowH + 10; rowH = 0; }
  });
  out.items.forEach((it) => { delete it.hasPos; });
  return out;
}

/* 工具箱里不再出现的类型（老设计 / 老代码导入时仍然要认，尺寸按老默认给）：
   「文本」与「标签」重复（都是文字控件，标签更常用），工具箱里已隐藏 */
const DSG_TYPES_HIDDEN = [['文本', 90, 24, '文字']];

/* 工具箱里某类型的默认尺寸 / 默认文本（导入时给控件补默认宽高用） */
function dsgTypeDefaults(type) {
  const groups = DSG_TYPES.concat([['（已隐藏）', DSG_TYPES_HIDDEN]]);
  for (let i = 0; i < groups.length; i++) {
    const list = groups[i][1] || [];
    for (let j = 0; j < list.length; j++) {
      if (list[j][0] === type) return { w: list[j][1], h: list[j][2], text: list[j][3] };
    }
  }
  return null;
}

/* 「导入工程设计」：读当前工程的 .yy 界面代码 → 还原成画布上的控件
   （与「保存到工程」正好相反：一个是代码 → 画布，一个是画布 → 代码）。
   点一次就把当前画布清空再导入，不弹询问。 */
async function dsgImportDesign() {
  if (!S.project) { toast('请先在上方选择一个工程'); return; }
  // 候选文件：当前打开的 .yy 优先，然后整个工程的 .yy
  const cands = [];
  const cur = activeTab();
  if (cur && cur.project === S.project && /\.yy$/i.test(cur.path || '')) cands.push(cur.path);
  let all = [];
  try { all = projectYyPaths() || []; } catch (e) { all = []; }
  all.forEach((rel) => { if (cands.indexOf(rel) < 0) cands.push(rel); });
  const hits = [];
  for (const rel of cands) {
    const tab = S.tabs.find((t) => t.project === S.project && t.path === rel);
    let text = null;
    if (tab) text = tab.content;                       // 已打开：用内存里的最新内容
    else {
      try {
        const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
          + '&path=' + encodeURIComponent(rel));
        if (!d.binary) text = d.text;
      } catch (e) { continue; }
    }
    if (text == null) continue;
    const p = dsgParseDesign(text);
    if (p) hits.push(Object.assign({ file: rel }, p));
  }
  if (!hits.length) {
    toast('当前工程的 .yy 里没有找到界面代码（需要含「界面.新建窗口(…)」或「界面控件.新建控件(…)」）', 5200);
    return;
  }
  hits.sort((a, b) => b.items.length - a.items.length);   // 控件最多的那个
  const h = hits[0];
  DSG.w = h.w || 760;
  DSG.h = h.h || 520;
  DSG.title = h.title || '我的程序';
  DSG.icon = h.icon || '';
  DSG.x = (h.x === undefined ? '' : h.x);
  DSG.y = (h.y === undefined ? '' : h.y);
  DSG.center = !!h.center; DSG.max = !!h.max; DSG.min = !!h.min; DSG.full = !!h.full;
  DSG.hide = !!h.hide; DSG.top = !!h.top; DSG.noFrame = !!h.noFrame;
  DSG.resizable = (h.resizable === undefined ? true : !!h.resizable);
  DSG.opacity = (h.opacity === undefined ? '' : h.opacity);
  if (h.bg) DSG.bg = h.bg;
  DSG.font = h.font || '';
  DSG.fontSize = h.fontSize || '';
  DSG.css = h.css || '';
  const base = Date.now();
  DSG.items = h.items.map((it, i) => Object.assign({
    type: '标签', name: '控件' + i, text: '', x: 10, y: 10, w: 100, h: 24,
    fontSize: '', color: '', bg: '', radius: '', border: '',
  }, it, { id: 'i' + base + '_' + i }));
  DSG.seq = DSG.items.length;
  dsgSyncWinPane();
  dsgSelect('');
  const extra = [];
  if (hits.length > 1) extra.push('工程里还有 ' + (hits.length - 1) + ' 个文件含界面代码，已取控件最多的');
  if (h.htmlCount) extra.push('另有 ' + h.htmlCount + ' 行「加HTML」的 HTML 骨架未导入');
  if (h.autoPlaced) extra.push(h.autoPlaced + ' 个控件没有「置位置」，已按流式排布');
  toast('已从「' + h.file + '」识别出 ' + DSG.items.length + ' 个控件'
    + (extra.length ? '（' + extra.join('；') + '）' : ''), 5600);
}

function closeDesigner() {
  dsgDesignFlush();                      // 关掉前把设计（含颜色）落盘，下次打开自动载入即可还原
  const m = $('dsgMask');
  if (m) m.classList.add('hidden');
}

function openDesigner() {
  const mask = $('dsgMask');
  if (!mask) return;
  closeQtDesigner();                     // 两个设计器不并存
  // 工具箱
  const tb = $('dsgToolbox');
  tb.innerHTML = '';
  DSG_TYPES.forEach(([cat, list]) => {
    const c = document.createElement('div');
    c.className = 'dsgCat';
    c.textContent = cat;
    tb.appendChild(c);
    list.forEach(([type]) => {
      const b = document.createElement('div');
      b.className = 'dsgTool';
      b.textContent = type;
      b.draggable = true;
      b.title = '拖到画布上新建「' + type + '」；也可以直接单击';
      b.ondragstart = (e) => {
        try { e.dataTransfer.setData('text/plain', type); } catch (err) { /* 忽略 */ }
        e.dataTransfer.effectAllowed = 'copy';
      };
      b.onclick = () => dsgAdd(type);
      tb.appendChild(b);
    });
  });
  // 画布
  const stage = $('dsgStage');
  stage.onmousedown = (e) => {
    const box = e.target.closest && e.target.closest('.dsgItem');
    if (!box) { dsgSelect(''); return; }
    const it = DSG.items.find((x) => x.id === box.dataset.id);
    if (!it) return;
    dsgSelect(it.id);
    const isHandle = e.target.classList && e.target.classList.contains('dsgHandle');
    const sx = e.clientX, sy = e.clientY;
    const o = { x: it.x, y: it.y, w: it.w, h: it.h };
    DSG.drag = (ev) => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (isHandle) {
        it.w = Math.max(8, o.w + dx);
        it.h = Math.max(8, o.h + dy);
      } else {
        it.x = Math.max(0, o.x + dx);
        it.y = Math.max(0, o.y + dy);
      }
      dsgRender();
    };
    DSG.dragEnd = () => { dsgRenderProps(); dsgStatus(); };
    e.preventDefault();
  };
  stage.ondragover = (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; };
  stage.ondrop = (e) => {
    e.preventDefault();
    let type = '';
    try { type = e.dataTransfer.getData('text/plain'); } catch (err) { type = ''; }
    if (!type || !dsgTypeInfo(type)) return;
    const r = stage.getBoundingClientRect();
    const info = dsgTypeInfo(type);
    dsgAdd(type, e.clientX - r.left - info[1] / 2, e.clientY - r.top - info[2] / 2);
  };
  // 窗口属性页签（宽/高/标题/图标/启动方式/页面外观/代码生成 + 页签切换）
  dsgBindWinPane();
  // 底部按钮
  $('dsgDel').onclick = dsgDelete;
  $('dsgClear').onclick = dsgClear;
  $('dsgClose').onclick = closeDesigner;
  $('dsgImport').onclick = dsgImportDesign;
  $('dsgGen').onclick = dsgInsert;
  dsgShowTab(DSG.sel ? 'ctl' : 'win');
  dsgRender();
  dsgRenderProps();
  mask.classList.remove('hidden');
  // 打开设计器 = 自动载入当前工程的设计文件（没工程 / 没保存过设计就悄悄跳过）
  dsgLoad(true);
}

/* 拖动 / 方向键 / 删除：全局监听（只在设计器打开时生效） */
function dsgGlobalHandlers() {
  document.addEventListener('mousemove', (e) => { if (DSG.drag) DSG.drag(e); });
  document.addEventListener('mouseup', () => {
    if (DSG.drag) { DSG.drag = null; if (DSG.dragEnd) DSG.dragEnd(); }
  });
  document.addEventListener('keydown', (e) => {
    const mask = $('dsgMask');
    if (!mask || mask.classList.contains('hidden')) return;
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = (tag === 'input' || tag === 'textarea' || tag === 'select');
    if (e.key === 'Escape') { closeDesigner(); return; }
    if (typing) return;
    if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); dsgDelete(); return; }
    const step = e.shiftKey ? 10 : 1;
    if (e.key === 'ArrowLeft') { e.preventDefault(); dsgNudge(-step, 0); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); dsgNudge(step, 0); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); dsgNudge(0, -step); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); dsgNudge(0, step); }
  });
}

/* ================= Qt 界面设计器（独立一套，生成 lib\qt.class 的句柄式代码） =================
   与 Sciter 那套的差别（所以才要两套，而不是一个开关）：

     · Qt 是「一种控件一个类 + **整数句柄**」：
         按钮1 = 按钮.新建(主窗, "确定")     ' 新建返回句柄
         控件.置位置(按钮1, 20, 20, 100, 32) ' 之后都拿句柄操作
       Sciter 是「按名字/选择器操作」：界面控件.置位置(主窗, "按钮1", …)
     · Qt 样式：控件.置样式(句柄, "QSS 整串") + 控件.置字色/置底色/置字体(句柄, 字号, 加粗)
       Sciter 样式：HTML/CSS 的「属性名 + 值」两参数
     · Qt 事件：命中 = 控件.取事件() 得到的是**整数句柄**，用**变量名**比较
         如果 (命中 = 按钮1) …
       Sciter 事件：命中 是**文本控件名**，和字符串比
     · 控件类型名不同：超链接在 Qt 叫「链接」；Sciter 另多出 密码框/富文本/画布/视频/
       输入区/日期/时间/文件/颜色；菜单/定时器/布局不是可视控件

   画布是 Qt 外观的**近似**预览（Qt 是原生控件，浏览器里无法真正复现）：底色取 Qt 窗口色，
   按钮/编辑框等按原生观感近似画。所见即所得是「布局级」的，不是像素级。 */

const QDSG_FILE = '界面设计_Qt.yydesign';

/* 工具箱：分类 → [类型, 默认宽, 默认高, 默认文本]
   类型名与 lib\qt.class 的「XX.新建」严格一致 —— 生成代码直接拿它拼函数名。 */
const QDSG_TYPES = [
  ['常用', [['按钮', 100, 32, '按钮'], ['标签', 100, 24, '标签'], ['编辑框', 180, 28, ''],
            ['文本域', 220, 96, ''], ['链接', 170, 24, 'https://example.com']]],
  ['选择', [['复选框', 110, 24, '复选框'], ['单选框', 110, 24, '单选框'],
            ['下拉框', 160, 28, '选项一|选项二'], ['列表框', 160, 96, '第一项|第二项'],
            ['滑块', 200, 24, ''], ['微调', 90, 28, '']]],
  ['展示', [['进度条', 200, 20, ''], ['表格', 320, 110, '列一|列二'], ['树', 180, 110, '名称'],
            ['图片', 120, 90, ''], ['分隔线', 320, 12, '']]],
  ['容器', [['分组框', 260, 140, '分组'], ['选项卡', 300, 170, '页1|页2'],
            ['容器', 240, 140, ''], ['滚动区', 240, 140, '']]],
];

/* Qt 设计态。窗口设置每一项都对应 lib\qt.class 里**真实可用**的写法：
   基本    新建 / 置标题 / 置图标
   位置大小 居中 / 置位置 / 置大小限制
   启动    最大化 / 最小化 / 全屏 / 隐藏
   外观    置样式(整窗 QSS) / 置底色 / 置字色 / 置字体
   行为    置置顶 / 置无边框 / 置可调边框 / 置透明度
   （其中 15 个是后来给 yyqt.cpp 新增的 Yy_Window* 封装，导出 135 → 150；
     置样式·置底色·置字色·置字体·置提示 是复用已有 Yy_Set* 的别名。）
   数值型可选字段留空 = 不生成对应代码（比如 左边/顶边 留空就交给系统定位）。 */
const QD = {
  w: 760, h: 520, items: [], sel: '', seq: 0, drag: null,
  title: '我的程序', icon: '',
  center: false, x: '', y: '', minW: '', minH: '',
  max: false, min: false, full: false, hide: false,
  bg: '', fg: '', font: '', fontSize: '', bold: false, opacity: '', qss: '',
  top: false, noFrame: false, resizable: true,
  btnMax: true, btnMin: true,            // 标题栏最大化 / 最小化按钮
  genVars: true, genLoop: true,
};

/* 设计态初值快照：打开设计器时当前工程**没有**设计文件 → 重置成这个（免得看到上一个工程的控件） */
const QD_INIT = Object.assign({}, QD);
function qdsgResetDesign() {
  Object.assign(QD, QD_INIT, { items: [], sel: '', seq: 0, drag: null });
  qdsgSyncWinPane();
  qdsgSelect('');
  QD_AUTO.last = qdsgDesignJson();     // 空设计 = 「已落盘」状态：不白写文件
}

/* ================= Qt 设计自动落盘（与 Sciter 版同一套做法） =================
   控件的颜色 / 字号 / 底色 / QSS…、窗体的颜色与其它设置都在设计文件里。
   一改动就防抖写盘，点「保存到工程」与关闭设计器时再立刻补写一次
   （以前靠底部「保存设计」按钮手动写盘，该按钮已移除，现在全自动）。 */
const QD_AUTO = { timer: 0, last: '' };

function qdsgDesignData() {
  return {
    type: 'yunyi-designer-qt', version: 2,
    win: {
      w: QD.w, h: QD.h, title: QD.title, icon: QD.icon,
      center: QD.center, x: QD.x, y: QD.y, minW: QD.minW, minH: QD.minH,
      max: QD.max, min: QD.min, full: QD.full, hide: QD.hide,
      bg: QD.bg, fg: QD.fg, font: QD.font, fontSize: QD.fontSize,
      bold: QD.bold, opacity: QD.opacity, qss: QD.qss,
      top: QD.top, noFrame: QD.noFrame, resizable: QD.resizable,
      genVars: QD.genVars, genLoop: QD.genLoop,
    },
    items: QD.items,
  };
}
function qdsgDesignJson() { return JSON.stringify(qdsgDesignData(), null, 2); }

function qdsgDesignTouch() {
  clearTimeout(QD_AUTO.timer);
  QD_AUTO.timer = setTimeout(qdsgDesignFlush, 800);
}
async function qdsgDesignFlush() {
  clearTimeout(QD_AUTO.timer);
  if (!S.project) return;
  const json = qdsgDesignJson();
  if (json === QD_AUTO.last) return;                       // 没有真改动
  const had = treeHasFile(QDSG_FILE);
  if (!QD.items.length && !had) return;                    // 空设计 + 还没设计文件 → 不建文件
  QD_AUTO.last = json;
  try {
    await api('POST', '/api/file', { project: S.project, path: QDSG_FILE, content: json });
    if (!had) await refreshTree().catch(() => { });         // 新建的文件：刷新文件树（自动载入要认它）
  } catch (e) { /* 忽略：下次改动会再写一次 */ }
}

/* 云易标识符：中英文 / 下划线开头，后接中英文 / 数字 / 下划线 */
const QD_NAME_RE = /^[A-Za-z_\u4e00-\u9fa5][A-Za-z0-9_\u4e00-\u9fa5]*$/;

function qdsgTypeInfo(type) {
  for (const g of QDSG_TYPES) for (const t of g[1]) if (t[0] === type) return t;
  return null;
}
/* 「文本」这一栏在各控件里到底是什么（属性面板的表头 + 生成代码的用法） */
function qdsgTextLabel(type) {
  if (type === '下拉框' || type === '列表框') return '各项(| 分隔)';
  if (type === '表格') return '表头(| 分隔)';
  if (type === '树') return '表头';
  if (type === '选项卡') return '各页标题(| 分隔)';
  if (type === '分组框') return '标题';
  if (type === '链接') return '显示文字';
  if (type === '编辑框' || type === '文本域') return '初始内容';
  return '文字';
}
/* 控件本体的预览标签（Qt 外观近似） */
function qdsgInner(it) {
  const x = dsgEsc(it.text);
  const opts = (t) => String(t || '').split('|').filter((s) => s !== '')
    .map((s) => '<option>' + dsgEsc(s) + '</option>').join('');
  switch (it.type) {
    case '按钮': return '<button>' + x + '</button>';
    case '标签': return '<label>' + x + '</label>';
    case '编辑框':
      return '<input type="' + (it.password ? 'password' : 'text') + '" value="' + x + '">';
    case '文本域': return '<textarea>' + x + '</textarea>';
    case '进度条': return '<progress max="100" value="40"></progress>';
    case '复选框':
      return '<label class="qChk"><input type="checkbox"' + (it.checked ? ' checked' : '')
        + '>' + x + '</label>';
    case '单选框':
      return '<label class="qChk"><input type="radio"' + (it.checked ? ' checked' : '')
        + '>' + x + '</label>';
    case '下拉框': return '<select>' + opts(it.text) + '</select>';
    case '列表框': return '<select size="6">' + opts(it.text) + '</select>';
    case '滑块': return '<input type="range" min="0" max="100" value="40">';
    case '微调': return '<input type="number" value="0">';
    case '表格': {
      const rows = it.rows > 0 ? it.rows : 3;
      const cols = it.cols > 0 ? it.cols : 2;
      const heads = String(it.text || '').split('|');
      let h = '<table class="qTable"><thead><tr>';
      for (let c = 0; c < cols; c++) h += '<th>' + dsgEsc(heads[c] || ('列' + (c + 1))) + '</th>';
      h += '</tr></thead><tbody>';
      const show = Math.max(1, Math.min(rows, 8));
      for (let r = 0; r < show; r++) {
        h += '<tr>';
        for (let c = 0; c < cols; c++) h += '<td></td>';
        h += '</tr>';
      }
      return h + '</tbody></table>';
    }
    case '树': return '<ul class="qTree"><li>' + (x || '根节点') + '</li><li>子项</li></ul>';
    case '分组框': return '<fieldset><legend>' + x + '</legend></fieldset>';
    case '选项卡': {
      const ps = String(it.text || '').split('|').filter((s) => s !== '');
      const list = ps.length ? ps : ['页1'];
      let h = '<div class="qTabs"><div class="qTabBar">';
      list.forEach((p, i) => {
        h += '<div class="qTab' + (i === 0 ? ' active' : '') + '">' + dsgEsc(p) + '</div>';
      });
      return h + '</div><div class="qTabBody"></div></div>';
    }
    case '容器': return '<div class="qBox"></div>';
    case '滚动区': return '<div class="qScroll"></div>';
    case '分隔线': return it.vertical ? '<div class="qVline"></div>' : '<hr class="qHline">';
    case '图片': return '<div class="qImg">图片</div>';
    case '链接': return '<a href="#">' + x + '</a>';
    default: return '<div class="qBox"></div>';
  }
}

function qdsgStatus() {
  const el = $('qdsgStatus');
  if (el) el.textContent = QD.items.length + ' 个控件' + (QD.sel ? '（已选中）' : '');
}

/* 重画 Qt 画布（画布一动 → 设计可能变了 → 触发一次设计落盘；内容相同不会真写盘） */
function qdsgRender() {
  qdsgDesignTouch();
  const stage = $('qdsgStage');
  if (!stage) return;
  stage.style.width = QD.w + 'px';
  stage.style.height = QD.h + 'px';
  stage.innerHTML = '';
  if (!QD.items.length) {
    const tip = document.createElement('div');
    tip.className = 'dsgEmpty';
    tip.textContent = '把左边的 Qt 控件拖到这里（也可以单击工具箱里的控件）';
    stage.appendChild(tip);
  }
  QD.items.forEach((it) => {
    const box = document.createElement('div');
    box.className = 'dsgItem' + (QD.sel === it.id ? ' sel' : '');
    box.dataset.id = it.id;
    box.style.cssText = 'left:' + it.x + 'px;top:' + it.y + 'px;width:' + it.w
      + 'px;height:' + it.h + 'px';
    box.innerHTML = qdsgInner(it);
    const inner = box.firstElementChild;
    if (inner) {
      inner.style.cssText += ';width:100%;height:100%;box-sizing:border-box;';
      if (it.fontSize) inner.style.fontSize = (parseInt(it.fontSize, 10) || 12) + 'px';
      if (it.bold) inner.style.fontWeight = 'bold';
      if (it.color) inner.style.color = it.color;
      if (it.bg) inner.style.background = it.bg;
    }
    if (QD.sel === it.id) {
      const h = document.createElement('i');
      h.className = 'dsgHandle';
      h.dataset.handle = '1';
      box.appendChild(h);
    }
    stage.appendChild(box);
  });
  qdsgStatus();
}

/* ---------- 右侧「窗口 / 控件」页签（与 Sciter 版同一套写法） ---------- */
function qdsgShowTab(which) {
  const win = which !== 'ctl';
  const tw = $('qdsgTabWin'), tc = $('qdsgTabCtl');
  if (tw) tw.classList.toggle('on', win);
  if (tc) tc.classList.toggle('on', !win);
  if ($('qdsgWinPane')) $('qdsgWinPane').classList.toggle('hidden', !win);
  if ($('qdsgCtlPane')) $('qdsgCtlPane').classList.toggle('hidden', win);
}
/* 把「窗口属性」里的**窗口背景色 / 文字色 / 字体 / 字号**立刻反映到 Qt 画布上（所见即所得）——
   与 Sciter 版的 dsgApplyWinPreview() 一个套路：往画布元素上写 CSS 变量（见 style.css 的 .qtStage）。
   改一下马上变，不用关掉设计器再打开；打开设计器、载入设计、导入工程设计、导入 Qt 设计后也会调一次。
   底色选了深的、又没单独设文字色 → 文字自动翻成浅色（免得深字压深底）。
   控件自己的面色（按钮 / 输入框 / 表格底）不动 —— Qt 里窗口置底色也不会把子控件刷成深色。 */
function qdsgApplyWinPreview() {
  const st = $('qdsgStage');
  if (!st) return;
  const bg = QD.bg || '#f0f0f0';
  const dark = dsgIsDark(bg);
  st.style.setProperty('--qcv-bg', bg);
  st.style.setProperty('--qcv-fg', QD.fg || (dark ? '#f0f0f0' : '#202020'));
  st.style.setProperty('--qcv-dim', dark ? 'rgba(255,255,255,.62)' : '#6a6a6a');
  st.style.setProperty('--qcv-line', dark ? 'rgba(255,255,255,.38)' : '#adadad');
  // 字体 / 字号：没填就把变量删掉，CSS 里退回默认（与以前完全一致）
  const setVar = (k, v) => { if (v) st.style.setProperty(k, v); else st.style.removeProperty(k); };
  setVar('--qcv-font', QD.font ? ("'" + QD.font + "', sans-serif") : '');
  setVar('--qcv-fontsize', QD.fontSize ? (QD.fontSize + 'px') : '');
}

/* 「窗口」页签绑定。Qt 版能给的选项只有 lib\qt.class 真实封装的那几个，
   所以这里比 Sciter 版少（没有最大化/最小化/全屏/置顶/背景与字体）。 */
function qdsgBindWinPane() {
  const txt = (id, k) => {
    const el = $(id);
    if (el) el.oninput = () => { QD[k] = el.value; qdsgApplyWinPreview(); qdsgDesignTouch(); };
  };
  const chk = (id, k) => {
    const el = $(id);
    if (el) el.onchange = () => { QD[k] = el.checked; qdsgApplyWinPreview(); qdsgDesignTouch(); };
  };
  const num = (id, k, min, max, redraw) => {
    const el = $(id);
    if (!el) return;
    el.oninput = () => {
      const v = parseInt(el.value, 10);
      if (!isFinite(v)) return;
      QD[k] = Math.max(min, Math.min(max, v));
      if (redraw) qdsgRender();
      qdsgApplyWinPreview();
      qdsgDesignTouch();
    };
  };
  /* 可选数字：清空就存 ''（表示「不设置」→ 不生成那行代码），否则按区间夹住 */
  const opt = (id, k, min, max) => {
    const el = $(id);
    if (!el) return;
    el.oninput = () => {
      const t = el.value.trim();
      if (t === '') { QD[k] = ''; qdsgApplyWinPreview(); qdsgDesignTouch(); return; }
      const v = parseInt(t, 10);
      QD[k] = isFinite(v) ? Math.max(min, Math.min(max, v)) : '';
      qdsgApplyWinPreview();
      qdsgDesignTouch();
    };
  };
  txt('qdsgWinTitle', 'title');
  txt('qdsgWinIcon', 'icon');
  txt('qdsgWinBg', 'bg');
  txt('qdsgWinFg', 'fg');
  /* 颜色：取色器在颜色编辑框上方 —— 选完自动填进编辑框；
     编辑框里写合法色值也回填取色器（写别的写法不拦，照样进生成代码） */
  const colorPair = (pickId, txtId, k) => {
    const p = $(pickId), t = $(txtId);
    if (!p || !t) return;
    p.oninput = () => { t.value = p.value; QD[k] = p.value; qdsgApplyWinPreview(); qdsgDesignTouch(); };
    t.addEventListener('input', () => {
      const hex = dsgHexOf(t.value);
      if (hex) p.value = hex;
      qdsgDesignTouch();
    });
  };
  colorPair('qdsgWinBgPick', 'qdsgWinBg', 'bg');
  colorPair('qdsgWinFgPick', 'qdsgWinFg', 'fg');
  txt('qdsgWinFont', 'font');
  txt('qdsgWinQss', 'qss');
  num('qdsgWinW', 'w', 120, 4000, true);
  num('qdsgWinH', 'h', 120, 4000, true);
  opt('qdsgWinX', 'x', -20000, 20000);
  opt('qdsgWinY', 'y', -20000, 20000);
  opt('qdsgWinMinW', 'minW', 0, 20000);
  opt('qdsgWinMinH', 'minH', 0, 20000);
  opt('qdsgWinFontSize', 'fontSize', 6, 72);
  opt('qdsgWinOpacity', 'opacity', 0, 100);
  chk('qdsgWinCenter', 'center');
  chk('qdsgWinMax', 'max'); chk('qdsgWinMin', 'min'); chk('qdsgWinFull', 'full');
  chk('qdsgWinHide', 'hide');
  chk('qdsgWinBold', 'bold');
  chk('qdsgWinTop', 'top'); chk('qdsgWinNoFrame', 'noFrame');
  chk('qdsgWinResizable', 'resizable');
  chk('qdsgWinBtnMax', 'btnMax'); chk('qdsgWinBtnMin', 'btnMin');
  chk('qdsgGenVars', 'genVars'); chk('qdsgGenLoop', 'genLoop');
  if ($('qdsgTabWin')) $('qdsgTabWin').onclick = () => qdsgShowTab('win');
  if ($('qdsgTabCtl')) $('qdsgTabCtl').onclick = () => qdsgShowTab('ctl');
  qdsgSyncWinPane();
}
function qdsgSyncWinPane() {
  const set = (id, v) => { const el = $(id); if (el) el.value = (v == null ? '' : v); };
  const chk = (id, v) => { const el = $(id); if (el) el.checked = !!v; };
  // 取色器：值只能是 #rrggbb，认不出（空 / 写了 red）就用默认色占位
  const setPick = (id, v, dft) => { const el = $(id); if (el) el.value = dsgHexOf(v) || dft; };
  set('qdsgWinTitle', QD.title); set('qdsgWinW', QD.w); set('qdsgWinH', QD.h);
  set('qdsgWinIcon', QD.icon);
  set('qdsgWinX', QD.x); set('qdsgWinY', QD.y);
  set('qdsgWinMinW', QD.minW); set('qdsgWinMinH', QD.minH);
  set('qdsgWinBg', QD.bg); set('qdsgWinFg', QD.fg); set('qdsgWinFont', QD.font);
  setPick('qdsgWinBgPick', QD.bg, '#ffffff');
  setPick('qdsgWinFgPick', QD.fg, '#000000');
  set('qdsgWinFontSize', QD.fontSize); set('qdsgWinOpacity', QD.opacity);
  set('qdsgWinQss', QD.qss);
  chk('qdsgWinCenter', QD.center);
  chk('qdsgWinMax', QD.max); chk('qdsgWinMin', QD.min); chk('qdsgWinFull', QD.full);
  chk('qdsgWinHide', QD.hide);
  chk('qdsgWinBold', QD.bold);
  chk('qdsgWinTop', QD.top); chk('qdsgWinNoFrame', QD.noFrame);
  chk('qdsgWinResizable', QD.resizable);
  chk('qdsgWinBtnMax', QD.btnMax); chk('qdsgWinBtnMin', QD.btnMin);
  chk('qdsgGenVars', QD.genVars); chk('qdsgGenLoop', QD.genLoop);
  qdsgApplyWinPreview();     // 打开设计器 / 载入设计 / 导入工程设计后，画布窗口底色·文字色也要跟上
}

/* 属性面板：通用字段 + 按控件类型出现的专属字段 */
function qdsgRenderProps() {
  const box = $('qdsgCtlPane');
  if (!box) return;
  const it = QD.items.find((x) => x.id === QD.sel);
  if (!it) {
    box.innerHTML = '<div class="dsgTip">先在画布上选中一个控件，这里会列出它的属性。<br><br>'
      + '常用操作：<br>· 拖动 = 移动<br>· 右下角小方块 = 缩放<br>'
      + '· 方向键 = 微调 1px（Shift = 10px）<br>· Delete = 删除<br>'
      + '· 点画布空白处 = 切回「窗口」设置<br><br>'
      + '生成的代码是 <b>Qt 控件库</b>的句柄式写法（<span class="dsgCode">lib\\qt.class</span>），'
      + '画布是 Qt 外观的近似预览。</div>';
    return;
  }
  const row = (label, key, type, extra) => {
    const v = type === 'number' ? (it[key] || 0) : (it[key] || '');
    return '<div class="dsgRow"><label>' + label + '</label>'
      + '<input data-k="' + key + '" type="' + (type || 'text') + '" value="' + dsgEsc(v) + '"'
      + (extra || '') + '></div>';
  };
  const chk = (label, key) => '<div class="dsgRow"><label>' + label + '</label>'
    + '<input data-k="' + key + '" type="checkbox"' + (it[key] ? ' checked' : '')
    + ' style="flex:none;width:auto"></div>';

  let h = '<div class="dsgPTitle">属性 · ' + dsgEsc(it.type) + ' <span class="dsgCode">'
    + dsgEsc(it.name) + '</span></div>';
  h += row('名称', 'name');
  if (!QD_NAME_RE.test(it.name || '') || it.name === it.type) {
    h += '<div class="dsgTip" style="color:var(--danger)">'
      + (it.name === it.type
        ? '⚠️ 变量名不能与控件类型同名（编译器会把「' + dsgEsc(it.name)
          + '」当类型，报「没有类函数」）。请改成 ' + dsgEsc(it.type) + '1 这样。'
        : '⚠️ 名称只能用中英文 / 数字 / 下划线，且不能以数字开头。')
      + '</div>';
  }
  h += '<div class="dsgRow"><label>' + qdsgTextLabel(it.type) + '</label>'
    + '<input data-k="text" type="text" value="' + dsgEsc(it.text) + '"></div>';

  // 专属字段
  if (it.type === '编辑框') h += chk('密码', 'password');
  if (it.type === '复选框' || it.type === '单选框') h += chk('默认选中', 'checked');
  if (it.type === '滑块') h += chk('横向', 'horizontal');
  if (it.type === '分隔线') h += chk('竖线', 'vertical');
  if (it.type === '表格') {
    h += row('行数', 'rows', 'number', ' min="0"');
    h += row('列数', 'cols', 'number', ' min="0"');
  }
  if (it.type === '图片') h += row('图片文件', 'file', 'text', ' placeholder="C:\\\\pic\\\\a.png"');
  if (it.type === '链接') h += row('网址', 'url', 'text', ' placeholder="https://…"');
  if (it.type === '选项卡') {
    h += '<div class="dsgTip">每一页会自动生成一个「容器」当页面，再调用 '
      + '<span class="dsgCode">选项卡.加页(选项卡, 页容器, "标题")</span> —— '
      + '第 2 个参数是<b>页面控件句柄</b>，不是页号（传页号会让 Qt 卡死）。</div>';
  }

  h += '<div class="dsgPTitle" style="margin-top:12px">位置与大小</div>';
  h += row('横', 'x', 'number') + row('纵', 'y', 'number');
  h += row('宽', 'w', 'number') + row('高', 'h', 'number');

  h += '<div class="dsgPTitle" style="margin-top:12px">字体与颜色</div>';
  h += row('字号', 'fontSize', 'number', ' readonly class="fpick" min="6" max="72" title="点击选择字号（带预览）"');
  h += chk('加粗', 'bold');
  h += dsgColorRow('文字色', 'color', it.color, '#202020', '#202020');
  h += dsgColorRow('底色', 'bg', it.bg, '#fdfdfd', '#fdfdfd');
  h += row('QSS', 'qss', 'text', ' placeholder="border-radius:4px"');
  h += row('提示', 'tip', 'text', ' placeholder="鼠标悬停提示"');
  h += '<div class="dsgTip" style="margin-top:6px">QSS 与提示只在运行时生效，画布不参与渲染。</div>';
  h += '<div class="dsgTip" style="margin-top:8px">生成的第一行：<br><span class="dsgCode">'
    + dsgEsc(qdsgLines(it)[0] || '') + '</span></div>';
  box.innerHTML = h;

  /* 写入一个设计字段（属性面板的编辑框与取色器共用同一套赋值 + 重绘） */
  const setKey = (k, val, kind) => {
    const cur = QD.items.find((x) => x.id === QD.sel);
    if (!cur) return;
    if (kind === 'checkbox') {
      cur[k] = !!val;
    } else if (kind === 'number') {
      let v = parseInt(val, 10) || 0;
      if (k === 'w' && v < 8) v = 8;
      if (k === 'h' && v < 8) v = 8;
      cur[k] = v;
    } else {
      cur[k] = String(val == null ? '' : val);
    }
    qdsgRender();                    // 只重画画布，属性面板保持焦点
    // 属性改动**不**即时写代码：等点「保存到工程」时统一写回（与窗口设置、拖动一致）
  };
  box.querySelectorAll('input[data-k]').forEach((inp) => {
    const k = inp.dataset.k;
    const kind = inp.type === 'checkbox' ? 'checkbox' : (inp.type === 'number' ? 'number' : 'text');
    inp.oninput = () => {
      setKey(k, kind === 'checkbox' ? inp.checked : inp.value, kind);
      // 颜色编辑框里写了合法颜色 → 同一行的取色器跟着变
      const pick = box.querySelector('input[data-c="' + k + '"]');
      if (pick) { const hex = dsgHexOf(inp.value); if (hex) pick.value = hex; }
    };
  });
  // 取色器：选色 → 自动填进下面那个颜色编辑框（并同步设计字段）
  box.querySelectorAll('input[data-c]').forEach((pick) => {
    pick.oninput = () => {
      const k = pick.dataset.c;
      const tx = box.querySelector('input[data-k="' + k + '"]');
      if (tx) tx.value = pick.value;
      setKey(k, pick.value, 'text');
    };
  });
}

function qdsgSelect(id) {
  QD.sel = id || '';
  qdsgShowTab(id ? 'ctl' : 'win');      // 选中控件 → 「控件」页签；点空白 → 回「窗口」
  qdsgRender();
  qdsgRenderProps();
}
function qdsgNextName(type) {
  let n = 0;
  const used = new Set(QD.items.map((x) => x.name));
  do { n++; } while (used.has(type + n));
  return type + n;
}
function qdsgAdd(type, x, y) {
  const info = qdsgTypeInfo(type) || [type, 120, 30, ''];
  QD.seq = (QD.seq || 0) + 1;
  const off = (QD.items.length % 8) * 14;
  const it = {
    id: 'q' + Date.now() + '_' + QD.seq,
    type,
    name: qdsgNextName(type),
    text: info[3] || '',
    w: info[1], h: info[2],
    x: (typeof x === 'number') ? Math.max(0, Math.round(x)) : 20 + off,
    y: (typeof y === 'number') ? Math.max(0, Math.round(y)) : 20 + off,
    fontSize: 12, bold: false, color: '', bg: '', qss: '', tip: '',
    password: false, checked: false, horizontal: true, vertical: false,
    rows: 3, cols: 2, file: '', url: '',
  };
  if (type === '滑块') it.horizontal = true;
  if (type === '分隔线') it.vertical = false;
  QD.items.push(it);
  qdsgSelect(it.id);
  dsgSyncSchedule('qt');                // 加控件 → 代码同步加一行
  dsgFocusStage('qdsgStage');           // 焦点留在画布上，别被代码编辑器抢走
  return it;
}
function qdsgDelete() {
  if (!QD.sel) { toast('先在画布上选中一个控件'); return; }
  QD.items = QD.items.filter((x) => x.id !== QD.sel);
  qdsgSelect('');
  // 删控件只在画布（预览）上生效，**不即时写代码** —— 要写进代码请点「保存到工程」
  dsgFocusStage('qdsgStage');
}
function qdsgClear() {
  if (!QD.items.length) return;
  if (!confirm('清空画布上的全部控件？')) return;
  QD.items = [];
  qdsgSelect('');
  // 清空同理：只在画布上生效，点「保存到工程」时才写回代码
  dsgFocusStage('qdsgStage');
}
function qdsgNudge(dx, dy) {
  const it = QD.items.find((x) => x.id === QD.sel);
  if (!it) return;
  it.x = Math.max(0, it.x + dx);
  it.y = Math.max(0, it.y + dy);
  qdsgRender();
  qdsgRenderProps();
  // 位置属于「属性」：不即时写代码，点「保存到工程」时统一写回
}

/* ---------- 生成云易代码（严格按 lib\qt.class 的签名） ---------- */
/* 单个控件对应的一串语句（新建 → 专属设置 → 位置 → 字体/颜色/QSS/提示） */
function qdsgLines(it) {
  const h = it.name;
  const t = it.text || '';
  const out = [];
  switch (it.type) {
    case '按钮': out.push(h + ' = 按钮.新建(主窗, ' + dsgStr(t) + ')'); break;
    case '标签': out.push(h + ' = 标签.新建(主窗, ' + dsgStr(t) + ')'); break;
    case '编辑框':
      out.push(h + ' = 编辑框.新建(主窗)');
      if (t) out.push('编辑框.置文本(' + h + ', ' + dsgStr(t) + ')');
      if (it.password) out.push('编辑框.置密码(' + h + ', 1)');
      break;
    case '文本域':
      out.push(h + ' = 文本域.新建(主窗)');
      if (t) out.push('文本域.置文本(' + h + ', ' + dsgStr(t) + ')');
      break;
    case '进度条':
      out.push(h + ' = 进度条.新建(主窗)');
      out.push('进度条.置范围(' + h + ', 0, 100)');
      break;
    case '复选框':
    case '单选框':
      out.push(h + ' = ' + it.type + '.新建(主窗, ' + dsgStr(t) + ')');
      if (it.checked) out.push(it.type + '.置选中(' + h + ', 1)');
      break;
    case '下拉框':
    case '列表框':
      out.push(h + ' = ' + it.type + '.新建(主窗)');
      if (t) out.push(it.type + '.加多项(' + h + ', ' + dsgStr(t) + ')');
      break;
    case '表格': {
      const rows = it.rows > 0 ? it.rows : 3;
      const cols = it.cols > 0 ? it.cols : 2;
      out.push(h + ' = 表格.新建(主窗, ' + rows + ', ' + cols + ')');
      if (t) out.push('表格.置表头(' + h + ', ' + dsgStr(t) + ')');
      break;
    }
    case '树':
      out.push(h + ' = 树.新建(主窗)');
      if (t) out.push('树.置表头(' + h + ', ' + dsgStr(t) + ')');
      break;
    case '滑块':
      out.push(h + ' = 滑块.新建(主窗, ' + (it.horizontal ? 1 : 0) + ')');
      out.push('滑块.置范围(' + h + ', 0, 100)');
      break;
    case '微调':
      out.push(h + ' = 微调.新建(主窗)');
      out.push('微调.置范围(' + h + ', 0, 100)');
      break;
    case '分组框': out.push(h + ' = 分组框.新建(主窗, ' + dsgStr(t) + ')'); break;
    case '选项卡': {
      // ⚠️ 选项卡.加页(选项卡, 页面, 标题) 的第 2 个参数是**页面控件的句柄**，
      //    不是页号！页面要先用「容器.新建(父)」单独建一个再交进来。
      //    传页号（0/1/2）会命中控件池里别的控件 —— 传到自己身上时
      //    Qt 会 addTab(t, t) 自我嵌套并**死循环**，表现是「程序活着但不显示窗口」。
      out.push(h + ' = 选项卡.新建(主窗)');
      const ps = t.split('|').filter((s) => s !== '');
      (ps.length ? ps : ['页1']).forEach((p, i) => {
        const pv = h + '_页' + (i + 1);
        out.push("' 第 " + (i + 1) + ' 页：先建一个容器当页面，再用 加页 交给选项卡');
        out.push(pv + ' = 容器.新建(主窗)');
        out.push('选项卡.加页(' + h + ', ' + pv + ', ' + dsgStr(p) + ')');
      });
      break;
    }
    case '容器': out.push(h + ' = 容器.新建(主窗)'); break;
    case '滚动区': out.push(h + ' = 滚动区.新建(主窗)'); break;
    case '分隔线':
      out.push(h + ' = 分隔线.' + (it.vertical ? '新建竖线(主窗)' : '新建(主窗)'));
      break;
    case '图片':
      out.push(h + ' = 图片.新建(主窗, ' + dsgStr(it.file || '') + ')');
      break;
    case '链接':
      out.push(h + ' = 链接.新建(主窗, ' + dsgStr(t) + ', ' + dsgStr(it.url || '') + ')');
      break;
    default:
      out.push(h + ' = 容器.新建(主窗)');
  }
  out.push('控件.置位置(' + h + ', ' + it.x + ', ' + it.y + ', ' + it.w + ', ' + it.h + ')');
  const fs = parseInt(it.fontSize, 10) || 0;
  if (fs && (fs !== 12 || it.bold)) {
    out.push('控件.置字体(' + h + ', ' + fs + ', ' + (it.bold ? 1 : 0) + ')');
  }
  if (it.color) out.push('控件.置字色(' + h + ', ' + dsgStr(it.color) + ')');
  if (it.bg) out.push('控件.置底色(' + h + ', ' + dsgStr(it.bg) + ')');
  if (it.qss) out.push('控件.置样式(' + h + ', ' + dsgStr(it.qss) + ')');
  if (it.tip) out.push('控件.置提示(' + h + ', ' + dsgStr(it.tip) + ')');
  return out;
}

function qdsgGenerate() {
  const L = [];
  const title = (QD.title || '').trim() || '我的程序';
  const genVars = QD.genVars !== false;
  const genLoop = QD.genLoop !== false;
  const center = !!QD.center;
  const icon = (QD.icon || '').trim();
  L.push("' ══════════ 由「Qt 界面设计」生成 ══════════");
  L.push("' 控件库：lib\\qt.class（侧栏「UI → Qt」栏）");
  L.push("' 运行前把 云易Qt.dll + Qt6 运行库 + platforms\\qwindows.dll 拷到 exe 同目录：");
  L.push("'   tools\\yyqt\\复制运行库.bat \"工程目录\\build\\debug\"（用 IDE 运行时自动拷）");
  L.push("' 要求：窗口程序；架构 x64 / x86 都行（按工程架构自动载入 qt.class 或 qt_x86.class）");
  L.push('');
  if (genVars) {
    L.push('变量 整数型 主窗');
    QD.items.forEach((it) => { qdsgVars(it).forEach((v) => L.push('变量 整数型 ' + v)); });
    L.push('变量 整数型 命中');
    if (genLoop) L.push('变量 整数型 事件类型');
    L.push('');
  }
  L.push('主窗 = 窗口.新建(' + dsgStr(title) + ', ' + QD.w + ', ' + QD.h + ')');
  // 外观：字体名走 QSS（窗口的 置字体 只能给字号/加粗），底色与字色走调色板
  const fontName = (QD.font || '').trim();
  const wbg = (QD.bg || '').trim();
  const wfg = (QD.fg || '').trim();
  if (fontName) L.push('窗口.置样式(主窗, ' + dsgStr("font-family:'" + fontName + "'") + ')');
  if (QD.fontSize !== '' || QD.bold) {
    L.push('窗口.置字体(主窗, ' + (QD.fontSize === '' ? 0 : QD.fontSize)
      + ', ' + (QD.bold ? 1 : 0) + ')');
  }
  if (wbg) L.push('窗口.置底色(主窗, ' + dsgStr(wbg) + ')');
  if (wfg) L.push('窗口.置字色(主窗, ' + dsgStr(wfg) + ')');
  if ((QD.qss || '').trim()) L.push('窗口.置样式(主窗, ' + dsgStr(QD.qss.trim()) + ')');
  if (icon) L.push('窗口.置图标(主窗, ' + dsgStr(icon) + ')');
  // 尺寸限制 / 位置：留空的项不生成（后两个 0 = 不限制最大尺寸）
  if (QD.minW !== '' || QD.minH !== '') {
    L.push('窗口.置大小限制(主窗, ' + (QD.minW === '' ? 0 : QD.minW) + ', '
      + (QD.minH === '' ? 0 : QD.minH) + ', 0, 0)');
  }
  if (QD.x !== '' || QD.y !== '') {
    L.push('窗口.置位置(主窗, ' + (QD.x === '' ? 0 : QD.x) + ', ' + (QD.y === '' ? 0 : QD.y) + ')');
  }
  if (center) L.push('窗口.居中(主窗)');
  // 窗口行为（改窗口标志的两个，封装内部会自动重新显示）
  if (QD.top) L.push('窗口.置置顶(主窗, 1)');
  if (QD.noFrame) L.push('窗口.置无边框(主窗, 1)');
  if (QD.resizable === false) L.push('窗口.置可调边框(主窗, 0)');
  if (QD.btnMax === false) L.push('窗口.置最大化按钮(主窗, 0)');
  if (QD.btnMin === false) L.push('窗口.置最小化按钮(主窗, 0)');
  if (QD.opacity !== '' && parseInt(QD.opacity, 10) !== 100) {
    L.push('窗口.置透明度(主窗, ' + QD.opacity + ')');
  }
  QD.items.forEach((it) => {
    L.push('');
    qdsgLines(it).forEach((ln) => L.push(ln));
  });
  // 窗口收尾：显示（或按设置先隐藏）。放在 genLoop 之外，不生成主循环时也要有。
  L.push('');
  if (QD.hide) {
    L.push("窗口.隐藏(主窗)          ' 按窗口设置：先不显示，需要时自己调 窗口.显示(主窗)");
  } else {
    L.push('窗口.显示(主窗)');
    if (QD.max) L.push('窗口.最大化(主窗)');
    if (QD.min) L.push('窗口.最小化(主窗)');
    if (QD.full) L.push('窗口.全屏(主窗)');
  }

  if (genLoop) {
    const hot = QD.items.filter((x) => ['按钮', '复选框', '单选框', '下拉框', '列表框', '编辑框',
      '文本域', '链接', '滑块', '微调', '选项卡', '树', '表格'].indexOf(x.type) >= 0);
    L.push('');
    L.push('当循环 窗口.可见(主窗) != 0');
    L.push('    控件.处理事件()');
    L.push('    命中 = 控件.取事件()          \' 取到的是「控件句柄」（整数型），用变量名比');
    L.push('    如果 (命中 != 0)');
    L.push('        事件类型 = 事件.取类型()');
    L.push("        ' 事件类型：1 点击 2 文本改变 3 值改变 4 选中改变 5 窗口关闭 6 按键");
    L.push("        '          7 双击 8 定时器 9 菜单项 10 回车 11 勾选改变 12 单元格改变");
    L.push("        ' 附带内容用 事件.取文本()；队列还剩几条看 事件.取数量()");
    if (hot.length) {
      L.push("        ' 可用的控件句柄（按变量名比较）：");
      hot.forEach((it) => L.push("        '   " + it.name + '（' + it.type + '）'));
      L.push('        如果 (命中 = ' + hot[0].name + ')');
      L.push("            ' TODO: 在这里写 " + hot[0].name + ' 的处理逻辑');
      L.push('            事件类型 = 事件.取类型()');
      L.push('        结束如果');
    }
    L.push('    结束如果');
    L.push('    延时(10)');
    L.push('结束循环');
  }
  L.push('');
  return L.join('\n');
}

/* 生成前检查：变量名必须合法、且不能与控件类型同名（否则编译器会把它当类型） */
function qdsgProblems() {
  const bad = [];
  const seen = {};
  QD.items.forEach((it) => {
    if (!QD_NAME_RE.test(it.name || '')) {
      bad.push('「' + (it.name || '') + '」（' + it.type + '）名称不合法：只能用中英文 / 数字 / 下划线，且不能以数字开头');
    } else if (it.name === it.type) {
      bad.push('「' + it.name + '」变量名与控件类型同名 —— 编译器会把它当类型，请改成 '
        + it.type + '1 这样');
    }
    if (seen[it.name]) bad.push('变量名重复：' + it.name);
    seen[it.name] = true;
  });
  return bad;
}

/* 一个控件会用到哪些变量名（选项卡的每一页都要一个「容器」当页面） */
function qdsgVars(it) {
  const vs = [it.name];
  if (it.type === '选项卡') {
    const ps = String(it.text || '').split('|').filter((s) => s !== '');
    const n = ps.length || 1;
    for (let i = 1; i <= n; i++) vs.push(it.name + '_页' + i);
  }
  return vs;
}

/* ---------- Qt 设计器：导入工程设计 / 就地替换（与 Sciter 版同一套做法） ---------- */

/* Qt 界面语句里可能出现的「宿主」名（控件类型 + 几个通用宿主） */
const QDSG_HOSTS = ['控件', '窗口', '事件', '按钮', '标签', '编辑框', '输入框', '文本域', '进度条', '复选框',
  '单选框', '下拉框', '列表框', '表格', '树', '滑块', '微调', '分组框', '选项卡', '容器',
  '滚动区', '分隔线', '图片', '链接', '剪贴板', '布局', '对话框', '定时器', '菜单'];

function qdsgIsCtl(s) {
  const m = /^([^\s.]+)\.([^\s(]+)[ \t]*\(/.exec(s);
  return !!m && QDSG_HOSTS.indexOf(m[1]) >= 0;
}
function qdsgIsAsg(s) {
  const m = /^([A-Za-z_\u4e00-\u9fa5][\w\u4e00-\u9fa5]*)[ \t]*=[ \t]*([^\s.]+)\.([^\s(]+)[ \t]*\(/
    .exec(s);
  if (m && QDSG_HOSTS.indexOf(m[2]) >= 0 && m[3] === '新建') return true;
  return /^变量[ \t]+整数型[ \t]+[\w\u4e00-\u9fa5]+$/.test(s);
}
/* Qt 版的「界面段」（生成标记与 Sciter 版不同） */
function qdsgFindBlock(text) {
  return dsgFindDesignBlock(text, { kind: 'qt', marker: DSG_MARK_QT,
                                    isCtl: qdsgIsCtl, isAsg: qdsgIsAsg });
}

/* 反向解析 Qt 界面代码 → QD 设计模型（qdsgGenerate 的逆运算；认不出的行忽略） */
function qdsgParseDesign(text) {
  const src = String(text || '').replace(/\r\n?/g, '\n');
  if (src.indexOf('窗口.新建(') < 0) return null;
  const out = { items: [], w: 0, h: 0, qss: '', pages: {} };
  const byName = {}, pageNames = [];
  const unq = (s) => {
    const m = /^\s*"((?:[^"\\]|\\.)*)"/.exec(s || '');
    return m ? m[1].replace(/\\(.)/g, '$1') : String(s || '').trim().replace(/^"|"$/g, '');
  };
  const num = (s) => { const n = parseInt(String(s || '').trim(), 10); return isFinite(n) ? n : 0; };
  src.split('\n').forEach((raw) => {
    const s = raw.trim();
    if (!s || s.charAt(0) === "'") return;
    let cm = /^([A-Za-z_\u4e00-\u9fa5][\w\u4e00-\u9fa5]*)[ \t]*=[ \t]*([\u4e00-\u9fa5]+)\.(新建[\u4e00-\u9fa5]*)[ \t]*\(/
      .exec(s);                                // 只有「X = 类型.新建…」才算一个控件
    if (cm) {
      const got = dsgCallArgs(s, cm[0].length - 1);
      const a = got ? dsgSplitArgs(got.args) : [];   // a[0] 是父容器（主窗）
      if (cm[2] === '窗口') {
        out.title = unq(a[0]);
        out.w = num(a[1]) || out.w;
        out.h = num(a[2]) || out.h;
        return;
      }
      const type = ctlType(cm[2]), name = cm[1], kind = cm[3];   // 老代码的「输入框」→「编辑框」
      const def = qdsgTypeInfo(type) || [type, 120, 30, ''];
      const it = { type, name, text: '', x: 0, y: 0, w: def[1], h: def[2],
                   fontSize: 12, bold: false, color: '', bg: '', qss: '', tip: '',
                   password: false, checked: false, horizontal: true, vertical: false,
                   rows: 3, cols: 2, file: '', url: '', hasPos: false };
      if (kind === '新建竖线') it.vertical = true;
      if (['按钮', '标签', '复选框', '单选框', '分组框'].indexOf(type) >= 0) it.text = unq(a[1]);
      else if (type === '链接') { it.text = unq(a[1]); it.url = unq(a[2]); }
      else if (type === '图片') it.file = unq(a[1]);
      else if (type === '表格') { it.rows = num(a[1]) || 3; it.cols = num(a[2]) || 2; }
      else if (type === '滑块') it.horizontal = num(a[1]) !== 0;
      byName[name] = it;
      out.items.push(it);
      return;
    }
    const gm = /^([A-Za-z_\u4e00-\u9fa5][\w\u4e00-\u9fa5]*)\.([\u4e00-\u9fa5]+)[ \t]*\(/.exec(s);
    if (!gm) return;
    const host = gm[1], fn = gm[2];
    const got2 = dsgCallArgs(s, gm[0].length - 1);
    const a = got2 ? dsgSplitArgs(got2.args) : [];
    if (host === '窗口') {                     // ---- 窗口设置 ----
      if (fn === '置样式') {
        const v = unq(a[1]);
        const fm = /font-family\s*:\s*'([^']+)'/.exec(v);
        if (fm) out.font = fm[1];
        else if (v) out.qss = (out.qss ? out.qss + '\n' : '') + v;
      } else if (fn === '置字体') { out.fontSize = num(a[1]) || ''; out.bold = num(a[2]) !== 0;
      } else if (fn === '置底色') { out.bg = unq(a[1]);
      } else if (fn === '置字色') { out.fg = unq(a[1]);
      } else if (fn === '置图标') { out.icon = unq(a[1]);
      } else if (fn === '置大小限制') { out.minW = num(a[1]) || ''; out.minH = num(a[2]) || '';
      } else if (fn === '置位置') { out.x = num(a[1]); out.y = num(a[2]);
      } else if (fn === '居中') { out.center = true;
      } else if (fn === '置置顶') { out.top = num(a[1]) !== 0;
      } else if (fn === '置无边框') { out.noFrame = num(a[1]) !== 0;
      } else if (fn === '置可调边框') { out.resizable = num(a[1]) !== 0;
      } else if (fn === '置最大化按钮') { out.btnMax = num(a[1]) !== 0;
      } else if (fn === '置最小化按钮') { out.btnMin = num(a[1]) !== 0;
      } else if (fn === '置透明度') { out.opacity = num(a[1]);
      } else if (fn === '隐藏') { out.hide = true;
      } else if (fn === '显示') { out.hide = false;
      } else if (fn === '最大化') { out.max = true;
      } else if (fn === '最小化') { out.min = true;
      } else if (fn === '全屏') { out.full = true;
      }
      return;
    }
    if (host === '事件') return;               // 事件循环里的调用，与界面无关
    if (host === '选项卡' && fn === '加页') {   // 页标题 → 选项卡；页面容器不算控件
      const tab = byName[unq(a[0])];
      pageNames.push(unq(a[1]));
      if (tab) out.pages[tab.name] = (out.pages[tab.name] || []).concat([unq(a[2])]);
      return;
    }
    const it = byName[unq(a[0])];
    if (!it) return;
    if (host === '控件') {
      if (fn === '置位置') {
        it.x = num(a[1]); it.y = num(a[2]);
        it.w = num(a[3]) || it.w; it.h = num(a[4]) || it.h;
        it.hasPos = true;
      } else if (fn === '置字体') { it.fontSize = num(a[1]) || 12; it.bold = num(a[2]) !== 0;
      } else if (fn === '置字色') { it.color = unq(a[1]);
      } else if (fn === '置底色') { it.bg = unq(a[1]);
      } else if (fn === '置样式') { it.qss = unq(a[1]);
      } else if (fn === '置提示') { it.tip = unq(a[1]);
      }
      return;
    }
    if (fn === '置文本' && !it.text) { it.text = unq(a[1]); return; }
    if (fn === '加多项' && !it.text) { it.text = unq(a[1]); return; }
    if (fn === '置表头' && !it.text) { it.text = unq(a[1]); return; }
    if (fn === '置密码') { it.password = num(a[1]) !== 0; return; }
    if (fn === '置选中') { it.checked = num(a[1]) !== 0; return; }
  });
  Object.keys(out.pages).forEach((nm) => {          // 选项卡文本 = 各页标题（| 连接）
    const it = byName[nm];
    if (it) it.text = out.pages[nm].join('|');
  });
  out.items = out.items.filter((it) => it.name && pageNames.indexOf(it.name) < 0);
  out.autoPlaced = out.items.filter((it) => !it.hasPos).length;
  let ax = 16, ay = 16, rowH = 0;                   // 没「置位置」的按流式排布
  out.items.forEach((it) => {
    if (it.hasPos) return;
    it.x = ax; it.y = ay;
    ax += it.w + 10;
    rowH = Math.max(rowH, it.h);
    if (out.w && ax + it.w > out.w) { ax = 16; ay += rowH + 10; rowH = 0; }
  });
  out.items.forEach((it) => { delete it.hasPos; });
  return out;
}

/* 「导入工程设计」（Qt 版）：读工程 .yy 里的 Qt 界面代码 → 还原到画布（直接清空再导入，不询问） */
async function qdsgImportDesign() {
  if (!S.project) { toast('请先在上方选择一个工程'); return; }
  const cands = [];
  const cur = activeTab();
  if (cur && cur.project === S.project && /\.yy$/i.test(cur.path || '')) cands.push(cur.path);
  let all = [];
  try { all = projectYyPaths() || []; } catch (e) { all = []; }
  all.forEach((rel) => { if (cands.indexOf(rel) < 0) cands.push(rel); });
  const hits = [];
  for (const rel of cands) {
    const tab = S.tabs.find((t) => t.project === S.project && t.path === rel);
    let text = null;
    if (tab) text = tab.content;
    else {
      try {
        const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
          + '&path=' + encodeURIComponent(rel));
        if (!d.binary) text = d.text;
      } catch (e) { continue; }
    }
    if (text == null) continue;
    const p = qdsgParseDesign(text);
    if (p) hits.push(Object.assign({ file: rel }, p));
  }
  if (!hits.length) {
    toast('当前工程的 .yy 里没有找到 Qt 界面代码（需要含「主窗 = 窗口.新建(…)」）', 5200);
    return;
  }
  hits.sort((a, b) => b.items.length - a.items.length);
  const h = hits[0];
  QD.w = h.w || 760; QD.h = h.h || 520;
  QD.title = h.title || '我的程序';
  QD.icon = h.icon || '';
  if (h.x !== undefined) QD.x = h.x;
  if (h.y !== undefined) QD.y = h.y;
  if (h.minW !== undefined) QD.minW = h.minW;
  if (h.minH !== undefined) QD.minH = h.minH;
  QD.center = !!h.center; QD.max = !!h.max; QD.min = !!h.min; QD.full = !!h.full;
  QD.hide = !!h.hide; QD.top = !!h.top; QD.noFrame = !!h.noFrame;
  if (h.resizable !== undefined) QD.resizable = !!h.resizable;
  if (h.opacity !== undefined) QD.opacity = h.opacity;
  QD.bg = h.bg || ''; QD.fg = h.fg || ''; QD.font = h.font || '';
  QD.fontSize = (h.fontSize === undefined || h.fontSize === '' ? '' : h.fontSize);
  QD.bold = !!h.bold; QD.qss = h.qss || '';
  const base = Date.now();
  QD.items = h.items.map((it, i) => Object.assign({}, it, { id: 'q' + base + '_' + i }));
  QD.seq = QD.items.length;
  qdsgSyncWinPane();
  qdsgSelect('');
  const extra = [];
  if (hits.length > 1) extra.push('工程里还有 ' + (hits.length - 1) + ' 个文件含 Qt 界面代码，已取控件最多的');
  if (h.autoPlaced) extra.push(h.autoPlaced + ' 个控件没有「置位置」，已按流式排布');
  toast('已从「' + h.file + '」识别出 ' + QD.items.length + ' 个 Qt 控件'
    + (extra.length ? '（' + extra.join('；') + '）' : ''), 5600);
}

/* 「保存到工程」（Qt 版）：把画布上的界面**就地替换**工程里原有的 Qt 界面代码 ——
   只动界面段里的「生成行」，其它代码与段内用户自己写的行一行不改。
   工程里还没有界面代码时才插入一份新的。 */
async function qdsgInsert() {
  if (!QD.items.length) { toast('画布上还没有控件'); return; }
  if (!S.project) { toast('请先在上方选择一个工程'); return; }
  qdsgDesignFlush();                     // 保存到工程时把设计（含颜色）也落盘 → 下次打开自动载入
  const bad = qdsgProblems();
  if (bad.length) { toast('生成前请先修好变量名：' + bad[0], 6000); return; }
  const code = qdsgGenerate();
  const n = QD.items.length;
  const suspect = [];
  const tail = (pl) => (pl.hasLoop
    ? '；你写在主循环里的处理逻辑、以及段内你自己写的行都原样保留' : '');
  const OK = (t) => !!t && t.project === S.project && !t.readonly && !t.gen
    && /\.yy$/i.test(t.path || '');

  // ① 当前编辑框：编辑框里的**实时内容**优先
  const t = activeTab();
  const ta = $('codeInput');
  if (ta && t && ta.value !== t.content) t.content = ta.value;
  if (OK(t)) {
    const pl = dsgPlanReplace(t.content, 'qt', code);
    if (pl && pl.suspect) {
      suspect.push(t.path);
    } else if (pl) {
      closeQtDesigner();
      editorReplaceRange(pl.s, pl.e, pl.text);
      toast('已就地更新「' + t.path + '」的 Qt 界面代码（' + n + ' 个控件，原在第 '
        + pl.blk.start + '-' + pl.blk.end + ' 行）' + tail(pl) + '，其它代码未改动', 6400);
      return;
    }
  }
  const other = S.tabs.find((x) => OK(x) && x !== t && qdsgFindBlock(x.content));
  if (other) {
    activateTab(S.tabs.indexOf(other));
    const t2 = activeTab() || other;
    const pl2 = dsgPlanReplace(t2.content, 'qt', code);
    if (pl2 && pl2.suspect) suspect.push(t2.path);
    else if (pl2) {
      closeQtDesigner();
      editorReplaceRange(pl2.s, pl2.e, pl2.text);
      toast('Qt 界面代码在「' + t2.path + '」，已就地更新（' + n + ' 个控件' + tail(pl2) + '）', 6000);
      return;
    }
  }
  const rels = (function () { try { return projectYyPaths() || []; } catch (e) { return []; } })();
  for (const rel of rels) {
    let txt = null;
    try {
      const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
        + '&path=' + encodeURIComponent(rel));
      if (!d.binary) txt = d.text;
    } catch (e) { continue; }
    if (txt == null) continue;
    const norm = txt.replace(/\r\n?/g, '\n');
    const pl = dsgPlanReplace(norm, 'qt', code);
    if (!pl) continue;
    if (pl.suspect) { suspect.push(rel); continue; }
    try {
      await api('POST', '/api/file', { project: S.project, path: rel,
                                       content: norm.slice(0, pl.s) + pl.text + norm.slice(pl.e) });
      closeQtDesigner();
      await refreshTree().catch(() => { });
      toast('Qt 界面代码在「' + rel + '」，已就地更新（' + n + ' 个控件' + tail(pl)
        + '；该文件未打开，已直接写盘）', 6400);
      return;
    } catch (e) { break; }
  }
  if (suspect.length) {
    toast('「' + suspect[0] + '」里那段 Qt 界面代码认不准（段内没找到「主窗 = 窗口.新建(…)」），'
      + '为免重复或错位，既没就地替换也没插入新代码。请确认那段是设计器生成的界面段'
      + '（带「由「Qt 界面设计」生成」标记），或先用「导入工程设计」看看画布', 9000);
    return;
  }
  closeQtDesigner();
  const where = await dsgInsertIntoEntry(code, 'qt').catch(() => null);
  if (where) {
    toast('工程里还没有 Qt 界面代码，已插入到 ' + where + '（' + n + ' 个控件）', 6400);
    return;
  }
  insertAtCursor(code, { block: true });
  toast('工程里还没有 Qt 界面代码，也没找到「子程序 程序入口()」，已在当前光标处插入一份新的（'
    + n + ' 个控件）', 6200);
}

/* 载入 Qt 设计文件。quiet = 打开设计器时自动载入（没工程 / 没保存过设计就悄悄跳过）。
   底部「载入设计」按钮已移除，现在只由「打开 Qt 设计器」自动调用（quiet 恒为 true）。 */
async function qdsgLoad(quiet) {
  if (!S.project) { if (!quiet) toast('请先在上方选择一个工程'); return; }
  if (quiet && !treeHasFile(QDSG_FILE)) { qdsgResetDesign(); return; }
  try {
    const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
      + '&path=' + encodeURIComponent(QDSG_FILE));
    const data = JSON.parse(d.text || '{}');
    if (!data || !Array.isArray(data.items)) throw new Error('不是有效的设计文件');
    const base = {
      id: '', type: '标签', name: '标签1', text: '', x: 10, y: 10, w: 100, h: 24,
      fontSize: 12, bold: false, color: '', bg: '', qss: '', tip: '',
      password: false, checked: false, horizontal: true, vertical: false,
      rows: 3, cols: 2, file: '', url: '',
    };
    QD.items = data.items.map((it, i) => Object.assign({}, base, it,
      { type: ctlType(it.type || base.type), id: 'q' + Date.now() + '_' + i }));
    QD.seq = QD.items.length;
    // 窗体设置：version 2 在 data.win；version 1 老文件是扁平的 w/h/title/center/genLoop
    const w = data.win || {};
    QD.w = Number(w.w != null ? w.w : data.w) || 760;
    QD.h = Number(w.h != null ? w.h : data.h) || 520;
    if (w.title != null) QD.title = w.title;
    else if (data.title != null) QD.title = data.title;
    if (w.icon != null) QD.icon = w.icon;
    if (w.center != null) QD.center = !!w.center;
    else if (data.center != null) QD.center = data.center === true;
    QD.hide = !!w.hide;
    // 后来新增的窗口设置：老设计文件里没有这些键，用 !== undefined 判断，缺就保持默认
    const numOrBlank = (v) => (v === '' || v == null ? '' : (isFinite(Number(v)) ? Number(v) : ''));
    if (w.x !== undefined) QD.x = numOrBlank(w.x);
    if (w.y !== undefined) QD.y = numOrBlank(w.y);
    if (w.minW !== undefined) QD.minW = numOrBlank(w.minW);
    if (w.minH !== undefined) QD.minH = numOrBlank(w.minH);
    if (w.max !== undefined) QD.max = !!w.max;
    if (w.min !== undefined) QD.min = !!w.min;
    if (w.full !== undefined) QD.full = !!w.full;
    if (w.bg !== undefined) QD.bg = w.bg;
    if (w.fg !== undefined) QD.fg = w.fg;
    if (w.font !== undefined) QD.font = w.font;
    if (w.fontSize !== undefined) QD.fontSize = numOrBlank(w.fontSize);
    if (w.bold !== undefined) QD.bold = !!w.bold;
    if (w.opacity !== undefined) QD.opacity = numOrBlank(w.opacity);
    if (w.qss !== undefined) QD.qss = w.qss;
    if (w.top !== undefined) QD.top = !!w.top;
    if (w.noFrame !== undefined) QD.noFrame = !!w.noFrame;
    if (w.resizable !== undefined) QD.resizable = !!w.resizable;
    if (w.genVars != null) QD.genVars = !!w.genVars;
    if (w.genLoop != null) QD.genLoop = !!w.genLoop;
    else if (data.genLoop != null) QD.genLoop = data.genLoop !== false;
    qdsgSyncWinPane();
    qdsgSelect('');
    QD_AUTO.last = qdsgDesignJson();         // 刚载入 = 与磁盘一致：没改动就不回写
    if (!quiet) toast('已载入 Qt 设计（' + QD.items.length + ' 个控件）');
  } catch (e) {
    // 打开设计器时自动载入：本工程还没有 Qt 设计文件 → 画布重置为空
    if (quiet) { qdsgResetDesign(); return; }
    toast('载入失败：' + e.message + '（若还没保存过设计，直接拖控件即可）', 4200);
  }
}

function closeQtDesigner() {
  qdsgDesignFlush();                     // 关掉前把设计（含颜色）落盘，下次打开自动载入即可还原
  const m = $('qdsgMask');
  if (m) m.classList.add('hidden');
}

function openQtDesigner() {
  const mask = $('qdsgMask');
  if (!mask) return;
  closeDesigner();                       // 两个设计器不并存
  const tb = $('qdsgToolbox');
  tb.innerHTML = '';
  QDSG_TYPES.forEach(([cat, list]) => {
    const c = document.createElement('div');
    c.className = 'dsgCat';
    c.textContent = cat;
    tb.appendChild(c);
    list.forEach(([type]) => {
      const b = document.createElement('div');
      b.className = 'dsgTool';
      b.textContent = type;
      b.draggable = true;
      b.title = '拖到画布上新建「' + type + '」（' + type + '.新建）；也可以直接单击';
      b.ondragstart = (e) => {
        try { e.dataTransfer.setData('text/plain', type); } catch (err) { /* 忽略 */ }
        e.dataTransfer.effectAllowed = 'copy';
      };
      b.onclick = () => qdsgAdd(type);
      tb.appendChild(b);
    });
  });
  const stage = $('qdsgStage');
  stage.onmousedown = (e) => {
    const box = e.target.closest && e.target.closest('.dsgItem');
    if (!box) { qdsgSelect(''); return; }
    const it = QD.items.find((x) => x.id === box.dataset.id);
    if (!it) return;
    qdsgSelect(it.id);
    const isHandle = e.target.classList && e.target.classList.contains('dsgHandle');
    const sx = e.clientX, sy = e.clientY;
    const o = { x: it.x, y: it.y, w: it.w, h: it.h };
    QD.drag = (ev) => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (isHandle) {
        it.w = Math.max(8, o.w + dx);
        it.h = Math.max(8, o.h + dy);
      } else {
        it.x = Math.max(0, o.x + dx);
        it.y = Math.max(0, o.y + dy);
      }
      qdsgRender();
    };
    QD.dragEnd = () => { qdsgRenderProps(); qdsgStatus(); };
    e.preventDefault();
  };
  stage.ondragover = (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; };
  stage.ondrop = (e) => {
    e.preventDefault();
    let type = '';
    try { type = e.dataTransfer.getData('text/plain'); } catch (err) { type = ''; }
    if (!type || !qdsgTypeInfo(type)) return;
    const r = stage.getBoundingClientRect();
    const info = qdsgTypeInfo(type);
    qdsgAdd(type, e.clientX - r.left - info[1] / 2, e.clientY - r.top - info[2] / 2);
  };
  // 窗口属性页签（宽/高/标题/图标/启动方式/代码生成 + 页签切换）
  qdsgBindWinPane();
  $('qdsgDel').onclick = qdsgDelete;
  $('qdsgClear').onclick = qdsgClear;
  $('qdsgClose').onclick = closeQtDesigner;
  $('qdsgImport').onclick = qdsgImportDesign;
  $('qdsgGen').onclick = qdsgInsert;
  qdsgShowTab(QD.sel ? 'ctl' : 'win');
  qdsgRender();
  qdsgRenderProps();
  mask.classList.remove('hidden');
  // 打开设计器 = 自动载入当前工程的设计文件（没工程 / 没保存过设计就悄悄跳过）
  qdsgLoad(true);
}

function qdsgGlobalHandlers() {
  document.addEventListener('mousemove', (e) => { if (QD.drag) QD.drag(e); });
  document.addEventListener('mouseup', () => {
    if (QD.drag) { QD.drag = null; if (QD.dragEnd) QD.dragEnd(); }
  });
  document.addEventListener('keydown', (e) => {
    const mask = $('qdsgMask');
    if (!mask || mask.classList.contains('hidden')) return;
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = (tag === 'input' || tag === 'textarea' || tag === 'select');
    if (e.key === 'Escape') { closeQtDesigner(); return; }
    if (typing) return;
    if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); qdsgDelete(); return; }
    const step = e.shiftKey ? 10 : 1;
    if (e.key === 'ArrowLeft') { e.preventDefault(); qdsgNudge(-step, 0); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); qdsgNudge(step, 0); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); qdsgNudge(0, -step); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); qdsgNudge(0, step); }
  });
}

/* ================= 状态 ================= */
const S = {
  env: null,
  corelib: { cats: [], cmds: [] },   // 核心库命令表
  libClass: null,                    // lib 类库缓存 {files, structs, methods, consts, funcs, apis, defs, loading}
                                     // （*.class → 类型/类函数/常量/子程序；*.api → API 声明）
  acIndex: {},                       // 自动完成符号表：name -> {name,kind,sig,insert}
  acList: [],                        // 自动完成符号表（按登记顺序）
  acProjectEntries: [],              // 工程文件解析出的符号 [{name,kind,sig,withCall}]
  branch: '',                        // 当前工程 Git 分支
  sideTab: 'files',                  // 侧栏当前内层选项卡（工程 / 函数 / 核心 / 类 / API / Qt / sciter）
  sideGroup: 'proj',                 // 侧栏外层选项卡：proj=项目 · sys=系统 · ui=UI（Qt/sciter）
  sideTabOfGroup: { proj: 'files', sys: 'lib', ui: 'widgets' },  // 每栏各自记住上次看的内层选项卡
  workspace: '',
  projects: [],
  project: '',          // 当前工程名
  cfg: null,
  tree: [],
  tabs: [],             // {path,name,lang,content,dirty,readonly,project}
  active: -1,
  sess: null,           // {sid,kind,target,nextIdx,done}
  consoleTab: 'console',
  problems: [],
  undefHits: [],        // 工程级：调用了、但整个工程里都没有定义的类库类函数（载入工程时扫描）
  projDefs: null,       // 工程级快照 { byFile: { 路径: {defs:Set, calls:[...]} } }
  saveTimer: null,
  contextMenu: null,
};

/* ================= IDE 快照（阶段性保存 / 刷新恢复） =================
   目标：浏览器刷新后恢复到刷新前的样子——当前工程、打开的标签页（含未保存
   的改动）、正在运行的程序会话。保存在 localStorage（键 yyIdeState）：
   · 触发时机：关键动作后防抖 250ms 保存一次 + 每 15 秒阶段性保存一次 +
     beforeunload 兜底保存；
   · 恢复时机：init() 里读快照 → 预置当前工程 → selectProject 按快照重开
     标签页 → restoreIdeSession 重连运行会话（服务端 SESSIONS 在内存里，
     since=0 可重放全部输出；服务端重启过则会话不在了，静默标记结束）；
   · 智能体不用快照：服务端已持久化会话（.temp/agent/session.json），
     aiInit → aiReconnect 自动恢复并重连进行中的回合。 */
const IDE_STATE_KEY = 'yyIdeState';
let ideRestore = null;          // init() 里读出的快照，等 selectProject 消费
let ideSaveTimer = null;

function ideSnapshot() {
  const tabs = [];
  S.tabs.forEach((t, i) => {
    if (!t || !t.path || (t.project && t.project !== S.project)) return;
    const o = { path: t.path, active: i === S.active, dirty: !!t.dirty };
    // 未保存的内容也存下来（只读/生成页除外），刷新后原样还原
    // （有折叠时存完整源码，刷新回来是展开状态，内容不会少）
    if (t.dirty && !t.readonly && !t.gen && typeof t.content === 'string') o.content = foldFullText(t);
    tabs.push(o);
  });
  return {
    v: 1,
    ts: Date.now(),
    project: S.project || '',
    tabs,
    sess: (S.sess && !S.sess.done) ? { sid: S.sess.sid, kind: S.sess.kind } : null,
    sideGroup: S.sideGroup || 'proj',
    sideTab: S.sideTab || 'files',
  };
}

function saveIdeState() {
  try {
    localStorage.setItem(IDE_STATE_KEY, JSON.stringify(ideSnapshot()));
  } catch (e) { /* 容量超限等：快照保不上就算了，不影响正常使用 */ }
}

function scheduleIdeSave() {
  if (ideSaveTimer) clearTimeout(ideSaveTimer);
  ideSaveTimer = setTimeout(saveIdeState, 250);
}

function loadIdeState() {
  try {
    const raw = localStorage.getItem(IDE_STATE_KEY);
    if (!raw) return null;
    const d = JSON.parse(raw);
    return (d && d.v === 1) ? d : null;
  } catch (e) { return null; }
}

/* 按快照重开标签页（工程已在 selectProject 里载好后调用）。
   返回 true = 至少恢复了一个标签页；false = 全部失败（调用方走默认开 main.yy）。 */
async function restoreTabsFromSnapshot(snap) {
  const list = (snap.tabs || []).filter((t) => t && t.path);
  if (!list.length) return false;
  let activePath = '';
  for (const st of list) {
    let t = null;
    try { t = await openFile(st.path); } catch (e) { /* 文件可能已被删除/改名：跳过 */ }
    if (!t) continue;
    if (st.dirty && typeof st.content === 'string') {
      t.content = st.content;                        // 还原未保存的改动
      t.dirty = t.content !== t.savedContent;
    }
    if (st.active) activePath = st.path;
  }
  if (!S.tabs.length) return false;
  if (activePath) {
    const idx = S.tabs.findIndex((t) => t.path === activePath);
    if (idx >= 0) { activateTab(idx); renderTabs(); renderEditor(); }
  }
  return true;
}

/* 重连刷新前的运行会话：服务端 SESSIONS 还在内存里，从 since=0 重放全部输出 */
function restoreIdeSession(sess) {
  if (!sess || !sess.sid) return;
  const kind = sess.kind === 'test' ? 'test' : 'run';
  ensureConsoleTab('console', '控制台');
  switchConsoleTab('console', true);
  S.sess = { sid: sess.sid, kind, next: 0, done: false };
  con('console', '── 已恢复刷新前的运行会话 #' + sess.sid + '，继续接收输出 ──', 'cl-sys');
  startSessionBtn(kind === 'test' ? '正在测试…' : '正在运行…');
  pollSession();                                     // 会话已不在（服务端重启过）→ catch 里静默标记结束
}

/* ================= 控制台 / 底部面板 ================= */
function switchConsoleTab(name, fromUser) {
  S.consoleTab = name;
  // 用户点击选项卡时：底部面板处于收起状态则自动弹出
  if (fromUser) setBottomFolded(false);
  // 记住当前底部选项卡，下次启动自动恢复（仅 console / problems 常驻）
  try {
    localStorage.setItem('yyConsoleTab', name === 'problems' ? 'problems' : 'console');
  } catch (e) { /* 忽略 */ }
  document.querySelectorAll('#consoleTabs .tab').forEach((t) => t.classList.toggle('active', t.dataset.k === name));
  const pb = $('problems');
  const cb = $('consoleBody');
  if (name === 'problems') {
    if (cb) cb.style.display = 'none';
    if (pb) { pb.style.display = ''; renderProblems(); }
    return;
  }
  if (pb) pb.style.display = 'none';
  if (!cb) return;
  cb.style.display = '';
  cb.innerHTML = '';
  const list = S[name + 'Lines'];
  if (list) list.forEach((ln) => renderConsoleLine(ln));
  cb.scrollTop = 1e9;
}

function ensureConsoleTab(k, label, color) {
  let found = document.querySelector('#consoleTabs .tab[data-k="' + k + '"]');
  if (!found) {
    const div = document.createElement('div');
    div.className = 'tab' + (S.consoleTab === k ? ' active' : '');
    div.dataset.k = k;
    div.innerHTML = '<span class="tname">' + label + '</span>';
    div.onclick = () => switchConsoleTab(k, true);
    $('consoleTabs').appendChild(div);
    S[k + 'Lines'] = [];
  } else {
    found.querySelector('.tname').textContent = label;
  }
  return found;
}

function renderConsoleLine(ln) {
  const cb = $('consoleBody');
  if (!cb) return;
  const wrap = document.createElement('div');
  wrap.className = ln.cls || 'cl-run';
  const pre = document.createElement('pre');
  pre.textContent = ln.text;
  wrap.appendChild(pre);
  if (ln.onclick) {
    wrap.style.cursor = 'pointer';
    wrap.onclick = ln.onclick;
  }
  cb.appendChild(wrap);
  // 自动滚到底（若原本就在底部）
  const atBottom = cb.scrollTop + cb.clientHeight >= cb.scrollHeight - 40;
  if (atBottom) cb.scrollTop = 1e9;
}

function con(k, text, cls, onclick) {
  if (!S[k + 'Lines']) S[k + 'Lines'] = [];
  S[k + 'Lines'].push({ text, cls, onclick });
  if (S.consoleTab !== k || S.consoleTab === 'problems') return;
  const cb = $('consoleBody');
  if (!cb) return;
  if (cb.childElementCount > 800) {
    cb.innerHTML = '';
    S[k + 'Lines'] = S[k + 'Lines'].slice(-400);
    S[k + 'Lines'].forEach((ln) => renderConsoleLine(ln));
    return;
  }
  renderConsoleLine({ text, cls, onclick });
}

function clearConsole(k) {
  S[k + 'Lines'] = [];
  if (S.consoleTab === k) {
    const cb = $('consoleBody');
    if (cb) cb.innerHTML = '';
  }
}

/* 底部面板折叠 / 展开 */
function setBottomFolded(folded) {
  const b = $('bottom');
  if (!b) return;
  b.classList.toggle('collapsed', !!folded);
  const btn = $('btnFold');
  if (btn) {
    btn.textContent = folded ? '▴' : '▾';
    btn.title = folded ? '展开底部面板' : '收起底部面板';
  }
  try { localStorage.setItem('yyBottomFolded', folded ? '1' : '0'); } catch (e) { /* 忽略 */ }
}

function toggleBottom() {
  setBottomFolded(!$('bottom').classList.contains('collapsed'));
}

/* 复制文本到剪贴板（优先 Clipboard API，失败回退 execCommand） */
function copyText(text) {
  const done = () => toast('已复制到剪贴板');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}
function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); }
  catch (e) { toast('复制失败：' + e.message); }
  ta.remove();
}

/* 控制台 / 问题面板：右键菜单（复制选中 / 复制全部） */
function bindPanelCopyMenu(panel, getText) {
  if (!panel) return;
  panel.addEventListener('contextmenu', (e) => {
    const sel = String((window.getSelection && window.getSelection()) || '');
    e.preventDefault();
    const items = [];
    if (sel) items.push({ label: '复制选中文本（' + sel.length + ' 字）', act: () => copyText(sel) });
    items.push({ label: '复制全部内容', act: () => copyText(getText()) });
    showContextMenu(e, items);
  });
}

/* 问题列表渲染 */
/* 问题条目 → 与控制台一致的单行文本（所见即所复制） */
function problemLineText(p) {
  const tag = { error: '错误', warning: '警告', ok: '完成' }[p.kind] || p.kind;
  const fname = (p.file || '').split('/').pop();
  const where = p.line ? (fname + ':' + p.line) : '';
  return '[' + tag + '] ' + p.text + (where ? '（' + where + '）' : '');
}

function renderProblems() {
  const pb = $('problems');
  if (!pb) return;
  pb.innerHTML = '';
  const t = activeTab();
  // 客户端实时提示：调用了类函数、但工程和类库里都没有定义（类库里有的会自动引入，不算问题）
  const undef = (t && t.undefCalls) || [];
  const other = (S.undefHits || []).filter((h) => !t || h.file !== t.path);
  const list = S.problems || [];
  if (!list.length && !undef.length && !other.length) {
    pb.innerHTML = '<div class="pempty">暂无问题（编译通过）</div>';
    return;
  }
  list.forEach((p) => {
    if (p.kind === 'ok') return;
    const wrap = document.createElement('div');
    wrap.className = 'problem-line ' + clsOf(p.kind);   // 与控制台同一套配色
    const pre = document.createElement('pre');
    pre.textContent = problemLineText(p);
    wrap.appendChild(pre);
    wrap.onclick = () => {
      // 拖选文字后松开鼠标也会触发 click：此时不跳转，避免打断复制
      const sel = String((window.getSelection && window.getSelection()) || '');
      if (sel) return;
      if (p.file && p.line) {
        const rel = relOf(p.file);
        if (rel) jumpTo(rel, p.line);
      }
    };
    pb.appendChild(wrap);
  });
  // 未定义的类函数调用：与控制台同一套配色（金色），点击跳到那一行
  undef.forEach((u) => {
    const wrap = document.createElement('div');
    wrap.className = 'problem-line cl-warn';
    const pre = document.createElement('pre');
    pre.textContent = '[未定义] 第 ' + u.line + ' 行：调用了类函数「' + u.key
      + '」，但工程和类库里都没有它的定义（请检查名称是否写错）';
    wrap.appendChild(pre);
    wrap.onclick = () => {
      const sel = String((window.getSelection && window.getSelection()) || '');
      if (sel || !t) return;
      jumpTo(t.path, u.line);
    };
    pb.appendChild(wrap);
  });
  // 工程内其它 .yy 文件里的未定义调用：标出文件名，点击打开并跳转到那一行
  other.forEach((h) => {
    const wrap = document.createElement('div');
    wrap.className = 'problem-line cl-warn';
    const pre = document.createElement('pre');
    pre.textContent = '[未定义] 文件：' + h.file + '，第 ' + h.line + ' 行：调用了类函数「' + h.key
      + '」，但整个工程和类库里都没有它的定义（请检查名称是否写错）';
    wrap.appendChild(pre);
    wrap.onclick = () => {
      const sel = String((window.getSelection && window.getSelection()) || '');
      if (sel) return;
      jumpTo(h.file, h.line);
    };
    pb.appendChild(wrap);
  });
  pb.scrollTop = 0;
}

function showProblems(msgs) {
  let list = msgs || [];
  if (list.length > 800) list = list.slice(-400);   // 与控制台一致的缓冲上限
  S.problems = list;
  if (S.consoleTab === 'problems') renderProblems();
  // 有错误时：自动弹出底部面板并切到「问题」页
  if ((S.problems || []).some((p) => p.kind === 'error')) {
    setBottomFolded(false);
    switchConsoleTab('problems');
  }
}

/* 统一的错误上报：toast 提示 + 写入「问题」面板并自动弹出 */
function reportError(msg, file, line) {
  toast(msg, 4200);
  showProblems([{ kind: 'error', text: String(msg || '未知错误'),
                  file: file || '', line: line || 0, col: 0 }]);
}

/* ================= 编辑器 ================= */
function activeTab() { return S.tabs[S.active] || null; }

function tabTitle(t) {
  const bn = t.path.split('/').pop();
  return t.kind === 'yy' ? '源码 · ' + bn : bn;
}

function renderTabs() {
  const bar = $('tabs');
  bar.innerHTML = '';
  S.tabs.forEach((t, i) => {
    const d = document.createElement('div');
    d.className = 'tab' + (i === S.active ? ' active' : '');
    const nm = document.createElement('span');
    nm.className = 'tname';
    nm.textContent = tabTitle(t);
    nm.title = t.path;
    d.appendChild(nm);
    const x = document.createElement('span');
    x.className = 'x';
    x.textContent = '✕';
    x.onclick = (e) => { e.stopPropagation(); closeTab(i); };
    d.appendChild(x);
    if (t.dirty) d.classList.add('dirty');
    d.onclick = () => activateTab(i);
    d.onmousedown = (e) => { if (e.button === 1) { e.preventDefault(); closeTab(i); } };
    bar.appendChild(d);
  });
}

async function closeTab(i) {
  const t = S.tabs[i];
  if (!t) return;
  if (t.dirty && !t.readonly && !t.gen) {
    const c = confirm('「' + t.path + '」尚未保存，关闭前要保存吗？\n\n确定 = 保存并关闭\n取消 = 直接关闭（放弃修改）');
    if (c) {
      const saved = await saveFile(t);
      if (!saved) return;
    }
  }
  doClose(i);
}

function doClose(i) {
  const wasActive = i === S.active;
  S.tabs.splice(i, 1);
  if (wasActive) {
    S.active = S.tabs.length ? Math.max(0, i - 1) : -1;
  } else if (i < S.active) S.active--;
  renderTabs();
  renderEditor();
  scheduleIdeSave();
}

async function openFile(path, opts) {
  opts = opts || {};
  let idx = S.tabs.findIndex((t) => t.path === path && t.project === S.project);
  if (idx >= 0) { activateTab(idx); return S.tabs[idx]; }
  const data = await api('GET', '/api/file?project=' + encodeURIComponent(S.project) + '&path=' + encodeURIComponent(path));
  if (data.binary) { toast('二进制文件不支持在编辑器查看'); return null; }
  // CRLF / 孤立 CR 统一归一为 LF：保证 行号、统计、辅助线 与编辑器渲染完全一致
  // （textarea 本身也会做同样的归一化；磁盘文件在下次保存时才会跟着变为 LF）
  const raw = (data.text || '').replace(/\r\n?/g, '\n');
  const text = normalizeIndent(raw);          // 打开时统一重排行首缩进（2 空格的整数倍）
  const t = {
    path,
    project: S.project,
    content: text,
    savedContent: raw,                        // 磁盘上的原始内容（用于「未保存」标记）
    dirty: text !== raw,
    readonly: !!opts.readonly,
    gen: !!opts.gen,
    kind: /\.yy$/i.test(path) ? 'yy' : 'text',
    top: 0,
    left: 0,
    undefCalls: [],           // 本文件里「调用了、但整个工程都没有定义」的类函数调用（问题面板 / 右键菜单用）
  };
  S.tabs.push(t);
  S.active = S.tabs.length - 1;
  renderTabs();
  renderEditor();
  scheduleIdeSave();
  return t;
}

function activateTab(i) {
  S.active = i;
  renderTabs();
  renderEditor();
  scheduleIdeSave();
}

function highlightOf(t) {
  return t.kind === 'yy' ? highlightToHtml : highlightCppToHtml;
}

function renderEditor() {
  const t = activeTab();
  const ta = $('codeInput');
  if (!t) {
    ta.value = '';
    ta.readOnly = false;
    $('gutter').innerHTML = '';
    $('highlight').innerHTML = '';
    if ($('foldLayer')) $('foldLayer').innerHTML = '';
    $('emptyHint').style.display = 'flex';
    ta.disabled = true;
    return;
  }
  $('emptyHint').style.display = 'none';
  ta.disabled = false;
  ta.readOnly = !!t.readonly;
  ta.value = t.content;
  if (t.savedContent === undefined) t.savedContent = t.content;   // 已保存内容（撤销后据此判断脏标记）
  if (!t.hist) histReset(t);                                      // 首次打开该标签页：初始化撤销/重做历史
  ta.scrollTop = t.top || 0;
  ta.scrollLeft = t.left || 0;
  drawOverlay(t);
  renderSubs();
  // 类函数定义快照 + 未定义调用标记：切换文件 / 标签时重建
  // （_fnSnap 与当前内容对齐，之后编辑器里删掉定义才能被检测出来）
  t._undefAsked = t._undefAsked || new Set();
  snapMethodDefs(t);
  updateProjDefsForTab(t);     // 该文件在工程快照里的条目 → 换成编辑器里的实时内容
  recomputeUndefHits();
  refreshUndefCalls(t);
  hideAutoComplete();
  S.lastCaretLine = null;   // 切换文件/标签时不触发上一行的标点转换
  updateStatusBar();
  const sb = $('statusbar');
  sb.classList.remove('busy');
}

/* 编辑器固定缩进单位：2 个空格（Tab 键、回车智能缩进、自动闭合、缩进/反缩进均使用它） */
const INDENT = '  ';

/* 块结构辅助线：扫描 如果/循环/子程序 等块，在缩进列画贯穿虚线 */
const GUIDE_OPEN = {
  '如果': ['结束如果'], '如果真': ['结束如果真'],
  '计次循环': ['结束循环'], '当循环': ['结束循环'],
  '判断循环首': ['判断循环尾', '结束循环'],
  '循环判断首': ['循环判断尾'],
  '子程序': ['结束子程序'], '测试函数': ['结束子程序'], '导出子程序': ['结束子程序'],
  '数据类型': ['结束数据类型'],
  '类函数': ['结束类函数'],
  'asm': ['结束asm'],
};
// 输入这些收尾关键字时自动反缩进一级（与块开始行对齐）
const DEDENT_KW = {
  '结束如果': 1, '结束如果真': 1, '结束循环': 1,
  '循环判断尾': 1, '判断循环尾': 1, '结束子程序': 1, '否则': 1, '否则如果': 1,
  '结束数据类型': 1, '结束类函数': 1, '结束asm': 1,
};

function buildGuides(t) {
  const layer = $('guideLayer');
  if (!layer) return;
  if (!t || t.kind !== 'yy') { layer.innerHTML = ''; return; }
  // 扫描基于「去注释后的源码」：注释行永远不会被当作块标识
  const lines = stripCommentsText(t.content).split('\n');
  const ctx = measureCtx();
  const stack = [];
  const blocks = [];
  const mids = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const m = /^[ \t]*([^\s"（(/（]+)/.exec(line);   // 行首第一个词（字符串/括号截断）
    if (!m) continue;
    const kw = m[1];
    const xKw = 4 + ctx.measureText(line.slice(0, m.index).replace(/\t/g, '    ')).width;
    // 线的位置按层级递进：顶层线在关键字左侧一个字宽间隙处，
    // 子级线相对父级线向右缩进 10px —— 保证垂直线之间永远不重叠
    const parentX = stack.length ? stack[stack.length - 1].x : null;
    const xLine = parentX !== null ? parentX + 10 : Math.max(4, xKw - 14);
    if (GUIDE_OPEN[kw]) {
      stack.push({ kw, start: i, x: xLine, xKw, close: GUIDE_OPEN[kw], depth: stack.length });
    } else if (stack.length && GUIDE_OPEN[stack[stack.length - 1].kw].indexOf(kw) >= 0) {
      blocks.push(Object.assign(stack.pop(), { end: i }));
    } else if ((kw === '否则' || kw === '否则如果') && stack.length) {
      const top = stack[stack.length - 1];
      mids.push({ i, x: top.x, xKw: top.xKw, depth: top.depth });
    }
  }
  // 渲染：每个「开始…结束」对应关系一条独立竖线（子程序/如果/循环 各自独立），
  // 首行/尾行/否则行用横向虚线连到关键字；块体内容行不画线（与效果图一致）
  let html = '';
  blocks.forEach((b) => {
    const d = b.depth % 3;
    // 纵线：从开始行中部直下到结束行中部
    html += '<div class="guideV d' + d + '" style="left:' + b.x.toFixed(1) + 'px;top:'
      + (b.start * LINE_H + 10) + 'px;height:' + ((b.end - b.start) * LINE_H) + 'px"></div>';
    // 开始行 / 结束行：横向虚线连到关键字
    html += '<div class="guideE d' + d + '" style="left:' + b.x.toFixed(1) + 'px;top:'
      + (b.start * LINE_H + 10) + 'px;width:' + (b.xKw - b.x).toFixed(1) + 'px"></div>'
      + '<div class="guideE d' + d + '" style="left:' + b.x.toFixed(1) + 'px;top:'
      + (b.end * LINE_H + 10) + 'px;width:' + (b.xKw - b.x).toFixed(1) + 'px"></div>';
  });
  // 否则/否则如果：横线连到所属「如果」的竖线
  mids.forEach((md) => {
    const d = md.depth % 3;
    html += '<div class="guideH d' + d + '" style="left:' + md.x.toFixed(1) + 'px;top:'
      + (md.i * LINE_H + 10) + 'px;width:' + (md.xKw - md.x).toFixed(1) + 'px"></div>';
  });
  layer.innerHTML = html;
}

/* 实际存在字符的行数：去掉末尾换行符产生的空行（中间空行、注释行照常计入） */
function charLineCount(text) {
  if (!text) return 0;
  const rows = text.split('\n');
  let n = rows.length;
  while (n > 1 && rows[n - 1] === '') n--;
  return n;
}

/* 纯注释行数：整行内容都是注释的行（行尾注释不算整行注释） */
function commentLineCount(text) {
  if (!text) return 0;
  const clean = stripCommentsText(text).split('\n');
  let n = 0;
  text.split('\n').forEach((raw, i) => {
    if (raw.trim() && !(clean[i] || '').trim()) n++;
  });
  return n;
}

/* 行数分解：总行数 = 代码行 + 注释行 + 空行（末尾连续空行不计） */
function statLines(text) {
  if (!text) return { total: 0, code: 0, comment: 0, blank: 0 };
  const rows = text.split('\n');
  let total = rows.length;
  while (total > 1 && rows[total - 1] === '') total--;
  const clean = stripCommentsText(text).split('\n');
  let code = 0, comment = 0, blank = 0;
  for (let i = 0; i < total; i++) {
    const raw = rows[i], cl = (clean[i] || '').trim();
    if (!raw.trim()) blank++;
    else if (!cl) comment++;
    else code++;
  }
  return { total, code, comment, blank };
}

/* ================= 代码折叠 =================
   做法：折叠时把被折起来的原文从编辑框文本里取出来，暂存在 t.folds（纯内存、不写盘），
   首行保留显示，行号栏加 ▸ 标记、行尾加「… 折叠 N 行」标签；
   保存 / 导出前用 foldFullText() 把原文插回，拼出完整源码。

   fold = { line: 首行在编辑框里的行号（1 基）, head: 首行原文（去首尾空白，编辑后据此重新定位）,
            text: 被折叠的原文（行间以 \n 分隔）, n: 行数 }

   之所以「编辑框文本 = t.content」：这样现有的输入、缩进、撤销、自动补全、符号分析都照常
   作用在可见内容上（行号与视图天然一致），只有写盘那一步需要拼回原文。
   文本被外部整体替换 / 编辑后首行被改坏时，foldResync 会重新定位，定位不到就自动展开
   —— 宁可展开也不丢内容。foldXXX 一律不进撤销历史（撤销/重做前先展开，避免内容重复）。 */
function foldsOf(t) { if (!t.folds) t.folds = []; return t.folds; }
function foldCount(t) { return ((t && t.folds) || []).length; }

/* 完整源码（可见内容 + 折叠起来的原文）：保存 / 快照用它 */
function foldFullText(t) {
  const text = (t && t.content != null) ? String(t.content) : '';
  const fs = (t && t.folds) || [];
  if (!fs.length) return text;
  const lines = text.split('\n');
  fs.slice().sort((a, b) => a.line - b.line).reverse().forEach((f) => {
    const at = Math.max(0, Math.min(f.line, lines.length));   // 插到首行（第 line 行）之后
    lines.splice(at, 0, ...String(f.text).split('\n'));
  });
  return lines.join('\n');
}

/* 某行行尾的字符偏移（不含换行符） */
function lineEndOffset(text, line) {
  const s = offsetOfLine(text, line);
  const nl = text.indexOf('\n', s);
  return nl < 0 ? text.length : nl;
}

/* 写回编辑框文本（内部用：不标脏、不记撤销，dirty 按「完整源码 vs 已保存内容」判断） */
function foldApplyText(t, text, caret) {
  const ta = $('codeInput');
  const c = caret == null ? (ta ? ta.selectionStart || 0 : 0) : caret;
  const top = ta ? ta.scrollTop : 0, left = ta ? ta.scrollLeft : 0;
  t.content = text;
  if (ta) {
    ta.value = text;
    const p = Math.max(0, Math.min(c, text.length));
    ta.setSelectionRange(p, p);
    ta.scrollTop = top;
    ta.scrollLeft = left;
  }
  t.dirty = foldFullText(t) !== t.savedContent;
  drawOverlay(t);
}

/* 展开第 idx 处折叠：原文插回首行之后，后面的折叠整体下移 */
function foldUnfoldAt(t, idx) {
  const fs = foldsOf(t);
  const f = fs[idx];
  if (!f) return false;
  fs.splice(idx, 1);
  const body = String(f.text).split('\n');
  const lines = String(t.content || '').split('\n');
  const at = Math.max(1, Math.min(f.line, lines.length));
  lines.splice(at, 0, ...body);
  for (const g of fs) if (g.line > f.line) g.line += body.length;
  const text = lines.join('\n');
  _foldSyncing = true;
  foldApplyText(t, text, lineEndOffset(text, f.line));
  _foldSyncing = false;
  return true;
}

/* 全部展开 */
function foldUnfoldAll(t) {
  if (!t || foldCount(t) === 0) return false;
  _foldSyncing = true;
  let guard = foldCount(t) + 1;
  while (t.folds && t.folds.length && guard-- > 0) foldUnfoldAt(t, 0);
  _foldSyncing = false;
  renderTabs();
  updateStatusBar();
  return true;
}

/* 折叠第 first..last 行（含）：first 行保留显示，first+1..last 收起来。返回折叠行数 */
function foldRange(t, first, last) {
  if (!t || t.readonly || t.gen) return 0;
  let lines = String(t.content || '').split('\n');
  first = Math.max(1, Math.min(first, lines.length));
  last = Math.min(last, lines.length);
  if (last - first < 1) return 0;
  const fs = foldsOf(t);
  // 区间里若已有折叠，先展开它（内容不能丢），随之末行后移
  for (;;) {
    let hit = -1;
    fs.forEach((f, i) => { if (f.line >= first && f.line <= last && (hit < 0 || fs[hit].line > f.line)) hit = i; });
    if (hit < 0) break;
    const add = String(fs[hit].text).split('\n').length;
    foldUnfoldAt(t, hit);
    last = Math.min(last + add, String(t.content || '').split('\n').length);
  }
  lines = String(t.content || '').split('\n');
  last = Math.min(last, lines.length);
  if (last - first < 1) return 0;
  const text = lines.slice(first, last).join('\n');
  const nw = lines.slice(0, first).concat(lines.slice(last)).join('\n');
  const hidden = last - first;
  fs.forEach((f) => { if (f.line > last) f.line -= hidden; });
  fs.push({ line: first, head: lines[first - 1], text, n: hidden });
  fs.sort((a, b) => a.line - b.line);
  _foldSyncing = true;
  foldApplyText(t, nw, lineEndOffset(nw, first));
  _foldSyncing = false;
  return hidden;
}

/* 某一行是不是折叠首行（返回在 t.folds 里的下标，不是则返回 -1） */
function foldIndexAtLine(t, ln) {
  const fs = (t && t.folds) || [];
  for (let i = 0; i < fs.length; i++) if (fs[i].line === ln) return i;
  return -1;
}

let _foldSyncing = false;      // 防止 foldXXX → drawOverlay → resync 递归
/* 文本变化后重定折叠位置；定位不到就把原文插回去（自动展开，内容不丢） */
function foldResync(t) {
  if (_foldSyncing || !t) return;
  const fs = foldsOf(t);
  if (!fs.length) return;
  const lines = String(t.content || '').split('\n');
  for (let i = fs.length - 1; i >= 0; i--) {
    const f = fs[i];
    const key = String(f.head || '').trim();
    let at = key ? ((lines[f.line - 1] || '').trim() === key ? f.line : -1) : -1;
    if (at < 0 && key) {
      for (let d = 1; d <= 4 && at < 0; d++) {                   // 上下各找 4 行
        if ((lines[f.line - 1 - d] || '').trim() === key) at = f.line - d;
        else if ((lines[f.line - 1 + d] || '').trim() === key) at = f.line + d;
      }
      if (at < 0) {                                              // 全文只此一处时按唯一命中重定位
        let only = -1, cnt = 0;
        for (let k = 0; k < lines.length; k++) {
          if (lines[k].trim() === key) { cnt++; only = k + 1; if (cnt > 1) break; }
        }
        if (cnt === 1) at = only;
      }
    }
    if (at > 0) { f.line = at; continue; }
    foldUnfoldAt(t, i);                                          // 首行被改坏/删掉：还原内容
  }
}

/* 行尾的「… 折叠 N 行」标签（画在独立图层，随编辑区一起滚动） */
function foldRenderMarks(t) {
  const layer = $('foldLayer');
  if (!layer) return;
  const fs = foldsOf(t);
  if (!fs.length) { layer.innerHTML = ''; return; }
  const ctx = measureCtx();
  const lines = String(t.content || '').split('\n');
  let html = '';
  fs.forEach((f) => {
    const n = String(f.text).split('\n').length;
    const x = 4 + ctx.measureText((lines[f.line - 1] || '').replace(/\t/g, '    ')).width + 12;
    html += '<div class="foldTag" style="left:' + x.toFixed(1) + 'px;top:'
      + ((f.line - 1) * LINE_H + 3) + 'px">… 折叠 ' + n + ' 行</div>';
  });
  layer.innerHTML = html;
}

/* 行首关键字（用于识别 子程序 / 如果 / 循环 … 的块；与 buildGuides 同一口径） */
function foldLineWord(line) {
  return (/^[ \t]*([^\s"（(/（]+)/.exec(line || '') || [])[1] || '';
}

/* 块首行 idx0（0 基）配对的结束行（0 基）；不是块首 / 没配对 → -1 */
function foldBlockEnd(lines, idx0) {
  const closers = GUIDE_OPEN[foldLineWord(lines[idx0])];
  if (!closers) return -1;
  const family = Object.keys(GUIDE_OPEN).filter((k) => GUIDE_OPEN[k][0] === closers[0]);
  let depth = 0;
  for (let i = idx0 + 1; i < lines.length; i++) {
    const tk = foldLineWord(lines[i]);
    if (!tk) continue;
    if (family.indexOf(tk) >= 0) { depth++; continue; }          // 嵌套的同类块
    if (closers.indexOf(tk) >= 0) { if (depth === 0) return i; depth--; }
  }
  return -1;
}

/* 右键「折叠选中代码」：选区覆盖多行即折这些行；只选中一行时，若它是块首行则整块折叠 */
function foldFromSelection() {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || ta.disabled || !t || t.readonly || t.gen) return;
  const txt = String(t.content || '');
  const maxLine = txt.split('\n').length;
  let first = lineOfOffset(txt, ta.selectionStart || 0);
  let last = lineOfOffset(txt, ta.selectionEnd || 0);
  if (ta.selectionEnd > ta.selectionStart) {
    // 选区正好停在某行行首（常见于拖动到下一行）→ 该行不算进来
    if (offsetOfLine(txt, last) === ta.selectionEnd && last > first) last--;
    if (last < first) last = first;
  }
  if (last === first) {                                          // 没跨行：试着整块折叠
    const end = foldBlockEnd(txt.split('\n'), first - 1);
    if (end >= first) last = end + 1;
    else {
      toast('请选中多行代码再折叠；光标放在「子程序 / 如果 / 循环 / 类函数」等块的首行也能整块折叠', 4200);
      return;
    }
  }
  last = Math.min(last, maxLine);
  const n = foldRange(t, first, last);
  if (n > 0) {
    try { ta.focus({ preventScroll: true }); } catch (e) { ta.focus(); }
    renderTabs();
    updateStatusBar();
    updateCaret();
    toast('已折叠 ' + n + ' 行（点行号左侧的 ▸ 或右键「展开」还原）', 3200);
  } else {
    toast('这里没有可折叠的内容');
  }
}

/* ---------------- 行号栏：单击选整行（拖动连选多行）；▸ 展开折叠 ---------------- */
function gutterLineAtY(clientY) {
  const ta = $('codeInput');
  if (!ta) return 1;
  const rect = ta.getBoundingClientRect();                       // 行号与代码同一套行网格
  const ln = Math.floor((clientY - rect.top + ta.scrollTop) / LINE_H) + 1;
  return ln < 1 ? 1 : ln;
}

/* 选中第 a..b 行（含），每一行连尾部换行符一起选进去 */
function selectLines(a, b) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || ta.disabled || !t) return;
  const txt = String(t.content || '');
  const max = txt.split('\n').length;
  const s1 = Math.max(1, Math.min(a, b, max));
  const e1 = Math.max(1, Math.min(Math.max(a, b), max));
  const st = offsetOfLine(txt, s1);
  let en = lineEndOffset(txt, e1);
  if (en < txt.length) en += 1;
  const top = ta.scrollTop, left = ta.scrollLeft;
  try { ta.focus({ preventScroll: true }); } catch (e) { ta.focus(); }
  ta.setSelectionRange(st, en);
  ta.scrollTop = top;
  ta.scrollLeft = left;
  updateCaret();
}

function bindGutter() {
  const g = $('gutter');
  if (!g) return;
  g.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    const ta = $('codeInput');
    const t = activeTab();
    if (!t || !ta || ta.disabled) return;
    e.preventDefault();                                          // 不夺走编辑器焦点、不留文本选择
    const ln = gutterLineAtY(e.clientY);
    const max = String(t.content || '').split('\n').length;
    if (e.target && e.target.classList && e.target.classList.contains('foldArrow')) {
      const idx = foldIndexAtLine(t, ln);                        // ▸ 展开这一处折叠
      if (idx >= 0) { foldUnfoldAt(t, idx); renderTabs(); updateCaret(); }
      return;
    }
    const anchor = e.shiftKey ? lineOfOffset(String(t.content || ''), ta.selectionStart || 0) : ln;
    selectLines(anchor, Math.min(ln, max));
    const onMove = (ev) => selectLines(anchor, Math.min(gutterLineAtY(ev.clientY), max));
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);                // 按住拖动：连选经过的行
    window.addEventListener('mouseup', onUp);
  });
  g.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const ta = $('codeInput');
    const t = activeTab();
    if (!t || !ta || ta.disabled) return;
    const ln = Math.min(gutterLineAtY(e.clientY), String(t.content || '').split('\n').length);
    const idx = foldIndexAtLine(t, ln);
    const items = [];
    if (idx >= 0) {
      const n = String(t.folds[idx].text).split('\n').length;
      items.push({ label: '展开此处（' + n + ' 行）', act: () => { foldUnfoldAt(t, idx); renderTabs(); } });
    } else {
      const end = foldBlockEnd(String(t.content || '').split('\n'), ln - 1);
      if (end >= ln) items.push({ label: '折叠第 ' + ln + ' 行所在的块', act: () => foldRange(t, ln, end + 1) });
    }
    if (foldCount(t)) {
      items.push({ label: '展开全部折叠（' + foldCount(t) + ' 处）', act: () => foldUnfoldAll(t) });
    }
    items.push({ label: '选中第 ' + ln + ' 行', act: () => selectLines(ln, ln) });
    showContextMenu(e, items);
  });
}

function drawOverlay(t) {
  if (!t) return;
  foldResync(t);                                     // 编辑后重定折叠位置（必要时自动展开）
  const ta = $('codeInput');
  const lines = t.content.split('\n');
  // 行号显示到「实际字符行」；若光标停在末尾空行，则该行也显示行号
  let total = lines.length;
  while (total > 1 && lines[total - 1] === '') total--;
  const caretLine = ta && !ta.disabled ? lineOfOffset(t.content, ta.selectionStart || 0) : 1;
  const showTo = Math.max(total, caretLine);
  const g = $('gutter');
  const foldAt = {};
  foldsOf(t).forEach((f) => { foldAt[f.line] = String(f.text).split('\n').length; });
  let html = '';
  for (let i = 1; i <= showTo; i++) {
    if (foldAt[i]) {
      html += '<div class="gline foldHead" data-ln="' + i + '" title="此处折叠了 ' + foldAt[i]
        + ' 行：点 ▸（或右键菜单）展开"><span class="foldArrow">▸</span>' + i + '</div>';
    } else {
      html += '<div class="gline" data-ln="' + i + '">' + i + '</div>';
    }
  }
  // 行号放进独立的内容层：滚动时平移内容层，而不是整个行号栏容器
  g.innerHTML = '<div class="glineWrap" id="gutterInner">' + html + '</div>';
  // 变量 / 自定义常量：动态收集本文件声明名，交给高亮器上色（.yy 才需要）
  if (t.kind === 'yy') {
    $('highlight').innerHTML = highlightOf(t)(t.content, collectVarNames(t.content), collectConstNames(t.content));
  } else {
    $('highlight').innerHTML = highlightOf(t)(t.content);
  }
  buildGuides(t);
  foldRenderMarks(t);
  syncScroll();
}

/* ---------------- 第二栏：核心库命令 ---------------- */
async function loadCorelib() {
  try {
    const d = await api('GET', '/api/corelib');
    S.corelib = { cats: d.categories || [], cmds: d.commands || [] };
  } catch (e) {
    S.corelib = { cats: [], cmds: [] };
  }
  updateLibCount();        // 面板标题的「核心库命令（N）」按当前命令表统计
  acRegisterCorelib();     // 核心库命令 → 自动完成符号表（逐项检测，未登记才添加）
}

/* 统计并显示「核心库命令（N）」：只数命令本身，不含「数据类型」「常量」两组 */
function updateLibCount() {
  const el = $('libCount');
  if (!el) return;
  const cmds = S.corelib.cmds || [];
  const n = cmds.filter((c) => c.form !== '类型' && c.form !== '常量').length;
  const 类型数 = cmds.filter((c) => c.form === '类型').length;
  const 常量数 = cmds.filter((c) => c.form === '常量').length;
  el.textContent = '核心库命令（' + n + '）'
    + (类型数 || 常量数 ? '·类型 ' + 类型数 + '·常量 ' + 常量数 : '');
}

function renderLib() {
  const box = $('libList');
  if (!box) return;
  const kw = (($('libSearch') && $('libSearch').value) || '').trim().toLowerCase();
  const cmds = S.corelib.cmds || [];
  let html = '';
  (S.corelib.cats || []).forEach((cat) => {
    // 搜索：命令名 / 说明（支持拼音全拼与首字母，见 kwHitText）
    const list = cmds.filter((c) => c.cat === cat && kwHit(kw, c.name, c.desc));
    if (!list.length) return;
    html += '<div class="libCat" data-cat="' + escHtml(cat) + '">'
      + escHtml(cat) + '（' + list.length + '）</div>';
    list.forEach((c) => {
      html += '<div class="libItem" data-cat="' + escHtml(cat) + '"'
        + ' data-name="' + escHtml(c.name) + '"'
        + ' data-args="' + escHtml(c.args || '') + '"'
        // 语句 / 运算符 / 数据类型 / 常量：双击插入的是「写法」，而不是 名称(参数…)
        + ' data-insert="' + escHtml(c.insert || '') + '"'
        + ' data-ret="' + escHtml(c.ret || '无') + '"'
        + ' data-desc="' + escHtml(c.desc || '') + '"'
        + ' title="' + escHtml(c.name + (c.insert ? '' : '(' + (c.args || '') + ')')
          + '  返回：' + (c.ret || '无')
          + '\n' + (c.desc || '') + '\n\n双击插入到编辑器') + '">'
        + '<span class="lname">' + escHtml(c.name) + '</span>'
        + '<span class="largs">' + escHtml(c.args || '') + '</span></div>';
    });
  });
  box.innerHTML = html || '<div class="subEmpty">没有匹配的命令</div>';

  box.querySelectorAll('.libCat').forEach((el) => {
    el.onclick = () => {
      const cat = el.dataset.cat;
      const 收起 = el.classList.toggle('collapsed');
      box.querySelectorAll('.libItem').forEach((it) => {
        if (it.dataset.cat === cat) it.style.display = 收起 ? 'none' : '';
      });
    };
  });
  box.querySelectorAll('.libItem').forEach((el) => {
    // 单击：显示命令说明；双击：插入到编辑器（双击时抑制单击提示）
    let clickTimer = null;
    el.onclick = () => {
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        toast(el.dataset.name + '(' + el.dataset.args + ')  返回：' + el.dataset.ret
          + ' — ' + el.dataset.desc, 3600);
      }, 230);
    };
    el.ondblclick = () => {
      clearTimeout(clickTimer);
      // 语句 / 运算符 / 类型 / 常量直接插入写法；函数调用按参数个数铺好逗号
      insertAtCursor(el.dataset.insert
        ? el.dataset.insert
        : acCallInsert(el.dataset.name, el.dataset.args));
    };
  });
}

/* 当前生效的目标架构（x64 / x86）。
   工具栏那个列表框是唯一事实来源：打开工程时会被设成该工程记录的架构，
   没打开工程时跟随全局设置 —— 编译、类库载入都按它走。 */
function currentArch() {
  const el = $('archSelect');
  const a = (el && el.value) || (S.env && S.env.env && S.env.env.arch) || 'x64';
  return String(a).toLowerCase();
}

/* 侧栏「类」栏 /「UI → Qt」/「UI → sciter」的分组：**只按文件名定死**（硬性规定）。
   · lib/qt.class、lib/qt_x86.class          → 'ctrl'   （只进「UI → Qt」栏，就这两个文件）
   · lib/sciter.class、lib/sciter_x86.class  → 'sciter' （只进「UI → sciter」栏，就这两个）
   · 其余 lib/*.class                        → 'class'  （进「类」栏，如 core.class / test.class）
   架构由服务端过滤：x64 只给 qt.class / sciter.class，x86 只给 qt_x86.* / sciter_x86.*，
   所以同一时刻每个栏里只会有那一个文件的内容，不会两套混着显示。
   注：早期版本看文件头的「@控件库 / @Qt控件 / @sciter控件」标记分组，那样任何标了记的
   *.class 都会混进这两个栏；现在改认文件名，两栏各自只加载自己那个文件。 */
const LIB_GROUP_FILES = [
  [/^qt(_x86)?\.class$/i, 'ctrl'],
  [/^sciter(_x86)?\.class$/i, 'sciter'],
];
function libClassGroup(file) {
  const n = String(file || '').trim();
  for (let i = 0; i < LIB_GROUP_FILES.length; i++) {
    if (LIB_GROUP_FILES[i][0].test(n)) return LIB_GROUP_FILES[i][1];
  }
  return 'class';
}

/* 拉取并缓存 lib 类库：「类」/「API」以及「UI」栏的「Qt」「sciter」、编辑器类名与类函数自动补全、
   悬停提示、lib 目录同步共用。
   · *.class → 数据类型 + 类函数 + 常量 + 子程序（文件里的 API 声明**不加载**）
   · *.api   → 只取 API 声明（core.api 最先，其余按文件名；服务端已排好序）
   架构（x64/x86）由服务端按 arch 参数过滤：x64 载入 qt.class/qt.api，
   x86 载入 qt_x86.class/qt_x86.api —— 所以缓存要记住自己是哪套，
   架构变了（切下拉框、打开别的工程）自动重读，不会串版本。
   force=true 时强制重新读取（三栏的刷新按钮用）；
   arch 不传时取 currentArch()。 */
function loadLibClasses(force, arch) {
  const want = String(arch || currentArch()).toLowerCase();
  const lc = S.libClass
    || (S.libClass = { files: null, arch: '', structs: {}, structFrom: {}, methods: [],
                       consts: [], funcs: [], constFiles: [],
                       defs: [], apis: [], loading: null, loadingArch: '' });
  if (lc.files && !force && lc.arch === want) return Promise.resolve(lc);
  if (lc.loading && lc.loadingArch === want) return lc.loading;
  {
    lc.loadingArch = want;
    lc.loading = api('GET', '/api/lib/classes?arch=' + encodeURIComponent(want)).then((d) => {
      const files = d.files || [];            // core.class → 其余 *.class → core.api → 其余 *.api
      const structs = {};                     // 类型名 -> [{name, type}]（成员）
      const structFrom = {};                  // 类型名 -> 声明它的 .class 文件名
      const seenFn = new Set();
      const seenApi = new Set();
      const seenConst = new Set();
      const seenSub = new Set();
      const methods = [];                     // [{owner, name, args, ret, line, from}]
      const consts = [];                      // [{name, type, line, from}]（*.class 里的常量）
      const funcs = [];                       // [{name, args, kind, line, from}]（*.class 里的子程序）
      const apis = [];                        // [{name, ret, args, dll, from, raw}]
      const constFiles = [];                  // *.const 里的常量 [{name, type, value, dec, line, from}]
      const defs = [];                        // 按定义顺序混合：{kind:'类型'|'类函数'|'常量'|'子程序'|'API', …}
      files.forEach((f) => {
        // 文件后缀决定解析什么：*.api 只取 API 声明，*.const 只取常量声明，
        // *.class 只取数据类型 + 类函数
        //（*.class 里写的 API 声明不加载 —— 与编译器 libauto.load_lib_defs 的规则一致）
        const isApiFile = (f.kind ? String(f.kind).toLowerCase() === 'api'
                                  : /\.api$/i.test(f.file || ''));
        const isConstFile = (f.kind ? String(f.kind).toLowerCase() === 'const'
                                    : /\.const$/i.test(f.file || ''));
        const order = [];                       // 先按行号排序，保证与文件书写顺序一致
        if (isConstFile) {
          // 全部 *.const 的声明都归「常量」栏（core.const 最先，其余按文件名）
          collectConstFileDefs(f.text).forEach((c) => {
            order.push({ kind: '文件常量', line: c.line, name: c.name, type: c.type,
                         value: c.value, dec: c.dec });
          });
        } else if (isApiFile) {
          // 全部 *.api 的声明都归「API」栏（core.api 的 Windows API、qt.api 的 Yy_xxx 都在这里）
          collectApiDecls(f.text).forEach((a) => {
            order.push({ kind: 'API', line: a.line, name: a.name, ret: a.ret, args: a.args,
                         dll: a.dll, raw: a.raw, comment: a.comment || '', group: 'api' });
          });
        } else {
          // 文件名决定归哪一栏：qt.class / qt_x86.class → 「UI → Qt」，
          // sciter.class / sciter_x86.class → 「UI → sciter」，其余进「类」栏
          const grp = libClassGroup(f.file);
          collectStructDefsOrdered(f.text).forEach((s) => {
            order.push({ kind: '类型', line: s.line, owner: s.name, fields: s.fields,
                         raw: s.raw, group: grp });
          });
          collectMethodDefs(f.text).forEach((m) => {
            order.push({ kind: '类函数', line: m.line, owner: m.owner, name: m.name,
                         args: m.args, ret: m.ret, raw: m.raw, group: grp });
          });
          // 常量与子程序也一并收集：与类型 / 类函数混在同一个 order 里按行号排序，
          // 保证「按文件书写顺序」加载（与编译器 libauto.load_lib_defs 的口径一致）
          collectLibConstDefs(f.text).forEach((c) => {
            order.push({ kind: '常量', line: c.line, name: c.name, type: c.type, group: grp });
          });
          parseSubs(f.text).forEach((s) => {
            order.push({ kind: '子程序', line: s.line, name: s.name, args: s.args,
                         subKind: s.kind, group: grp });
          });
        }
        order.sort((a, b) => a.line - b.line);
        order.forEach((it) => {
          if (it.kind === '文件常量') {
            if (seenConst.has(it.name)) return;            // 同名常量以先出现者为准
            seenConst.add(it.name);
            constFiles.push({ name: it.name, type: it.type || '', value: it.value,
                              dec: it.dec, line: it.line, from: f.file });
            return;
          }
          if (it.kind === 'API') {
            if (seenApi.has(it.name)) return;             // 同名 API 声明以先出现者为准
            seenApi.add(it.name);
            apis.push({ name: it.name, ret: it.ret, args: it.args, dll: it.dll,
                        from: f.file, raw: it.raw, comment: it.comment || '' });
            defs.push({ kind: 'API', name: it.name, ret: it.ret, args: it.args,
                        dll: it.dll, from: f.file, raw: it.raw,
                        comment: it.comment || '', group: it.group || 'api' });
            return;
          }
          if (it.kind === '常量') {
            if (seenConst.has(it.name)) return;            // 同名常量以先出现者为准
            seenConst.add(it.name);
            consts.push({ name: it.name, type: it.type || '', line: it.line, from: f.file });
            defs.push({ kind: '常量', name: it.name, type: it.type || '', from: f.file,
                        group: it.group || 'class' });
            return;
          }
          if (it.kind === '子程序') {
            if (seenSub.has(it.name)) return;              // 同名子程序以先出现者为准
            seenSub.add(it.name);
            funcs.push({ name: it.name, args: it.args || '', kind: it.subKind || '子程序',
                         line: it.line, from: f.file });
            defs.push({ kind: '子程序', name: it.name, args: it.args || '',
                        subKind: it.subKind || '子程序', from: f.file,
                        group: it.group || 'class' });
            return;
          }
          if (it.kind === '类型') {
            if (it.owner in structs) return;               // 同名数据类型以先出现者为准
            structs[it.owner] = it.fields;
            structFrom[it.owner] = f.file;
            defs.push({ kind: '类型', owner: it.owner, from: f.file, fields: it.fields,
                        raw: it.raw, group: it.group || 'class' });
            return;
          }
          const key = it.owner + '.' + it.name;
          if (seenFn.has(key)) return;                     // 同名类函数以先出现者为准
          seenFn.add(key);
          methods.push({ owner: it.owner, name: it.name, args: it.args, ret: it.ret,
                         line: it.line, from: f.file, raw: it.raw });
          defs.push({ kind: '类函数', owner: it.owner, from: f.file, name: it.name,
                      args: it.args, ret: it.ret, raw: it.raw, group: it.group || 'class' });
        });
      });
      lc.files = files;
      lc.arch = want;              // 记住这批文件属于哪个架构（架构变了要整批重读）
      lc.structs = structs;
      lc.structFrom = structFrom;
      lc.methods = methods;
      lc.consts = consts;                      // *.class 里的常量（「#」补全用）
      lc.constFiles = constFiles;              // *.const 里的常量（「常量」栏展示用）
      lc.funcs = funcs;                        // *.class 里的子程序（自动补全用）
      lc.apis = apis;                          // API 声明（「类」选项卡展示 + 双击插入）
      lc.defs = defs;                          // 「类」选项卡按此顺序混合展示
      acRegisterLibClasses();   // 类函数命令 / 数据类型与类成员 → 自动完成符号表
      try { refreshUndefCalls(activeTab()); } catch (e) { /* 类库到位后重算一次未定义调用 */ }
      lc.loading = null;
      return lc;
    }, (e) => { lc.loading = null; throw e; });
  }
  return lc.loading;
}

/* 架构变化后重读类库并重画受影响的栏。
   「类」/「API」/「Qt」三栏的内容都来自 lib 目录，而 lib 目录按当前架构过滤
   Qt 文件（x64 → qt.class / qt.api，x86 → qt_x86.class / qt_x86.api），
   所以**切架构**和**打开工程（工程记着别的架构）**都要走这里整批重读，
   否则栏里还停着上一套的条目、自动补全与「转到定义」也会指到错的文件。
   arch 不传时取工具栏当前值；类库同时是「未定义类函数」检查的白名单，
   换库后一并重算，免得「问题」栏留下过期的报错。 */
async function reloadLibClasses(arch) {
  S.libClass = null;                                    // 清缓存，强制重新拉取
  await loadLibClasses(true, arch).catch(() => { });
  renderClasses();
  renderApis();
  renderConsts();
  renderWidgets();
  renderSciter();
  try { recomputeUndefHits(); refreshUndefCalls(activeTab()); } catch (e) { /* 未定义调用检查 */ }
  if (S.consoleTab === 'problems') renderProblems();
}

/* 「类」栏 /「UI → Qt」/「UI → sciter」：读取 lib 目录下的 *.class 文件（core.class 优先），
   展示文件里声明的「数据类型」（含成员）、「类函数命令」（含返回类型），
   以及「常量」与「子程序」（*.class 里定义的，按定义顺序、按文件分组展示；
   常量双击插入 #名称，子程序双击插入调用——编译时都会自动引入），
   两者按所属类型名合并分组；交互与核心库一致（分组 / 单击说明 / 双击插入）。
   「类」栏（group='class'）不展示常量，Qt / sciter 栏照常展示。
   三栏共用本函数，靠 group 区分：
   · group='class'  →「类」栏：普通类库 *.class（core.class / test.class …）；
   · group='ctrl'   →「UI → Qt」：**只加载 lib/qt.class（x86 时是 qt_x86.class）**，
     即 Qt 控件的**中文封装**：窗口.新建 / 按钮.新建 / 控件.置位置 …；
   · group='sciter' →「UI → sciter」：**只加载 lib/sciter.class（x86 时是 sciter_x86.class）**。
   注：API 声明只从 *.api 文件加载，不在这三栏（见 renderApis → 「API」栏）。 */
async function renderClassList(opts) {
  const O = opts || {};
  const group = O.group || 'class';
  const what = O.what || '类函数';
  const box = $(O.box || 'classList');
  if (!box) return;
  const search = O.search || 'clsSearch';
  const kw = (($(search) && $(search).value) || '').trim().toLowerCase();
  box.innerHTML = '<div class="subEmpty">正在读取 lib/*.class …</div>';
  let lib;
  try {
    lib = await loadLibClasses();
  } catch (e) {
    box.innerHTML = '<div class="subEmpty">读取 lib 目录失败：' + escHtml(e.message) + '</div>';
    return;
  }
  // 按 lib/*.class 里的「定义顺序」混合加载：数据类型与类函数谁先定义谁在前
  // （同一个类型名合并成一组：组内成员在前、类函数在后；只有其中一种也会列出）
  const groups = [];            // [{owner, from, fields, methods, consts, subs, pseudo?}]
  const groupOf = (owner, from, key) => {
    const k = key || owner;
    let g = groups.find((x) => x._key === k);
    if (!g) {
      g = { _key: k, owner, from: from || '', fields: [], methods: [], consts: [], subs: [] };
      groups.push(g);
    }
    if (!g.from && from) g.from = from;
    return g;
  };
  const rawOf = {};            // 类型名 -> 原始「数据类型 … 结束数据类型」定义文本（供右键插入）
  let totalFn = 0;
  (lib.defs || []).forEach((d) => {
    if (d.kind === 'API') return;                  // API 声明：不在此栏（「API」栏专门展示）
    if (d.kind === '类函数') {
      // 自动补全登记：三栏的类函数都要登记（不管当前显示的是哪一栏）
      acEnsureClassMethod(d, '类库 ' + (d.from || ''));
    }
    // 分组先于一切：本栏只显示属于它的那些 *.class 文件的内容（常量 / 子程序也一样），
    // 别的文件里的常量与子程序不会串到 Qt / sciter 栏
    if ((d.group || 'class') !== group) return;
    if (d.kind === '常量' || d.kind === '子程序') {
      if (d.kind === '常量' && group === 'class') return;   // 「类」栏不再展示常量（Qt/sciter 栏照旧）
      // 常量 / 子程序：没有宿主类型，按「种类 + 文件」各自成组，
      // 出现在它们被定义的位置（与类型 / 类函数一起按定义顺序展示）
      const g = groupOf(d.kind, d.from, d.kind + '@' + (d.from || ''));
      g.pseudo = true;
      if (d.kind === '常量') g.consts.push({ name: d.name, type: d.type || '' });
      else g.subs.push({ name: d.name, args: d.args || '' });
      return;
    }
    const g = groupOf(d.owner, d.from);
    if (d.kind === '类型') {
      g.fields = (d.fields || []).map((f) => ({ name: f.name, type: f.type }));
      g.declared = true;                       // 本组是「数据类型」→ 组头用黄色
      g.raw = d.raw || '';
      rawOf[d.owner] = d.raw || '';
      return;
    }
    totalFn++;                                 // 类函数总数（不受搜索过滤影响）
    g.methods.push({ name: d.name, args: d.args, ret: d.ret, raw: d.raw || '' });
  });
  const cnt = $(O.cnt || 'clsCount');
  if (cnt) cnt.textContent = (O.title || '类函数命令') + '（' + totalFn + '）';
  if (!groups.length) {
    box.innerHTML = kw
      ? '<div class="subEmpty">没有匹配的' + what + ' / 数据类型</div>'
      : '<div class="subEmpty">' + (O.empty || '') + '</div>';
    return;
  }
  let html = '';
  let lastFile = null;                         // 当前输出的 .class 文件名（用于插入文件名行）
  groups.forEach((g) => {
    // 搜索过滤：类型名 / 成员名与成员类型 / 类函数名、参数、返回类型；
    // 也可输入「数据类型」「成员」「类函数」按种类筛选
    if (kw) {
      // 种类关键词：本栏的名称（如「Qt」「sciter」「类函数」）+ 数据类型 / 成员 / 类函数 / 常量 / 子程序
      const kinds = (what + ' ') + (g.declared ? '数据类型 ' : '')
        + (g.fields.length ? '成员 ' : '') + (g.methods.length ? '类函数 ' : '')
        + (g.consts.length ? '常量 ' : '') + (g.subs.length ? '子程序 ' : '');
      const hit = kinds.indexOf(kw) >= 0
        || kwHit(kw, g.owner)
        || g.fields.some((f) => kwHit(kw, f.name, f.type))
        || g.methods.some((m) => kwHit(kw, m.name, m.args, m.ret))
        || g.consts.some((c) => kwHit(kw, c.name, c.type))
        || g.subs.some((s) => kwHit(kw, s.name, s.args));
      if (!hit) return;
    }
    // 换到下一个 *.class 文件 → 先插入文件名行（灰色；单击折叠/展开该文件的全部内容）
    const file = g.from || '（未记录来源）';
    if (file !== lastFile) {
      lastFile = file;
      html += '<div class="libCat fileCat" data-file="' + escHtml(file) + '" title="'
        + escHtml('源文件：' + file + '\n单击：折叠/展开该文件的全部数据类型与类函数')
        + '">' + escHtml(file) + '</div>';
    }
    const parts = [];
    if (g.pseudo) {
      parts.push(String(g.consts.length + g.subs.length));   // 常量组 / 子程序组：只显示数量
    } else {
      if (g.fields.length) parts.push('成员 ' + g.fields.length);
      if (g.methods.length) parts.push('类函数 ' + g.methods.length);
      if (g.consts.length) parts.push('常量 ' + g.consts.length);
      if (g.subs.length) parts.push('子程序 ' + g.subs.length);
    }
    // 组头颜色看「这组是什么」：含类函数 / 子程序的组 → 绿色 fnCat；
    // 只有成员 / 常量、没有可调用内容的纯数据类型组 → 淡蓝色 typeCat
    const headTip = g.pseudo
      ? (g.owner === '常量'
          ? '常量（来源：' + (g.from || '未记录') + '）\n工程里用 #常量名 引用（编译时自动引入，无需复制）'
          : '子程序（来源：' + (g.from || '未记录') + '）\n工程里可直接调用（编译时自动引入，无需复制）')
      : ((g.declared ? '数据类型 ' + g.owner
          + (g.methods.length ? ' 及其类函数' : '') : '类函数组 ' + g.owner)
        + '（来源：' + (g.from || '未记录') + '）\n工程里可直接调用：' + g.owner + '.方法(…)\n'
        + '（编译时会自动引入类库定义，无需复制）\n\n双击：把定义复制进当前文件（想查看/修改源码时用）');
    const grpCls = ((g.declared && !g.methods.length && !g.subs.length && !g.pseudo)
      || (g.pseudo && g.owner === '常量')) ? ' typeCat' : ' fnCat';
    html += '<div class="libCat' + grpCls
      + '" data-file="' + escHtml(file) + '" data-owner="' + escHtml(g.owner) + '"'
      + (g.pseudo ? ' data-pseudo="1" data-kind="' + escHtml(g.owner) + '"' : '')
      + ' title="' + escHtml(headTip) + '"'
      + '>' + escHtml(g.owner) + '（' + (parts.join(' · ') || '数据类型') + '）</div>';
    // ① 数据类型成员：成员名 + 成员类型（来自「数据类型 … 结束数据类型」）
    g.fields.forEach((f) => {
      html += '<div class="libItem fieldItem" data-file="' + escHtml(file) + '"'
        + ' data-kind="成员" data-owner="' + escHtml(g.owner) + '"'
        + ' data-name="' + escHtml(f.name) + '" data-type="' + escHtml(f.type) + '"'
        + ' data-from="' + escHtml(g.from) + '"'
        + ' title="' + escHtml('成员 ' + g.owner + '.' + f.name + '：' + f.type
          + '\n来源：' + (g.from || '未记录') + '\n双击插入到编辑器') + '">'
        + '<span class="lname">' + escHtml(f.name) + '</span>'
        + '<span class="mtype" title="成员类型：' + escHtml(f.type) + '">'
        + escHtml(f.type) + '</span></div>';
    });
    // ② 类函数：函数名 + 参数（返回类型不在列表里显示，仅保留在悬停提示与搜索里）
    g.methods.forEach((m) => {
      const sig = m.args || '';
      const ret = (m.ret || '无').trim() || '无';        // 返回类型（无返回值时为「无」）
      html += '<div class="libItem" data-file="' + escHtml(file) + '"'
        + ' data-kind="类函数" data-owner="' + escHtml(g.owner) + '"'
        + ' data-name="' + escHtml(m.name) + '"'
        + ' data-sig="' + escHtml(sig) + '"'
        + ' data-ret="' + escHtml(ret) + '"'
        + ' data-from="' + escHtml(g.from) + '"'
        + ' title="' + escHtml('类函数 ' + g.owner + '.' + m.name + '(' + sig + ')  返回：' + ret
          + '\n来源：' + g.from
          + '\n调用方式：变量.' + m.name + '(' + sig + ')\n\n双击插入到编辑器') + '">'
        + '<span class="lname">' + escHtml(m.name) + '</span>'
        + '<span class="largs">' + escHtml(sig) + '</span></div>';
    });
    // ③ 常量：名称 + 类型（使用方式 #名称；双击插入 #名称）
    g.consts.forEach((c) => {
      html += '<div class="libItem fieldItem" data-file="' + escHtml(file) + '"'
        + ' data-kind="常量" data-owner="' + escHtml(g.owner) + '"'
        + ' data-name="' + escHtml(c.name) + '" data-type="' + escHtml(c.type || '整数型') + '"'
        + ' data-from="' + escHtml(g.from) + '"'
        + ' title="' + escHtml('常量 ' + c.name + '：' + (c.type || '整数型')
          + '\n来源：' + (g.from || '未记录')
          + '\n使用方式：#' + c.name + '（编译时自动引入，无需复制）\n\n双击插入 #名称') + '">'
        + '<span class="lname">' + escHtml(c.name) + '</span>'
        + '<span class="mtype" title="常量类型：' + escHtml(c.type || '整数型') + '">'
        + escHtml(c.type || '整数型') + '</span></div>';
    });
    // ④ 子程序：名称 + 参数（双击插入调用）
    g.subs.forEach((s) => {
      html += '<div class="libItem" data-file="' + escHtml(file) + '"'
        + ' data-kind="子程序" data-owner="' + escHtml(g.owner) + '"'
        + ' data-name="' + escHtml(s.name) + '" data-sig="' + escHtml(s.args) + '"'
        + ' data-from="' + escHtml(g.from) + '"'
        + ' title="' + escHtml('子程序 ' + s.name + '(' + s.args + ')'
          + '\n来源：' + (g.from || '未记录')
          + '\n可直接调用（编译时自动引入，无需复制）\n\n双击插入调用') + '">'
        + '<span class="lname">' + escHtml(s.name) + '</span>'
        + '<span class="largs">' + escHtml(s.args) + '</span></div>';
    });
  });
  box.innerHTML = html;

  // 文件名行：单击折叠/展开该文件下的全部数据类型与类函数
  box.querySelectorAll('.libCat.fileCat').forEach((el) => {
    el.onclick = () => {
      const s = attrSel(el.dataset.file);
      const 收起 = el.classList.toggle('collapsed');
      const parts = '[data-file="' + s + '"]:not(.fileCat)';
      if (收起) {
        box.querySelectorAll(parts).forEach((n) => { n.style.display = 'none'; });
        return;
      }
      box.querySelectorAll(parts).forEach((n) => { n.style.display = ''; });
      // 展开时恢复该文件里仍处于折叠状态的「类函数」组（数据类型组头不折叠）
      box.querySelectorAll('.libCat.collapsed[data-file="' + s + '"]:not(.fileCat)').forEach((g) => {
        box.querySelectorAll('.libItem[data-file="' + s + '"][data-owner="'
          + attrSel(g.dataset.owner) + '"]').forEach((it) => { it.style.display = 'none'; });
      });
    };
  });
  // 组头（类函数组头 / 数据类型组头）：不折叠（无 ▾/▸ 箭头、点击不收起）；
  // 双击 → 把「数据类型 + 这一组类函数」的定义复制进当前文件（想查看/修改源码时用）。
  // 说明：不复制也能直接调用——编译时会把类库里缺的定义自动引入。
  box.querySelectorAll('.libCat:not(.fileCat)').forEach((el) => {
    el.ondblclick = () => {
      if (el.dataset.pseudo) return;               // 常量/子程序组：没有「整组定义」可复制
      const owner = el.dataset.owner;
      if (!owner) return;
      const g0 = groups.find((x) => x.owner === owner);
      if (!g0) return;
      // 插入前检查：这些类函数是否都已登记到自动完成，没有则补上
      let added = false;
      g0.methods.forEach((m) => { if (acEnsureLibMethod(owner, m.name, m.args)) added = true; });
      if (added) toast('已加入自动完成：' + owner);
      insertMissingClassDefs(owner, g0);
    };
  });
  box.querySelectorAll('.libItem').forEach((el) => {
    const isField = (el.dataset.kind === '成员');
    const isConst = (el.dataset.kind === '常量');
    const isSub = (el.dataset.kind === '子程序');
    let clickTimer = null;
    el.onclick = () => {
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        if (isConst) {                                  // 常量：类型 + 来源
          toast('常量 ' + el.dataset.name + '：' + el.dataset.type
            + '  来源：' + (el.dataset.from || '—') + '（使用：#' + el.dataset.name + '）', 3600);
        } else if (isSub) {                             // 子程序：参数 + 来源
          toast('子程序 ' + el.dataset.name + '(' + el.dataset.sig + ')'
            + '  来源：' + (el.dataset.from || '—'), 3600);
        } else if (isField) {                           // 数据类型成员：成员名 + 成员类型
          toast('成员 ' + el.dataset.owner + '.' + el.dataset.name + '：' + el.dataset.type
            + '  来源：' + (el.dataset.from || '—'), 3600);
        } else {                                        // 类函数：参数 + 返回类型
          toast('类函数 ' + el.dataset.owner + '.' + el.dataset.name + '(' + el.dataset.sig
            + ')  返回：' + el.dataset.ret + '  来源：' + el.dataset.from, 3600);
        }
      }, 230);
    };
    el.ondblclick = () => {
      clearTimeout(clickTimer);
      const owner = el.dataset.owner, name = el.dataset.name;
      // 常量：插入 #名称（编译时自动引入，无需复制定义）
      if (isConst) {
        insertAtCursor('#' + name);
        toast('已插入 #' + name + '（编译时会自动从 '
          + (el.dataset.from || '类库') + ' 引入，无需手动复制）', 4200);
        return;
      }
      // 子程序：插入调用（编译时自动引入，无需复制定义）
      if (isSub) {
        acEnsure(name, '子程序', el.dataset.sig || '', true);
        const call = acCallInsert(name, el.dataset.sig || '');
        insertAtCursor(call);
        toast('已插入调用 ' + call + '（定义会在编译时自动从 '
          + (el.dataset.from || '类库') + ' 引入，无需手动复制）', 4200);
        return;
      }
      const g0 = groups.find((x) => x.owner === owner);
      // 插入前检查：该「类函数 / 成员」是否已在自动完成里，没有则补上
      const added = isField
        ? acEnsureLibType(owner, g0 ? g0.fields : [])
        : acEnsureLibMethod(owner, name, el.dataset.sig);
      if (added) toast('已加入自动完成：' + owner + (isField ? '' : '.' + name));
      if (isField) { insertAtCursor(owner + '.' + name); return; }
      // 类函数：直接插入调用 —— 编译（运行/编译/测试/发布）时会把类库里
      // 缺失的「数据类型 + 类函数」定义自动引入，无需先复制定义到本文件。
      // 想把定义复制进来查看/修改：双击组头，或右键调用处选「复制类函数定义」。
      warnReservedMethodName(owner, name);      // 名字被内置命令占用 → 编译必报错，提醒改名
      const call = acCallInsert(owner + '.' + name, el.dataset.sig);
      insertAtCursor(call);
      toast('已插入调用 ' + call + '（定义会在编译时自动从 '
        + (el.dataset.from || '类库') + ' 引入，无需手动复制）', 4200);
    };
  });
}

/* 「类」栏：普通类库（lib/*.class 里的数据类型与类函数；
   qt.class / qt_x86.class / sciter.class / sciter_x86.class 除外 —— 那几个只进「UI」栏） */
function renderClasses() {
  return renderClassList({
    box: 'classList', cnt: 'clsCount', search: 'clsSearch', group: 'class',
    title: '类函数命令', what: '类函数',
    empty: 'lib 目录下没有类定义（新建 *.class 文件，格式：'
      + '数据类型 … 结束数据类型 / 类函数 … 结束类函数；'
      + '控件库的中文封装见「UI」栏的「Qt」「sciter」选项卡，API 声明写在 *.api 文件里，见「API」栏）',
  });
}

/* 「API」栏：列出 lib/*.api 文件里的 API 声明
   （`API 返回类型 名字(参数) 在库 "xxx.dll"`）：core.api 最先加载、其余按文件名；
   Qt 封装 DLL 的 `Yy_xxx` 声明（lib/qt.api）也在这一栏
   （对应的中文封装 lib/qt.class 在「UI → Qt」，见 renderWidgets）。
   *.class 里的 API 声明不会被加载（与编译器一致）。
   列表结构：文件名行（单击折叠/展开）→ 下面是该文件的声明条目（双击插入代码编辑框）。 */
async function renderApiList(opts) {
  const O = opts || {};
  const box = $(O.box || 'apiList');
  if (!box) return;
  const group = O.group || 'api';
  const what = O.what || 'API 声明';
  const search = O.search || 'apiSearch';
  const kw = (($(search) && $(search).value) || '').trim().toLowerCase();
  box.innerHTML = '<div class="subEmpty">正在读取 lib 类库…</div>';
  let lib;
  try {
    lib = await loadLibClasses();
  } catch (e) {
    box.innerHTML = '<div class="subEmpty">读取 lib 目录失败：' + escHtml(e.message) + '</div>';
    return;
  }
  // 按 .api 文件成组（保持文件顺序；同名只算首次出现的那个 —— 解析时已去重）
  const groups = [];                       // [{from, apis:[{name,ret,args,dll,raw,comment}]}]
  const groupOf = (from) => {
    const key = from || '（未记录来源）';
    let g = groups.find((x) => x.from === key);
    if (!g) { g = { from: key, apis: [] }; groups.push(g); }
    return g;
  };
  let total = 0;
  (lib.defs || []).forEach((d) => {
    if (d.kind !== 'API') return;
    if ((d.group || 'api') !== group) return;      // 另一栏的声明不在这里显示
    total++;
    groupOf(d.from).apis.push({ name: d.name, ret: d.ret, args: d.args, dll: d.dll,
                                raw: d.raw, comment: d.comment || '' });
  });
  const cnt = $(O.cnt || 'apiCount');
  if (cnt) cnt.textContent = (O.title || 'API 声明') + '（' + total + '）';
  if (!groups.length) {
    box.innerHTML = kw
      ? '<div class="subEmpty">没有匹配的' + what + '</div>'
      : '<div class="subEmpty">' + (O.empty || '') + '</div>';
    return;
  }
  let html = '';
  groups.forEach((g) => {
    // 搜索：API 名 / 参数 / 返回类型 / 所在库 / 注释；也可输入「API」按种类筛选
    const list = kw
      ? g.apis.filter((a) => kwHit(kw, a.name, a.args, a.ret, a.dll, a.comment,
        'API 声明 api'))
      : g.apis;
    if (!list.length) return;
    // 文件名行下面**直接**是声明条目（不再单独占一行「API 声明（N）」组头）
    html += '<div class="libCat fileCat" data-file="' + escHtml(g.from) + '" title="'
      + escHtml('源文件：' + g.from + '（共 ' + g.apis.length + ' 条' + what + '）'
        + '\n单击：折叠/展开该文件的' + what
        + '\n下面每条：双击把该声明插入代码编辑框') + '">'
      + escHtml(g.from) + '</div>';
    list.forEach((a) => {
      const sig = a.args || '';
      const ret = (a.ret || '空').trim() || '空';
      html += '<div class="libItem apiItem" data-file="' + escHtml(g.from) + '"'
        + ' data-kind="API" data-name="' + escHtml(a.name) + '"'
        + ' data-sig="' + escHtml(sig) + '" data-ret="' + escHtml(ret) + '"'
        + ' data-dll="' + escHtml(a.dll) + '" data-raw="' + escHtml(a.raw || '') + '"'
        + ' data-comment="' + escHtml(a.comment || '') + '"'
        + ' data-from="' + escHtml(g.from) + '" title="'
        + escHtml('API ' + a.name + '(' + sig + ')  返回：' + ret
          + '\n所在库：' + a.dll + '\n来源：' + g.from
          + (a.comment ? '\n\n' + a.comment : '')       // 悬停：显示该声明的全部注释
          + '\n\n工程里可直接调用（编译时自动引入声明）'
          + '\n双击：把声明插入代码编辑框') + '">'
        + '<span class="lname">' + escHtml(a.name) + '</span>'
        + '<span class="largs">' + escHtml('(' + sig + ')') + '</span>'
        + '<span class="mtype" title="所在库">' + escHtml(a.dll) + '</span></div>';
    });
  });
  box.innerHTML = html;

  // 文件名行：单击折叠/展开该文件的 API 声明；双击给出操作提示（这里不插入）
  box.querySelectorAll('.libCat.fileCat').forEach((el) => {
    el.onclick = () => {
      const s = attrSel(el.dataset.file);
      const 收起 = el.classList.toggle('collapsed');
      box.querySelectorAll('[data-file="' + s + '"]:not(.fileCat)').forEach((n) => {
        n.style.display = 收起 ? 'none' : '';
      });
    };
    el.ondblclick = () => toast('双击下面的条目即可把声明插入代码编辑框'
      + '（单击文件名行是折叠 / 展开）', 4200);
  });
  // 条目：单击看详情（参数 / 返回 / 所在库），双击把声明插入代码编辑框
  box.querySelectorAll('.libItem').forEach((el) => {
    let clickTimer = null;
    el.onclick = () => {
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        toast('API ' + el.dataset.name + '(' + (el.dataset.sig || '') + ')  返回：'
          + el.dataset.ret + '  在库：' + el.dataset.dll
          + '  来源：' + (el.dataset.from || '类库'), 4200);
      }, 230);
    };
    el.ondblclick = () => {
      clearTimeout(clickTimer);
      insertLibApiDecl(el);                 // 插入 API 声明（本文件已有则只提示）
    };
  });
}

/* 「API」栏：普通的外部 API 声明（lib/*.api，默认分组） */
function renderApis() {
  return renderApiList({
    box: 'apiList', cnt: 'apiCount', search: 'apiSearch', group: 'api',
    title: 'API 声明', what: 'API 声明',
    empty: 'lib 目录下没有 API 声明（写法：API 返回类型 名字(参数) 在库 "xxx.dll"，'
      + '写在 *.api 文件里，如 core.api；*.class 里的声明不会加载。'
      + '工程里可直接调用，编译时自动引入）',
  });
}

/* 「常量」栏：lib/*.const 里的常量声明（core.const 最先，其余按文件名；写法：常量 名称 = 值）。
   列表结构与「API」栏一致：文件名行（单击折叠/展开）→ 下面是该文件的常量条目，
   每条显示常量名和它的十进制值（文本等非数值显示原文）；双击条目把 #名称 插入代码编辑框
   （编译时自动从所在 *.const 引入）。 */
async function renderConstList(opts) {
  const O = opts || {};
  const box = $(O.box || 'constList');
  if (!box) return;
  const search = O.search || 'constSearch';
  const kw = (($(search) && $(search).value) || '').trim().toLowerCase();
  box.innerHTML = '<div class="subEmpty">正在读取 lib/*.const …</div>';
  let lib;
  try {
    lib = await loadLibClasses();
  } catch (e) {
    box.innerHTML = '<div class="subEmpty">读取 lib 目录失败：' + escHtml(e.message) + '</div>';
    return;
  }
  // 按 .const 文件成组（保持文件顺序；同名只算首次出现的那个 —— 解析时已去重）
  const groups = [];                       // [{from, consts:[{name,type,value,dec,line}]}]
  const groupOf = (from) => {
    const key = from || '（未记录来源）';
    let g = groups.find((x) => x.from === key);
    if (!g) { g = { from: key, consts: [] }; groups.push(g); }
    return g;
  };
  let total = 0;
  (lib.constFiles || []).forEach((c) => {
    total++;
    groupOf(c.from).consts.push(c);
  });
  if (!groups.length) {
    box.innerHTML = kw
      ? '<div class="subEmpty">没有匹配的常量</div>'
      : '<div class="subEmpty">' + (O.empty || '') + '</div>';
    return;
  }
  let html = '';
  groups.forEach((g) => {
    // 搜索：常量名 / 值 / 十进制值 / 所在文件；也可输入「常量」按种类筛选
    const list = kw
      ? g.consts.filter((c) => kwHit(kw, c.name, c.value, constDecTxt(c.dec), '常量 const'))
      : g.consts;
    if (!list.length) return;
    html += '<div class="libCat fileCat" data-file="' + escHtml(g.from) + '" title="'
      + escHtml('源文件：' + g.from + '（共 ' + g.consts.length + ' 个常量）'
        + '\n单击：折叠/展开该文件的常量'
        + '\n下面每条：双击把 #常量名 插入代码编辑框') + '">'
      + escHtml(g.from) + '</div>';
    list.forEach((c) => {
      const dec = constDecTxt(c.dec);
      const shown = dec || (c.value || '（无法求值）');
      html += '<div class="libItem constItem" data-file="' + escHtml(g.from) + '"'
        + ' data-kind="常量" data-name="' + escHtml(c.name) + '"'
        + ' data-value="' + escHtml(c.value) + '"'
        + ' data-dec="' + escHtml(dec) + '"'
        + ' data-from="' + escHtml(g.from) + '" title="'
        + escHtml('常量 ' + c.name + ' = ' + (c.value || '')
          + (dec ? '  （十进制：' + dec + '）' : '')
          + '\n类型：' + (c.type || '按值推断') + '\n来源：' + g.from
          + '\n\n工程里可直接使用（编译时自动引入声明）'
          + '\n双击：把 #' + c.name + ' 插入代码编辑框') + '">'
        + '<span class="lname">' + escHtml(c.name) + '</span>'
        + '<span class="mtype" title="值">' + escHtml(shown) + '</span></div>';
    });
  });
  box.innerHTML = html;

  // 文件名行：单击折叠/展开该文件的常量；双击给出操作提示（这里不插入）
  box.querySelectorAll('.libCat.fileCat').forEach((el) => {
    el.onclick = () => {
      const s = attrSel(el.dataset.file);
      const 收起 = el.classList.toggle('collapsed');
      box.querySelectorAll('[data-file="' + s + '"]:not(.fileCat)').forEach((n) => {
        n.style.display = 收起 ? 'none' : '';
      });
    };
    el.ondblclick = () => toast('双击下面的条目即可把 #常量名 插入代码编辑框'
      + '（单击文件名行是折叠 / 展开）', 4200);
  });
  // 条目：单击看详情（值 / 十进制 / 来源），双击把 #常量名 插入代码编辑框
  box.querySelectorAll('.libItem').forEach((el) => {
    let clickTimer = null;
    el.onclick = () => {
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        toast('常量 #' + el.dataset.name + ' = ' + (el.dataset.value || '')
          + (el.dataset.dec ? '  （十进制：' + el.dataset.dec + '）' : '')
          + '  来源：' + (el.dataset.from || 'lib/*.const'), 4200);
      }, 230);
    };
    el.ondblclick = () => {
      clearTimeout(clickTimer);
      insertAtCursor('#' + el.dataset.name);
      toast('已插入 #' + el.dataset.name + '（编译时会自动从 '
        + (el.dataset.from || 'lib/*.const') + ' 引入，无需手动复制）', 4200);
    };
  });
}

/* 「常量」栏：lib/*.const 里的常量声明 */
function renderConsts() {
  return renderConstList({
    box: 'constList', search: 'constSearch',
    empty: 'lib 目录下没有常量声明（写法：常量 名称 = 值，写在 *.const 文件里，如 core.const；'
      + '工程里可直接使用，编译时自动引入）',
  });
}

/* 「UI → Qt」选项卡：只加载 lib/qt.class（x86 工程时是 lib/qt_x86.class）里 Qt 控件的
   **中文封装** —— `类函数 窗口.新建(文本型 标题, 整数型 宽, 整数型 高) 整数型` 等。
   双击条目把调用插进编辑器（如 `窗口.新建()`），双击组头把定义复制进来。
   原始的 `Yy_xxx` 声明（qt.api）在「API」栏。 */
function renderWidgets() {
  return renderClassList({
    box: 'widgetList', cnt: 'widgetCount', search: 'widgetSearch', group: 'ctrl',
    title: 'Qt', what: 'Qt函数',
    empty: '本栏只加载 lib/qt.class（x86 时是 qt_x86.class）：把 Qt 控件的中文封装写成'
      + '「数据类型 … / 类函数 窗口.新建(…) 结束类函数」即可，其它 *.class 一律进「类」栏。',
  });
}

/* 「UI → sciter」选项卡：只加载 lib/sciter.class（x86 工程时是 lib/sciter_x86.class）。
   交互与「Qt」选项卡完全一致：双击条目把调用插进编辑器，双击组头把定义复制进来。 */
function renderSciter() {
  return renderClassList({
    box: 'sciterList', cnt: 'sciterCount', search: 'sciterSearch', group: 'sciter',
    title: 'sciter', what: 'sciter函数',
    empty: '本栏只加载 lib/sciter.class（x86 时是 sciter_x86.class）：把 Sciter 控件的中文封装写成'
      + '「数据类型 … / 类函数 界面控件.新建控件(…) 结束类函数」即可，其它 *.class 一律进「类」栏。',
  });
}

/* ---------------- 编辑器右键「转到定义」 ---------------- */
/* 选择器属性值转义（标识符里可能出现的引号/反斜杠） */
function attrSel(name) {
  return String(name == null ? '' : name).replace(/([\\"])/g, '\\$1');
}

/* 解析标识符的定义位置（自定义符号一律跳编辑器，库命令跳侧栏）：
   ① 本文件的 子程序 / 测试函数 / 导出子程序
   ② 本文件声明的 API（自定义 DLL 函数）
   ③ 本文件的类函数（类型.方法）
   ④ 本文件的 变量 / 全局变量 / 常量、数据类型，以及「变量.成员」
   ⑤ 核心库命令 → 「核心」选项卡定位并高亮
   ⑥ 类库 lib/*.class 的类函数 → 「类」选项卡定位并高亮
   返回 {kind:'file',line} | {kind:'classLib',owner,name} | {kind:'core',name} | null */
function resolveDefinition(word, owner, t) {
  if (!word || !t) return null;
  const text = t.content || '';
  // ① 本文件的子程序 / 测试函数 / 导出子程序
  if (!owner) {
    const sub = parseSubs(text).find((s) => s.name === word);
    if (sub) return { kind: 'file', line: sub.line, name: word };
  }
  // ② 本文件声明的「API」（自定义 DLL 函数声明：API 返回类型 名称(参数) 在库 "xxx.dll"）
  if (!owner) {
    const api = apiDeclMap(text)[word];
    if (api) return { kind: 'file', line: api.line, name: word, api: true };
  }
  // ③ 本文件的类函数（「类型.方法」或只写方法名）
  const ms = collectMethodDefs(text);
  const m = owner ? ms.find((x) => x.owner === owner && x.name === word)
                  : ms.find((x) => x.name === word);
  if (m) return { kind: 'file', line: m.line, name: word, owner: m.owner };
  // ④ 本文件的 变量 / 全局变量 / 常量、数据类型（以及自定义类型的成员）
  const types = collectTypeDefs(text);
  if (!owner) {
    const vd = collectVarDecls(text).find((v) => v.name === word);
    if (vd) return { kind: 'file', line: vd.line, name: word, sym: vd.kind };
    if (types[word]) return { kind: 'file', line: types[word].line, name: word, sym: '数据类型' };
  } else {
    // 「变量.成员」：owner 可能是本文件的变量（取其数据类型），或就是数据类型名
    const vt = collectVarTypes(text, collectStructDefs(text));
    const otype = vt[owner] || owner;
    const td = types[otype];
    const fld = td && td.fields.find((f) => f.name === word);
    if (fld) return { kind: 'file', line: fld.line, name: word, owner: otype, sym: '成员' };
  }
  // ⑤ 核心库命令（不带「类名.」前缀时）
  if (!owner && (S.corelib.cmds || []).some((c) => c.name === word)) {
    return { kind: 'core', name: word };
  }
  // ⑥ 类库 lib/*.class 的类函数
  const libMs = (S.libClass && S.libClass.methods) || [];
  const lm = owner ? libMs.find((x) => x.owner === owner && x.name === word)
                   : libMs.find((x) => x.name === word);
  if (lm) return { kind: 'classLib', owner: lm.owner, name: lm.name };
  return null;
}

/* 在侧栏选项卡里定位并高亮条目（被搜索框过滤、或分组折叠时先恢复显示） */
async function revealSideItem(panel, listId, searchId, selector) {
  switchSideTab(panel);
  if (panel === 'classes') await renderClasses(); else renderLib();
  const box = $(listId);
  if (!box) return false;
  let el = box.querySelector(selector);
  if (!el) {                                   // 可能被搜索框过滤掉了 → 清空过滤再找
    const s = $(searchId);
    if (s && s.value) {
      s.value = '';
      if (panel === 'classes') await renderClasses(); else renderLib();
      el = box.querySelector(selector);
    }
  }
  if (!el) return false;
  // 展开它所在的分组（分组折叠时条目是 display:none，滚动无效）
  let catEl = el.previousElementSibling;
  while (catEl && !(catEl.classList && catEl.classList.contains('libCat'))) {
    catEl = catEl.previousElementSibling;
  }
  if (catEl) {
    catEl.classList.remove('collapsed');
    const key = (catEl.dataset.owner !== undefined) ? 'owner' : 'cat';
    box.querySelectorAll('.libItem').forEach((it) => {
      if (it.dataset[key] === catEl.dataset[key]) it.style.display = '';
    });
  }
  el.style.display = '';
  el.scrollIntoView({ block: 'center' });
  el.classList.add('hit');
  clearTimeout(el._hitTimer);
  el._hitTimer = setTimeout(() => el.classList.remove('hit'), 1800);
  return true;
}

/* 转到定义（编辑器右键菜单调用）：本文件函数 → 编辑器；类函数/核心库命令 → 侧栏定位高亮 */
async function gotoDefinition(word, owner) {
  const t = activeTab();
  if (!t) return;
  const target = resolveDefinition(word, owner, t);
  if (!target) { toast('未找到「' + word + '」的定义'); return; }
  if (target.kind === 'file') { gotoLine(target.line); return; }
  if (target.kind === 'core') {
    const ok = await revealSideItem('lib', 'libList', 'libSearch',
      '.libItem[data-name="' + attrSel(target.name) + '"]');
    toast(ok ? ('核心库命令：' + target.name) : ('未在「核心」选项卡中找到 ' + target.name));
    return;
  }
  const ok = await revealSideItem('classes', 'classList', 'clsSearch',
    '.libItem[data-owner="' + attrSel(target.owner) + '"][data-name="' + attrSel(target.name) + '"]');
  toast(ok ? ('类函数：' + target.owner + '.' + target.name)
    : ('未在「类」选项卡中找到 ' + target.owner + '.' + target.name));
}

/* 确保当前标签是可编辑的 .yy 源码（必要时自动切换到可编辑标签），再回调该标签。
   用于「插入前必须先读取目标文件内容做检查」的场景（如双击类函数时检查定义是否已存在） */
function withEditableTab(cb) {
  const t0 = activeTab();
  if (t0 && !t0.readonly && !t0.gen) { cb(t0); return; }
  ensureEditableTab().then((ok) => {
    if (!ok) return;
    const ta = $('codeInput');
    // 刚切过来的标签若光标停在 0（未记忆光标），就放到末尾，插入位置更符合预期
    if (ta && ta.selectionStart === 0 && ta.selectionEnd === 0) {
      ta.selectionStart = ta.selectionEnd = ta.value.length;
    }
    const t = activeTab();
    if (t) cb(t);
  });
}

/* 在编辑器光标处插入文本（并标脏、触发自动保存）。
   若当前标签是只读 / C++ 生成代码，则先自动切到可编辑的 .yy 源码标签，再插入。 */
function insertAtCursor(text, opts) {
  const t = activeTab();
  if (!t || t.readonly || t.gen) {
    ensureEditableTab().then((ok) => {
      if (!ok) return;
      const ta = $('codeInput');
      // 刚切过来的标签若光标停在 0（未记忆光标），就放到末尾，插入位置更符合预期
      if (ta && ta.selectionStart === 0 && ta.selectionEnd === 0) {
        ta.selectionStart = ta.selectionEnd = ta.value.length;
      }
      insertAtCursorNow(text, opts);
    });
    return;
  }
  insertAtCursorNow(text, opts);
}

/* 切到可编辑的 .yy 源码标签：优先用已打开的（取最近打开的那个），
   没有则打开工程里的第一个 .yy；都没有则提示。返回是否已就绪。 */
async function ensureEditableTab() {
  const cur = activeTab();
  if (cur && cur.kind === 'yy' && !cur.readonly && !cur.gen) return true;
  const cands = [];
  S.tabs.forEach((x, i) => {
    if (x.kind === 'yy' && !x.readonly && !x.gen) cands.push(i);
  });
  if (cands.length) {
    const i = cands[cands.length - 1];
    activateTab(i);
    toast('已在源码「' + S.tabs[i].path + '」中插入');
    return true;
  }
  if (S.project) {
    try {
      const tr = await api('GET', '/api/tree?project=' + encodeURIComponent(S.project));
      const find = (nodes) => {
        for (const n of (nodes || [])) {
          if (!n.dir && /\.yy$/i.test(n.path)) return n.path;
          const r = find(n.children);
          if (r) return r;
        }
        return null;
      };
      const p = find(tr.tree || []);
      if (p) {
        await openFile(p, {});
        toast('已打开源码「' + p + '」再插入');
        return true;
      }
    } catch (e) { /* 忽略：下面统一提示 */ }
  }
  toast(S.project
    ? '请先打开一个 .yy 源码文件（当前标签是只读或 C++ 生成代码），插入目标是正在编辑的源码'
    : '请先在上方选择一个工程（或打开工程里的 .yy 源码文件），再插入', 4600);
  return false;
}

function insertAtCursorNow(text, opts) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || !t || t.readonly || t.gen) { toast('请先打开一个可编辑的源码文件'); return; }
  let txt = text;
  let s = ta.selectionStart, e = ta.selectionEnd;
  if (opts && opts.block) {
    // 多行块（整段定义 / 一组定义）：不把当前行劈开 ——
    // 光标停在非空行中间时，把插入点移到本行末尾，让整块落到这一行下方
    if (s === e) {
      const ls = ta.value.lastIndexOf('\n', s - 1) + 1;
      let le = ta.value.indexOf('\n', s);
      if (le < 0) le = ta.value.length;
      if (ta.value.slice(ls, s).trim() !== '' || ta.value.slice(s, le).trim() !== '') {
        s = e = le;
        ta.setSelectionRange(s, s);
      }
    }
    // 光标不在行首时先另起一行，块末再补一个换行，避免与既有代码粘连
    const before = ta.value.slice(0, s);
    if (before && !/\n\s*$/.test(before)) txt = '\n' + txt;
    if (!/\n$/.test(txt)) txt += '\n';
  }
  const v = ta.value;
  // 光标停在「(」后面、且到「)」之间只剩逗号分隔符（刚补出来的空调用就是这种）→
  // 整段替换这个调用（连旧调用名一起换掉），避免连续点击造成嵌套或名字叠在一起。
  // 参数分隔符跟着新文本一起进来。
  let lp = -1, rp = -1;
  if (s === e && s >= 1 && v[s - 1] === '(') {
    const close = v.indexOf(')', s);
    if (close >= 0 && /^,*$/.test(v.slice(s, close))) {
      rp = close;
      let i = s - 2;      // 往回吃掉调用名（子程序名 /「类型.方法」）
      while (i >= 0 && /[A-Za-z0-9_一-龥.]/.test(v[i])) i -= 1;
      lp = i + 1;
    }
  }
  if (!(opts && opts.block) && lp >= 0) {
    const off = acCallCaretOffset(txt);
    ta.value = v.slice(0, lp) + txt + v.slice(rp + 1);
    ta.selectionStart = ta.selectionEnd = lp + (off >= 0 ? off : txt.length - 1);
  } else {
    ta.value = v.slice(0, s) + txt + v.slice(e);
    // 调用文本（括号里已按参数个数铺好逗号）→ 光标停到第一个参数处
    const off = acCallCaretOffset(txt);
    const 光标 = off >= 0 ? s + off : s + txt.length;
    ta.selectionStart = ta.selectionEnd = 光标;
  }
  t.content = ta.value;
  t.dirty = true;
  updateProjDefsForTab(t);       // 工程级快照：本文件内容变了
  recomputeUndefHits();
  refreshUndefCalls(t);          // 补上定义后立即撤销对应的「未定义」标记
  // 插入（含双击补定义）不产生 input 事件，这里手动把「类函数定义快照」对齐，
  // 否则随后删掉刚插入的定义时，删除检测会漏掉它
  snapMethodDefs(t);
  histPush(t, true);             // 插入函数调用：独立一步
  renderTabs();
  drawOverlay(t);
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => saveFile(t), 900);
  ta.focus();
}

/* ---------------- 重命名符号（同步修改调用处） ---------------- */
/* 在本工程所有 .yy 文件中，把「整词」出现的旧名替换为新名：
   子程序 / 测试函数 / 类函数（方法名）/ 变量 / 常量 / 数据类型 等一视同仁。
   返回 { files, count }：改动的文件数与替换处数。 */
async function renameSymbol(oldName, newName) {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(^|[^A-Za-z0-9_\\u4e00-\\u9fff])(' + esc(oldName)
    + ')(?![A-Za-z0-9_\\u4e00-\\u9fff])', 'g');
  let count = 0;
  let files = 0;
  for (const rel of projectYyPaths()) {
    const tab = S.tabs.find((t) => t.project === S.project && t.path === rel);
    let text = null;
    if (tab) text = tab.content;
    else {
      try {
        const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
          + '&path=' + encodeURIComponent(rel));
        if (!d.binary) text = d.text;
      } catch (e) { continue; }
    }
    if (text == null) continue;
    let n = 0;
    const out = text.replace(re, (m, p1) => { n++; return p1 + newName; });
    if (!n) continue;
    if (tab) {                                  // 已打开：先改内存（随后统一保存）
      tab.content = out;
      tab.dirty = true;
      count += n;
      files++;
    } else {                                    // 未打开：直接写盘
      try {
        await api('POST', '/api/file', { project: S.project, path: rel, content: out });
        count += n;
        files++;
      } catch (e) { /* 写入失败则跳过该文件 */ }
    }
  }
  // 当前文件：把改名结果同步到编辑框，并记入撤销历史（可整体撤销）
  const act = activeTab();
  const ta = $('codeInput');
  if (act && ta && !act.readonly && !act.gen) {
    const caret = Math.min(ta.selectionStart, act.content.length);
    ta.value = act.content;
    ta.setSelectionRange(caret, caret);
    drawOverlay(act);
    histPush(act, true);
    renderTabs();
    updateStatusBar();
    renderSubs();
    renderClasses();
    updateAutoComplete();
  }
  try { await saveAll(); } catch (e) { /* 忽略保存异常 */ }
  return { files, count };
}

/* 右键「重命名」的适用范围：只有下面四类「定义」才给这个菜单项 ——
   · 变量（含 全局变量） · 常量 · 自定义数据类型 · 子程序（含 测试函数 / 导出子程序）

   类函数、类库类函数、数据类型成员、API 声明、核心库命令、语言关键字等一律不给：
   右键菜单里干脆不出现「重命名」，免得把关键字 / 库命令名改坏
   （这些名字要在「类」/「API」栏或源码里手工改，改完还要连带改调用约定）。
   返回命中的种类名（对话框标题用），不属于上述四类时返回 ''。
   判定依据是**当前编辑器文件**里的定义（变量 / 常量 / 类型 / 子程序都定义在 .yy 里）。 */
function renamableKind(word, owner, t) {
  if (!word || owner || !t || t.kind !== 'yy') return '';   // 「类型.成员 / 类型.方法」不给
  const text = t.content || '';
  const sub = parseSubs(text).find((s) => s.name === word);
  if (sub) return sub.kind;                                 // 子程序 / 测试函数 / 导出子程序
  const vd = collectVarDecls(text).find((v) => v.name === word);
  if (vd) return vd.kind;                                   // 变量 / 全局变量 / 常量
  if (collectTypeDefs(text)[word]) return '数据类型';          // 自定义数据类型
  return '';
}

/* 弹出「重命名」对话框并执行改名
   （owner 为所属数据类型，what 为种类说明：变量 / 常量 / 数据类型 / 子程序） */
async function promptRename(oldName, owner, what) {
  const t = activeTab();
  if (!t || t.kind !== 'yy' || t.readonly || t.gen || !S.project) {
    toast('请先打开一个可编辑的源码文件');
    return;
  }
  const f = await modalForm('重命名' + (owner ? '（' + owner + ' 的' + (what || '类函数') + '）'
                                            : (what ? '（' + what + '）' : '')), [
    { key: 'name', label: '新名称', value: oldName,
      help: '将同步修改本工程内所有 .yy 文件中调用它的名称' },
  ], '重命名');
  if (!f) return;
  const nn = (f.name || '').trim();
  if (!nn || nn === oldName) return;
  if (!/^[A-Za-z0-9_\u4e00-\u9fff]+$/.test(nn)) {
    toast('名称只能使用中英文、数字与下划线');
    return;
  }
  const r = await renameSymbol(oldName, nn);
  toast(r.count
    ? ('已重命名 ' + oldName + ' → ' + nn + '（' + r.count + ' 处 / ' + r.files + ' 个文件）')
    : ('未找到 ' + oldName + ' 的引用'));
}

/* ---------------- 第三栏：当前源码的子程序 ---------------- */
/* 去掉源码中的注释（保持行结构不变）：' 与 // 行注释、跨行 /* 块注释。
   字符串内的内容原样保留。所有「识别定义/块结构」的扫描都必须先用它，
   保证注释行不会被当作任何标识。 */
function stripCommentsText(text) {
  const out = [];
  let inBlock = false;                       // 跨行块注释状态
  (text || '').split('\n').forEach((line) => {
    let result = '';
    let inStr = false;
    let j = 0;
    while (j < line.length) {
      const c = line[j];
      if (inBlock) {                         // 在块注释内：找到本行的 */
        const ep = line.indexOf('*/', j);
        if (ep < 0) { j = line.length; break; }
        j = ep + 2;
        inBlock = false;
        continue;
      }
      if (inStr) {                           // 字符串内：转义与闭合
        if (c === '\\') { result += c + (line[j + 1] || ''); j += 2; continue; }
        result += c;
        if (c === '"') inStr = false;
        j++;
        continue;
      }
      if (c === '"') { inStr = true; result += c; j++; continue; }
      if (c === "'") break;                  // 行注释
      if (c === '/' && line[j + 1] === '/') break;
      if (c === '/' && line[j + 1] === '*') {  // 块注释（可能单行闭合或跨行）
        const ep = line.indexOf('*/', j + 2);
        if (ep < 0) { inBlock = true; break; }
        j = ep + 2;
        continue;
      }
      result += c;
      j++;
    }
    out.push(result);
  });
  return out.join('\n');
}

function parseSubs(text) {
  const out = [];
  const re = /^[ \t]*(导出子程序|子程序|测试函数)[ \t]+([^\s(（]+)[ \t]*[\(（]?([^)）]*)[\)）]?/;
  stripCommentsText(text).split('\n').forEach((ln, i) => {
    const m = re.exec(ln);
    if (m) out.push({ kind: m[1], name: m[2], args: (m[3] || '').trim(), line: i + 1 });
  });
  return out;
}

function renderSubs() {
  const box = $('subList');
  if (!box) return;
  const t = activeTab();
  if (!t) { S.subsTab = null; box.innerHTML = '<div class="subEmpty">未打开文件</div>'; return; }
  // 记下这份列表来自哪个文件：「函数」栏的 ⟳ 要重载的正是它（见 refreshSubsFromFile）
  S.subsTab = t;
  const allSubs = parseSubs(t.content);
  const allMethods = collectMethodDefs(t.content);
  const allStructs = collectStructDefsOrdered(t.content);   // 本文件的数据类型（含成员）
  const allApis = collectApiDecls(t.content);               // 本文件顶层的 API 声明（含注释）
  // 「函数」选项卡列出的子程序 / 类函数 / API → 同步登记到自动完成符号表（未登记才添加）
  // 登记一律使用完整列表，不受上方搜索框过滤影响
  allSubs.forEach((s) => acEnsure(s.name, s.kind, s.args, true));
  allMethods.forEach((m) => acEnsureClassMethod(m, '本文件'));
  allApis.forEach((a) => acEnsure(a.name, 'API 声明', a.args, true));
  if (!allSubs.length && !allMethods.length && !allStructs.length && !allApis.length) {
    box.innerHTML = '<div class="subEmpty">本文件还没有子程序 / API 声明</div>';
    return;
  }
  // 搜索过滤：按名字（类函数按「类型.方法」全名）与参数 / 成员类型匹配（支持拼音 / 首字母）
  const kw = (($('subSearch') && $('subSearch').value) || '').trim().toLowerCase();
  const hit = (name, args) => kwHit(kw, name, args);
  const subs = allSubs.filter((s) => hit(s.name, s.args));
  const methods = allMethods.filter((m) => hit(m.owner + '.' + m.name, m.args));
  // API 声明：名称 / 参数 / 所在库 / 注释都能搜
  const apis = allApis.filter((a) => hit(a.name,
    (a.args || '') + ' ' + (a.dll || '') + ' ' + (a.comment || '')));
  // 数据类型：类型名命中，或任一成员命中，则整组显示
  const structs = allStructs.filter((s) => !kw || hit(s.name, '')
    || (s.fields || []).some((f) => hit(f.name, f.type)));
  if (!subs.length && !methods.length && !structs.length && !apis.length) {
    box.innerHTML = '<div class="subEmpty">没有匹配的函数</div>';
    return;
  }
  // 列表按源码行号顺序排列：子程序单独一行；「数据类型 + 它的类函数」合并成一组
  // （与「类」选项卡一致：成员行在前、类函数行在后；含类函数的组头绿色，纯数据类型组头淡蓝色）
  const fieldsByOwner = {};
  structs.forEach((s) => { if (!fieldsByOwner[s.name]) fieldsByOwner[s.name] = s; });
  const methodsByOwner = {};
  methods.forEach((m) => { (methodsByOwner[m.owner] = methodsByOwner[m.owner] || []).push(m); });
  Object.values(methodsByOwner).forEach((l) => l.sort((a, b) => a.line - b.line));
  const owners = [];                       // 组的顺序：按组内首个定义（成员或类函数）的行号
  const firstLine = {};
  const noteOwner = (name, line) => {
    if (!(name in firstLine)) { owners.push(name); firstLine[name] = line; }
    else if (line < firstLine[name]) firstLine[name] = line;
  };
  structs.forEach((s) => noteOwner(s.name, s.line));
  methods.forEach((m) => noteOwner(m.owner, m.line));
  const entries = subs.map((s) => ({ sub: true, line: s.line, name: s.name, args: s.args, kind: s.kind }))
    .concat(apis.map((a) => ({ api: true, line: a.line, name: a.name, args: a.args,
                               ret: a.ret, dll: a.dll, raw: a.raw, comment: a.comment || '' })))
    .concat(owners.map((o) => ({ sub: false, group: true, line: firstLine[o], owner: o })));
  entries.sort((a, b) => a.line - b.line);
  let html = '';
  const gdata = {};                        // owner → { sd, list }：组头 / 类函数行双击补定义时用
  for (const en of entries) {
    if (en.sub) {
      html += '<div class="subItem' + (en.kind === '测试函数' ? ' test' : '')
        + '" data-line="' + en.line + '" data-name="' + escHtml(en.name)
        + '" data-args="' + escHtml(en.args || '') + '" title="'
        + escHtml(en.kind + ' ' + en.name + '（第 ' + en.line + ' 行）'
          + '\n右键：转到定义 / 重命名（同步改全部调用处）；双击：插入函数调用') + '">'
        + '<span class="sname">' + escHtml(en.name) + '</span>'
        + '<span class="sargs">' + escHtml(en.args) + '</span>'
        + '<span class="sline">' + en.line + '</span></div>';
      continue;
    }
    if (en.api) {
      // 本文件里声明的 API：列表里**只显示命令名称**（+ 行号，与其它行一致），
      // 不带参数、不带注释；参数 / 返回 / 所在库 / 全部注释放在悬停气泡里
      // （名称用编辑框里 API 的关键字色，与「API」栏同一套）
      html += '<div class="subItem apiSub" data-line="' + en.line + '"'
        + ' data-name="' + escHtml(en.name) + '" data-sig="' + escHtml(en.args || '') + '"'
        + ' data-ret="' + escHtml(en.ret || '空') + '"'
        + ' data-dll="' + escHtml(en.dll || '') + '" data-raw="' + escHtml(en.raw || '') + '"'
        + ' data-comment="' + escHtml(en.comment || '') + '" title="'
        + escHtml('API ' + en.name + '(' + (en.args || '') + ')  返回：' + (en.ret || '空')
          + '\n所在库：' + (en.dll || '') + '（本文件第 ' + en.line + ' 行，已在源码顶层声明）'
          + (en.comment ? '\n\n' + en.comment : '')
          + '\n\n右键：转到定义；双击：插入该 API 的调用') + '">'
        + '<span class="sname">' + escHtml(en.name) + '</span>'
        + '<span class="sline">' + en.line + '</span></div>';
      continue;
    }
    const owner = en.owner;
    const sd = fieldsByOwner[owner];
    const flds = (sd && sd.fields) || [];
    const list = methodsByOwner[owner] || [];
    gdata[owner] = { sd, list };                     // 组头 / 类函数行双击补定义时取用
    const parts = [];
    if (flds.length) parts.push('成员 ' + flds.length);
    if (list.length) parts.push('类函数 ' + list.length);
    const defLine = (sd && sd.line) || en.line;      // 转到定义：优先跳到「数据类型」定义行
    // 组头：有类函数 → 绿色（.libCat 默认色）；只有成员 → 淡蓝色（.dataMgroup）
    // 不折叠（点击不收起）；双击补上本文件缺的定义；右键菜单：转到定义 / 重命名
    html += '<div class="libCat mgroup' + (list.length ? '' : ' dataMgroup')
      + '" data-owner="' + escHtml(owner) + '" data-line="' + defLine + '" title="'
      + escHtml('数据类型 ' + owner + '（' + (parts.join(' · ') || '无成员') + '）'
        + (sd ? '\n来源：本文件第 ' + defLine + ' 行'
              : '\n注意：本文件里还没有「数据类型 ' + owner + '」声明（双击可从类库补上）')
        + '\n双击：补上本文件缺少的数据类型 / 类函数定义'
        + '\n右键：转到定义 / 重命名（组内成员与类函数见下方列表）') + '">'
      + escHtml(owner) + '（' + (parts.join(' · ') || '无成员') + '）</div>';
    // ① 成员行（成员名 + 成员类型）；右键菜单与子程序一致
    flds.forEach((f) => {
      html += '<div class="subItem memberItem" data-owner="' + escHtml(owner)
        + '" data-name="' + escHtml(f.name) + '" data-line="' + (f.line || '') + '" title="'
        + escHtml('成员 ' + owner + '.' + f.name + '：' + f.type
          + (f.line ? '（第 ' + f.line + ' 行）' : '')
          + '\n右键：转到定义；双击：插入 ' + owner + '.' + f.name) + '">'
        + '<span class="sname">' + escHtml(f.name) + '</span>'
        + '<span class="mtype">' + escHtml(f.type) + '</span></div>';
    });
    // ② 类函数行
    list.forEach((m) => {
      html += '<div class="subItem methodItem" data-line="' + m.line
        + '" data-owner="' + escHtml(m.owner) + '" data-name="' + escHtml(m.name)
        + '" data-args="' + escHtml(m.args || '') + '" title="'
        + escHtml('类函数 ' + m.owner + '.' + m.name + '(' + (m.args || '') + ')（第 ' + m.line + ' 行）'
          + '\n右键：转到定义；双击：插入类函数调用'
          + '（本文件缺「数据类型 / 类函数」定义时会先补上）') + '">'
        + '<span class="sname">' + escHtml(m.name) + '</span>'
        + '<span class="sargs">' + escHtml(m.args || '') + '</span>'
        + '<span class="sline">' + m.line + '</span></div>';
    });
  }
  box.innerHTML = html;
  // 子程序：双击插入调用；右键菜单「转到定义 / 重命名（同步改调用处）」
  box.querySelectorAll('.subItem:not(.methodItem):not(.memberItem):not(.apiSub)').forEach((el) => {
    el.ondblclick = () => {
      const ta = $('codeInput');
      if (ta && !ta.disabled && activeTab()) insertAtCursor(acCallInsert(el.dataset.name, el.dataset.args));
    };
    el.oncontextmenu = (e) => {
      e.preventDefault();
      showContextMenu(e, [
        { label: '转到定义', act: () => gotoLine(parseInt(el.dataset.line, 10)) },
        { label: '重命名「' + el.dataset.name + '」…', act: () => promptRename(el.dataset.name) },
      ]);
    };
  });
  // 本文件声明的 API：单击看参数 / 返回 / 所在库（注释就显示在行下方）；
  // 双击插入该 API 的调用；右键只有「转到定义」（API 不属于可重命名的四类，不给重命名）
  box.querySelectorAll('.subItem.apiSub').forEach((el) => {
    let clickTimer = null;
    el.onclick = () => {
      clearTimeout(clickTimer);
      clickTimer = setTimeout(() => {
        toast('API ' + el.dataset.name + '(' + (el.dataset.sig || '') + ')  返回：'
          + (el.dataset.ret || '空') + '  在库：' + el.dataset.dll
          + '  本文件第 ' + el.dataset.line + ' 行', 4200);
      }, 230);
    };
    el.ondblclick = () => {
      clearTimeout(clickTimer);
      const ta = $('codeInput');
      if (ta && !ta.disabled && activeTab()) insertAtCursor(acCallInsert(el.dataset.name, el.dataset.sig));
    };
    el.oncontextmenu = (e) => {
      e.preventDefault();
      showContextMenu(e, [
        { label: '转到定义', act: () => gotoLine(parseInt(el.dataset.line, 10)) },
      ]);
    };
  });
  // 数据类型 / 类函数组头（如 `运算（成员 2 · 类函数 4）`）：不折叠（点击不收起）；
  // 双击 → 与「类」选项卡一致：把本文件缺少的「数据类型声明 + 该组类函数定义」补进编辑器
  // （本文件没有「数据类型 运算」声明时，会从 lib/*.class 取原文补上）；右键：转到定义 / 重命名
  box.querySelectorAll('.libCat.mgroup').forEach((el) => {
    const owner = el.dataset.owner;
    el.ondblclick = () => {
      const g = gdata[owner] || {};
      const sd = g.sd;
      insertMissingClassDefs(owner, {
        raw: (sd && sd.raw) || libStructRaw(owner),
        fields: (sd && sd.fields) || libFields(owner),
        methods: (g.list || []).map((m) => ({ name: m.name, args: m.args,
          raw: m.raw || libMethodRaw(m.owner, m.name) })),
      });
    };
    el.oncontextmenu = (e) => {
      e.preventDefault();
      showContextMenu(e, [
        { label: '转到定义', act: () => gotoLine(parseInt(el.dataset.line, 10)) },
        { label: '重命名「' + owner + '」…', act: () => promptRename(owner) },
      ]);
    };
  });
  // 数据类型成员：双击插入「类型.成员」；右键菜单「转到定义」
  // （成员不属于「变量/常量/数据类型/子程序」，因此不提供重命名）
  box.querySelectorAll('.memberItem').forEach((el) => {
    el.ondblclick = () => {
      const ta = $('codeInput');
      if (ta && !ta.disabled && activeTab()) {
        insertAtCursor(el.dataset.owner + '.' + el.dataset.name);
      }
    };
    el.oncontextmenu = (e) => {
      e.preventDefault();
      const ln = parseInt(el.dataset.line, 10);
      showContextMenu(e, [
        { label: '转到定义', act: () => gotoLine(isNaN(ln) ? 1 : ln) },
      ]);
    };
  });
  // 类函数成员：双击插入「类型.方法()」；本文件缺「数据类型 类型」声明或该类函数定义时先补上；
  // 右键菜单「转到定义」→ 定位到类函数定义处
  box.querySelectorAll('.methodItem').forEach((el) => {
    el.ondblclick = () => {
      const ta = $('codeInput');
      if (!ta || ta.disabled || !activeTab()) return;
      const owner = el.dataset.owner, name = el.dataset.name;
      const g = gdata[owner] || {};
      withEditableTab((t) => {
        const text = t.content || '';
        const parts = [];
        const missing = [];
        if (!collectStructDefs(text)[owner]) {         // 本文件没有「数据类型 类型」声明 → 补上
          const sd = g.sd;
          const raw = (sd && sd.raw) || libStructRaw(owner);
          // 类库/文件里有数据类型原文就用原文；没有就补空数据类型（命名空间），否则编译报「数据类型未定义」
          parts.push(raw || ('数据类型 ' + owner + '\n结束数据类型'));
          acEnsureLibType(owner, (sd && sd.fields) || libFields(owner));
          missing.push('数据类型 ' + owner + (raw ? '' : '（空数据类型·命名空间）'));
        }
        if (!collectMethodDefs(text).some((m) => m.owner === owner && m.name === name)) {
          const md = (g.list || []).find((m) => m.name === name);
          const raw = (md && md.raw) || libMethodRaw(owner, name);
          if (raw) { parts.push(raw); missing.push('类函数 ' + owner + '.' + name); }
          }
          parts.push(acCallInsert(owner + '.' + name, el.dataset.args || ''));
        if (missing.length) toast('本文件缺少定义，已先补上：' + missing.join('、'), 4200);
        warnReservedMethodName(owner, name);      // 名字被内置命令占用 → 编译必报错，提醒改名
        insertAtCursor(parts.join('\n\n'), { block: parts.length > 1 });
      });
    };
    el.oncontextmenu = (e) => {
      e.preventDefault();
      showContextMenu(e, [
        { label: '转到定义', act: () => gotoLine(parseInt(el.dataset.line, 10)) },
      ]);
    };
  });
}

function gotoLine(line) {
  const ta = $('codeInput');
  if (!ta || ta.disabled) return;
  const idx = offsetOfLine(ta.value, line);
  ta.focus();
  ta.setSelectionRange(idx, idx);
  ta.scrollTop = Math.max(0, (line - 1) * LINE_H - ta.clientHeight / 2);
  ta.scrollLeft = 0;
  syncScroll();
}

/* ---------------- 侧栏选项卡切换（两层） ----------------
   外层（标题在底部）三栏：「系统 / 项目 / UI」
     · 系统：核心（核心库命令）/ 类（lib/*.class 数据类型与类函数）/ API（lib/*.api 里的 API 声明）
     · 项目：工程（文件树）/ 函数（当前源文件的子程序与类函数）
     · UI  ：界面控件库的中文封装 —— Qt（只加载 lib/qt.class，x86 时 qt_x86.class）/
             sciter（只加载 lib/sciter.class，x86 时 sciter_x86.class）
   三栏各有自己的内层选项卡条；切到某个内层选项卡时会自动把外层切到它所属的那一栏，
   所以其它地方原有的 switchSideTab('classes') / switchSideTab('subs') 调用都不用改。 */
const SIDE_PANELS = { files: 'panelFiles', subs: 'panelSubs',
                      widgets: 'panelWidgets', sciter: 'panelSciter',
                      lib: 'panelLib', classes: 'panelClasses', apis: 'panelApis',
                      consts: 'panelConsts' };
const SIDE_GROUPS = { proj: 'groupProj', sys: 'groupSys', ui: 'groupUI' };      // 外层栏 → 容器 id
/* 内层选项卡 → 所属栏；每栏的默认选项卡（该栏还没被看过时用）。 */
const SIDE_TAB_GROUP = { files: 'proj', subs: 'proj',
                         widgets: 'ui', sciter: 'ui',
                         lib: 'sys', classes: 'sys', apis: 'sys', consts: 'sys' };
const SIDE_DEFAULT_TAB = { proj: 'files', sys: 'lib', ui: 'widgets' };

/* 只切换外层栏（高亮 + 显示/隐藏），不动内层选项卡 */
function _applySideGroup(key) {
  if (!SIDE_GROUPS[key]) key = 'proj';
  S.sideGroup = key;
  document.querySelectorAll('#sideGroups .sideGroupTab').forEach((el) => {
    el.classList.toggle('active', el.dataset.group === key);
  });
  Object.keys(SIDE_GROUPS).forEach((k) => {
    const g = $(SIDE_GROUPS[k]);
    if (g) g.classList.toggle('hidden', k !== key);
  });
}

/* 点底部「系统 / 项目 / UI」：切到该栏，并恢复它上次看的内层选项卡 */
function switchSideGroup(key) {
  if (!SIDE_GROUPS[key]) key = 'proj';
  const last = (S.sideTabOfGroup || {})[key];
  switchSideTab(last || SIDE_DEFAULT_TAB[key] || 'files');
}

function switchSideTab(key) {
  if (!SIDE_PANELS[key]) key = 'files';
  S.sideTab = key;
  const grp = SIDE_TAB_GROUP[key] || 'proj';
  if (S.sideTabOfGroup) S.sideTabOfGroup[grp] = key;
  _applySideGroup(grp);
  // 三栏各有一根内层选项卡条（同一个 .sideTabs 类），都要按当前 key 刷新高亮
  document.querySelectorAll('.sideTabs .sideTab').forEach((el) => {
    el.classList.toggle('active', el.dataset.panel === key);
  });
  Object.keys(SIDE_PANELS).forEach((k) => {
    const p = $(SIDE_PANELS[k]);
    if (p) p.classList.toggle('hidden', k !== key);
  });
  if (key === 'lib') renderLib();
  if (key === 'classes') renderClasses();
  if (key === 'apis') renderApis();
  if (key === 'consts') renderConsts();
  if (key === 'widgets') renderWidgets();
  if (key === 'sciter') renderSciter();
  if (key === 'subs') renderSubs();
  scheduleIdeSave();
}

/* ---------------- 底部状态栏 ---------------- */
/* 把指定行内（字符串之外）的全角标点统一转换为半角。
   返回 null（无需替换）或 { changed, delta, lineStart, lineText, lineEnd }。 */
const FULLWIDTH_PUNCT = {
  '，': ',', '、': ',', '（': '(', '）': ')', '：': ':', '；': ';',
  '！': '!', '？': '?', '。': '.', '　': ' ',
};

function normalizePunctOnLine(ta, lineNo) {
  const text = ta.value;
  let ls = 0;
  for (let k = 1; k < lineNo; k++) {
    const p = text.indexOf('\n', ls);
    if (p < 0) return null;
    ls = p + 1;
  }
  let le = text.indexOf('\n', ls);
  if (le < 0) le = text.length;
  const line = text.slice(ls, le);
  let out = '', inStr = false, inComment = false, changed = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inComment) { out += c; continue; }           // 行注释内容原样保留
    if (!inStr && c === "'") { inComment = true; out += c; continue; }
    if (inStr && c === '\\') {                        // 字符串内转义字符原样保留
      out += c + (line[i + 1] || '');
      i++;
      continue;
    }
    // 引号是结构性字符：全角/半角引号都作为字符串边界，并统一转成半角 "
    if (c === '"' || c === '“' || c === '”') {
      inStr = !inStr;
      if (c !== '"') changed = true;
      out += '"';
      continue;
    }
    if (!inStr) {                                     // 字符串内的全角内容原样保留
      const m = FULLWIDTH_PUNCT[c];
      if (m !== undefined) { out += m; changed = true; continue; }
    }
    out += c;
  }
  if (!changed) return null;
  return { changed: true, delta: out.length - line.length, lineStart: ls,
           lineText: out, lineEnd: le };
}

function updateCaret() {
  const el = $('stCaret');
  if (!el) return;
  const ta = $('codeInput');
  if (!ta || ta.disabled) { el.textContent = '行 1 : 列 1'; return; }
  const pos = ta.selectionStart || 0;
  const line = lineOfOffset(ta.value, pos);

  // 光标离开某行后：自动把该行（字符串之外）的全角标点统一换成半角
  const t = activeTab();
  if (S.lastCaretLine !== undefined && S.lastCaretLine !== null
      && S.lastCaretLine !== line && S.lastCaretLine > 0
      && t && t.kind === 'yy' && !t.readonly && !t.gen) {
    const r = normalizePunctOnLine(ta, S.lastCaretLine);
    if (r) {
      ta.value = ta.value.slice(0, r.lineStart) + r.lineText + ta.value.slice(r.lineEnd);
      if (pos > r.lineStart) ta.setSelectionRange(pos + r.delta, pos + r.delta);
      t.content = ta.value;
      t.dirty = true;
      histPush(t, true);           // 全角标点自动转换：独立一步
      renderTabs();
      drawOverlay(t);
      clearTimeout(S.saveTimer);
      S.saveTimer = setTimeout(() => saveFile(t), 900);
      clearTimeout(S.subTimer);
      S.subTimer = setTimeout(() => { renderSubs(); renderClasses(); }, 400);
    }
  }
  S.lastCaretLine = line;

  const bol = offsetOfLine(ta.value, line);
  el.textContent = '行 ' + line + ' : 列 ' + (pos - bol + 1);
}

function updateStatusBar() {
  const t = activeTab();
  if ($('stProject')) {
    $('stProject').textContent = S.project ? '工程：' + S.project : '未打开工程';
    $('stProject').title = (S.cfg && S.cfg.dir) ? S.cfg.dir : '未打开工程';
  }
  if ($('stFile')) {
    if (t) {
      $('stFile').textContent = (t.dirty ? '● ' : '') + t.path;
      $('stFile').title = t.path + (t.dirty ? '（未保存）' : '') + (t.readonly ? '（只读）' : '');
    } else {
      $('stFile').textContent = '无文件';
      $('stFile').title = '未打开文件';
    }
  }
  if ($('stStat')) {
    if (!t) { $('stStat').textContent = '—'; }
    else {
      const s = statLines(t.content);
      $('stStat').textContent = s.total + ' 行 = 代码 ' + s.code + ' + 注释 ' + s.comment
        + ' + 空行 ' + s.blank + ' / ' + (t.content || '').length + ' 字符';
    }
  }
  if ($('stLang')) {
    $('stLang').textContent = !t ? '—' : (t.kind === 'yy' ? '云易中文' : (t.gen ? '生成的 C++' : 'C++'));
  }
  if ($('stMode')) {
    const arch = $('archSelect') ? $('archSelect').value : 'x64';
    const sv = ($('subsysSelect') && $('subsysSelect').value) || 'console';
    const subsys = sv === 'window' ? '窗口程序' : (sv === 'dll' ? 'DLL程序' : '控制台程序');
    $('stMode').textContent = '模式：' + ($('modeSelect') && $('modeSelect').value === 'release' ? '发布版' : '调试版')
      + ' · ' + arch + ' · ' + subsys;
  }
  if ($('stGit')) {
    $('stGit').textContent = S.branch ? '⎇ ' + S.branch : 'Git：无';
    $('stGit').title = S.branch ? ('当前分支：' + S.branch) : '尚未初始化 Git 仓库';
  }
  updateCaret();
}

async function refreshGitBranch() {
  if (!S.project) { S.branch = ''; updateStatusBar(); return; }
  try {
    const st = await api('GET', '/api/git/status?project=' + encodeURIComponent(S.project));
    S.branch = st.repo ? (st.branch || '') : '';
  } catch (e) { S.branch = ''; }
  updateStatusBar();
}

function startStatusBarClock() {
  const pad = (n) => (n < 10 ? '0' + n : String(n));
  const tick = () => {
    const now = new Date();
    const el = $('stTime');
    if (el) el.textContent = now.toLocaleTimeString('zh-CN', { hour12: false });
    // 顶栏「品牌下方」的时间 / 日期框（#clockDate / #clockTime）：与状态栏共用这一个
    // 定时器，不额外起 interval。日期带星期；时分秒补足两位，配合 CSS 的等宽数字，
    // 每秒跳动时框宽不会抖。
    const de = $('clockDate');
    if (de) {
      const wk = '星期' + '日一二三四五六'.charAt(now.getDay());
      de.textContent = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-'
        + pad(now.getDate()) + ' ' + (i18nLookup(wk) || wk);
    }
    const te = $('clockTime');
    if (te) {
      te.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes())
        + ':' + pad(now.getSeconds());
    }
  };
  tick();
  setInterval(tick, 1000);
}

function syncScroll() {
  const ta = $('codeInput');
  const pre = $('highlight');
  const gi = $('gutterInner');
  const gl = $('guideLayer');
  if (gi) gi.style.transform = 'translateY(-' + ta.scrollTop + 'px)';
  if (gl) gl.style.transform = 'translate(-' + ta.scrollLeft + 'px,-' + ta.scrollTop + 'px)';
  const fd = $('foldLayer');
  if (fd) fd.style.transform = 'translate(-' + ta.scrollLeft + 'px,-' + ta.scrollTop + 'px)';
  pre.style.transform = 'translate(-' + ta.scrollLeft + 'px,-' + ta.scrollTop + 'px)';
  updateEditorScrollbar();
}

/* 编辑器右侧自绘滚动条：同步高度与滑块位置/大小
   （系统的覆盖式滚动条又细又难点，故纵向改成自绘的 16px 宽滚动条） */
function updateEditorScrollbar() {
  const ta = $('codeInput'), bar = $('edScroll'), tr = $('edScrollTrack'), th = $('edScrollThumb');
  if (!ta || !bar || !tr || !th) return;
  if (ta.disabled) { bar.classList.add('hidden'); return; }   // 未打开工程
  bar.classList.remove('hidden');
  bar.style.height = ta.clientHeight + 'px';                 // 与可视高度一致
  const trackH = tr.clientHeight;
  const sh = ta.scrollHeight, ch = ta.clientHeight;
  if (sh <= ch + 1) { th.style.display = 'none'; return; }   // 内容放得下：只留两端按钮
  th.style.display = '';
  const h = Math.max(28, Math.round(trackH * ch / sh));
  const maxTop = Math.max(0, trackH - h);
  th.style.height = h + 'px';
  th.style.top = Math.round(maxTop * (ta.scrollTop / (sh - ch))) + 'px';
}

function initEditorScrollbar() {
  const ta = $('codeInput'), bar = $('edScroll'), tr = $('edScrollTrack'), th = $('edScrollThumb');
  if (!ta || !bar || !tr || !th) return;
  const jump = (id, where) => {
    const b = $(id);
    if (!b) return;
    b.onmousedown = (e) => e.preventDefault();     // 不夺走编辑器焦点（按完仍可继续打字）
    b.onclick = () => scrollEditorTo(where);
  };
  jump('scrollTopBtn', 'top');
  jump('scrollBottomBtn', 'bottom');
  // 拖动滑块滚动
  th.onmousedown = (e) => {
    e.preventDefault();
    const sh = ta.scrollHeight, ch = ta.clientHeight;
    const maxTop = Math.max(1, tr.clientHeight - th.offsetHeight);
    const maxScroll = Math.max(1, sh - ch);
    const y0 = e.clientY, top0 = ta.scrollTop;
    const mv = (ev) => {
      ta.scrollTop = top0 + (ev.clientY - y0) * maxScroll / maxTop;
    };
    const up = () => {
      document.removeEventListener('mousemove', mv);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
  };
  // 点滑轨空白：上/下翻一页
  tr.onmousedown = (e) => {
    if (e.target !== tr) return;
    e.preventDefault();
    const down = e.clientY > th.getBoundingClientRect().bottom;
    ta.scrollTop += (down ? 1 : -1) * Math.max(60, ta.clientHeight - 40);
  };
  // 面板高度/窗口尺寸变化时（编辑器尺寸随之改变）自动同步
  if (window.ResizeObserver) new ResizeObserver(() => updateEditorScrollbar()).observe(ta);
  updateEditorScrollbar();
}

/* ---------------- 智能体面板：右侧自绘滚动条（与编辑器同款） ----------------
   两端按钮：▲ 一键到顶（贴最顶）、▼ 一键到底（贴最底）；滑块可拖、轨道可点翻页。
   原生滚动条已隐藏，高度/滑块位置随消息增删与面板尺寸变化自动同步。 */
function updateAiScrollbar() {
  const box = $('aiMsgs'), bar = $('aiScroll'), tr = $('aiScrollTrack'), th = $('aiScrollThumb');
  if (!box || !bar || !tr || !th) return;
  bar.style.height = box.clientHeight + 'px';   // 条本身绝对定位、无自动高度，必须显式给
  const sh = box.scrollHeight, ch = box.clientHeight;
  if (sh <= ch + 1) { th.style.display = 'none'; return; }   // 内容放得下：只留两端按钮
  th.style.display = '';
  const trackH = tr.clientHeight;
  const h = Math.max(28, Math.round(trackH * ch / sh));
  const maxTop = Math.max(0, trackH - h);
  th.style.height = h + 'px';
  th.style.top = Math.round(maxTop * (box.scrollTop / Math.max(1, sh - ch))) + 'px';
}

function initAiScrollbar() {
  const box = $('aiMsgs'), tr = $('aiScrollTrack'), th = $('aiScrollThumb');
  if (!box || !tr || !th) return;
  const jump = (id, top) => {
    const b = $(id);
    if (!b) return;
    b.onmousedown = (e) => e.preventDefault();   // 不抢焦点
    b.onclick = () => { box.scrollTop = top ? 0 : box.scrollHeight; };
  };
  jump('aiScrollTop', true);
  jump('aiScrollBottom', false);
  // 拖动滑块
  th.onmousedown = (e) => {
    e.preventDefault();
    const sh = box.scrollHeight, ch = box.clientHeight;
    const maxTop = Math.max(1, tr.clientHeight - th.offsetHeight);
    const maxScroll = Math.max(1, sh - ch);
    const y0 = e.clientY, top0 = box.scrollTop;
    const mv = (ev) => {
      box.scrollTop = top0 + (ev.clientY - y0) * maxScroll / maxTop;
    };
    const up = () => {
      document.removeEventListener('mousemove', mv);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
  };
  // 点滑轨空白：上/下翻一页
  tr.onmousedown = (e) => {
    if (e.target !== tr) return;
    e.preventDefault();
    const down = e.clientY > th.getBoundingClientRect().bottom;
    box.scrollTop += (down ? 1 : -1) * Math.max(60, box.clientHeight - 40);
  };
  box.addEventListener('scroll', updateAiScrollbar);
  if (window.ResizeObserver) new ResizeObserver(updateAiScrollbar).observe(box);
  // 消息增加 / 删除时，滑块长度与位置也要跟着变
  if (window.MutationObserver) {
    new MutationObserver(updateAiScrollbar).observe(box, { childList: true, subtree: true });
  }
  updateAiScrollbar();
}

/* ---------------- 快捷键辅助 ---------------- */
// 记住鼠标当前指着的元素（Ctrl+Home / Ctrl+End 按「鼠标所在控件」滚动）
let hoverEl = null;
document.addEventListener('mouseover', (e) => {
  const t = e.target;
  hoverEl = (t && t.nodeType === 1) ? t : (t && t.parentElement) || null;
}, true);

/* 从元素向上找最近的「可纵向滚动」容器（编辑器、控制台、文件树、核心库/类/函数列表…） */
function scrollableAncestor(el) {
  for (let n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
    const can = (n.tagName === 'TEXTAREA')
      || /^(auto|scroll|overlay)$/.test(getComputedStyle(n).overflowY);
    if (can && n.scrollHeight > n.clientHeight + 2) return n;
  }
  return null;
}

/* Ctrl+Home / Ctrl+End：把鼠标所在控件的滚动条移到顶端 / 底端。
   返回 true 表示已处理、需要阻止浏览器默认行为；
   编辑器获得焦点时返回 false，保留原生行为（光标移到源码开头/末尾，顺带滚到顶/底） */
function scrollHoveredTo(where) {
  const box = scrollableAncestor(hoverEl) || scrollableAncestor(document.activeElement);
  if (!box) return false;
  const ta = $('codeInput');
  if (box === ta) {
    ta.scrollTop = (where === 'top') ? 0 : ta.scrollHeight;
    const t = activeTab();
    if (t) t.top = ta.scrollTop;
    syncScroll();
    return document.activeElement !== ta;
  }
  box.scrollTop = (where === 'top') ? 0 : box.scrollHeight;
  return true;
}

/* Ctrl+Enter：打开「请输入内容」对话框（自动切到「控制台」标签并展开底部面板）。
   程序执行到「输入文本」等待标准输入时也会自动弹出这个对话框（见 promptStdInput）。 */
function openConsoleInput() {
  if (S.consoleTab === 'problems') switchConsoleTab('console', true);
  setBottomFolded(false);
  promptStdInput(false);
}

/* 编辑器滚动条两端的快捷按钮：▲ 一键到顶 / ▼ 一键到底
   （直接改 textarea 的 scrollTop，再同步高亮层/行号/辅助线，编辑器仍可继续输入） */
function scrollEditorTo(where) {
  const ta = $('codeInput');
  if (!ta || ta.disabled) return;
  ta.scrollTop = (where === 'top') ? 0 : ta.scrollHeight;
  const t = activeTab();
  if (t) t.top = ta.scrollTop;          // 记住滚动位置（与手动滚动一致）
  syncScroll();
}

function jumpTo(path, line) {
  openFile(path).then((t) => {
    if (!t) return;
    const ta = $('codeInput');
    const idx = offsetOfLine(ta.value, line);
    ta.focus();
    ta.setSelectionRange(idx, idx);
    const pos = (line - 1) * LINE_H;
    ta.scrollTop = Math.max(0, pos - ta.clientHeight / 2);
    syncScroll();
  });
}

function offsetOfLine(text, line) {
  let off = 0;
  for (let i = 1; i < line; i++) {
    const p = text.indexOf('\n', off);
    if (p < 0) break;
    off = p + 1;
  }
  return off;
}

function lineOfOffset(text, off) {
  let line = 1;
  for (let i = 0; i < off; i++) if (text[i] === '\n') line++;
  return line;
}

/* ================= 编辑器撤销 / 重做 =================
   检测编辑框变化：每次改动后记录一份内容快照（连续输入按时间窗合并为一步），
   Ctrl+Z 撤销、Ctrl+Y / Ctrl+Shift+Z 重做。所有改写 ta.value 的地方都要调用 histPush。 */
const HIST_LIMIT = 300;        // 每个文件最多保存的快照数
const HIST_COALESCE = 600;     // 连续输入合并为一步撤销的时间窗（毫秒）

function histReset(t) {
  const ta = $('codeInput');
  t.hist = [{
    content: t.content,
    selStart: (ta && ta.selectionStart) || 0,
    selEnd: (ta && ta.selectionEnd) || 0,
  }];
  t.histIdx = 0;
  t.histTime = 0;
}

/* 判断 prev→next 是否属于「逐字输入」的小改动（最多增/删 1 个字符，且不含换行）；
   粘贴、大段删除、回车换行都视为独立一步。 */
function histTypingStep(prev, next) {
  if (prev === next) return false;
  if (Math.abs(next.length - prev.length) > 1) return false;
  const n = Math.min(prev.length, next.length);
  let i = 0;
  while (i < n && prev[i] === next[i]) i++;
  let j = 0;
  while (j < n - i && prev[prev.length - 1 - j] === next[next.length - 1 - j]) j++;
  const changedNext = next.slice(i, next.length - j);
  if (changedNext === '\n') return false;                    // 回车单独成步
  return prev.slice(i, prev.length - j).length <= 1 && changedNext.length <= 1;
}

/* 记录当前编辑框状态；force=true 表示独立成一步（不并入连续的逐字输入） */
function histPush(t, force) {
  const ta = $('codeInput');
  if (!ta || !t || t.readonly || t.gen) return;
  if (!t.hist) histReset(t);
  const cur = { content: ta.value, selStart: ta.selectionStart, selEnd: ta.selectionEnd };
  const top = t.hist[t.histIdx];
  if (top && top.content === cur.content) {          // 内容未变：只同步光标位置
    top.selStart = cur.selStart;
    top.selEnd = cur.selEnd;
    return;
  }
  const now = Date.now();
  const coalesce = !force && top
    && t.histIdx === t.hist.length - 1
    && now - (t.histTime || 0) < HIST_COALESCE
    && histTypingStep(top.content, cur.content);
  if (coalesce) {
    t.hist[t.histIdx] = cur;                         // 连续输入：并入上一步
  } else {
    t.hist = t.hist.slice(0, t.histIdx + 1);         // 丢弃「重做」分支
    t.hist.push(cur);
    t.histIdx = t.hist.length - 1;
    if (t.hist.length > HIST_LIMIT) { t.hist.shift(); t.histIdx--; }
  }
  t.histTime = now;
}

/* 跳到指定历史快照（撤销 / 重做共用） */
function histApply(t, idx) {
  const ta = $('codeInput');
  const st = t.hist[idx];
  if (!ta || !st) return;
  foldUnfoldAll(t);            // 撤销/重做前先展开：快照是完整源码，留着折叠会重复一份
  t.histIdx = idx;
  t.histTime = 0;
  const s = Math.max(0, Math.min(st.selStart, st.content.length));
  const e = Math.max(0, Math.min(st.selEnd, st.content.length));
  ta.value = st.content;
  ta.setSelectionRange(s, e);
  t.content = st.content;
  t.dirty = t.content !== t.savedContent;      // 回到已保存内容时清除「未保存」标记
  renderTabs();
  drawOverlay(t);
  updateStatusBar();
  hideAutoComplete();
  hideHoverTip();
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => saveFile(t), 900);
  clearTimeout(S.subTimer);
  S.subTimer = setTimeout(() => { renderSubs(); renderClasses(); }, 400);
  ta.focus();
  S.lastCaretLine = null;                      // 撤销/重做不触发全角标点自动转换
  updateCaret();
}

function undoEditor() {
  const t = activeTab();
  if (!t || t.readonly || t.gen) return false;
  if (!t.hist) histReset(t);
  if (t.histIdx <= 0) return false;
  histApply(t, t.histIdx - 1);
  return true;
}

function redoEditor() {
  const t = activeTab();
  if (!t || t.readonly || t.gen) return false;
  if (!t.hist) histReset(t);
  if (t.histIdx >= t.hist.length - 1) return false;
  histApply(t, t.histIdx + 1);
  return true;
}

/* ================= 缩进规范化（固定 2 空格） ================= */
/* 整份代码行首缩进统一重排：
   先探测文件现有的缩进单位，再按「层级 × INDENT」重排，
   保证每行行首缩进都是 2 空格的整数倍。 */
function normalizeIndent(text) {
  const src = String(text == null ? '' : text);
  if (!src) return src;
  const lines = src.split('\n');
  const widthOf = (ind) => ind.replace(/\t/g, '    ').length;
  const widths = [];
  for (const ln of lines) {
    if (!ln.trim()) continue;
    const w = widthOf(/^[ \t]*/.exec(ln)[0]);
    if (w > 0) widths.push(w);
  }
  if (!widths.length) return src;                      // 整体没有缩进：不动
  // 缩进单位 = 2..8 中「能整除的行数占比 ≥ 2/3」的最大者。
  // 这样个别的缩进笔误（如 3 空格）不会把单位带偏成 1。
  let unit = 1;
  for (let u = 2; u <= 8; u++) {
    let ok = 0;
    for (const w of widths) if (w % u === 0) ok++;
    if (ok >= widths.length * 2 / 3) unit = u;
  }
  let changed = false;
  const out = lines.map((ln) => {
    if (!ln.trim()) return ln;                         // 空行保持原样
    const ind = /^[ \t]*/.exec(ln)[0];
    const w = widthOf(ind);
    let lv = Math.round(w / unit);
    if (w > 0 && lv < 1) lv = 1;                       // 有缩进的行至少保留一级
    const nind = INDENT.repeat(lv);
    if (ind === nind) return ln;
    changed = true;
    return nind + ln.slice(ind.length);
  });
  return changed ? out.join('\n') : src;
}

/* 保存前统一重排：更新 t.content；若该文件正在编辑，同步到编辑框并保持光标所在位置 */
function applyNormalizedContent(t) {
  const norm = normalizeIndent(t.content);
  if (norm === t.content) return false;
  const ta = $('codeInput');
  const active = activeTab() === t;
  let line = 1, col = 0;
  if (active && ta) {
    const caret = ta.selectionStart || 0;
    line = lineOfOffset(t.content, caret);
    col = caret - offsetOfLine(t.content, line);
  }
  t.content = norm;
  if (active && ta && !t.readonly && !t.gen) {
    ta.value = norm;
    const bol = offsetOfLine(norm, line);
    const nl = norm.indexOf('\n', bol);
    const len = (nl < 0 ? norm.length : nl) - bol;
    const np = bol + Math.min(col, len);
    ta.setSelectionRange(np, np);
    drawOverlay(t);
    histPush(t, true);                                 // 自动重排记入撤销历史
  }
  return true;
}

/* ================= 代码格式化（右键菜单「格式化代码」） =================
   云易的分支结构由成对关键字决定（如果 … 结束如果），行首缩进只影响阅读。
   格式化做三件事（都不改语义）：
     ① **按上下文重排行首缩进**：块开始 +1 级、结束关键字 / 否则 / 循环尾 -1 级（一级 = 2 空格）
     ② **语法之间统一为一个空格**：连续空格压成一个；运算符两侧补空格（`a=1` → `a = 1`）；
        逗号后一个空格；`.` 与 `(` `)` `[` `]` 紧贴（关键字后的 `(` 除外：`如果 (a > 0)`）
     ③ 去掉行尾空白；字符串 `"…"` 与注释内容一律原样保留
   返回 { text, changed }（changed = false 表示本来就是规范格式） */
const FM_MID = ['否则', '否则如果'];                 // 本级行 → 之后的内容再缩进一级
const FM_KW_PAREN = ['如果', '如果真', '计次循环', '当循环', '判断循环首', '循环判断首',
  '否则如果', '返回', '直到'];                       // 这些关键字后面的 ( 前留一个空格
const FM_NO_SPACE_BEFORE = [',', ')', ']', '[', '.', '，', '）', '；', ';'];   // 数组下标 表[0] 紧贴
const FM_NO_SPACE_AFTER = ['(', '[', '.', '（'];
const FM_BINARY = ['=', '==', '!=', '>=', '<=', '>', '<', '+', '-', '*', '/', '%', '\\',
  '+=', '-=', '*=', '/=', '&&', '||', '&', '|', '且', '或', ':', '：'];
const FM_OPENERS = Object.keys(GUIDE_OPEN);
const FM_CLOSERS = (() => {
  const s = new Set();
  FM_OPENERS.forEach((k) => GUIDE_OPEN[k].forEach((c) => s.add(c)));
  return s;
})();
const FM_PUNCT_HALF = { '，': ',', '、': ',', '（': '(', '）': ')', '：': ':',
  '；': ';', '！': '!', '？': '?', '　': ' ' };

/* 单行代码 → token 串（字符串整段保留；全角标点顺手换成半角） */
function fmTokenize(s) {
  const out = [];
  const isW = (c) => /[A-Za-z0-9_\u4e00-\u9fff]/.test(c);
  let i = 0;
  while (i < s.length) {
    const c = s.charAt(i);
    if (c === ' ' || c === '\t' || c === '\u3000') { i++; continue; }
    if (c === '"') {                                   // 字符串：原样一段
      let j = i + 1;
      while (j < s.length && s.charAt(j) !== '"') {
        if (s.charAt(j) === '\\') j++;
        j++;
      }
      if (j >= s.length) { out.push(s.slice(i)); break; }
      out.push(s.slice(i, j + 1));
      i = j + 1;
      continue;
    }
    if (isW(c)) {
      let j = i;
      while (j < s.length && isW(s.charAt(j))) j++;
      if (/[0-9]/.test(c) && s.charAt(j) === '.' && /[0-9]/.test(s.charAt(j + 1) || '')) {
        j++;
        while (j < s.length && /[0-9]/.test(s.charAt(j))) j++;
      }
      out.push(s.slice(i, j));
      i = j;
      continue;
    }
    const two = s.substr(i, 2);
    if (FM_BINARY.indexOf(two) >= 0) { out.push(two); i += 2; continue; }
    out.push(FM_PUNCT_HALF[c] || c);
    i++;
  }
  return out;
}

/* token 串 → 规范空格的代码（不含缩进） */
function fmJoin(toks) {
  let out = '';
  for (let i = 0; i < toks.length; i++) {
    const cur = toks[i];
    if (i === 0) { out = cur; continue; }
    const prev = toks[i - 1];
    let sp = true;
    if (FM_NO_SPACE_AFTER.indexOf(prev) >= 0) sp = false;
    else if (FM_NO_SPACE_BEFORE.indexOf(cur) >= 0) sp = false;
    else if (cur === '(') sp = FM_KW_PAREN.indexOf(prev) >= 0;   // 如果 (…) / 输出(…)
    else if (prev === '!' || prev === '~') sp = false;           // 单目 非
    else if ((prev === '-' || prev === '+') && fmIsUnary(toks, i - 1)) sp = false;  // -1 / +2
    out += (sp ? ' ' : '') + cur;
  }
  return out;
}

/* toks[idx] 是一元 +/-（前面是运算符、左括号、逗号或行首） */
function fmIsUnary(toks, idx) {
  if (idx <= 0) return true;
  const p = toks[idx - 1];
  return FM_NO_SPACE_AFTER.indexOf(p) >= 0 || FM_BINARY.indexOf(p) >= 0;
}

/* 一行 → { code, comment }：字符串之外的 ' 或 // 或 /* 起为注释（原样保留） */
function fmSplitComment(line) {
  let inStr = false;
  for (let i = 0; i < line.length; i++) {
    const c = line.charAt(i);
    if (inStr) {
      if (c === '\\') { i++; continue; }
      if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') { inStr = true; continue; }
    if (c === "'") return { code: line.slice(0, i), comment: line.slice(i) };
    if (c === '/' && line.charAt(i + 1) === '/') return { code: line.slice(0, i), comment: line.slice(i) };
    if (c === '/' && line.charAt(i + 1) === '*') return { code: line.slice(0, i), comment: line.slice(i) };
  }
  return { code: line, comment: '' };
}

function fmFirstWord(line) {
  const m = /^[ \t]*([^\s("'（]+)/.exec(line);
  return m ? m[1] : '';
}

/* 第 upTo 行（0 基）之前的块深度：给「格式化选中代码」定起始缩进用 */
function fmDepthBefore(lines, upTo) {
  let depth = 0;
  for (let i = 0; i < upTo && i < lines.length; i++) {
    const kw = fmFirstWord(fmSplitComment(lines[i]).code);
    if (!kw) continue;
    if (FM_MID.indexOf(kw) >= 0) depth = Math.max(0, depth - 1) + 1;
    else if (FM_CLOSERS.has(kw)) depth = Math.max(0, depth - 1);
    else if (FM_OPENERS.indexOf(kw) >= 0) depth += 1;
  }
  return depth;
}

/* 整段代码格式化（startDepth：起始块深度，默认 0） */
function formatCodeText(text, startDepth) {
  const src = String(text == null ? '' : text).replace(/\r\n?/g, '\n');   // 统一 LF
  if (!src) return { text: src, changed: false };
  const lines = src.split('\n');
  let depth = Math.max(0, startDepth || 0);
  let inBlock = false;                                 // 跨行 /* */ 注释内部：整行原样
  let inAsm = false;                                   // asm 块内部：整行原样（汇编不能排版）
  const out = lines.map((ln) => {
    const noTail = ln.replace(/[ \t]+$/, '');
    if (inBlock) {
      if (noTail.indexOf('*/') >= 0) inBlock = false;
      return noTail;
    }
    if (inAsm) {
      const w = fmFirstWord(noTail);
      if (w === '结束asm' || w === '结束汇编') inAsm = false;
      return noTail;                                   // 指令原文照抄（空格/缩进都不动）
    }
    if (!noTail.trim()) return '';                     // 空行（含纯空白）→ 空行
    const sp = fmSplitComment(noTail);
    const code = sp.code.trim();
    const opensBlockComment = sp.comment.indexOf('/*') >= 0 && sp.comment.indexOf('*/') < 0;
    if (!code) {                                       // 纯注释行：按当前缩进，注释原样
      if (opensBlockComment) inBlock = true;
      return INDENT.repeat(depth) + sp.comment.trim();
    }
    const kw = fmFirstWord(code);
    if (kw === 'asm') {                                // asm 块头：后面的指令行整行原样
      inAsm = true;
      return INDENT.repeat(depth) + code;
    }
    const d = (FM_MID.indexOf(kw) >= 0 || FM_CLOSERS.has(kw)) ? Math.max(0, depth - 1) : depth;
    let line = INDENT.repeat(d) + fmJoin(fmTokenize(code));
    if (sp.comment) line += ' ' + sp.comment.trim();
    if (FM_MID.indexOf(kw) >= 0) depth = d + 1;        // 否则 / 否则如果：本级 → 内容 +1
    else if (FM_CLOSERS.has(kw)) depth = d;            // 结束xxx：回到本级
    else if (FM_OPENERS.indexOf(kw) >= 0) depth = d + 1;  // 块开始：内容 +1
    else depth = d;
    if (opensBlockComment) inBlock = true;
    return line;
  });
  const outText = out.join('\n');
  return { text: outText, changed: outText !== src };
}

/* 格式化编辑器内容：scope = 'all'（全部代码）| 'selection'（选区覆盖的整行）
   记入撤销历史（可 Ctrl+Z 撤回）；没有改动时给出明确提示，避免「按了没反应」 */
function formatEditorCode(scope) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || !t || ta.disabled) return;
  if (t.readonly || t.gen) {
    toast('这是只读 / C++ 生成代码，不能格式化；请先切到 .yy 源码文件');
    return;
  }
  foldUnfoldAll(t);          // 格式化会重写全部 / 选区内的行：先展开，折叠内容也一并规范掉
  if (scope === 'selection') {
    const s = ta.selectionStart, e = ta.selectionEnd;
    if (e <= s) { formatEditorCode('all'); return; }       // 没有选中 → 按「全部代码」处理
    const v = ta.value;
    const ls = v.lastIndexOf('\n', s - 1) + 1;             // 选区覆盖的整行
    let le = v.indexOf('\n', e);
    if (le < 0) le = v.length;
    const seg = v.slice(ls, le);
    // 起始缩进按「选区第一行之前的块深度」算：选中块内一段也不会越缩越平
    const r = formatCodeText(seg, fmDepthBefore(v.split('\n'), lineOfOffset(v, ls) - 1));
    if (!r.changed) {
      ta.focus();
      toast('选中部分已经是规范格式（缩进与空格都规范）');
      return;
    }
    const d = r.text.length - seg.length;
    editorReplaceRange(ls, le, r.text, s + d, e + d);
    toast('已格式化选中部分（第 ' + lineOfOffset(v, ls) + ' 行起，按上下文重排缩进）');
    return;
  }
  const r = formatCodeText(ta.value);
  if (!r.changed) { toast('代码已经是规范格式（缩进与空格都规范）'); return; }
  // 光标保持在原来的行 / 列附近
  const caret = ta.selectionStart || 0;
  const line = lineOfOffset(t.content, caret);
  const col = caret - offsetOfLine(t.content, line);
  const bol = offsetOfLine(r.text, line);
  const nl = r.text.indexOf('\n', bol);
  const len = (nl < 0 ? r.text.length : nl) - bol;
  const np = bol + Math.min(col, len);
  editorReplaceRange(0, ta.value.length, r.text, np, np);
  toast('已格式化全部代码（按上下文重排缩进、语法间统一一个空格）');
}

/* 「半级缩进」补正：当前行的行首缩进不足一级时补正到上一级（1→2、3→4 …），
   保证任何时候行首缩进都是 INDENT 的整数倍 */
function fixLineIndentAt(ta) {
  const v = ta.value;
  const pos = ta.selectionStart;
  const ls = v.lastIndexOf('\n', pos - 1) + 1;
  let le = v.indexOf('\n', pos);
  if (le < 0) le = v.length;
  const lineText = v.slice(ls, le);
  const ind = /^[ \t]*/.exec(lineText)[0];
  if (!ind || ind.indexOf('\t') >= 0) return false;    // 无缩进 / 含制表符：不动
  const nw = Math.ceil(ind.length / INDENT.length) * INDENT.length;
  if (nw === ind.length) return false;
  const newLine = INDENT.repeat(nw / INDENT.length) + lineText.slice(ind.length);
  const delta = newLine.length - lineText.length;
  ta.value = v.slice(0, ls) + newLine + v.slice(le);
  const np = Math.max(ls, pos + delta);
  ta.setSelectionRange(np, np);
  return true;
}

/* ================= 编辑器右键菜单（选中文本 / 标识符） ================= */
/* 鼠标位置 → 编辑区内的绝对字符偏移（点在行尾空白处则取该行末尾） */
function editorOffsetAt(e) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || ta.disabled || !t || t.kind !== 'yy') return -1;
  const rect = ta.getBoundingClientRect();
  const lineNo = Math.floor((e.clientY - rect.top + ta.scrollTop) / LINE_H) + 1;
  const lines = t.content.split('\n');
  if (lineNo < 1 || lineNo > lines.length) return -1;
  const lineText = lines[lineNo - 1];
  const x = e.clientX - rect.left + ta.scrollLeft - 4;
  const idx = Math.max(0, Math.min(charIndexAtX(lineText, x), lineText.length));
  return offsetOfLine(t.content, lineNo) + idx;
}

/* 用 text 替换 [s,e) 区间（并标脏、记入撤销历史、刷新界面、触发自动保存） */
function editorReplaceRange(s, e, text, caretStart, caretEnd, opts) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || !t || t.readonly || t.gen) return;
  // 调用前谁持有焦点？设计器自动同步（加/删控件）时焦点在画布上 —— 编辑器只是被
  // 「顺手改掉」，不能把焦点抢过来：否则在画布上点一下，光标就跳进代码框，
  // 接下来敲的方向键/删除全作用在代码上。setSelectionRange 同样会聚焦，也要跳过。
  const prevFocus = document.activeElement;
  const keepFocus = !!(prevFocus && prevFocus !== ta
                       && prevFocus !== document.body
                       && document.body.contains(prevFocus));
  const out = ta.value.slice(0, s) + text + ta.value.slice(e);
  const c0 = caretStart === undefined ? s + text.length : caretStart;
  const c1 = caretEnd === undefined ? c0 : caretEnd;
  ta.value = out;
  if (!keepFocus) ta.setSelectionRange(c0, c1);
  t.content = out;
  t.dirty = true;
  // opts.coalesce：把这次改动并进上一步撤销（设计器自动同步用，免得一次拖动刷出几十步）
  histPush(t, !(opts && opts.coalesce));
  renderTabs();
  drawOverlay(t);
  updateStatusBar();
  updateCaret();
  hideAutoComplete();
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => saveFile(t), 900);
  clearTimeout(S.subTimer);
  S.subTimer = setTimeout(() => { renderSubs(); renderClasses(); }, 400);
  // 焦点归还：原先编辑器有焦点就继续留在编辑器；否则把焦点还给调用前的元素
  // （设计器场景 = 画布），绝不主动把光标搬进代码框。
  if (keepFocus) { if (prevFocus.focus) prevFocus.focus(); }
  else ta.focus();
}

/* 对选区覆盖的整行做统一变换（注释 / 取消注释 / 缩进 …） */
function editorTransformLines(fn) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || !t || t.readonly || t.gen) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  if (e <= s) return;
  const v = ta.value;
  const ls = v.lastIndexOf('\n', s - 1) + 1;
  let le = v.indexOf('\n', e);
  if (le < 0) le = v.length;
  const seg = v.slice(ls, le);
  const out = fn(seg.split('\n')).join('\n');
  if (out === seg) { ta.focus(); return; }
  editorReplaceRange(ls, le, out, s, e + (out.length - seg.length));
}

const COMMENT_PREFIX = "' ";                                        // 云易行注释
const editorCommentLine = (ln) => (ln.trim() ? COMMENT_PREFIX + ln : ln);
const editorUncommentLine = (ln) => ln.replace(/^([ \t]*)('\s?|\/\/\s?)/, '$1');
const editorIndentLine = (ln) => (ln.trim() ? INDENT + ln : ln);
const editorUnindentLine = (ln) => {
  const m = new RegExp('^ {1,' + INDENT.length + '}').exec(ln) || /^\t/.exec(ln);
  return m ? ln.slice(m[0].length) : ln;
};

function editorCopy() {
  const ta = $('codeInput');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  if (e > s) copyText(ta.value.slice(s, e));
}

function editorCut() {
  const ta = $('codeInput');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  if (e <= s) return;
  copyText(ta.value.slice(s, e));
  editorReplaceRange(s, e, '');
}

function editorDelete() {
  const ta = $('codeInput');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  if (e <= s) return;
  editorReplaceRange(s, e, '');
}

async function editorPaste() {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || !t || t.readonly || t.gen) return;
  let text = '';
  try {
    text = await navigator.clipboard.readText();
  } catch (err) {
    toast('浏览器未授权读取剪贴板，请改用 Ctrl+V 粘贴');
    ta.focus();
    return;
  }
  if (!text) { ta.focus(); return; }
  editorReplaceRange(ta.selectionStart, ta.selectionEnd, text);
}

/* 选中文本时的右键菜单项 */
function editorSelectionItems() {
  const ta = $('codeInput');
  const sel = ta ? ta.value.slice(ta.selectionStart, ta.selectionEnd) : '';
  const word = sel.trim();
  const items = [
    { label: '复制', act: editorCopy },
    { label: '剪切', act: editorCut },
    { label: '粘贴', act: editorPaste },
    { label: '删除', act: editorDelete },
    { sep: true },
    { label: '注释选中行', act: () => editorTransformLines((ls) => ls.map(editorCommentLine)) },
    { label: '取消注释', act: () => editorTransformLines((ls) => ls.map(editorUncommentLine)) },
    { sep: true },
    { label: '增加缩进', act: () => editorTransformLines((ls) => ls.map(editorIndentLine)) },
    { label: '减少缩进', act: () => editorTransformLines((ls) => ls.map(editorUnindentLine)) },
    { sep: true },
    { label: '格式化选中代码', act: () => formatEditorCode('selection') },
    { label: '折叠选中代码', act: () => foldFromSelection() },
  ];
  // 选中的正好是一个完整标识符、且它是「变量 / 常量 / 自定义数据类型 / 子程序」的
  // 定义时，才额外提供重命名（类函数 / API / 核心库命令 / 关键字等不给）
  const cur = activeTab();
  const rk = (word && /^[A-Za-z0-9_\u4e00-\u9fff]+$/.test(word))
    ? renamableKind(word, '', cur) : '';
  if (rk) {
    items.push({ label: '重命名「' + word + '」…', act: () => promptRename(word, '', rk) });
  }
  if (foldCount(cur)) {
    items.push({ label: '展开全部折叠（' + foldCount(cur) + ' 处）', act: () => foldUnfoldAll(cur) });
  }
  return items;
}

/* 判断从 startIdx 行开始的块，后面是否已经存在配对的结束关键字。
   按「同类块」嵌套计数：只有与 closer 配对的开始关键字参与计数
   （如 结束子程序 对应 子程序 / 测试函数；结束循环 对应 计次循环 / 当循环 / 判断循环首） */
function blockAlreadyClosed(lines, startIdx, opener, closer) {
  const family = Object.keys(GUIDE_OPEN).filter((k) => GUIDE_OPEN[k][0] === closer);
  let depth = 0;
  for (let i = startIdx + 1; i < lines.length; i++) {
    const tk = ((lines[i] || '').trim().split(/[\s(（]/)[0]) || '';
    if (!tk) continue;
    if (family.indexOf(tk) >= 0) { depth++; continue; }    // 嵌套的同类块
    if (tk === closer) {
      if (depth === 0) return true;                        // 找到本块的结束关键字
      depth--;
    }
  }
  return false;
}

function bindEditor() {
  const ta = $('codeInput');
  ta.addEventListener('input', () => {
    const t = activeTab();
    if (!t || t.readonly || t.gen) return;
    t.content = ta.value;
    t.dirty = true;
    renderTabs();
    clearTimeout(S.saveTimer);
    S.saveTimer = setTimeout(() => saveFile(t), 900);
    drawOverlay(t);
    clearTimeout(S.subTimer);
    S.subTimer = setTimeout(() => {
      renderSubs();
      renderClasses();
      updateProjDefsForTab(t);    // 工程级快照：本文件改用编辑器里的实时内容
      recomputeUndefHits();
      refreshUndefCalls(t);
      checkDeletedDefs(t);        // 类函数定义被删掉而本文件还有调用 → 标为未定义并提示
    }, 400);
    // 输入「结束如果 / 结束循环 / 否则」等收尾关键字时，自动反缩进一级
    const pos = ta.selectionStart;
    const v = ta.value;
    const ls = v.lastIndexOf('\n', pos - 1) + 1;
    let le = v.indexOf('\n', pos);
    if (le < 0) le = v.length;
    const lineText = v.slice(ls, le);
    const kwM = /^[ \t]*(\S+)/.exec(lineText);
    if (kwM && DEDENT_KW[kwM[1]]) {
      const ind = /^[ \t]*/.exec(lineText)[0];
      const dedentKey = ls + ':' + kwM[1];
      if (ind.length >= INDENT.length && S.lastDedent !== dedentKey) {
        S.lastDedent = dedentKey;
        const newLine = ind.slice(INDENT.length) + lineText.slice(ind.length);
        ta.value = v.slice(0, ls) + newLine + v.slice(le);
        const np = Math.max(ls, pos - INDENT.length);
        ta.setSelectionRange(np, np);
        t.content = ta.value;
        drawOverlay(t);
      }
    }
    // 「半级缩进」补正：行首缩进始终为 INDENT 的整数倍（删到只剩 1 个空格会被补回 2 个）
    if (ta.selectionStart === ta.selectionEnd && fixLineIndentAt(ta)) {
      t.content = ta.value;
      drawOverlay(t);
    }
    histPush(t);                 // 记录本次输入（连续输入自动合并为一步撤销）
    updateAutoComplete();
  });
  ta.addEventListener('scroll', () => {
    hideHoverTip();
    const t = activeTab();
    if (t) { t.top = ta.scrollTop; t.left = ta.scrollLeft; }
    syncScroll();
  });
  // 悬停提示：函数 / API / 核心库命令
  ta.addEventListener('mousemove', onEditorHover);
  ta.addEventListener('mouseleave', hideHoverTip);
  ta.addEventListener('mousedown', hideHoverTip);
  // 右键菜单：① 在选中的文本上右键 → 复制 / 剪切 / 粘贴 / 注释 / 缩进 …
  //           ② 否则命中标识符 → 转到定义 / 重命名（同步改调用处）
  //           都不匹配时保留浏览器默认菜单
  ta.addEventListener('contextmenu', (e) => {
    const t = activeTab();
    if (!t || t.readonly || t.gen) return;
    const s = ta.selectionStart, en = ta.selectionEnd;
    if (en > s) {
      const off = editorOffsetAt(e);
      if (off >= s && off <= en) {                 // 点在选中的文本上
        e.preventDefault();
        showContextMenu(e, editorSelectionItems());
        return;
      }
    }
    const hit = editorWordAt(e);
    e.preventDefault();
    const items = [];
    if (hit && hit.word) {
      // 命中类库类函数调用（类型.方法）→ 提供「复制定义到本文件 / 删除调用」
      // （不复制也能直接调用——编译时会自动引入类库定义；复制进来是想查看/修改源码）
      const lcalls = libCallsIn(t.content || '');
      const lu = lcalls.find((c) => c.owner === hit.owner && c.name === hit.word
        && c.line === hit.line);
      if (lu) {
        const cnt = lcalls.filter((c) => c.key === lu.key).length;
        items.push({ label: '复制类函数定义「' + lu.key + '」到本文件', act: () => insertDefForCall(lu) });
        items.push({ label: '删除「' + lu.key + '」的全部调用（' + cnt + ' 处）', danger: true,
          act: () => {
            const n = removeCallsOfKey(t, lu.key);
            toast(n ? ('已删除 ' + n + ' 处调用：' + lu.key) : ('未找到可删除的调用：' + lu.key));
          } });
        items.push({ sep: true });
      }
      // 命中「有定义」的标识符时提供「转到定义」：
      //   本文件的子程序/类函数 → 编辑器内跳转；类函数/核心库命令 → 侧栏选项卡定位高亮
      if (resolveDefinition(hit.word, hit.owner, t)) {
        items.push({ label: '转到定义', act: () => gotoDefinition(hit.word, hit.owner) });
      }
      // 「重命名」只给「变量 / 常量 / 自定义数据类型 / 子程序」这四类定义；
      // 类函数、类库类函数、成员、API、核心库命令、关键字等不出现该菜单项
      const rk = renamableKind(hit.word, hit.owner, t);
      if (rk) {
        items.push({ label: '重命名「' + hit.word + '」…',
                     act: () => promptRename(hit.word, '', rk) });
      }
      items.push({ sep: true });
    }
    // 光标所在行处于折叠状态 → 提供「展开此处」（多行连选后右键也能整段折叠）
    const lnHere = lineOfOffset(t.content || '', ta.selectionStart || 0);
    const fi = foldIndexAtLine(t, lnHere);
    if (fi >= 0) {
      const fn = String(t.folds[fi].text).split('\n').length;
      items.push({ label: '展开此处（' + fn + ' 行）', act: () => { foldUnfoldAt(t, fi); renderTabs(); } });
    } else if (en > s && ta.selectionEnd > ta.selectionStart) {
      items.push({ label: '折叠选中代码', act: () => foldFromSelection() });
    }
    if (foldCount(t)) {
      items.push({ label: '展开全部折叠（' + foldCount(t) + ' 处）', act: () => foldUnfoldAll(t) });
    }
    // 未选中文本时的通用项（也是没命中任何标识符时的兜底菜单，右键必有反应）
    items.push({ label: '全选', act: () => { ta.focus(); ta.select(); } });
    items.push({ label: '格式化全部代码', act: () => formatEditorCode('all') });
    showContextMenu(e, items);
  });
  // 光标位置 → 状态栏
  ['keyup', 'click', 'select', 'focus', 'input'].forEach((ev) => {
    ta.addEventListener(ev, updateCaret);
  });
  // 点击编辑区时刷新自动补全候选；滚动时关闭候选框
  ta.addEventListener('click', updateAutoComplete);
  ta.addEventListener('scroll', () => hideAutoComplete());
  ta.addEventListener('keydown', (e) => {
    const t = activeTab();
    if (!t) return;
    // 撤销 / 重做：Ctrl+Z 撤销，Ctrl+Y 或 Ctrl+Shift+Z 重做（Cmd 同效）
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      const k = (e.key || '').toLowerCase();
      if (k === 'z') { e.preventDefault(); if (e.shiftKey) redoEditor(); else undoEditor(); return; }
      if (k === 'y') { e.preventDefault(); redoEditor(); return; }
    }
    // 自动补全候选框打开时的键盘导航
    if (S.ac && S.ac.open) {
      if (e.key === 'ArrowDown') { e.preventDefault(); acMove(1); return; }
      if (e.key === 'ArrowUp') { e.preventDefault(); acMove(-1); return; }
      if ((e.key === 'Enter' || e.key === 'Tab') && !e.ctrlKey && !e.altKey) {
        e.preventDefault(); acApply(); return;
      }
      if (e.key === 'Escape') { e.preventDefault(); hideAutoComplete(); return; }
    }
    // 回车智能缩进：继承当前行缩进；块开始行（如果/循环/子程序/类函数/数据类型/否则）再多缩进一级
    // 块开始行还会自动补出对应的结束关键字（如 子程序→结束子程序），中间隔两行，
    // 结束关键字与块首同缩进（顶层即顶格、不缩进）
    if (e.key === 'Enter' && !e.ctrlKey && !e.shiftKey
        && t.kind === 'yy' && !t.readonly && !t.gen) {
      e.preventDefault();
      const pos = ta.selectionStart;
      const v = ta.value;
      const ls = v.lastIndexOf('\n', pos - 1) + 1;
      const line = v.slice(ls, pos);
      const base = (/^[ \t]*/.exec(line) || [''])[0];   // 当前行缩进
      const first = line.trim().split(/[\s(（]/)[0] || '';
      const closer = (GUIDE_OPEN[first] || [])[0] || ''; // 对应的结束关键字
      let indent = base;
      if (GUIDE_OPEN[first] || first === '否则' || first === '否则如果') {
        indent += INDENT;
      }
      // 该块若已存在配对的结束关键字（如「子程序」下面已有「结束子程序」），则不再补出
      const 已有结束 = closer
        && blockAlreadyClosed(v.split('\n'), lineOfOffset(v, ls) - 1, first, closer);
      const insert = (closer && !已有结束)
        ? '\n' + indent + '\n' + '\n' + base + closer
        : '\n' + indent;
      ta.value = v.slice(0, pos) + insert + v.slice(pos);
      const caret = pos + 1 + indent.length;            // 光标落在第一条块内空行（已缩进）
      ta.setSelectionRange(caret, caret);
      t.content = ta.value;
      t.dirty = true;
      histPush(t, true);           // 回车自动缩进：独立一步
      renderTabs();
      drawOverlay(t);
      updateStatusBar();
      updateCaret();
      hideAutoComplete();
      clearTimeout(S.saveTimer);
      S.saveTimer = setTimeout(() => saveFile(t), 900);
      clearTimeout(S.subTimer);
      S.subTimer = setTimeout(() => { renderSubs(); renderClasses(); }, 400);
      return;
    }
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = ta.selectionStart, en = ta.selectionEnd;
      const v = ta.value;
      const multi = v.slice(s, en).indexOf('\n') >= 0;
      if (multi) {
        // 多行选区：整块缩进 / 反缩进
        const ls = v.lastIndexOf('\n', s - 1) + 1;
        const seg = v.slice(ls, en);
        const out = seg.split('\n').map((ln) => {
          if (!e.shiftKey) return INDENT + ln;
          const m3 = new RegExp('^ {1,' + INDENT.length + '}').exec(ln) || /^\t/.exec(ln);
          return m3 ? ln.slice(m3[0].length) : ln;
        }).join('\n');
        ta.value = v.slice(0, ls) + out + v.slice(en);
        ta.setSelectionRange(ls, ls + out.length);
      } else if (e.shiftKey) {
        // 当前行反缩进一级
        const ls = v.lastIndexOf('\n', s - 1) + 1;
        let le = v.indexOf('\n', ls);
        if (le < 0) le = v.length;
        const lineText = v.slice(ls, le);
        const m3 = new RegExp('^ {1,' + INDENT.length + '}').exec(lineText) || /^\t/.exec(lineText);
        if (m3) {
          ta.value = v.slice(0, ls) + lineText.slice(m3[0].length) + v.slice(le);
          const d = -m3[0].length;
          ta.setSelectionRange(Math.max(ls, s + d), Math.max(ls, en + d));
        }
      } else {
        ta.value = v.slice(0, s) + INDENT + v.slice(en);
        ta.selectionStart = ta.selectionEnd = s + INDENT.length;
      }
      t.content = ta.value;
      t.dirty = true;
      histPush(t, true);           // Tab 缩进：独立一步
      renderTabs();
      drawOverlay(t);
      updateStatusBar();
      updateCaret();
      return;
    }
    if (e.ctrlKey && e.key === 's') {
      e.preventDefault();
      saveFile(t);
    }
  });
}

async function saveFile(t) {
  if (!t || t.readonly || t.gen) return true;
  applyNormalizedContent(t);            // 保存前统一重排行首缩进（2 空格的整数倍）
  const full = foldFullText(t);         // 写盘用完整源码：折叠起来的原文也一并存回去
  try {
    await api('POST', '/api/file', { project: t.project || S.project, path: t.path, content: full });
    t.savedContent = full;
    t.dirty = false;
    renderTabs();
    updateStatusBar();
    return true;
  } catch (e) {
    reportError('保存失败：' + e.message);
    return false;
  }
}

async function saveAll() {
  for (const t of S.tabs) {
    if (t.dirty && !t.readonly && !t.gen) {
      const ok = await saveFile(t);
      if (!ok) return false;
    }
  }
  return true;
}

/* ================= 工程 / 文件树 ================= */
/* 用 S.projects 重建下拉框选项（首项固定为「（选择工程…）」），keep 选中项 */
function fillProjectOptions(keep) {
  const sel = $('projectSelect');
  sel.innerHTML = '';
  const opt = document.createElement('option');
  opt.value = '';
  opt.textContent = '（选择工程…）';
  sel.appendChild(opt);
  S.projects.forEach((p) => {
    const o = document.createElement('option');
    o.value = p.name;
    // 工程标记（已标记或自动识别）：程序类型 · 架构 · 模式 直接显示在工程名后
    const marks = [p.subsystemLabel, p.arch, p.modeLabel].filter(Boolean);
    o.textContent = p.name + (marks.length ? '（' + marks.join(' · ') + '）' : '');
    o.title = '程序类型：' + (p.subsystemLabel || '控制台程序')
      + '　架构：' + (p.arch || 'x64')
      + '　模式：' + (p.modeLabel || '调试版');
    sel.appendChild(o);
  });
  if (keep && S.projects.find((p) => p.name === keep)) sel.value = keep;
  else sel.value = '';
}

async function loadProjects() {
  const d = await api('GET', '/api/projects');
  S.workspace = d.workspace;
  S.projects = d.projects || [];
  fillProjectOptions(S.project);
  if (S.project && !S.projects.find((p) => p.name === S.project)) S.project = '';
  updateStatusBar();
  if (!S.project) {
    $('tree').innerHTML = '<div class="treeEmpty">当前没有工程<br>点右上角「新建工程」开始</div>';
    renderTabs();
    renderEditor();
    $('stProject').textContent = '未打开工程';
    setBusy(false);
  } else {
    await selectProject(S.project, true);
  }
}

/* 点开「选择工程」下拉时刷新列表：重新拉一遍 /api/projects 并重建选项。
   工作区里手工新建 / 删除 / 改名的工程文件夹，点一下下拉立刻反映出来。
   只更新下拉选项、保持当前选中项，不走 loadProjects（那会把工程整个重载一遍）；
   mousedown 在下拉弹出前触发，Chrome/Edge 会用重建后的选项渲染弹层。
   projListRefreshing 防抖：上一次刷新还没回来时不重复请求。 */
let projListRefreshing = false;
async function refreshProjectList() {
  if (projListRefreshing) return;
  projListRefreshing = true;
  try {
    const d = await api('GET', '/api/projects');
    S.workspace = d.workspace;
    S.projects = d.projects || [];
    fillProjectOptions(S.project);
  } catch (e) { /* 刷新失败静默：下拉里还是旧列表，选回空项时有 clearProject 兜底 */ }
  projListRefreshing = false;
}

function fmtSize(n) {
  let v = Number(n) || 0;
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
  return (i === 0 ? Math.round(v) + ' B' : v.toFixed(1) + ' ' + units[i]);
}

function setBusy(b) {
  ['btnRun', 'btnBuild', 'btnTest', 'btnRelease', 'btnExport', 'btnCleanBuild'].forEach((id) => {
    $(id).disabled = b;
  });
}

async function selectProject(name, force) {
  if (!force && S.project === name) return;
  if (S.project && S.project !== name && !(await saveAll())) return;
  // 切换工程时清空已有标签页，避免旧文件写进新工程
  if (S.project !== name) {
    S.tabs = [];
    S.active = -1;
    S.problems = [];
  }
  S.project = name;
  $('projectSelect').value = name;
  try {
    const d = await api('GET', '/api/project/load?project=' + encodeURIComponent(name));
    S.cfg = d.project;
    // 程序类型（工程级）：工具栏「程序类型」列表框自动选中本工程的类型
    if ($('subsysSelect') && S.cfg.subsystem) $('subsysSelect').value = S.cfg.subsystem;
    // 目标架构（工程级）：工具栏自动选中本工程的架构，并同步前端缓存的 env
    const archBefore = (S.libClass && S.libClass.arch) || '';
    if ($('archSelect') && S.cfg.arch) {
      $('archSelect').value = S.cfg.arch;
      if (S.env && S.env.env) S.env.env.arch = S.cfg.arch;
    }
    // 编译模式（工程级）：工具栏自动选中本工程的模式
    if ($('modeSelect') && S.cfg.mode) $('modeSelect').value = S.cfg.mode;
    // 架构与本工程不一致 → 整批重读类库：「类」/「API」/「Qt」三栏是
    // 「按架构载入不同文件」的（x64 → qt.class/qt.api，x86 → qt_x86.*），
    // 不重读就会把上一个架构（或启动时的全局架构）的条目留在栏里。
    // 放在 acRebuild 之前：类库符号要先就位，符号表才建得对。
    if (currentArch() !== archBefore) {
      await reloadLibClasses();
      // 三栏内容跟着架构整套换了：明说一句，免得以为是载入出了错
      toast('本工程目标架构为 ' + (currentArch() === 'x86' ? 'x86（32 位）' : 'x64（64 位）')
        + '，已按此载入「类 / API / Qt」三栏', 4200);
    }
    updateStatusBar();                       // 状态栏同步显示 模式 · 架构 · 程序类型
    refreshGitBranch();
    $('stProject').textContent = name + '（' + (S.cfg.target || name) + '）'
      + (S.cfg.subsystemLabel ? ' · ' + S.cfg.subsystemLabel : '');
    if (S.cfg.subsystemAuto) {
      toast('已自动识别程序类型：' + (S.cfg.subsystemLabel || '') + '（已写入工程配置）');
    }
    if (S.cfg.archAuto) {
      toast('已自动识别目标架构：' + (S.cfg.archLabel || '') + '（已写入工程配置）');
    }
    if (S.cfg.modeAuto) {
      toast('已自动识别编译模式：' + (S.cfg.modeLabel || '') + '（已写入工程配置）');
    }
    const tr = await api('GET', '/api/tree?project=' + encodeURIComponent(name));
    S.tree = tr.tree;
    renderTree();
    acRebuild();                                          // 重建符号表（核心库 + 类库 + 已缓存工程符号）
    acRegisterProjectSources().catch(() => { });          // 载入工程文件符号 → 自动完成符号表
    checkProjectClassDefs().catch(() => { });             // 载入工程：检查类函数是否都已定义
    if (S.tabs.length === 0) {
      // 刷新恢复：有快照就按快照重开标签页（含未保存内容），否则默认打开 main.yy
      const snap = (ideRestore && ideRestore.project === name) ? ideRestore : null;
      if (!(snap && await restoreTabsFromSnapshot(snap))) {
        const first = (S.cfg.sources || []).find((s) => /^main\.yy$/i.test(s)) || (S.cfg.sources || [])[0];
        if (first) openFile(first).catch(() => {});
        else renderEditor();
      }
    } else {
      renderTabs();
      renderEditor();
    }
    scheduleIdeSave();                                // 工程/标签页有变：排一次快照保存
    setBusy(false);
  } catch (e) {
    toast('打开工程失败：' + e.message);
  }
}

/* 下拉框选回「（选择工程…）」= **取消选择工程并重新载入**：
   · 重新拉一遍工程列表 —— 在 工作区 里手工新建 / 删除 / 改名的工程文件夹，点一下这里立刻反映出来；
   · 同时把当前工程卸掉：关掉已打开的标签页、清空文件树与「函数」栏、状态栏回到「未打开工程」。
   以前这里点了什么都不做，会出现「下拉框显示没选工程、右边树里却还留着上一个工程的文件」
   这种半截状态 —— 现在统一回到刚打开 IDE 的样子。 */
async function clearProject() {
  if (S.project && !(await saveAll())) return;   // 未保存的改动先落盘（与切换工程同一规则）
  S.project = '';
  S.cfg = null;
  S.tabs = [];
  S.active = -1;
  S.problems = [];
  S.tree = [];
  S.subsTab = null;
  $('projectSelect').value = '';
  try {
    await loadProjects();        // 重载工程列表；「无工程」的界面（空树提示 / 状态栏）由它铺好
  } catch (e) { reportError('重载工程列表失败：' + e.message); }
  renderSubs();                  // 「函数」栏 → 未打开文件
  acRebuild();                   // 符号表里去掉上一个工程登记的符号
  scheduleIdeSave();             // 快照里也清掉工程与标签页
  toast('已取消选择工程，工程列表已重新载入');
}

/* 文件树：正确按目录层级渲染 */
function renderTree() {
  const box = $('tree');
  box.innerHTML = '';

  function addNode(it, depth, parent) {
    const row = document.createElement('div');
    row.className = 'treeItem' + (it.dir ? ' dir' : ' file');
    row.style.paddingLeft = (6 + depth * 14) + 'px';
    if (it.dir) {
      const tw = document.createElement('span');
      tw.className = 'tw';
      tw.textContent = '▾';
      row.appendChild(tw);
      const ico = document.createElement('span');
      ico.className = 'ico';
      ico.textContent = '📁';
      row.appendChild(ico);
      const nm = document.createElement('span');
      nm.className = 'nm';
      nm.textContent = it.name;
      row.appendChild(nm);
      parent.appendChild(row);
      const kids = document.createElement('div');
      kids.className = 'treeChildren';
      kids.style.display = '';
      (it.children || []).forEach((c) => addNode(c, depth + 1, kids));
      parent.appendChild(kids);
      row.onclick = () => {
        const show = kids.style.display !== 'none';
        kids.style.display = show ? 'none' : '';
        tw.textContent = show ? '▸' : '▾';
      };
      row.oncontextmenu = (e) => {
        e.preventDefault();
        showContextMenu(e, [
          { label: '在此新建 .yy 文件', act: () => newFileIn(it) },
          { label: '删除文件夹（递归）', danger: true, act: () => deleteTreeNode(it, true) },
        ]);
      };
    } else {
      const ico = document.createElement('span');
      ico.className = 'ico';
      ico.textContent = it.path.toLowerCase().endsWith('.yy') ? '📄' : '🗎';
      row.appendChild(ico);
      const nm = document.createElement('span');
      nm.className = 'nm';
      nm.textContent = it.name;
      row.appendChild(nm);
      parent.appendChild(row);
      row.onclick = () => { openFile(it.path); markActiveTree(row); };
      row.oncontextmenu = (e) => {
        e.preventDefault();
        markActiveTree(row);
        showContextMenu(e, [
          { label: '打开', act: () => openFile(it.path) },
          { label: '重命名', act: () => renameTreeNode(it) },
          { label: '删除', danger: true, act: () => deleteTreeNode(it, false) },
        ]);
      };
    }
    return row;
  }
  S.tree.forEach((it) => addNode(it, 0, box));
}

function markActiveTree(row) {
  document.querySelectorAll('#tree .treeItem').forEach((r) => r.classList.remove('active'));
  if (row) row.classList.add('active');
}

function currentNodeFullPath(node) {
  return node.path;
}

async function newFileIn(dirNode) {
  const base = dirNode && dirNode.path ? dirNode.path + '/' : '';
  const f = await modalForm('新建源码文件', [
    { key: 'name', label: '文件名', value: '新模块.yy', help: '将以 .yy 结尾创建于目录：' + (base || '工程根目录') },
  ], '创建');
  if (!f || !f.name.trim()) return;
  const name = f.name.trim();
  if (!/\.yy$/i.test(name)) { toast('源码文件必须以 .yy 结尾'); return; }
  const path = base + name;
  try {
    await api('POST', '/api/file/new', { project: S.project, path, content: "'\n'\n" });
    await refreshTree();
    await openFile(path);
  } catch (e) { reportError('创建失败：' + e.message); }
}

async function renameTreeNode(node) {
  const oldBase = node.path.split('/').slice(0, -1).join('/');
  const oldName = node.path.split('/').pop();
  const f = await modalForm('重命名文件', [
    { key: 'name', label: '新文件名', value: oldName },
  ], '重命名');
  if (!f || !f.name.trim() || f.name.trim() === oldName) return;
  const newName = f.name.trim();
  const newPath = (oldBase ? oldBase + '/' : '') + newName;
  try {
    await api('POST', '/api/file/rename', { project: S.project, old: node.path, new: newPath });
    // 更新已打开的标签
    for (const t of S.tabs) {
      if (t.path === node.path) { t.path = newPath; t.dirty = false; }
    }
    renderTabs();
    await refreshTree();
    toast('已重命名');
  } catch (e) { reportError('重命名失败：' + e.message); }
}

async function deleteTreeNode(node, isDir) {
  const tip = isDir ? '将递归删除文件夹「' + node.path + '」及其全部内容，且不可恢复。' : '将删除文件「' + node.path + '」。';
  if (!confirm('确定要删除吗？\n' + tip)) return;
  try {
    await api('POST', '/api/file/delete', { project: S.project, path: node.path });
    // 关闭打开的标签
    S.tabs = S.tabs.filter((t) => t.path !== node.path);
    if (S.active >= S.tabs.length) S.active = S.tabs.length - 1;
    renderTabs();
    renderEditor();
    await refreshTree();
    toast('已删除');
  } catch (e) { reportError('删除失败：' + e.message); }
}

async function refreshTree() {
  const tr = await api('GET', '/api/tree?project=' + encodeURIComponent(S.project));
  S.tree = tr.tree;
  renderTree();
}

/* 右键菜单 */
function showContextMenu(e, items) {
  hideContextMenu();
  const m = document.createElement('div');
  m.className = 'cmenu';
  items.forEach((it) => {
    if (it.sep) {                                  // 分隔线
      const d = document.createElement('div');
      d.className = 'csep';
      m.appendChild(d);
      return;
    }
    const b = document.createElement('button');
    b.className = it.danger ? 'danger' : '';
    b.textContent = it.label;
    b.onclick = () => { hideContextMenu(); it.act(); };
    m.appendChild(b);
  });
  document.body.appendChild(m);
  m.style.left = Math.min(e.clientX, window.innerWidth - m.offsetWidth - 8) + 'px';
  m.style.top = Math.min(e.clientY, window.innerHeight - m.offsetHeight - 8) + 'px';
  S.contextMenu = m;
  setTimeout(() => {
    document.addEventListener('mousedown', onDocMouseDown, true);
    document.addEventListener('keydown', onDocEsc, true);
  }, 0);
}

function onDocMouseDown(e) {
  if (S.contextMenu && !S.contextMenu.contains(e.target)) hideContextMenu();
}
function onDocEsc(e) {
  if (e.key === 'Escape') hideContextMenu();
}
function hideContextMenu() {
  if (S.contextMenu) { S.contextMenu.remove(); S.contextMenu = null; }
  document.removeEventListener('mousedown', onDocMouseDown, true);
  document.removeEventListener('keydown', onDocEsc, true);
}

/* ================= 构建 / 运行 ================= */
function startSessionBtn(text) {
  $('btnStop').disabled = false;
  $('stState').textContent = text;
}
function stopSessionBtn() {
  $('btnStop').disabled = true;
  if (!S.sess || S.sess.done) $('stState').textContent = '就绪';
}

async function doRun(target, mode) {
  if (!S.project) { toast('请先选择工程'); return; }
  // DLL 程序：不能直接「运行」；但「测试」可用（会编译成 exe 运行测试函数，便于自测导出函数）
  if (target !== 'test' && $('subsysSelect') && $('subsysSelect').value === 'dll') {
    toast('当前是「DLL程序」，不能直接运行；请用「编译」生成 .dll，或点「测试」自测导出函数');
    return;
  }
  // 先禁用按钮再保存：saveAll 是异步的（逐文件写回），期间不锁住会因快速
  // 双击「运行」触发两次 /api/run，导致编译的程序被执行两次。
  setBusy(true);
  if (!(await saveAll())) { setBusy(false); return; }
  ensureConsoleTab('console', '控制台');
  switchConsoleTab('console', true);
  clearConsole('console');
  con('console', '── 编译中（' + (mode === 'debug' ? '调试版' : '发布版') + ' / ' + (target === 'test' ? '测试' : '运行') + '）──', 'cl-sys');
  try {
    const d = await api('POST', '/api/run', { project: S.project, mode, target });
    showProblems(d.result.messages);
    if (!d.ok) { setBusy(false); con('console', '编译未通过，详见「问题」。', 'cl-err'); return; }
    const exeName = (d.result.artifacts && d.result.artifacts.exe || '程序').replace(/\\/g, '/').split('/').pop();
    con('console', '已启动：' + exeName, 'cl-sys');
    S.sess = { sid: d.sid, kind: target === 'test' ? 'test' : 'run', next: 0, done: false };
    if (target === 'test') {
      ensureConsoleTab('test', '测试结果');
      switchConsoleTab('test', true);
    }
    startSessionBtn(target === 'test' ? '正在测试…' : '正在运行…');
    scheduleIdeSave();                                // 快照记下运行会话，刷新后可重连
    pollSession();
  } catch (e) {
    setBusy(false);
    reportError('运行失败：' + e.message);
  }
}

function sessionLineClass(kind, ln) {
  let cls = 'cl-run';
  if (kind === 'test') {
    if (ln.indexOf('[断言失败]') >= 0) cls = 'cl-fail';
    else if (ln.indexOf('[测试]') >= 0) {
      cls = ln.indexOf('失败 0 项') >= 0 || ln.indexOf('失败=0') >= 0 ? 'cl-pass'
        : (ln.indexOf('失败') >= 0 ? 'cl-fail' : 'cl-run');
    }
  } else if (kind === 'console') {
    if (/错误|失败|Exception|异常/.test(ln)) cls = 'cl-err';
    else if (/警告|warning/i.test(ln)) cls = 'cl-warn';
    else if (/^请输入|^读入|error/i.test(ln.trim())) cls = 'cl-cmd';
  }
  return cls;
}

/* 运行库在「输入文本」读标准输入前会输出一个隐藏标记（ESC[?yy-in]，见 yunyi_rt.hpp）：
   收到后弹出「请输入内容」对话框（标记本身不显示在控制台里）。 */
const YY_INPUT_MARK = '\u001b[?yy-in]';
function yyStripInputHint(line) {
  if (typeof line !== 'string' || line.indexOf(YY_INPUT_MARK) < 0) return line;
  promptStdInput(true);                   // 程序在等输入 → 弹对话框
  return line.split(YY_INPUT_MARK).join('');
}

/* ---------- 控制台程序的「输入文本」：改用弹出的「请输入内容」对话框 ----------
   与「重命名」对话框同一套外壳（标题 / 左下角关闭 / 右下角确定），输入区是多行文本框，
   左右不写文字、占满这一行的可用宽度（.rowFull / .mfFull，见 style.css）。
   · 确定 → 把文本框内容作为标准输入发给程序（多行会按行依次喂给后续的「输入文本」）；
   · 关闭 → 不发送，程序仍在等待输入（可再按 Ctrl+Enter 打开）。
   原来底部面板下那一行「输入框」已删除。 */
let stdInputBusy = false;                 // 对话框正开着：程序连续读输入时不重复弹
function stdInputSession() { return (S.sess && !S.sess.done) ? S.sess : null; }

/* 会话结束时调用：还开着的「请输入内容」对话框自动收起
   （程序都没了，输入也没用；点它的「关闭」正好走收尾逻辑） */
function closeStdInputDlg() {
  if (!stdInputBusy) return;
  const mask = $('modalMask');
  if (!mask || mask.classList.contains('hidden')) return;
  if ($('modalHead').textContent !== '请输入内容') return;   // 别的对话框（用户自己开的）不动
  const close = $('modalFoot').querySelector('button.btnClose');
  if (close) close.click();
}

async function promptStdInput(auto) {
  if (stdInputBusy) return;
  const sess = stdInputSession();
  if (!sess) {
    if (!auto) toast('现在没有正在运行的程序：先点「运行」，程序执行到「输入文本」时会自动弹出输入对话框');
    return;
  }
  // 弹窗同时只能有一个：环境设置 / 工具链等对话框正开着时不抢（关掉后按 Ctrl+Enter 再输入）
  const mask = $('modalMask');
  if (mask && !mask.classList.contains('hidden')) {
    if (!auto) toast('请先关掉当前对话框，再按 Ctrl+Enter 输入内容');
    return;
  }
  const k = sess.kind === 'test' ? 'test' : 'console';
  if (S.consoleTab === 'problems') switchConsoleTab('console', true);
  setBottomFolded(false);
  con(k, '（程序正在等待输入 —— 在弹出的「请输入内容」对话框中输入，点「确定」发送给程序）', 'cl-sys');
  stdInputBusy = true;
  let f = null;
  try {
    f = await modalForm('请输入内容', [{ key: 'data', type: 'textarea', full: true }], '确定');
  } finally {
    stdInputBusy = false;
  }
  if (!f) {                               // 关闭：不发送
    con(k, stdInputSession()
      ? '（已关闭输入对话框：程序仍在等待输入，按 Ctrl+Enter 可重新打开）'
      : '（已关闭输入对话框：程序已结束）', 'cl-sys');
    return;
  }
  const cur = stdInputSession();
  if (!cur) { con(k, '（会话已结束）', 'cl-sys'); return; }
  const val = f.data == null ? '' : f.data;
  api('POST', '/api/session/' + cur.sid + '/input', { data: val })
    .then(() => con(k, '》' + val, 'cl-cmd'))
    .catch((er) => toast(er.message));
}

function pollSession() {
  if (!S.sess || S.sess.done) return;
  const k = S.sess.kind === 'test' ? 'test' : 'console';
  api('GET', '/api/session/' + S.sess.sid + '?since=' + S.sess.next)
    .then((d) => {
      (d.lines || []).forEach((raw) => {
        const ln = yyStripInputHint(raw);
        // 纯提示行（只有「等待输入」标记）不显示到控制台，只弹输入对话框
        if (ln === raw || ln.trim() !== '') con(k, ln, sessionLineClass(k, ln));
      });
      S.sess.next = d.since;
      if (!d.running) {
        S.sess.done = true;
        const code = d.exitCode === 0 ? '正常结束' : ('退出码 ' + d.exitCode);
        con(k, '── 进程结束（' + code + '）──', d.exitCode === 0 ? 'cl-pass' : 'cl-err');
        closeStdInputDlg();                // 还开着的输入对话框：程序都结束了，自动收起
        stopSessionBtn();
        setBusy(false);
        scheduleIdeSave();                 // 会话已结束：快照里清掉，下次刷新不再重连
        return;
      }
      setTimeout(pollSession, 300);
    })
    .catch((e) => {
      S.sess.done = true;
      con(k, '会话错误：' + e.message, 'cl-err');
      // 传输层中断（刷新页面/连接断开）不弹「问题」面板，避免打扰
      if (!/请求失败|响应异常|网络请求失败/.test(e.message)) {
        reportError('会话错误：' + e.message);
      }
      stopSessionBtn();
      setBusy(false);
    });
}

async function doStop() {
  if (!S.sess) return;
  try {
    await api('POST', '/api/session/' + S.sess.sid + '/kill', {});
  } catch (e) { /* 忽略 */ }
  S.sess.done = true;
  con('console', '── 已停止 ──', 'cl-sys');
  stopSessionBtn();
  setBusy(false);
  scheduleIdeSave();
}

async function doBuild() {
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  if (!(await saveAll())) { setBusy(false); return; }
  const mode = $('modeSelect').value;
  ensureConsoleTab('console', '控制台');
  switchConsoleTab('console', true);
  clearConsole('console');
  con('console', '── 编译（' + (mode === 'debug' ? '调试版' : '发布版') + '）──', 'cl-sys');
  try {
    const d = await api('POST', '/api/build', { project: S.project, mode, target: 'run' });
    showProblems(d.result.messages);
    // DLL 程序：把导出函数列到「输出」里（清单文件由服务端生成）
    const exps = (d.result && d.result.exports) || [];
    if (d.ok && exps.length) {
      con('console', '── DLL 导出函数（' + exps.length + ' 个）──', 'cl-pass');
      exps.forEach((e) => con('console', '  ' + e.name
        + (e.cn && e.cn !== e.name ? '  ← 云易子程序 ' + e.cn : '')
        + '    ' + e.signature, 'cl-run'));
      if (d.result.exportFile) con('console', '导出函数清单：' + d.result.exportFile, 'cl-sys');
    }
    if (d.result.log) con('console', d.result.log.trim(), 'cl-run');
    con('console', '── 构建结束 ──', d.ok ? 'cl-pass' : 'cl-err');
  } catch (e) { reportError(e.message); }
  setBusy(false);
}

function relOf(absPath) {
  if (!S.project) return null;
  const cfgDir = (S.cfg && S.cfg.dir || '').replace(/\\/g, '/');
  const ap = absPath.replace(/\\/g, '/');
  if (cfgDir && ap.indexOf(cfgDir) === 0) {
    const rel = ap.slice(cfgDir.length);
    return rel.replace(/^\//, '');
  }
  const nm = ap.split('/').pop();
  const src = (S.cfg && S.cfg.sources || []).find((s) => s === nm || s.split('/').pop() === nm);
  return src || null;
}

/* 「导出C++」/「导出Python」：弹出进度条窗口（后端分阶段执行导出），完成后点「确定」关闭 */
async function doExport(kind) {
  kind = kind || 'cpp';
  const isPy = kind === 'python';
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  if (!(await saveAll())) { setBusy(false); return; }
  setModalWide(false);
  $('modalHead').textContent = isPy ? '导出 Python' : '导出 C++（纯正模式）';
  $('modalBody').innerHTML =
      '<div id="expPhase" style="margin-bottom:8px">准备导出…</div>'
    + '<div style="background:rgba(128,128,128,.25);border-radius:6px;height:14px;overflow:hidden">'
    +   '<div id="expBar" style="height:100%;width:0%;background:var(--accent,#2563eb);transition:width .2s"></div>'
    + '</div>'
    + '<div id="expPct" style="margin-top:6px;font-size:12px;opacity:.7">0%</div>';
  const foot = $('modalFoot');
  foot.innerHTML = '';
  $('modalMask').classList.remove('hidden');
  try {
    const started = await api('POST', '/api/export', { project: S.project, kind });
    const res = await pollExport(started.tid);
    const bar = $('expBar'), pct = $('expPct'), phase = $('expPhase');
    if (res.ok) {
      if (bar) { bar.style.width = '100%'; bar.style.background = '#16a34a'; }
      if (pct) pct.textContent = '100%';
      const notes = (res.messages || []).map((m) => '\n⚠ ' + m.text).join('');
      if (phase) phase.innerHTML =
          '导出完成：<b>' + escHtml(res.dir) + '</b>'
        + '<div style="white-space:pre-wrap;margin-top:6px;opacity:.85">'
        + (isPy ? '已生成 Python 工程（main.py：自包含的标准 Python 3，双击 运行.bat 运行）'
                : res.native ? '已生成纯正 C++（main.cpp：标准类型 + Windows API 静态调用，不依赖中文运行库）'
                             : '已生成中文转译版 C++（main_gen.cpp + yunyi_rt.hpp）')
        + escHtml(notes) + '</div>';
    } else {
      if (bar) { bar.style.width = '100%'; bar.style.background = '#dc2626'; }
      if (pct) pct.textContent = '导出失败';
      const errs = (res.messages || []).map((m) => m.text).join('\n');
      if (phase) phase.innerHTML =
          '<span style="color:#dc2626">导出失败</span>'
        + '<div style="white-space:pre-wrap;margin-top:6px">' + escHtml(errs) + '</div>';
    }
    const b = document.createElement('button');
    b.className = 'accent';
    b.textContent = '确定';
    b.onclick = () => hideModal();
    foot.innerHTML = '';
    foot.appendChild(b);
  } catch (e) {
    hideModal();
    reportError('导出失败：' + e.message);
  }
  setBusy(false);
}

/* 轮询导出进度（每 200ms），任务结束（done）后返回最终状态 */
async function pollExport(tid) {
  for (;;) {
    const s = await api('GET', '/api/export/status?tid=' + tid);
    const bar = $('expBar'), pct = $('expPct'), phase = $('expPhase');
    if (bar) bar.style.width = Math.max(2, s.percent) + '%';
    if (pct) pct.textContent = s.percent + '%';
    if (phase && s.done !== true && s.phase) phase.textContent = s.phase + '…';
    if (s.done) return s;
    await new Promise((r) => setTimeout(r, 200));
  }
}

async function doRelease() {
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  if (!(await saveAll())) { setBusy(false); return; }
  ensureConsoleTab('console', '控制台');
  switchConsoleTab('console', true);
  clearConsole('console');
  con('console', '── 正在编译发布版 ──', 'cl-sys');
  toast('正在编译发布版…', 600);
  try {
    const d = await api('POST', '/api/release', { project: S.project });
    con('console', '✓ 发布成功', 'cl-pass');
    con('console', '程序：' + d.exe, 'cl-run');
    con('console', '压缩包：' + d.zip, 'cl-run');
    modalInfo('发布成功', '程序：' + d.exe + '\n压缩包：' + d.zip);
  } catch (e) {
    con('console', '✗ 发布失败：' + e.message, 'cl-err');
    reportError('发布失败：' + e.message);
    modalInfo('发布失败', e.message);
  }
  setBusy(false);
}

/* ================= 工程设置：库 / SDK ================= */
async function openProjectConfig() {
  if (!S.project) { toast('请先选择工程'); return; }
  const c = S.cfg || {};
  const name = S.project;                 // 点「删除工程」时用它：删完回写状态时 S.project 已被清空
  const f = await modalForm('工程设置（库 / SDK）— ' + S.project, [
    { key: 'version', label: '版本号', value: c.version || '1.0' },
    { key: 'target', label: '输出文件名', value: c.target || S.project, help: '不含 .exe 后缀' },
    { key: 'icon', label: '程序图标 (.ico)', value: c.icon || '', help: '留空 = 默认图标 config\\ico.ico；也可填相对工程目录的 .ico（如 icon.ico）' },
    { key: 'includeDirs', label: '头文件目录（SDK）', value: c.includeDirs || '', help: '多个用逗号或空格分隔；相对路径以工程目录为基准' },
    { key: 'libDirs', label: '库目录', value: c.libDirs || '', help: '放 .a / .lib 的目录，多个用逗号分隔' },
    { key: 'libs', label: '链接库名', value: c.libs || '', help: '只填名字即可，如 ssl crypto（自动加 -l）' },
    { key: 'defines', label: '宏定义', value: c.defines || '', help: '如 _DEBUG USE_SSL' },
    { key: 'extraArgs', label: '额外编译参数', value: c.extraArgs || '' },
    { key: 'linkArgs', label: '额外链接参数', value: c.linkArgs || '' },
    { key: 'asmSyntax', label: '汇编语法', type: 'select',
      options: ['AT&T', 'Intel'], value: c.asmSyntax || 'AT&T',
      help: 'AT&T = GCC 默认写法（movl $1, %eax）；Intel = mov eax, 1（块头写 asm Intel 可单独指定）' },
  ], '保存', [
    { text: '🗑 删除工程', danger: true,
      title: '删除「' + name + '」的整个工程目录（源码 / 配置 / 构建产物），不可恢复',
      onClick: (hide) => deleteProject(name, hide) },
  ]);
  if (!f) return;
  try {
    const d = await api('POST', '/api/project/save', {
      project: S.project,
      config: Object.assign({}, c, f),
    });
    S.cfg = d.project;
    toast('工程设置已保存');
  } catch (e) { reportError('保存失败：' + e.message); }
}

/* 删除工程：整个工程目录（源码 .yy / 工程配置 .yyproj / 构建脚本 / build 与发布产物）
   从磁盘上清掉，IDE 随后回到没有打开工程的样子 ——
   工具栏组合框躺回「（选择工程…）」、列表重新载入（与 clearProject 同一套收尾）。 */
async function deleteProject(name, hide) {
  if (!name) { toast('请先选择工程'); return; }
  const go = window.confirm(
    '确定删除工程「' + name + '」？\n\n'
    + '将删除它的整个目录：源码(.yy)、工程配置(.yyproj)、构建脚本\n'
    + '以及 build / 发布 / 导出C++ / 导出Python 产物。\n\n'
    + '删除后不可恢复（回收站里也找不回来）；编辑器里没保存的改动会一起丢失。');
  if (!go) return;
  // 有程序正在运行先停掉：Windows 上被占用的 .exe / .dll 删不掉（rmtree 会报「文件被占用」）
  if (S.sess && !S.sess.done) {
    try { await api('POST', '/api/session/' + S.sess.sid + '/kill', {}); } catch (e) { /* 忽略 */ }
    S.sess.done = true;
    stopSessionBtn();
    scheduleIdeSave();
  }
  setBusy(true);
  try {
    await api('POST', '/api/project/delete', { project: name });
  } catch (e) {
    setBusy(false);
    reportError('删除工程失败：' + e.message);
    return;
  }
  if (hide) hide();                    // 删成了才关掉「工程设置」对话框；失败时留在原地好看到报错
  S.project = '';
  S.cfg = null;
  S.tabs = [];                         // 属于该工程的标签页连同未保存改动一起没了
  S.active = -1;
  S.problems = [];
  S.tree = [];
  S.subsTab = null;
  showProblems([]);                    // 清掉上一个工程留在「问题」栏里的编译报错
  $('projectSelect').value = '';
  try {
    await loadProjects();              // 刷新工程列表；删完了自然停在「（选择工程…）」
  } catch (e) { reportError('重载工程列表失败：' + e.message); }
  renderSubs();                        // 「函数」栏 → 未打开文件
  acRebuild();                         // 符号表里去掉上一个工程登记的符号
  updateStatusBar();
  setBusy(false);
  toast('已删除工程「' + name + '」');
}

/* ================= 构建系统（Makefile / CMake） ================= */
async function doMakeBuild() {
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  ensureConsoleTab('console', '控制台');
  switchConsoleTab('console');
  clearConsole('console');
  con('console', '── make 构建（' + ($('modeSelect').value === 'debug' ? '调试版' : '发布版') + '）──', 'cl-sys');
  try {
    const d = await api('POST', '/api/build/make', {
      project: S.project, mode: $('modeSelect').value, makeTarget: 'all',
    });
    const r = d.result || {};
    if (r.log) con('console', r.log.trim(), 'cl-run');
    if (r.messages) showProblems(r.messages);
    con('console', r.ok ? '── make 构建成功 ──' : '── make 构建失败 ──', r.ok ? 'cl-pass' : 'cl-err');
  } catch (e) { reportError(e.message); }
  setBusy(false);
}

/* 清理构建：删除可重新生成的产物（build / 发布 / 导出C++），源码与工程配置不动 */
async function doCleanBuild() {
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  try {
    const pre = await api('POST', '/api/build/clean', { project: S.project, dryRun: 1 });
    const c = pre.clean || {};
    if (!c.files) {
      toast('「' + S.project + '」没有可清理的构建产物');
      setBusy(false);
      return;
    }
    const lines = (c.items || []).map((it) => '· ' + it.name + '：' + it.files + ' 个文件（' + fmtSize(it.bytes) + '）');
    const go = window.confirm('清理「' + S.project + '」的构建产物？\n\n' + lines.join('\n')
      + '\n\n共 ' + c.files + ' 个文件（' + fmtSize(c.bytes) + '）。\n'
      + '这些都是「编译 / 运行 / 测试 / 发布 / 导出」可重新生成的文件；\n'
      + '源码(.yy)、工程配置(.yyproj)、构建脚本(Makefile/CMakeLists.txt/构建.bat) 不受影响。');
    if (!go) { setBusy(false); return; }
    const d = await api('POST', '/api/build/clean', { project: S.project });
    const r = d.clean || {};
    switchConsoleTab('console', true);
    clearConsole('console');
    con('console', '── 清理构建 ──', 'cl-sys');
    (r.messages || []).forEach((m) => con('console', m.text, m.kind === 'warning' ? 'cl-err' : 'cl-sys'));
    if ((r.removed || []).length) {
      await refreshTree();
      updateStatusBar();
    }
    toast('清理完成：删除 ' + (r.files || 0) + ' 个文件（' + fmtSize(r.bytes || 0) + '）');
  } catch (e) { reportError('清理失败：' + e.message); }
  setBusy(false);
}

async function doMakeScript() {
  if (!S.project) { toast('请先选择工程'); return; }
  setBusy(true);
  try {
    const d = await api('POST', '/api/build/script', { project: S.project, mode: $('modeSelect').value });
    await refreshTree();
    const go = window.confirm('构建脚本已生成：\n\n' + (d.files || []).join('\n')
      + '\n\n可用 mingw32-make / cmake 命令行构建，或双击 构建.bat。\n\n是否立即用内置 make 构建一次？');
    if (go) await doMakeBuild();
  } catch (e) { reportError('生成失败：' + e.message); }
  setBusy(false);
}

/* ================= CI/CD ================= */
async function doCI() {
  if (!S.project) { toast('请先选择工程'); return; }
  try {
    const d = await api('POST', '/api/ci', {
      project: S.project, providers: ['github', 'gitlab', 'gitea'],
    });
    await refreshTree();
    modalInfo('CI/CD 配置已生成', '已生成：\n\n' + (d.files || []).join('\n')
      + '\n\n把工程推送到远程仓库后，即可自动翻译、编译并产出 EXE 产物。');
  } catch (e) { reportError('生成失败：' + e.message); }
}

/* ================= Git ================= */
let gitTimer = null;
function gitPath() {
  return S.cfg && S.cfg.dir ? S.cfg.dir : '';
}
async function refreshGit() {
  if (!gitTimer) return;
  const pj = S.project;
  try {
    const st = await api('GET', '/api/git/status?project=' + encodeURIComponent(pj));
    const el = $('gitStatus');
    el.textContent = st.repo
      ? (st.branch ? '分支：' + st.branch + '\n' : '') + (st.lines.join('\n') || '工作区干净')
      : '还不是 Git 仓库，点「初始化仓库」开始版本控制。';
    if (st.repo) {
      S.branch = st.branch || '';
      updateStatusBar();
      const lg = await api('GET', '/api/git/log?project=' + encodeURIComponent(pj));
      $('gitLog').textContent = lg.commits.join('\n') || '（暂无提交记录）';
      $('btnGitInit').style.display = 'none';
      await refreshBranches();
      await refreshDiff();
    } else {
      $('btnGitInit').style.display = '';
      $('gitLog').textContent = '';
    }
  } catch (e) { if ($('gitStatus')) $('gitStatus').textContent = 'Git 状态读取失败：' + e.message; }
}
async function gitInit() {
  try {
    const d = await api('POST', '/api/git/init', { project: S.project });
    toast(d.note || '已初始化');
    refreshGit();
  } catch (e) { reportError(e.message); }
}
async function gitCommit() {
  const msg = $('gitMsg').value.trim() || '更新';
  try {
    const d = await api('POST', '/api/git/commit', { project: S.project, message: msg });
    toast(d.note || '提交成功');
    refreshGit();
  } catch (e) { reportError(e.message); }
}

async function refreshBranches() {
  try {
    const d = await api('GET', '/api/git/branches?project=' + encodeURIComponent(S.project));
    const sel = $('gitBranch');
    if (!sel) return;
    const list = d.branches || [];
    sel.innerHTML = list.map((b) => '<option value="' + escHtml(b) + '"'
      + (b === d.branch ? ' selected' : '') + '>' + escHtml(b) + '</option>').join('');
  } catch (e) { /* 未初始化仓库时忽略 */ }
}

async function refreshDiff() {
  try {
    const d = await api('GET', '/api/git/diff?project=' + encodeURIComponent(S.project));
    const el = $('gitDiff');
    if (el) el.textContent = d.text || d.stat || '';
  } catch (e) { /* 忽略 */ }
}

async function gitBranchOp(action) {
  const name = (action === 'create' ? $('gitNewBranch').value : $('gitBranch').value || '').trim();
  if (!name) { toast('请填写分支名'); return; }
  try {
    const d = await api('POST', '/api/git/branch', { project: S.project, action, name });
    toast(d.note || '操作完成');
    if (action === 'create') $('gitNewBranch').value = '';
    refreshGit();
  } catch (e) { reportError(e.message); }
}

async function gitRemoteSet() {
  const url = ($('gitRemote').value || '').trim();
  if (!url) { toast('请填写远程仓库地址'); return; }
  try {
    const d = await api('POST', '/api/git/remote', { project: S.project, action: 'set', url });
    toast(d.note || '已设置 origin');
  } catch (e) { reportError(e.message); }
}

async function gitSyncOp(action) {
  try {
    const d = await api('POST', '/api/git/sync', { project: S.project, action });
    toast(d.note || '完成');
    refreshGit();
  } catch (e) { reportError(e.message); }
}

function openGit() {
  $('modalHead').textContent = '版本控制（Git）— ' + S.project;
  const box = $('modalBody');
  box.innerHTML = '<div class="gitBar"><button id="btnGitInit" class="accent" style="display:none">初始化仓库</button>'
    + '<button id="btnGitRefresh">刷新</button></div>'
    + '<div class="gitBar"><label style="align-self:center">分支</label><select id="gitBranch"></select>'
    + '<input id="gitNewBranch" placeholder="新分支名…">'
    + '<button id="btnGitBranchNew">新建并切换</button><button id="btnGitCheckout">切换</button></div>'
    + '<div class="help" style="margin:2px 0 6px">当前更改（未提交）：</div>'
    + '<div class="mono-block" id="gitStatus"></div>'
    + '<div class="gitBar"><input id="gitMsg" placeholder="提交说明…"><button id="btnGitCommit" class="accent">提交全部更改</button></div>'
    + '<div class="help" style="margin:2px 0 6px">改动明细（diff）：</div>'
    + '<div class="mono-block" id="gitDiff" style="max-height:150px"></div>'
    + '<div class="help" style="margin:2px 0 6px">远程仓库：</div>'
    + '<div class="gitBar"><input id="gitRemote" placeholder="https://… 或 git@…">'
    + '<button id="btnGitRemoteSet">设置 origin</button>'
    + '<button id="btnGitPull">↓ 拉取</button><button id="btnGitPush">↑ 推送</button></div>'
    + '<div class="help" style="margin:2px 0 6px">最近提交记录：</div>'
    + '<div class="mono-block" id="gitLog"></div>';
  const foot = $('modalFoot');
  foot.innerHTML = '';
  const close = document.createElement('button');
  close.className = 'btnClose';     // 原来是 accent 靠右，现在统一图片样式并靠左
  close.title = '关闭';
  close.textContent = '关闭';
  close.onclick = () => { clearInterval(gitTimer); gitTimer = null; hideModal(); };
  foot.appendChild(close);
  setModalWide(false);                      // Git 面板保持默认宽度
  $('modalMask').classList.remove('hidden');
  $('btnGitInit').onclick = gitInit;
  $('btnGitRefresh').onclick = refreshGit;
  $('btnGitCommit').onclick = gitCommit;
  $('btnGitBranchNew').onclick = () => gitBranchOp('create');
  $('btnGitCheckout').onclick = () => gitBranchOp('checkout');
  $('btnGitRemoteSet').onclick = gitRemoteSet;
  $('btnGitPull').onclick = () => gitSyncOp('pull');
  $('btnGitPush').onclick = () => gitSyncOp('push');
  clearInterval(gitTimer);
  gitTimer = setInterval(refreshGit, 6000);
  refreshGit();
}

/* ================= 环境 / 设置 ================= */
/* 工具链自检：g++ / make / Git / Python / bash 的路径（与版本）。
   启动、状态栏、以及设置里的「⟳ 自检工具链」共用同一套判定。 */
function envItems() {
  const env = (S.env && S.env.env) || null;
  if (!env) return null;
  // 版本号提取：去掉括号里的说明（如 g++ 的「(Rev6, Built by MSYS2 project)」）后取最后一段
  const cut = (v) => {
    const parts = String(v || '').replace(/\([^)]*\)/g, ' ').trim().split(/\s+/).filter(Boolean);
    return parts.length ? parts[parts.length - 1] : '';
  };
  return [
    ['g++', env.gxx, cut(env.gxxVer)],
    ['make', env.make, cut(env.makeVer)],
    ['Git', env.git, cut(env.gitVer)],
    ['Python', env.pythonPath, env.python ? 'v' + env.python : ''],
    // pip 的重点不是「有没有」，而是**它属于哪个 Python**（pip.exe 是写死解释器的壳）。
    // 归属不一致的警告放最前面：自检列表按「名称：路径　补充」拼接，路径很长会被截断，
    // 补充信息放在末尾就看不见了。
    ['pip', env.pip, (env.pip && !env.pipMatched
      ? '⚠ 归属 Python ' + (env.pipPython || '?') + '　' : '')
      + (env.pipVer ? 'v' + env.pipVer : '') + pipSourceTag(env)],
    ['bash', env.bash, bashVersion(env.bashVer) + bashSourceTag(env)],
    ['Node', env.node, (env.nodeVer || '') + nodeSourceTag(env)],
    ['Qt（x64 运行库）', env.qt, ''],
    ['Qt（x86 运行库）', env.qtx86, ''],
    ['Sciter（x64）', env.sciter, ''],
    ['Sciter（x86）', env.sciterx86, ''],
    ['zstd', env.zstd, env.zstdVer || ''],
  ];
}

/* bash 的来源标记：tools（IDE 自带）/ 系统 / 手动填写。
   定位规则：tools 子目录下存在就用 tools 里的，不存在才检查系统。 */
function bashSourceTag(env) {
  const s = (env || {}).bashSource;
  return s === 'tools' ? '（自带）' : s === 'system' ? '（系统）'
    : s === 'setting' ? '（手动）' : '';
}

/* node 的来源标记：与 bashSourceTag 同款（智能体 PTC 的 TypeScript 运行时）。 */
function nodeSourceTag(env) {
  const s = (env || {}).nodeSource;
  return s === 'tools' ? '（自带）' : s === 'system' ? '（系统）'
    : s === 'setting' ? '（手动）' : '';
}

/* pip 的来源标记（与 bashSourceTag 同款）。 */
function pipSourceTag(env) {
  const s = (env || {}).pipSource;
  return s === 'tools' ? '（自带）' : s === 'system' ? '（系统）'
    : s === 'setting' ? '（手动）' : '';
}

/* 「环境设置」里 Python / pip 路径下方那段说明。
   pip 最要紧的一条：**它属于哪个 Python** —— pip.exe 是个写死了目标解释器的壳，
   来源拷错会变成「能跑，但包装到别的 Python 里去了」（后端 pip_report 已经查好）。 */
function pipHelpText(env) {
  const e = env || {};
  if (!e.pip) {
    return tr('pip：未找到。把 pip.exe 放进 tools\\python\\Scripts 即可（或在上面指定路径）。'
      + '注意它必须属于 IDE 自带的那个 Python，否则包装不到自带 Python 里。');
  }
  const where = e.pipSource === 'tools' ? tr('IDE 自带（tools\\python\\Scripts）')
    : e.pipSource === 'system' ? tr('系统（PATH）')
      : e.pipSource === 'setting' ? tr('设置里手动指定的路径') : tr('未知');
  const mod = e.pipModuleOk
    ? tr('　自带 Python 的 python -m pip 可用 ✓（推荐用它装包：一定装进自带 Python）。')
    : tr('　自带 Python 的 python -m pip 不可用 ✗（它里面没有 pip 模块；'
      + '要装进自带 Python 得先把 pip 装进去）。');
  return tr('来源：') + where + '。' + (e.pipNote || '') + mod;
}

/* 「环境设置」里 bash 路径下方那段说明：把当前来源直接写出来。 */
function bashHelpText(env) {
  const src = (env || {}).bashSource;
  const where = src === 'tools' ? tr('IDE 自带（tools 目录）')
    : src === 'system' ? tr('系统（常见安装位置 / PATH）')
      : src === 'setting' ? tr('设置里手动指定的路径')
        : tr('未找到');
  return tr('绿色免安装 bash（含 ls / grep / sed / awk / find 等 coreutils）：')
    + tr('tools 子目录下存在就自动填入它的路径，不存在才检查系统。')
    + tr('当前来源：') + where + '。' + tr('智能体的 run_script 用它执行工程内的 .sh 脚本；')
    + tr('留空＝自动定位（tools → 系统）。');
}

/* bash 的版本串是 "GNU bash, version 5.3.15(2)-release (x86_64-pc-cygwin)"，
   按空格取最后一段会得到 "-release"，所以单独抽数字版本号。 */
function bashVersion(v) {
  const m = /(\d+\.\d+(?:\.\d+)?)/.exec(String(v || ''));
  return m ? 'v' + m[1] : '';
}

/* 服务端 /api/env 是否带 bash 字段：
   运行中的服务进程若是旧版代码（重启前启动的），返回的 env 里根本没有 bash，
   这时前端无论怎么刷新都看不到 bash —— 直接提示重启 IDE，避免「查不出原因」。 */
function hasBashField(env) {
  return !!env && Object.prototype.hasOwnProperty.call(env, 'bash');
}

function refreshToolchainLabel() {
  const el = $('stToolchain');
  const env = S.env && S.env.env;
  if (!env) { el.textContent = '工具链未知'; return; }
  const items = envItems() || [];
  const miss = items.filter((it) => !it[1]).map((it) => it[0]);
  if (env.gxx) {
    const gxxIt = items.find((it) => it[0] === 'g++');
    const v = (gxxIt && gxxIt[2]) || env.gxx;
    el.textContent = '工具链：MinGW ' + v + (miss.length ? '（缺 ' + miss.join('、') + '）' : '');
    el.style.color = miss.length ? '#ffd08a' : '';
    el.title = items.map((it) => it[0] + '  : ' + (it[1] || '未找到')
      + (it[2] ? '　' + it[2] : '')).join('\n')
      + (miss.length ? '\n⚠ 缺少：' + miss.join('、') + '（点击打开 IDE设置查看详情）' : '')
      + '\n（点击打开 IDE设置）';
  } else {
    el.textContent = '⚠ 未找到 MinGW，点此打开 IDE设置';
    el.style.color = '#ffb3b0';
    el.title = '点击打开 IDE设置查看工具链状态（Qt / Sciter / zstd 等运行库包缺失时把对应包解压回 tools 目录）';
  }
}

/* 启动自检：把 g++ / make / Git / Python / bash / Node / 运行库包的检查结果写进控制台，
   缺项给出提示。注意：这里只检查**本地**工具（读一次 /api/env），**从不联网**——
   IDE 启动过程不访问网络，全部工具随 tools 目录分发（远程下载功能已移除）。 */
function checkEnvAtStartup() {
  const items = envItems();
  if (!items) { con('console', '✗ 工具链检测失败（/api/env 无数据）', 'cl-err'); return; }
  if (!hasBashField((S.env || {}).env)) {
    con('console', '⚠ 服务端代码是旧版（/api/env 里没有 bash 字段）：'
      + '请关闭 IDE 服务后重新运行「启动云易IDE.bat」，bash 才会被检测', 'cl-warn');
  }
  items.forEach((it) => {
    con('console', (it[1] ? '✓ ' : '✗ ') + (it[0] + '      ').slice(0, 6) + '：'
      + (it[1] || '未找到') + (it[2] ? '　' + it[2] : ''), it[1] ? 'cl-ok' : 'cl-err');
  });
  const miss = items.filter((it) => !it[1]).map((it) => it[0]);
  if (miss.length) {
    con('console', '✗ 缺少工具：' + miss.join('、')
      + '　（运行库包把对应目录解压回 IDE 的 tools 下即可；也可在「IDE设置」里手动指定路径）', 'cl-err');
    toast('缺少工具：' + miss.join('、') + '（详见「IDE设置」）', 5200);
  } else {
    con('console', '✓ 工具链自检通过：g++ / make / Git / Python / pip / bash / Node / Qt / Sciter / zstd 就绪', 'cl-ok');
  }
}

/* ================= IDE 配色（界面 + 编辑器语法着色，点「保存设置」才生效） =================
   与 style.css 的 CSS 变量一一对应：dark=深色主题（:root）、light=浅色主题（body.light）。
   界面颜色（--bg2/--fg 等）+ 背景色（--bg）+ 编辑器文字色（--tok-*）。
   用户改过的颜色保存到服务端 config/ide_settings.json（tokColors 字段），
   localStorage（键 yyIdeTokColors）只留一份即时缓存；启动时注入 <style id="tokColorStyle">
   （在 style.css 之后 → 同名变量后者覆盖前者），未改过的项继续用 style.css 的默认值。
   「IDE设置」打开期间改的都是草稿（draftTokColors），点「保存设置」才提交生效并落盘，
   直接关闭对话框即放弃改动。 */
const TOK_COLORS = {
  dark: [
    ['bg2', '面板背景', '#21242c'], ['con', '控制台', '#c7cbd4'], ['bg3', '控件背景', '#2a2e39'],
    ['fg', '文字颜色', '#d5d9e2'], ['fg-dim', '次要文字', '#8b93a5'],
    ['line', '边框线', '#333845'], ['accent', '强调色', '#4c9aff'],
    ['bg', '背景色', '#1a1c22'],
    ['kw', '关键字', '#c586c0'], ['flow', '流程语句', '#4c9aff'], ['type', '数据类型', '#4ec9b0'],
    ['fn', '函数命令', '#dcdcaa'], ['mfn', '类函数', '#e6c07b'],
    ['var', '变量', '#33c77f'], ['const', '常量', '#98a814'],
    ['str', '字符串', '#ce9178'], ['num', '数字', '#b5cea8'], ['com', '注释', '#6a9955'],
    ['op', '运算符', '#d4d4d4'], ['brk', '括号', '#569cd6'],
  ],
  light: [
    ['bg2', '面板背景', '#f4f6f9'], ['con', '控制台', '#24292f'], ['bg3', '控件背景', '#e9eef4'],
    ['fg', '文字颜色', '#24292f'], ['fg-dim', '次要文字', '#6a737d'],
    ['line', '边框线', '#d5dbe4'], ['accent', '强调色', '#0969da'],
    ['bg', '背景色', '#ffffff'],
    ['kw', '关键字', '#cf222e'], ['flow', '流程语句', '#4c9aff'], ['type', '数据类型', '#0550ae'],
    ['fn', '函数命令', '#8250df'], ['mfn', '类函数', '#9a6700'],
    ['var', '变量', '#33c77f'], ['const', '常量', '#98a814'],
    ['str', '字符串', '#0a3069'], ['num', '数字', '#0550ae'], ['com', '注释', '#6a737d'],
    ['op', '运算符', '#24292a'], ['brk', '括号', '#cf222e'],
  ],
};
/* 配色项 → CSS 变量名：界面/背景类直接用同名变量，其余是编辑器文字色（--tok-*）；
   「控制台」(con) 特例：映射到控制台输出文字色 --cl-run（普通输出行 .cl-run 用的变量） */
const TOK_UI_KEYS = new Set(['bg', 'bg2', 'bg3', 'fg', 'fg-dim', 'line', 'accent']);
const TOK_VAR_ALIAS = { con: '--cl-run' };
function tokVarName(k) {
  return TOK_VAR_ALIAS[k] || (TOK_UI_KEYS.has(k) ? '--' + k : '--tok-' + k);
}
const TOK_COLOR_KEY = 'yyIdeTokColors';
let userTokColors = { dark: {}, light: {} };   // 已生效的自定义（只存改过的项；空 = 全用默认）
let draftTokColors = null;                     // 「IDE设置」打开期间的草稿；保存时提交

function activeTokColors() { return draftTokColors || userTokColors; }
function tokDefaultColor(theme, k) {
  const it = TOK_COLORS[theme].find((x) => x[0] === k);
  return it ? it[2] : '#000000';
}
function tokColorOf(theme, k) {
  const u = activeTokColors();
  return (u[theme] && u[theme][k]) || tokDefaultColor(theme, k);
}
function loadTokColors() {
  try {
    const d = JSON.parse(localStorage.getItem(TOK_COLOR_KEY) || 'null');
    if (d && d.dark && d.light) {
      userTokColors = { dark: Object.assign({}, d.dark), light: Object.assign({}, d.light) };
    }
  } catch (e) { /* 数据坏了按默认来 */ }
}
function saveTokColors() {
  // localStorage 只作即时缓存；真正落盘在服务端 config/ide_settings.json
  try { localStorage.setItem(TOK_COLOR_KEY, JSON.stringify(userTokColors)); } catch (e) { /* 忽略 */ }
  ideCfgQueueSave({ tokColors: userTokColors });
}
/* 把用户配色注入 <style id="tokColorStyle">（只写改过的变量，其余继续用 style.css 默认值） */
function applyTokColors() {
  let el = $('tokColorStyle');
  if (!el) {
    el = document.createElement('style');
    el.id = 'tokColorStyle';
    document.head.appendChild(el);
  }
  const block = (theme, sel) => sel + ' {\n' + TOK_COLORS[theme]
    .filter((it) => userTokColors[theme] && userTokColors[theme][it[0]])
    .map((it) => '  ' + tokVarName(it[0]) + ': ' + userTokColors[theme][it[0]] + ';').join('\n')
    + '\n}';
  el.textContent = block('dark', ':root') + '\n' + block('light', 'body.light');
}
function initTokColors() { loadTokColors(); applyTokColors(); }

/* 「IDE配色」页里的示例代码（两个主题各预览一份，颜色随取色器即时更新） */
const TOK_PREVIEW_HTML =
  '<span class="tok-kw">子程序</span> <span class="tok-fn">主程序</span>() <span class="tok-com">\' 入口</span>\n'
  + '<span class="tok-kw">变量</span> <span class="tok-type">整数型</span> <span class="tok-var">计数</span> <span class="tok-op">=</span> <span class="tok-num">0</span>\n'
  + '<span class="tok-flow">如果</span> <span class="tok-var">计数</span> <span class="tok-op">&gt;</span> <span class="tok-num">10</span>\n'
  + '    <span class="tok-fn">信息框</span>(<span class="tok-str">"你好"</span>, <span class="tok-const">颜色_红</span>)\n'
  + '<span class="tok-kw">类函数</span> <span class="tok-type">窗口</span><span class="tok-op">.</span>'
  + '<span class="tok-mfn">新建</span>()  <span class="tok-com">\' 类函数（方法）单独一色</span>';

function tokColorPageHtml() {
  const esc = (s) => escHtml(s || '');
  const section = (theme, note) => {
    const rows = TOK_COLORS[theme].map((it) => {
      const cur = tokColorOf(theme, it[0]);
      return '<div class="row setRow tokRow"><label>' + esc(it[1]) + '</label>'
        + '<input type="color" class="tokColor" data-theme="' + theme + '" data-tok="' + it[0]
        + '" value="' + cur + '" title="' + esc(it[1]) + '">'
        + '<span class="tokColorVal">' + cur + '</span></div>';
    }).join('');
    const vars = TOK_COLORS[theme].filter((it) => !TOK_UI_KEYS.has(it[0]) && !TOK_VAR_ALIAS[it[0]])
      .map((it) => '--tok-' + it[0] + ':' + tokColorOf(theme, it[0])).join(';');
    /* 预览块背景用本主题自己的「背景色」（内联样式 → 浅色区预览在深色模式下也显示浅色底） */
    return '<div class="setSectionHead"><small>' + esc(note) + '</small></div>'
      + '<div class="tokPreview" id="tokPreview-' + theme + '" style="' + vars
      + ';background:' + tokColorOf(theme, 'bg') + '">'
      + TOK_PREVIEW_HTML + '</div>' + rows;
  };
  /* 浅色 / 深色两个主题放进子选项卡（.tokTabs 平分宽度），标题在选项卡上、分组头只留说明 */
  const page = (theme, note, hidden) =>
    '<div id="tokPage-' + theme + '"' + (hidden ? ' class="hidden"' : '') + '>' + section(theme, note) + '</div>';
  return '<div class="setTabs tokTabs" id="tokTabs">'
    + '<button type="button" class="setTab active" data-page="tokPage-light">浅色主题</button>'
    + '<button type="button" class="setTab" data-page="tokPage-dark">深色主题</button>'
    + '</div>'
    + page('light', '「控制台」设控制台输出文字的颜色；「背景色」往下是编辑器文字颜色', false)
    + page('dark', '「控制台」设控制台输出文字的颜色；「背景色」往下是编辑器文字颜色', true)
    + '<div class="row setRow"><label></label>'
    + '<button type="button" id="btnResetColors" title="恢复全部颜色为默认值">恢复默认配色</button></div>';
}

/* 绑定「IDE配色」页的事件：改动只写草稿 + 更新预览，点「保存设置」才生效（见 saveSettings）；
   「恢复默认配色」同样只重置草稿，未保存前不影响 IDE */
function bindTokColorPage() {
  /* 子选项卡切换：浅色主题 / 深色主题（点「恢复默认配色」重绘后会重新绑定） */
  const tokTabs = $('tokTabs');
  if (tokTabs) {
    tokTabs.querySelectorAll('.setTab').forEach((b) => {
      b.onclick = () => {
        tokTabs.querySelectorAll('.setTab').forEach((x) => x.classList.toggle('active', x === b));
        ['tokPage-light', 'tokPage-dark'].forEach((id) => {
          $(id).classList.toggle('hidden', id !== b.dataset.page);
        });
      };
    });
  }
  document.querySelectorAll('#setPageColor .tokColor').forEach((inp) => {
    inp.oninput = () => {
      const theme = inp.dataset.theme;
      const k = inp.dataset.tok;
      const v = inp.value;
      (draftTokColors[theme] = draftTokColors[theme] || {})[k] = v;
      const pv = $('tokPreview-' + theme);
      if (pv) {
        if (k === 'bg') pv.style.background = v;          // 背景色：直接改预览块底色
        else pv.style.setProperty(tokVarName(k), v);      // 文字色：改预览块上的 CSS 变量
      }
      const val = inp.parentElement.querySelector('.tokColorVal');
      if (val) val.textContent = v;
    };
  });
  $('btnResetColors').onclick = () => {
    draftTokColors = { dark: {}, light: {} };
    $('setPageColor').innerHTML = tokColorPageHtml();
    bindTokColorPage();
  };
}

function settingsBodyHtml() {
  const env = (S.env && S.env.env) || {};
  const esc = (s) => escHtml(s || '');
  return '<div class="setTabs" id="setTabs">'
    + '<button type="button" class="setTab active" data-page="setPageWs">工作区</button>'
    + '<button type="button" class="setTab" data-page="setPageEnv">环境设置 / 工具链</button>'
    + '<button type="button" class="setTab" data-page="setPageColor">IDE配色</button>'
    + '</div>'
    /* 第一栏：工作区（工作区目录 + 服务端口） */
    + '<div id="setPageWs">'
    + '<div class="row setRow"><label>工作区目录</label><input id="setWorkspace" value="' + esc(S.workspace || '') + '"></div>'
    + '<div class="row setRow"><label>服务端口</label><input id="setPort" value="' + esc((S.env && S.env.port) || 8405) + '" placeholder="默认 8405"></div>'
    + '<div class="help" style="width:100%;text-align:left;margin-top:-4px">修改端口并保存后，服务会自动切换到新端口并跳转（默认 8405）。</div>'
    + '<hr class="setSep">'
    + '<div class="row setRow"><label>界面语言</label><select id="setLang"></select></div>'
    + '<div class="help" style="width:100%;text-align:left;margin-top:-4px">语言包在 config 目录（*.lng，如 zh_cn.lng / en_us.lng）；切换语言并保存后界面自动刷新生效。</div>'
    + '</div>'
    /* 第二栏：环境设置 / 工具链（自检结果 + 各工具路径） */
    + '<div id="setPageEnv" class="hidden">'
    + '<div class="envInfo" id="envInfo"></div>'
    + '<div class="row setRow"><label>bash 路径</label><input id="setBash" value="' + esc(env.bash) + '" placeholder="留空＝自动：优先 tools 目录，其次系统"></div>'
    + '<div class="help" id="bashHelp" style="width:100%;text-align:left;margin-top:-4px">'
    + esc(bashHelpText(env)) + '</div>'
    + '<div class="row setRow"><label>g++ 路径</label><input id="setGxx" value="' + esc(env.gxx) + '" placeholder="留空自动检测（tools 优先，其次系统）"></div>'
    + '<div class="row setRow"><label>make 路径</label><input id="setMake" value="' + esc(env.make) + '"></div>'
    + '<div class="row setRow"><label>git 路径</label><input id="setGit" value="' + esc(env.git || 'git') + '"></div>'
    + '<div class="row setRow"><label>Python 路径</label><input id="setPython" value="' + esc((S.env && S.env.pythonPath) || '') + '" placeholder="留空自动检测（tools 优先，其次系统）"></div>'
    + '<div class="row setRow"><label>pip 路径</label><input id="setPip" value="' + esc(env.pip) + '" placeholder="留空＝自动：优先 tools\\python\\Scripts，其次系统"></div>'
    + '<div class="help" id="pipHelp" style="width:100%;text-align:left;margin-top:-4px">'
    + esc(pipHelpText(env)) + '</div>'
    + '<div class="row setRow"><label>Node 路径</label><input id="setNode" value="' + esc(env.node) + '" placeholder="留空＝自动：优先 tools\\node\\node.exe，其次系统"></div>'
    + '<div class="row setRow"><label>Qt x64 路径</label><input id="setQt" value="' + esc(env.qt) + '" placeholder="留空＝自动：tools\\Qt\\ucrt64\\bin"></div>'
    + '<div class="row setRow"><label>Qt x86 路径</label><input id="setQtx86" value="' + esc(env.qtx86) + '" placeholder="留空＝自动：tools\\Qtx86\\ucrt32\\bin"></div>'
    + '<div class="row setRow"><label>Sciter x64 路径</label><input id="setSciter" value="' + esc(env.sciter) + '" placeholder="留空＝自动：tools\\sciter\\bin"></div>'
    + '<div class="row setRow"><label>Sciter x86 路径</label><input id="setSciterx86" value="' + esc(env.sciterx86) + '" placeholder="留空＝自动：tools\\sciterx86\\yysciter_x86.dll"></div>'
    + '<div class="row setRow"><label>zstd 路径</label><input id="setZstd" value="' + esc(env.zstd) + '" placeholder="留空＝自动：tools\\zstd 下找 zstd.exe"></div>'
    + '<div class="help" style="width:100%;text-align:left;margin-top:-4px">'
    + '所有路径默认已写入 tools 目录下的对应程序（启动时自动检测填写）；留空或路径失效时恢复自动检测（tools 优先，其次系统），'
    + '缺失时把对应包解压回 tools 目录即可。</div>'
    + '<div class="row setRow"><label></label>'
    + '<button type="button" id="btnTestToolchain" title="重新检测 g++ / make / Git / Python / pip / bash / Node / Qt / Sciter / zstd">⟳ 自检工具链</button></div>'
    + '</div>'
    /* 第三栏：IDE配色（浅色 / 深色主题子选项卡） */
    + '<div id="setPageColor" class="hidden">' + tokColorPageHtml() + '</div>';
}

function appendEnvInfo(line, cls) {
  const box = $('envInfo');
  if (!box) return;
  const d = document.createElement('div');
  d.className = cls || '';
  d.textContent = line;
  box.appendChild(d);
  box.scrollTop = 1e9;
}

async function testToolchain() {
  appendEnvInfo('→ 正在检测工具链（g++ / make / Git / Python / pip / bash / Node / Qt / Sciter / zstd）…', 'cl-sys');
  try {
    const d = await api('GET', '/api/env');
    const e = d.env;
    S.env = d;
    (envItems() || []).forEach((it) => {
      appendEnvInfo((it[0] + '            ').slice(0, 12) + '：' + (it[1] || '未找到')
        + (it[2] ? '　' + it[2] : ''), it[1] ? 'cl-pass' : 'cl-err');
    });
    if ($('setPython')) $('setPython').value = e.pythonPath || '';
    if ($('setPip')) $('setPip').value = e.pip || '';
    $('setGxx').value = e.gxx || '';
    $('setMake').value = e.make || '';
    $('setGit').value = e.git || 'git';
    if ($('setBash')) $('setBash').value = e.bash || '';
    if ($('setNode')) $('setNode').value = e.node || '';
    if ($('setQt')) $('setQt').value = e.qt || '';
    if ($('setQtx86')) $('setQtx86').value = e.qtx86 || '';
    if ($('setSciter')) $('setSciter').value = e.sciter || '';
    if ($('setSciterx86')) $('setSciterx86').value = e.sciterx86 || '';
    if ($('setZstd')) $('setZstd').value = e.zstd || '';
    if ($('bashHelp')) $('bashHelp').textContent = bashHelpText(e);
    if ($('pipHelp')) $('pipHelp').textContent = pipHelpText(e);
    const miss = (envItems() || []).filter((it) => !it[1]).map((it) => it[0]);
    if (miss.length) {
      appendEnvInfo('✗ 缺少：' + miss.join('、')
        + '　（Qt / Sciter / zstd 等运行库包把对应目录解压回 IDE 的 tools 下即可；'
        + 'g++ / make / Git / Python / pip / bash / Node 也可在上方路径里手动指定）', 'cl-err');
    } else {
      appendEnvInfo('✓ 工具链就绪：MinGW（g++ / make）、Git、Python、pip、bash、Node、'
        + 'Qt（x64/x86）、Sciter（x64/x86）、zstd 均可直接使用', 'cl-pass');
    }
    // 服务端是重启前的旧进程：返回里没有 bash 字段 → 提示重启 IDE
    if (!hasBashField(e)) {
      appendEnvInfo('⚠ 服务端代码是旧版（/api/env 里没有 bash 字段）：'
        + '请关闭 IDE 服务后重新运行「启动云易IDE.bat」，bash 才会被检测', 'cl-warn');
    }
    // 端口检查放最后（工具链项全部检查完再报端口）
    appendEnvInfo('端口  ：' + (d.port || 8405) + '（' + (d.portNote || '') + '）',
      d.portCurrent ? 'cl-sys' : (d.portNote === '可用' ? 'cl-pass' : 'cl-warn'));
    if ($('setPort')) $('setPort').value = d.port || 8405;
  } catch (e) { appendEnvInfo('检测失败：' + e.message, 'cl-err'); }
}

async function saveSettings() {
  try {
    const portVal = parseInt($('setPort').value, 10);
    const d = await api('POST', '/api/settings', {
      workspace: $('setWorkspace').value.trim(),
      gxx: $('setGxx').value.trim(),
      make: $('setMake').value.trim(),
      git: $('setGit').value.trim(),
      python: $('setPython').value.trim(),
      pip: ($('setPip') ? $('setPip').value.trim() : ''),
      bash: $('setBash').value.trim(),
      node: ($('setNode') ? $('setNode').value.trim() : ''),
      qt: ($('setQt') ? $('setQt').value.trim() : ''),
      qtx86: ($('setQtx86') ? $('setQtx86').value.trim() : ''),
      sciter: ($('setSciter') ? $('setSciter').value.trim() : ''),
      sciterx86: ($('setSciterx86') ? $('setSciterx86').value.trim() : ''),
      zstd: ($('setZstd') ? $('setZstd').value.trim() : ''),
      language: ($('setLang') ? $('setLang').value : ''),
      port: isNaN(portVal) ? 8405 : portVal,
    });
    S.env = d;
    /* 配色：服务端保存成功后提交草稿 → 注入 <style> 生效并落盘
       config/ide_settings.json（localStorage 同步一份缓存，
       端口变更整页跳转后由 initTokColors + syncIdeConfigLoad 恢复） */
    if (draftTokColors) {
      userTokColors = draftTokColors;
      draftTokColors = null;
      applyTokColors();
      saveTokColors();
    }
    if (d.portChanged) {
      appendEnvInfo('✓ 设置已保存，端口切换为 ' + d.port + '，正在跳转…', 'cl-pass');
      const target = location.protocol + '//' + location.hostname + ':' + d.port + '/';
      setTimeout(() => { location.href = target; }, 1200);
      return;
    }
    /* 语言变了：整页刷新，让 loadI18n 按新语言重新拉词典 */
    if ($('setLang') && $('setLang').value !== I18N.lang) {
      appendEnvInfo('✓ 设置已保存，正在切换界面语言…', 'cl-pass');
      setTimeout(() => { location.reload(); }, 800);
      return;
    }
    appendEnvInfo('✓ 设置已保存', 'cl-pass');
    refreshToolchainLabel();
    await loadProjects();
  } catch (e) { appendEnvInfo('保存失败：' + e.message, 'cl-err'); }
}

/* 远程下载功能已移除：全部工具随 IDE 的 tools 目录分发（缺失时手动解压回 tools 即可） */

/* 「关于」对话框信息（每次改动后按 v+yyyyMMddHHmm 更新版本号） */
const ABOUT = {
  name: '云易IDE',
  tagline: '中文编程语言集成开发环境',
  version: 'v202609292232',
  release: '2026-09-18',
  author: '毛茸茸的小幸福',
  url: 'https://www.24992499.xyz',
};

function openAbout() {
  const esc = (s) => escHtml(s);
  $('aboutInfo').innerHTML = ''
    + '<span class="abName">' + esc(ABOUT.name) + '</span>　' + esc(ABOUT.tagline) + '\n'
    + '版本号：' + esc(ABOUT.version) + '\n'
    + '发布时间：' + esc(ABOUT.release) + '\n'
    + '作者：' + esc(ABOUT.author) + '\n'
    + '网址：<a href="' + esc(ABOUT.url) + '" target="_blank" rel="noopener">' + esc(ABOUT.url) + '</a>'
    + '\n\u00a0\n\u00a0';   // 网址下方保留两个可见空白行
  const foot = $('aboutFoot');
  foot.innerHTML = '';
  const b = document.createElement('button');
  b.className = 'btnClose';         // 统一普通文字按钮样式（该对话框底部本来就左对齐）
  b.title = '关闭';
  b.textContent = '✗ 关闭';
  b.onclick = () => $('aboutMask').classList.add('hidden');
  foot.appendChild(b);
  $('aboutMask').classList.remove('hidden');
}

async function openSettings() {
  setModalWide(true);                       // 底部按钮多：用宽版对话框
  setModalSize(true);                       // IDE设置：宽度固定 800、高度自适应
  $('modalHead').textContent = 'IDE设置';
  /* 配色草稿：IDE设置里改颜色不即时生效，点「保存设置」才提交（见 saveSettings），
     直接关闭则丢弃草稿（下次打开时重新从 userTokColors 复制） */
  draftTokColors = { dark: Object.assign({}, userTokColors.dark), light: Object.assign({}, userTokColors.light) };
  $('modalBody').innerHTML = settingsBodyHtml();
  /* 界面语言下拉：选项来自 /api/langs（服务端读 config\*.lng 的 @label）。
     当前语言不在列表里（语言包被删）时回落到 zh_cn。 */
  (() => {
    const sel = $('setLang');
    if (!sel) return;
    const langs = (I18N.langs && I18N.langs.length) ? I18N.langs : [{ name: 'zh_cn', label: '简体中文' }];
    langs.forEach((it) => {
      const o = document.createElement('option');
      o.value = it.name;
      o.textContent = it.label + '（' + it.name + '）';
      sel.appendChild(o);
    });
    sel.value = I18N.lang || 'zh_cn';
    if (sel.selectedIndex < 0) sel.value = 'zh_cn';
  })();
  const foot = $('modalFoot');
  foot.innerHTML = '';
  const mkBtn = (label, cls, fn) => {
    const b = document.createElement('button');
    b.textContent = label;
    if (cls) b.className = cls;
    b.onclick = fn;
    foot.appendChild(b);
    return b;
  };
  /* 「环境设置 / 工具链」的关闭按钮**保持原来的普通按钮样式**（文字「✗ 关闭」），
     不跟其它地方一起换成图片外观；靠左的做法原本就有（margin-right:auto）。 */
  const closeBtn = mkBtn('✗ 关闭', '', hideModal);
  closeBtn.style.marginRight = 'auto';              // 关闭按钮贴最左，其余按钮靠右
  mkBtn('关于', '', openAbout);                     // 紧挨关闭按钮右边
  const sv = mkBtn('保存设置', 'accent', saveSettings);
  sv.style.cssText = 'background:var(--accent-btn);border-color:var(--accent-btn-bd);';
  $('modalMask').classList.remove('hidden');
  /* 选项卡切换：工作区 / 环境设置·工具链 / IDE配色 */
  const tabs = $('setTabs');
  tabs.querySelectorAll('.setTab').forEach((b) => {
    b.onclick = () => {
      tabs.querySelectorAll('.setTab').forEach((x) => x.classList.toggle('active', x === b));
      ['setPageWs', 'setPageEnv', 'setPageColor'].forEach((id) => {
        $(id).classList.toggle('hidden', id !== b.dataset.page);
      });
    };
  });
  /* 「⟳ 自检工具链」按钮移到【环境设置 / 工具链】页最下面（打开时自动自检一次的逻辑不变） */
  $('btnTestToolchain').onclick = testToolchain;
  bindTokColorPage();
  testToolchain();
}

/* ================= 编辑器悬停提示 ================= */
let _lastHoverTime = 0;
let _hoverKey = '';
let _hoverTimer = null;      // 悬停延时显示计时器
let _hoverPending = '';      // 正在等待显示的提示标识（词 + 说明）
let _hoverX = 0;             // 最近一次鼠标位置（延时结束后据此定位气泡）
let _hoverY = 0;
const HOVER_DELAY = 230;     // 与核心库命令提示一致：停留 230ms 后显示气泡（毫秒）

let _measureCtx = null;
function measureCtx() {
  if (!_measureCtx) {
    _measureCtx = document.createElement('canvas').getContext('2d');
  }
  _measureCtx.font = editorFont + 'px Consolas, "Cascadia Mono", "Microsoft YaHei", monospace';
  return _measureCtx;
}

/* 等宽字体下逐字符累计宽度，返回横向坐标 x 对应的字符下标 */
function charIndexAtX(lineText, x) {
  const ctx = measureCtx();
  let acc = 0;
  for (let i = 0; i < lineText.length; i++) {
    const w = ctx.measureText(lineText[i]).width;
    if (acc + w / 2 > x) return i;
    acc += w;
  }
  return lineText.length;
}

/* 取某行 API 声明「贴着它」的注释（悬停提示与「API」栏悬停都显示这些），规则：
   ① 声明行尾的行内注释（`API … 在库 "x.dll"  ' 说明`）；
   ② 紧跟其后的连续注释行（遇到空行 / 代码行即停，如 core.api 里写法）；
   ③ 紧接其上的连续注释行（中间不能有空行 —— 免得把文件头或上一条的注释吸过来）。
   注释符号 `'` / `//` / `/* … *\/` 都会被去掉，返回纯文本（无注释时返回 ''）。 */
function apiCommentText(lines, i) {
  const CMT = /^[ \t]*('|'|\/\/|\/\*|\*|\*\/)/;
  const clean = (s) => String(s == null ? '' : s).replace(/\r$/, '')
    .replace(/^[ \t]*('|'|\/\/|\/\*|\*|\*\/)[ \t]?/, '').replace(/[ \t]+$/, '');
  const out = [];
  const ln = String(lines[i] == null ? '' : lines[i]);
  const q = Math.max(ln.lastIndexOf('"'), ln.lastIndexOf('”'));
  if (q >= 0) {                                  // ① 行内注释（在 在库 "…" 之后）
    const rest = ln.slice(q + 1);
    const p1 = rest.indexOf("'"), p2 = rest.indexOf('//');
    const at = p1 >= 0 ? p1 : p2;
    if (at >= 0) {
      const txt = rest.slice(at + (at === p1 ? 1 : 2)).trim();
      if (txt) out.push(txt);
    }
  }
  for (let k = i + 1; k < lines.length; k++) {    // ② 下方连续注释行
    const s = String(lines[k] == null ? '' : lines[k]);
    if (!s.trim() || !CMT.test(s)) break;
    out.push(clean(s));
  }
  const up = [];
  for (let k = i - 1; k >= 0; k--) {              // ③ 上方紧邻注释行（空行断开）
    const s = String(lines[k] == null ? '' : lines[k]);
    if (!s.trim() || !CMT.test(s)) break;
    up.unshift(clean(s));
  }
  return up.concat(out).filter(Boolean).join('\n');
}

/* 解析源码 / 类库里的「API」声明，按出现顺序返回
   [{name, ret, args, dll, line, raw, comment}]：
     语法：API 返回类型 名称(类型 参数, …) 在库 "xxx.dll"（返回类型可为「空」/「无」）
     line = 1 基行号（供「转到定义」与排序用）；
     raw = 该声明的原始整行（双击插入代码编辑框时原样使用）；
     comment = 贴着该声明的注释原文（悬停提示用，见 apiCommentText）。 */
function collectApiDecls(text) {
  const out = [];
  const src = String(text == null ? '' : text).split('\n');     // 原始行（带缩进）
  const rows = stripCommentsText(text || '').split('\n');       // 去注释（行结构不变）
  const re = /^[ \t]*API[ \t]+(空|无|[^\s(（]+)[ \t]+([^\s(（]+)[ \t]*[\(（]([^)）]*)[\)）][ \t]*在库[ \t]*["“]([^"”]+)["”]/;
  const seen = new Set();
  rows.forEach((row, i) => {
    const m = re.exec(row);
    if (!m) return;
    const name = m[2];
    if (seen.has(name)) return;                 // 同名以先出现者为准
    seen.add(name);
    out.push({ name,
               ret: (m[1] === '无' ? '空' : m[1]),
               args: (m[3] || '').trim(),
               dll: (m[4] || '').trim(),
               line: i + 1,
               comment: apiCommentText(src, i),
               raw: String(src[i] == null ? '' : src[i]).replace(/\r$/, '').trim() });
  });
  return out;
}

/* 解析源码顶层「API」声明 → { 名称: {args, dll, line, comment} }（悬停提示 / 转到定义用） */
function apiDeclMap(text) {
  const map = {};
  collectApiDecls(text).forEach((a) => {
    map[a.name] = { args: a.args, dll: a.dll, line: a.line, comment: a.comment || '' };
  });
  return map;
}

/* 悬停提示：变量 / 全局变量 / 常量 / 子程序参数 → 显示声明类型（找不到返回 null）。
   类型为自定义数据类型时顺带列出成员；常量补充显示常量值。 */
function varHoverInfo(word, text) {
  const structs = collectStructDefs(text);
  const libStructs = (S.libClass && S.libClass.structs) || {};
  const known = BASIC_TYPES.concat(Object.keys(structs)).concat(Object.keys(libStructs));
  const typeLine = (ty) => {
    if (!ty) return '类型：（未能识别）';
    const fs = structs[ty] || libStructs[ty];
    if (!fs || !fs.length) return '类型：' + ty;
    return '类型：' + ty + '（自定义数据类型）\n成员：'
      + fs.map((f) => f.type + ' ' + f.name).join('、');
  };
  // 变量 / 全局变量（本文件声明）
  for (const v of collectVarDecls(text)) {
    if (v.name !== word || v.kind === '常量') continue;
    return '【' + v.kind + '】' + v.name + '\n' + typeLine(v.type)
      + '\n定义于第 ' + v.line + ' 行';
  }
  // 常量：兼容「常量 名 类型 = 值」与「常量 名 = 值」（后者按值推断类型）
  for (const c of collectLibConstDefs(text)) {
    if (c.name !== word) continue;
    const raw = (stripCommentsText(text || '').split('\n')[c.line - 1] || '');
    const eq = raw.indexOf('=');
    const val = eq >= 0 ? raw.slice(eq + 1).trim() : '';
    return '【常量】' + c.name + '\n' + typeLine(c.type)
      + (val ? '\n值：' + val : '')
      + '\n定义于第 ' + c.line + ' 行（使用时写作 #' + c.name + '）';
  }
  // 子程序参数（参数 类型 名，取每个逗号段最后一个 token 为参数名，与上色逻辑一致）
  for (const s of parseSubs(text)) {
    for (const seg of (s.args || '').split(/[,，]/)) {
      const parts = seg.replace(/=.*/, '').trim().split(/\s+/).filter(Boolean);
      if (parts.length && parts[0] === '参数') parts.shift();
      if (!parts.length || parts[parts.length - 1] !== word) continue;
      const type = known.indexOf(parts[0]) >= 0 ? parts[0]
        : (parts.length >= 2 ? parts[parts.length - 2] : '');
      return '【参数】' + word + '\n' + typeLine(type) + '\n子程序：' + s.name;
    }
  }
  // 类库常量（lib/*.class 与 lib/*.const，编译时自动引入）
  const libConst = ((S.libClass && S.libClass.consts) || []).find((x) => x.name === word)
    || ((S.libClass && S.libClass.constFiles) || []).find((x) => x.name === word);
  if (libConst) {
    return '【常量】' + libConst.name
      + '\n类型：' + (libConst.type || '数值')
      + (libConst.value != null && libConst.value !== '' ? '\n值：' + libConst.value : '')
      + '\n来源：lib/' + (libConst.from || '')
      + '\n\n编译时自动引入，使用时写作 #' + libConst.name;
  }
  return null;
}

function lookupWordInfo(word, t, owner) {
  const apis = apiDeclMap(t.content);
  if (apis[word]) {
    const a = apis[word];
    return '【Windows API】' + word + '(' + a.args + ')'
      + '\n所在库：' + a.dll
      + (a.comment ? '\n\n' + a.comment : '')       // 声明处写的全部注释
      + '\n\n已在源码顶层声明，可直接调用。';
  }
  // 类库（lib/*.api）里声明的 API：工程里不写声明也能直接调用（编译时自动引入）
  const libApi = ((S.libClass && S.libClass.apis) || []).find((a) => a.name === word);
  if (libApi) {
    return '【Windows API】' + word + '(' + (libApi.args || '') + ')'
      + '\n所在库：' + libApi.dll
      + '\n来源：lib/' + (libApi.from || '')
      + (libApi.comment ? '\n\n' + libApi.comment : '')   // 声明处写的全部注释
      + '\n\n编译时会自动引入该声明（不必复制进源码，可直接调用）；'
      + '\n「API」栏可查看，双击条目可把声明插入本文件。';
  }
  const kw0 = YY_KEYWORDS_AC.find((k) => k.name === word);
  if (kw0) {
    // 基本数据类型（核心库「数据类型」条目）：显示 C++ 对应类型与大小
    const bt = (S.corelib.cmds || []).find((x) => x.form === '类型' && x.name === word);
    if (bt) {
      return '【数据类型】' + word
        + '\n对应 C++：' + String(bt.args || '').replace(/^C\+\+：/, '')
        + '\n大小：' + (bt.ret || '不定长')
        + (bt.desc ? '\n' + bt.desc : '');
    }
    if (word === 'asm' || word === '结束asm' || word === '结束汇编') {
      return '【关键字】' + word
        + '\n裸写汇编块：asm 开头、结束asm 收尾，中间的汇编指令原样写进生成的 C++'
        + '（__asm__ __volatile__("…")），不用引号也不用逗号。'
        + '\nasm 后面可写 Intel 或 AT&T 指定本块语法；省略则用「工程设置 → 汇编语法」。'
        + '\n块内不保证云易变量还在内存里，通常只用于 nop / cpuid / rdtsc 这类操作。';
    }
    return '【关键字】' + word;
  }
  // 变量 / 全局变量 / 常量 / 参数：悬停显示声明类型（本文件声明优先，其次类库常量）
  const vInfo = varHoverInfo(word, t.content);
  if (vInfo) return vInfo;
  // 类函数：悬停「类名.方法」中的方法 → 当前文件 / lib 类库中的定义
  if (owner) {
    const fm = collectMethodDefs(t.content).find((x) => x.owner === owner && x.name === word);
    const lm = ((S.libClass && S.libClass.methods) || [])
      .find((x) => x.owner === owner && x.name === word);
    const m = fm || lm;
    if (m) {
      return '【类函数】' + m.owner + '.' + m.name + '(' + (m.args || '') + ')'
        + '\n返回：' + (m.ret || '无')
        + '\n调用：' + m.owner + '.' + m.name + '(' + (m.args || '') + ')'
        + '\n来源：' + (m.from ? 'lib/' + m.from : '本文件')
        + (!fm && lm ? '\n\n⚠ 本文件里没有『类函数 ' + m.owner + '.' + m.name
            + '』的定义（编译会报未定义）\n双击「类」选项卡里的「' + m.owner
            + '」条目可自动补上定义；右键此处可删除该调用' : '');
    }
  }
  const sub = parseSubs(t.content).find((s) => s.name === word);
  if (sub) {
    return '【' + sub.kind + '】' + sub.name + '(' + sub.args + ')'
      + '\n定义于第 ' + sub.line + ' 行，可点击「函数列表」选项卡快速定位。';
  }
  const c = (S.corelib.cmds || []).find((x) => x.name === word);
  if (c) {
    if (c.form === '常量') {
      return '【核心库常量】' + c.name
        + '\n类型：' + (c.ret || '数值')
        + '\n' + (c.desc || '')
        + (c.demo ? '\n\n示例：' + c.demo : '');
    }
    return '【核心库 · ' + c.cat + '】' + c.name + '(' + (c.args || '') + ')'
      + '\n返回：' + (c.ret || '无')
      + '\n' + (c.desc || '')
      + (c.demo ? '\n\n示例：' + c.demo : '');
  }
  // 类名：当前文件的 数据类型/类函数宿主 或 lib/*.class 类库中的类
  const structs = collectStructDefs(t.content);
  const libStructs = (S.libClass && S.libClass.structs) || {};
  const libMethods = (S.libClass && S.libClass.methods) || [];
  const isFileClass = !!structs[word]
    || collectMethodDefs(t.content).some((x) => x.owner === word);
  const isLibClass = !!libStructs[word] || libMethods.some((x) => x.owner === word);
  if (isFileClass || isLibClass) {
    const seenN = new Set();
    const names = [];
    collectMethodDefs(t.content).concat(libMethods).forEach((x) => {
      if (x.owner === word && !seenN.has(x.name)) { seenN.add(x.name); names.push(x.name); }
    });
    const src = (isFileClass ? '本文件' : '') + (isFileClass && isLibClass ? ' / ' : '')
      + (isLibClass ? '类库' : '');
    // 数据类型（结构体）：悬停列出全部成员（类型 名称）
    const fs = structs[word] || libStructs[word];
    if (fs && fs.length) {
      return '【数据类型】' + word + '（' + src + '）'
        + '\n成员（' + fs.length + '）：\n  '
        + fs.map((f) => f.type + ' ' + f.name).join('\n  ')
        + (names.length ? '\n\n类函数（' + names.length + '）：' + names.join('、') : '');
    }
    return '【类】' + word + '（' + src + '）'
      + (names.length ? '\n类函数（' + names.length + '）：' + names.join('、') : '\n（暂无类函数）');
  }
  return null;
}

function showHoverTip(x, y) {
  const tip = $('hoverTip');
  if (!tip) return;
  tip.classList.remove('hidden');
  tip.style.left = Math.min(x + 14, window.innerWidth - tip.offsetWidth - 8) + 'px';
  tip.style.top = Math.min(y + 18, window.innerHeight - tip.offsetHeight - 8) + 'px';
}

function hideHoverTip() {
  clearTimeout(_hoverTimer);      // 取消尚未触发的延时显示
  _hoverTimer = null;
  _hoverPending = '';
  const tip = $('hoverTip');
  if (tip) tip.classList.add('hidden');
  _hoverKey = '';
}

/* 鼠标位置 → 编辑区内的标识符：{ word, owner, line }
   owner 为「类名.方法」中方法前的类名（不是这种写法则为空） */
function editorWordAt(e) {
  const ta = $('codeInput');
  const t = activeTab();
  if (!ta || ta.disabled || !t || t.kind !== 'yy') return null;

  // 鼠标位置 → 行号（等宽行高）
  const rect = ta.getBoundingClientRect();
  const lineNo = Math.floor((e.clientY - rect.top + ta.scrollTop) / LINE_H) + 1;
  const lines = t.content.split('\n');
  if (lineNo < 1 || lineNo > lines.length) return null;
  const lineText = lines[lineNo - 1];

  // 鼠标位置 → 行内字符下标（canvas 按字符测量宽度，中英文都准确）
  const x = e.clientX - rect.left + ta.scrollLeft - 4;   // 减去左内边距
  const idx = Math.min(charIndexAtX(lineText, x), lineText.length - 1);
  if (idx < 0 || !lineText[idx]) return null;

  // 从命中字符向两侧扩展出完整标识符（中英文 / 数字 / 下划线）
  const isWord = (c) => /[A-Za-z0-9_\u4e00-\u9fff]/.test(c);
  if (!isWord(lineText[idx])) return null;
  let s = idx, en = idx;
  while (s > 0 && isWord(lineText[s - 1])) s--;
  while (en < lineText.length - 1 && isWord(lineText[en + 1])) en++;

  // 「类名.方法()」中的方法：连同前面的类名一并返回
  let owner = '';
  if (s >= 1 && lineText[s - 1] === '.') {
    let b = s - 1;
    while (b > 0 && isWord(lineText[b - 1])) b--;
    owner = lineText.slice(b, s - 1).trim();
  }
  return { word: lineText.slice(s, en + 1), owner, line: lineNo };
}

function onEditorHover(e) {
  const now = Date.now();
  if (now - _lastHoverTime < 60) return;      // 节流
  _lastHoverTime = now;

  const t = activeTab();
  const hit = editorWordAt(e);
  if (!hit || !t) { hideHoverTip(); return; }
  const word = hit.word, owner = hit.owner;

  const info = lookupWordInfo(word, t, owner);
  if (!info) { hideHoverTip(); return; }

  // 悬停延时：在同一标识符上停留 HOVER_DELAY 毫秒后才显示气泡；
  // 移到别的标识符则重新计时（先收起气泡），移出/滚动/按下鼠标则取消
  _hoverX = e.clientX;
  _hoverY = e.clientY;
  const key = word + '|' + info;
  if (key !== _hoverPending) {
    clearTimeout(_hoverTimer);
    _hoverPending = key;
    _hoverKey = key;
    const tip = $('hoverTip');
    if (tip) { tip.textContent = info; tip.classList.add('hidden'); }
    _hoverTimer = setTimeout(() => {
      _hoverTimer = null;
      showHoverTip(_hoverX, _hoverY);
    }, HOVER_DELAY);
  }
}

/* ================= 编辑器自动补全 ================= */
/* 从源码中收集 声明关键字 后面的名称（兼容「名称 类型」与「类型 名称」两种写法） */
function collectNames(text, kw, types) {
  /* types：可识别的类型名集合（基本类型 + 数据类型名），用于区分「类型 名称」写法；
     缺省仅识别基本类型 */
  const TYPE = types || ['逻辑型', '字节型', '短整数型', '整数型', '长整数型', '小数型', '文本型', '字节集'];
  const out = [];
  const re = new RegExp('^[ \\t]*' + kw + '[ \\t]+(.+)$', 'gm');
  let m;
  const clean = stripCommentsText(text || '');
  while ((m = re.exec(clean))) {
    const parts = m[1].replace(/=.*/, '').replace(/\[.*$/, '').trim().split(/[\s,，]+/).filter(Boolean);
    if (parts.length >= 2) {
      const name = TYPE.indexOf(parts[0]) >= 0 ? parts[1] : parts[0];
      if (name) out.push(name);
    }
  }
  return out;
}

/* 语言关键字（自动补全 + 悬停提示用） */
const YY_KEYWORDS_AC = [
  '变量', '常量', '全局变量', '子程序', '测试函数', '导出子程序', '结束子程序',
  'API', '在库', '如果', '否则', '否则如果', '结束如果', '如果真', '结束如果真',
  '计次循环', '结束循环', '当循环', '判断循环首', '判断循环尾', '循环判断首', '循环判断尾',
  '跳出循环', '到循环尾', '返回', '参考', '传址', '程序入口', '真', '假', '且', '或', '非', '空',
  '数据类型', '结束数据类型', '类函数', '结束类函数',
  'asm', '结束asm',
].map((name) => ({ name, kind: '关键字' }));

/* 英文别名（自动补全用）：输入英文单词也能补出对应的中文关键字 / 数据类型 /
   常用命令 / 常量。补出的候选插入的仍是中文名（语言本身只认中文写法），
   英文只作为「查找入口」。匹配规则与原名一致：别名前缀命中即出候选。 */
const YY_EN_ALIAS = {
  // 流程控制 / 声明关键字
  'if': '如果', 'iftrue': '如果真', 'else': '否则', 'elseif': '否则如果', 'elif': '否则如果',
  'endif': '结束如果', 'switch': '判断', 'while': '判断循环首', 'dowhile': '循环判断首',
  'for': '计次循环首', 'foreach': '变量循环首', 'continue': '到循环尾', 'break': '跳出循环',
  'return': '返回', 'exit': '结束', 'end': '结束',
  'var': '变量', 'let': '变量', 'const': '常量', 'global': '全局变量',
  'func': '子程序', 'function': '子程序', 'sub': '子程序', 'def': '子程序',
  'test': '测试函数', 'export': '导出子程序', 'main': '程序入口',
  'struct': '数据类型', 'class': '数据类型', 'method': '类函数', 'api': 'API',
  'true': '真', 'false': '假', 'null': '空', 'void': '空', 'none': '空',
  'and': '且', 'or': '或', 'not': '非',
  // 数据类型
  'bool': '逻辑型', 'boolean': '逻辑型', 'byte': '字节型', 'short': '短整数型',
  'int': '整数型', 'integer': '整数型', 'long': '长整数型',
  'float': '小数型', 'double': '双精度小数型',
  'string': '文本型', 'str': '文本型', 'bytes': '字节集',
  'date': '日期时间型', 'datetime': '日期时间型',
  // 常用命令
  'print': '输出', 'echo': '输出', 'input': '输入文本', 'debug': '调试输出',
  'cls': '清屏', 'clear': '清屏', 'wait': '等待按键', 'sleep': '延时', 'delay': '延时',
  'abs': '取绝对值', 'floor': '向下取整', 'ceil': '向上取整', 'round': '四舍五入',
  'sqrt': '求平方根', 'pow': '求次方', 'random': '取随机数', 'rand': '取随机数',
  'max': '取最大值', 'min': '取最小值', 'now': '取现行时间',
  'year': '取年份', 'month': '取月份', 'day': '取日',
  'hour': '取小时', 'minute': '取分钟', 'second': '取秒',
  'len': '取文本长度', 'length': '取文本长度',
  'left': '取文本左边', 'right': '取文本右边', 'mid': '取文本中间', 'substr': '取文本中间',
  'find': '寻找文本', 'replace': '替换文本', 'split': '分割文本',
  'upper': '到大写', 'lower': '到小写', 'trim': '删首尾空',
  'msgbox': '信息框', 'inputbox': '输入框',
  'run': '运行', 'exec': '执行程序', 'read': '读入文件', 'write': '写到文件',
  'copy': '复制文件', 'mkdir': '创建目录', 'rmdir': '删除目录', 'exists': '文件是否存在',
  // 常量（「#」补全用）
  'black': '颜色_黑', 'white': '颜色_白', 'red': '颜色_红', 'green': '颜色_绿',
  'blue': '颜色_蓝', 'yellow': '颜色_黄', 'cyan': '颜色_青', 'purple': '颜色_紫',
};
/* 反向索引：中文名 → 英文别名串（逗号分隔，只建一次） */
const YY_EN_ALIAS_REV = {};
Object.keys(YY_EN_ALIAS).forEach((en) => {
  const cn = YY_EN_ALIAS[en];
  YY_EN_ALIAS_REV[cn] = YY_EN_ALIAS_REV[cn] ? YY_EN_ALIAS_REV[cn] + ',' + en : en;
});
/* 名称是否被英文前缀 p 经别名命中；命中返回那个别名（否则 null） */
function enAliasHit(name, p) {
  const al = YY_EN_ALIAS_REV[name];
  if (!al || !p) return null;
  return al.split(',').find((a) => a.startsWith(p)) || null;
}
/* 候选 sig 列的英文别名提示：命中别名显示命中的那个；否则显示首个别名（如有） */
function enAliasSig(name, hit) {
  const al = YY_EN_ALIAS_REV[name];
  if (!al) return '';
  return hit || al.split(',')[0];
}

/* 汇总候选：变量 / 全局变量 / 常量 / 子程序 / 测试函数 / API / 核心库命令
   匹配支持：原名前缀、拼音全拼、拼音首字母（不区分大小写） */
const PINYIN_DATA = '输shu 出chu 调tiao 试shi 入ru 文wen 本ben 整zheng 数shu 等deng 待dai 按an 键jian '
  + '清qing 屏ping 信xin 息xi 框kuang 到dao 长chang 短duan 逻luo 辑ji 字zi 节jie 值zhi '
  + '取qu 度du 左zuo 右you 中zhong 间jian 寻xun 找zhao 倒dao 换huan 替ti 子zi 分fen 段duan '
  + '大da 写xie 删shan 首shou 尾wei 空kong 白bai 重chong 复fu 比bi 较jiao 开kai 头tou '
  + '为wei 结jie 束shu 是shi 否fou 符fu 码ma 绝jue 对dui 号hao 序xu 向xiang 上shang 下xia '
  + '四si 舍she 五wu 求qiu 平ping 方fang 根gen 次ci 自zi 然ran 常chang 用yong 最zui '
  + '随sui 机ji 种zhong 余yu 圆yuan 周zhou 率lv 当dang 前qian 日ri 期qi 年nian 月yue '
  + '时shi 秒miao 星xing 启qi 动dong 延yan 毫hao 员yuan 组zu 加jia 排pai 反fan 转zhuan '
  + '除chu 制zhi 移yi 创chuang 建jian 列lie 表biao 读du 写xie 运yun 行xing 临lin 环huan '
  + '境jing 执zhi 命ming 令ling 幕mu 宽kuan 高gao 标biao 题ti 位wei 或huo 异yi 断duan '
  + '言yan 变bian 量liang 全quan 局ju 声sheng 明ming 定ding 义yi 类lei 型xing 参can '
  + '名ming 称cheng 返fan 回hui 弹tan 窗chuang 演yan 示shi 计ji 算suan 器qi 增zeng '
  + '改gai 查cha 显xian 藏cang 打da 关guan 闭bi 控kong 跳tiao 停ting 止zhi 完wan '
  + '成cheng 败bai 功gong 错cuo 误wu 帮bang 助zhu 设she 置zhi 应ying 接jie 口kou '
  + '单dan 别bie 退tui 检jian 测ce 角jiao 切qie 程cheng 台tai 果guo 那na 么me 循xun '
  + '判pan 真zhen 假jia 且qie 非fei 考kao 主zhu 能neng 游you 戏xi 图tu 形xing 界jie '
  + '面mian 布bu 存cun 储chu 据ju 库ku 连lian 服fu 务wu 客ke 户hu 处chu 理li 载zai '
  + '目mu 录lu 函han 则ze 如ru 集ji 类lei 型xing';
const PINYIN = {};
// ① 完整拼音表（常用汉字 GB2312，web/js/pinyin-data.js 生成）：
//    形如 "中zhong国guo…"，每个汉字后紧跟其无声调小写全拼
(function loadFullPinyin() {
  const s = (typeof window !== 'undefined' && window.YY_PINYIN_DATA) || '';
  let i = 0;
  while (i < s.length) {
    const ch = s[i++];
    let j = i;
    while (j < s.length && s[j] >= 'a' && s[j] <= 'z') j++;
    if (j > i) PINYIN[ch] = s.slice(i, j);
    i = j;
  }
})();
// ② 核心库专用读音（覆盖完整表，保证 重复=chongfu、长整数型=chang 等既有习惯）
PINYIN_DATA.split(' ').forEach((s) => { if (s) PINYIN[s[0]] = s.slice(1); });

const _pyCache = new Map();
/* 取名称的拼音全拼与首字母（供自动补全匹配）：
   - 汉字 → 全拼小写（无声调，ü 写 v）；
   - 英文字母 / 数字 → 原样小写；
   - '_' 与 '.'（如「类型.方法」）→ 跳过后继续拼接，使类函数也能按全拼/首字母补全；
   - 表外字符 → 跳过该字，不影响其余字符的拼音匹配。 */
function pinyinOf(name) {
  if (_pyCache.has(name)) return _pyCache.get(name);
  let full = '', ini = '';
  for (const ch of name) {
    const py = PINYIN[ch];
    if (py) { full += py; ini += py[0]; continue; }
    if (ch >= '0' && ch <= '9') { full += ch; ini += ch; continue; }
    if ((ch >= 'a' && ch <= 'z')) { full += ch; ini += ch; continue; }
    if (ch >= 'A' && ch <= 'Z') { const l = ch.toLowerCase(); full += l; ini += l; continue; }
    // '_' / '.' 等分隔符与表外字符：跳过（不阻断整体全拼/首字母匹配）
  }
  const r = { full, initials: ini };
  _pyCache.set(name, r);
  return r;
}

/* ---------- 侧栏搜索（核心 / 类 / API / 常量 / 函数 / Qt / sciter 七栏共用） ----------
   原来的搜索只做「原文子串」匹配，汉字条目必须打汉字才能找到。这里统一加上
   拼音匹配，两条都走**子串**（与原来的原文匹配一致，不要求从开头匹配）：
     · 全拼：  quzhengshu → 取整数；xinjian → 窗口.新建
     · 首字母：qzs        → 取整数；xj     → 新建
   · 关键词含非字母数字（中文、空格等）时只做原文匹配 —— 拼音串只可能是字母数字；
   · 原文里没有汉字时不必算拼音（那样的字符串原文匹配已经覆盖）。 */
function kwHitText(kw, text) {
  if (!kw) return true;
  kw = String(kw).toLowerCase();                  // 各栏传进来已是小写，这里再兜一层
  const s = String(text == null ? '' : text).toLowerCase();
  if (!s) return false;
  if (s.indexOf(kw) >= 0) return true;
  // 拼音串只由字母数字组成：把空格 / 下划线 / 连字符去掉，
  // 「xin jian」「xin_jian」与「xinjian」同样能命中「新建」
  const kp = String(kw).toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!kp) return false;                          // 中文关键词：只做原文匹配
  if (!/[\u3400-\u9fff]/.test(s)) return false;   // 原文没有汉字：原文已判过，不必算拼音
  const py = pinyinOf(s);
  return !!(py && ((py.full && py.full.indexOf(kp) >= 0)
    || (py.initials && py.initials.indexOf(kp) >= 0)));
}
/* 多个字段只要有一个命中就算命中（kw 为空一律命中，省得每处再写 !kw || …） */
function kwHit(kw) {
  for (let i = 1; i < arguments.length; i++) if (kwHitText(kw, arguments[i])) return true;
  return false;
}

/* ---------- 自定义数据类型：结构定义 / 变量类型 收集（供成员自动补全） ---------- */
const BASIC_TYPES = ['逻辑型', '字节型', '短整数型', '整数型', '长整数型', '小数型', '文本型', '字节集'];

function collectStructDefsOrdered(text) {
  /* 源码中的 数据类型...结束数据类型 →
     [{name, fields:[{name,type}], line, raw}]（按定义顺序；line 为 1 基行号；
      raw 为原始定义文本「数据类型 … 结束数据类型」，供「插入当前位置」用） */
  const out = [];
  const src = String(text == null ? '' : text).split('\n');   // 原始行（保留缩进）
  const rows = stripCommentsText(text || '').split('\n');     // 去注释（行结构不变，可与 src 对齐）
  const cut = (i) => String(src[i] == null ? '' : src[i]).replace(/\r$/, '');
  let cur = null;
  for (let i = 0; i < rows.length; i++) {
    const line = rows[i].trim();
    const head = /^数据类型\s+(\S+)$/.exec(line);
    if (head) {
      cur = { name: head[1], fields: [], line: i + 1, rawLines: [cut(i)] };
      out.push(cur);
      continue;
    }
    if (/^结束数据类型$/.test(line)) {
      if (cur) { cur.rawLines.push(cut(i)); cur.raw = cur.rawLines.join('\n'); }
      cur = null;
      continue;
    }
    if (cur) {
      cur.rawLines.push(cut(i));
      const fm = /^(\S+)\s+(\S+)/.exec(line);
      if (fm && BASIC_TYPES.indexOf(fm[1]) >= 0) {
        // 成员写法固定为「类型 名称」；带行号供「转到定义」用
        cur.fields.push({ name: fm[2], type: fm[1], line: i + 1 });
      }
    }
  }
  // 未闭合的块（缺 结束数据类型）：也给出手上已有的文本
  out.forEach((s) => { if (!s.raw) s.raw = (s.rawLines || []).join('\n'); });
  return out;
}

function collectStructDefs(text) {
  /* 源码中的 数据类型...结束数据类型 → { 类型名: [{name, type}, ...] }（同名以先出现者为准） */
  const map = {};
  collectStructDefsOrdered(text).forEach((s) => {
    if (!(s.name in map)) map[s.name] = s.fields;
  });
  return map;
}

function collectMethodDefs(text) {
  /* 源码中的类函数定义 → [{owner, name, args, ret, line, raw}]
     （line 为 1 基行号，同名以先出现者为准；raw 为整段原始定义
       「类函数 … 结束类函数」含函数体，供「类」选项卡双击插入整组定义用）
     兼容两种写法：
     ① 类函数 类型.函数(参数) [返回类型]   —— 标准写法（可带缩进）
     ② 类型.函数(参数) [返回类型]          —— 顶格简写，其后需跟 函数体 与 结束类函数 */
  const out = [];
  const seen = new Set();
  const src = String(text == null ? '' : text).split('\n');   // 原始行（保留缩进）
  const rows = stripCommentsText(text || '').split('\n');     // 去注释（行结构不变，与 src 对齐）
  const cut = (i) => String(src[i] == null ? '' : src[i]).replace(/\r$/, '');
  const rawOf = (a, b) => {                                   // 取 [a, b] 行的原始文本（b 含）
    const ls = [];
    for (let k = a; k <= b; k++) ls.push(cut(k));
    return ls.join('\n');
  };
  const TOP_HEAD = /^(全局变量|常量|数据类型|类函数|子程序|测试函数|导出子程序|API)(\s|$)/;
  const reKw = /^类函数\s+(\S+)\.(\S+)\s*\((.*)\)\s*(\S*)\s*$/;
  const reBare = /^([\w\u4e00-\u9fff]+)\.([\w\u4e00-\u9fff]+)\s*\((.*)\)\s*(\S*)\s*$/;
  const push = (owner, name, args, ret, line, raw) => {
    const key = owner + '.' + name;
    if (owner && name && !seen.has(key)) {
      seen.add(key);
      out.push({ owner, name, args: (args || '').trim(), ret: ret || '无', line,
                 raw: raw || '' });
    }
  };
  // 函数体结束行：遇到 结束类函数 取它，遇到其它顶层结构就停
  const endOfBlock = (from, limit) => {
    let end = from;
    for (let j = from + 1; j < rows.length && j <= from + limit; j++) {
      const ln = rows[j].trim();
      if (ln === '结束类函数') return j;
      if (TOP_HEAD.test(ln) || ln === '结束子程序' || ln === '结束数据类型') break;
    }
    return end;
  };
  for (let i = 0; i < rows.length; i++) {
    const raw = rows[i];
    const line = raw.trim();
    const head = reKw.exec(line);
    if (head) {                                          // ① 标准写法
      const end = endOfBlock(i, 400);
      push(head[1], head[2], head[3], head[4], i + 1, rawOf(i, end));
      continue;
    }
    if (!raw || raw.charAt(0) === ' ' || raw.charAt(0) === '\t') continue;   // ② 简写必须顶格
    const bare = reBare.exec(line);
    if (!bare || TOP_HEAD.test(line)) continue;
    // 顶格「类型.函数(...)」：向后找到 结束类函数 才视为定义；
    // 先遇到其它顶层结构（子程序 / 数据类型 / …）则视为普通调用语句
    for (let j = i + 1; j < rows.length && j <= i + 200; j++) {
      const ln = rows[j].trim();
      if (ln === '结束类函数') {
        push(bare[1], bare[2], bare[3], bare[4], i + 1, rawOf(i, j));
        break;
      }
      if (TOP_HEAD.test(ln) || ln === '结束子程序' || ln === '结束数据类型') break;
    }
  }
  return out;
}

/* 顶层的 常量 声明 → [{name, type, line}]
   兼容三种写法：常量 名称 = 值（类型省略，与编译器一致按值推断）/ 
   常量 名称 类型 = 值 / 常量 类型 名称 = 值（lib/*.class 用第一种） */
function collectLibConstDefs(text) {
  const out = [];
  const seen = new Set();
  stripCommentsText(text || '').split('\n').forEach((raw, i) => {
    const m = /^常量\s+(.+?)\s*=/.exec(raw.trim());
    if (!m) return;
    const parts = m[1].split(/[\s,，]+/).filter(Boolean);
    if (!parts.length) return;
    let name = parts[0];
    let type = parts[1] || '';
    if (parts.length >= 2 && BASIC_TYPES.indexOf(parts[0]) >= 0) {   // 类型在前的写法
      name = parts[1];
      type = parts[0];
    }
    if (!type) {                                                     // 按值推断类型
      const v = (raw.trim().split('=')[1] || '').trim();
      type = /^"/.test(v) || v.indexOf('「') === 0 ? '文本型'
        : (v === '真' || v === '假') ? '逻辑型'
          : /\./.test(v) ? '小数型' : '整数型';
    }
    if (name && !seen.has(name)) { seen.add(name); out.push({ name, type, line: i + 1 }); }
  });
  return out;
}

/* 常量值的十进制表示（lib/*.const 的新格式）：
   · 真→1、假→0；
   · 整数型 / 小数型 / 0x十六进制 / 科学计数法直接转 —— 科学计数法允许 e 前后带空格：
     1.23 e4 → 12300、1.23 e - 4 → 0.000123、1.23 e + 4 → 12300；
     指数过大上溢 → Infinity（列表显示 ∞），下溢 → 0；
   · 文本型（"…" 或 「…」）等非数值返回 null（列表里展示原文）。 */
function constDecValue(v) {
  let s = (v || '').trim();
  if (s === '真') return 1;
  if (s === '假') return 0;
  if (/^["「]/.test(s)) return null;                          // 文本常量：无十进制值
  s = s.replace(/\s+/g, '');                                  // 去掉全部空白（1.23 e - 4 → 1.23e-4）
  if (!/^[-+]?(0[xX][0-9a-fA-F]+|(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?)$/.test(s)) return null;
  const n = Number(s);
  return isNaN(n) ? null : n;
}

/* 十进制值的显示文本：∞ / -∞（上下溢）、普通数字、非数值为空串 */
function constDecTxt(dec) {
  if (dec === null || dec === undefined) return '';
  if (dec === Infinity) return '∞';
  if (dec === -Infinity) return '-∞';
  return String(dec);
}

/* lib/*.const 文件里的常量声明 → [{name, type, value, dec, line}]
   兼容新格式：行首可有缩进；写法为 常量 名称 = 值 / 常量 名称 类型 = 值 /
   常量 类型 名称 = 值（复用 collectLibConstDefs 的口径）；
   值支持 整数型 / 小数型 / 科学计数法（e 前后可带空格）/ 真 / 假 / 文本型；
   dec 为值的十进制表示（文本等非数值为 null）。 */
function collectConstFileDefs(text) {
  const stripped = stripCommentsText(text || '');
  return collectLibConstDefs(stripped).map((c) => {
    const raw = (stripped.split('\n')[c.line - 1] || '');
    const value = (raw.split('=').slice(1).join('=') || '').trim();
    return { name: c.name, type: c.type, value, dec: constDecValue(value), line: c.line };
  });
}

/* 本文件的 变量 / 全局变量 / 常量 声明 → [{kind, name, type, line}]
   兼容两种写法：变量 类型 名称 / 常量 名称 类型 = 值 */
function collectVarDecls(text) {
  const known = BASIC_TYPES.concat(Object.keys(collectTypeDefs(text)));
  const out = [];
  const re = /^(全局变量|常量|变量)\s+(.+)$/;
  stripCommentsText(text || '').split('\n').forEach((raw, i) => {
    const m = re.exec(raw.trim());
    if (!m) return;
    const rest = m[2].replace(/=.*/, '').replace(/\[.*$/, '').trim();
    const parts = rest.split(/[\s,，]+/).filter(Boolean);
    if (parts.length < 2) return;
    const typeFirst = known.indexOf(parts[0]) >= 0;
    out.push({
      kind: m[1],
      name: typeFirst ? parts[1] : parts[0],
      type: typeFirst ? parts[0] : parts[1],
      line: i + 1,
    });
  });
  return out;
}

/* 本文件声明的「变量 / 全局变量」名 + 各子程序的参数名 → Set（供编辑器给变量上色）
   参数写法：子程序 名(参数 整数型 a, 参数 文本型 b)，取每个逗号段最后一个 token 作为参数名。 */
function collectVarNames(text) {
  const set = new Set();
  collectVarDecls(text).forEach((v) => {
    if ((v.kind === '变量' || v.kind === '全局变量') && v.name) set.add(v.name);
  });
  parseSubs(text).forEach((s) => {
    (s.args || '').split(/[,，]/).forEach((seg) => {
      const cleaned = seg.replace(/=.*/, '').trim();
      const parts = cleaned.split(/\s+/).filter(Boolean);
      if (!parts.length) return;
      const last = parts[parts.length - 1];
      if (last && /^[A-Za-z_一-龥]/.test(last)) set.add(last);
    });
  });
  return set;
}

/* 本文件声明的「常量」名 → Set（供编辑器给自定义常量上色，颜色与核心常量一致） */
function collectConstNames(text) {
  const set = new Set();
  collectVarDecls(text).forEach((v) => {
    if (v.kind === '常量' && v.name) set.add(v.name);
  });
  return set;
}

/* 本文件的 数据类型 定义 → { 类型名: {line, fields:[{name,type,line}]} }
   （collectStructDefs 不含行号，这里额外给出定义行与成员行，供「转到定义」用） */
function collectTypeDefs(text) {
  const map = {};
  let cur = null;
  stripCommentsText(text || '').split('\n').forEach((raw, i) => {
    const line = raw.trim();
    const head = /^数据类型\s+(\S+)/.exec(line);
    if (head) { cur = head[1]; map[cur] = { line: i + 1, fields: [] }; return; }
    if (/^结束数据类型/.test(line)) { cur = null; return; }
    if (!cur) return;
    const fm = /^(\S+)\s+([^\s=]+)/.exec(line);
    if (fm && BASIC_TYPES.indexOf(fm[1]) >= 0) {
      map[cur].fields.push({ name: fm[2], type: fm[1], line: i + 1 });   // 成员写法：类型 名称
    }
  });
  return map;
}

function collectVarTypes(text, structs) {
  /* 变量/全局变量/常量 声明 → { 变量名: 类型 }（兼容「名称 类型」与「类型 名称」写法） */
  const known = BASIC_TYPES.concat(Object.keys(structs || {}));
  const map = {};
  const re = /^(全局变量|常量|变量)\s+(.+)$/;
  for (const raw of stripCommentsText(text || '').split('\n')) {
    const m = re.exec(raw.trim());
    if (!m) continue;
    const rest = m[2].replace(/=.*/, '').replace(/\[.*$/, '').trim();
    const parts = rest.split(/[\s,，]+/).filter(Boolean);
    if (parts.length < 2) continue;
    if (known.indexOf(parts[0]) >= 0) map[parts[1]] = parts[0];
    else map[parts[0]] = parts[1];
  }
  return map;
}

function memberItems(fields, prefix, methods) {
  /* 数据类型成员候选：字段 + 类函数，按前缀 / 拼音过滤 */
  const p = prefix.toLowerCase();
  const items = [];
  const hit = (name) => {
    const nm = name.toLowerCase();
    const py = pinyinOf(name);
    return !p || nm.startsWith(p)
      || (py.full && py.full.startsWith(p))
      || (py.initials && py.initials.startsWith(p));
  };
  (fields || []).forEach((f) => {
    if (hit(f.name)) items.push({ name: f.name, kind: '成员', sig: f.type, insert: f.name });
  });
  (methods || []).forEach((m) => {
    if (hit(m.name)) {
      // 类函数：括号里按参数个数铺好逗号分隔符
      items.push({ name: m.name, kind: '类函数', sig: m.args || '', insert: acCallInsert(m.name, m.args) });
    }
  });
  return items.slice(0, 30);
}

/* ---------- 自动完成符号表（核心库命令 / 类函数命令 / 工程文件） ----------
   载入以上三类数据时，逐项检测其中的
   函数、变量、常量、数据类型、自定义数据类型 是否已登记，未登记则加入；
   collectCompletions 统一从这里取用（acEnsure 按名称去重）。 */
function acReset() {
  S.acIndex = {};
  S.acList = [];
}

function acHas(name) {
  return Object.prototype.hasOwnProperty.call(S.acIndex, name);
}

/* 参数个数：按逗号切分签名（云易里参数写成「类型 名, 类型 名」；全角「，」同样算分隔）。
   空签名 = 0 个参数；末尾的「… / ...」是可变参数标记（如核心库 输出 的「内容1, 内容2, …」），
   不算一个参数位。 */
function acArgCount(sig) {
  const s = (sig || '').replace(/，/g, ',').trim();
  if (!s) return 0;
  return s.split(',').map((x) => x.trim())
    .filter((x) => x && x !== '…' && x !== '...').length;
}

/* 调用式补全的插入文本：按参数个数在括号里铺好逗号分隔符（n 个参数 → n-1 个逗号）：
   0/1 个参数 → 名称()；2 个 → 名称(,)；3 个 → 名称(,,)。光标随后落在第一个参数处。 */
function acCallInsert(name, sig) {
  const n = acArgCount(sig);
  return name + '(' + (n > 1 ? ','.repeat(n - 1) : '') + ')';
}

/* 插入文本里「第一个参数」的偏移（光标落点）；不是「(…)」形式则返回 -1 */
function acCallCaretOffset(text) {
  const lp = (text || '').lastIndexOf('(');
  return (lp >= 0 && text.endsWith(')')) ? lp + 1 : -1;
}

function acEnsure(name, kind, sig, withCall) {
  if (!name || acHas(name)) return false;      // 已登记 → 不重复添加
  const it = { name, kind, sig: sig || '', insert: withCall ? acCallInsert(name, sig) : name };
  S.acIndex[name] = it;
  S.acList.push(it);
  return true;
}

/* 枚举到一个类函数时：检测「所属类型 + 类函数」是否已登记，未登记则加入自动完成 */
function acEnsureClassMethod(m, from) {
  if (!m || !m.owner || !m.name) return;
  acEnsure(m.owner, '自定义数据类型', from || '', false);      // 所属自定义数据类型
  acEnsure(m.owner + '.' + m.name, '类函数', m.args, true);   // 类函数（类型.方法()）
}

/* 「类」选项卡双击插入前：再检查一次该「类函数」是否已登记到自动完成，没有则补上。
   返回本次是否新增（用于提示）。 */
function acEnsureLibMethod(owner, name, args) {
  if (!owner || !name) return false;
  let added = acEnsure(owner, '自定义数据类型', '类库', false);
  if (acEnsure(owner + '.' + name, '类函数', args || '', true)) added = true;
  return added;
}

/* 「类」选项卡双击插入前：再检查一次该「数据类型」及其成员是否已登记到自动完成，没有则补上。
   返回本次是否新增（用于提示）。 */
function acEnsureLibType(owner, fields) {
  if (!owner) return false;
  let added = acEnsure(owner, '自定义数据类型', '类库', false);
  (fields || []).forEach((f) => {
    if (acEnsure(owner + '.' + f.name, '变量', f.type || '', false)) added = true;
  });
  return added;
}

/* 「API」栏：双击 API 声明条目 → 把声明原文插入代码编辑框（本文件已有则只提示）。
   说明：不插入也能直接调用 —— 编译时会把 lib/*.api 里的 API 声明自动引入；
   插进来主要是为了查看 / 改成别的 DLL 或函数名。 */
function insertLibApiDecl(el) {
  const name = el.dataset.name || '';
  const dll = el.dataset.dll || '';
  const decl = (el.dataset.raw || '').trim()
    || ('API 整数型 ' + name + '() 在库 "' + dll + '"');
  withEditableTab((t) => {
    const exist = collectApiDecls(t.content || '').find((a) => a.name === name);
    if (exist) {
      toast('当前文件第 ' + (exist.line || '?') + ' 行已有 API 声明：' + name
        + '，未重复插入（编译时也会自动引入类库里的声明）', 4600);
      return;
    }
    acEnsure(name, 'API 声明', '在库 ' + dll, true);   // 登记到自动完成（输入时能补全）
    insertAtCursor(decl, { block: true });            // 整行插入（光标停在行中间也不会劈开该行）
    toast('已插入 API 声明：' + name + '（在库 ' + dll + '）；'
      + '不插入也能直接调用 —— 编译时会自动引入', 4600);
  });
}

/* ---------- 「类」/「函数」选项卡：把本文件缺少的「数据类型 + 类函数」定义补进编辑器 ---------- */
/* lib/*.class 里某数据类型的定义原文 / 成员表 / 某类函数的定义原文（找不到给空） */
function libStructRaw(owner) {
  const d = ((S.libClass && S.libClass.defs) || [])
    .find((x) => x.kind === '类型' && x.owner === owner);
  return (d && d.raw) || '';
}

function libFields(owner) {
  return ((S.libClass && S.libClass.structs) || {})[owner] || [];
}

function libMethodRaw(owner, name) {
  const m = ((S.libClass && S.libClass.methods) || [])
    .find((x) => x.owner === owner && x.name === name);
  return (m && m.raw) || '';
}

/* 类函数名不能是「保留字 / 内置命令名 / 基本类型名」：
   编译器会报「类函数名 'X' 是保留字/内置函数名，不能使用」
   （例如 类函数 信息.输出 不合法 ——「输出」是核心库命令） */
function isReservedMethodName(name) {
  if (!name) return false;
  if (BASIC_TYPES.indexOf(name) >= 0) return true;
  if (YY_KEYWORDS_AC.some((k) => k.name === name)) return true;
  return (S.corelib.cmds || []).some((c) => c.name === name);
}

/* 插入类函数时的警告：名字被内置命令/保留字占用 → 编译必报错，提示改名 */
function warnReservedMethodName(owner, name) {
  if (!isReservedMethodName(name)) return false;
  toast('注意：类函数名「' + name + '」是内置命令名或保留字，编译会报「类函数名 ' + name
    + ' 是保留字」；建议改名为「' + owner + '.提示」这类没被占用的名字'
    + '（可在「函数」选项卡里右键该条目 → 重命名，调用处会一起改）', 8000);
  return true;
}

/* 把 owner 这一组「数据类型定义 + 类函数定义」中**当前文件里缺少的**插入编辑器光标处。
    g = { raw, fields, methods: [{name, args, raw}] }
    ——「类」选项卡传类库里的定义文本，「函数」选项卡传本文件/类库的定义文本。
    说明：不插入也能直接调用——编译时会自动引入类库定义；
    这里是「想把定义复制进本文件查看/修改」的高级用法。已在文件里的不重复插。 */
function insertMissingClassDefs(owner, g) {
  if (!owner || !g) return;
  withEditableTab((t) => {
    const text = t.content || '';
    const declared = !!collectStructDefs(text)[owner];
    const defd = new Set(collectMethodDefs(text)
      .filter((m) => m.owner === owner).map((m) => m.name));
    const methods = g.methods || [];
    const parts = [];
    const missing = [];
    if (!declared && (g.raw || methods.length)) {
      // 先补「数据类型 X」声明：类库/文件里有原文就用原文；
      // 都没有（例如 lib/test.class 的 信息 只给了类函数）就补一个**空数据类型**当命名空间 ——
      // 否则「类函数 X.方法」会编译报「数据类型 'X' 未定义」
      parts.push(g.raw || ('数据类型 ' + owner + '\n结束数据类型'));
      acEnsureLibType(owner, g.fields);
      missing.push('数据类型 ' + owner + (g.raw ? '' : '（空数据类型·命名空间）'));
    }
    methods.forEach((m) => {
      if (defd.has(m.name) || !m.raw) return;
      parts.push(m.raw);
      acEnsureLibMethod(owner, m.name, m.args);
      missing.push('类函数 ' + owner + '.' + m.name);
    });
    // 名字被内置命令/保留字占用的类函数：编译必报错，插入时一并提醒
    const bad = methods.filter((m) => isReservedMethodName(m.name)).map((m) => m.name);
    const badTip = bad.length
      ? '；注意：类函数名「' + bad.join('、') + '」是内置命令名或保留字，编译会报错，'
        + '建议右键改名（如 ' + owner + '.提示）'
      : '';
    if (!parts.length) {
      toast('「' + owner + '」的数据类型与 ' + methods.length + ' 个类函数都已在当前文件中，无需重复插入' + badTip,
        bad.length ? 8000 : 2600);
      return;
    }
    toast('已把定义复制进当前文件（' + missing.length + ' 项：' + missing.join('、')
      + '）；不复制也可直接调用，编译时会自动引入类库定义' + badTip,
      bad.length ? 8000 : 4200);
    // 多行块：整段落到当前行下方（不会把光标所在的那行代码劈开）
    insertAtCursor(parts.join('\n\n'), { block: true });
  });
}

/* ---------- 未定义的类函数调用（类函数定义被删掉后的引用处理） ---------- */
/* 标识符字符集（中英文 / 数字 / 下划线）；不带方括号，便于拼进 [^…] 与 […] */
const _WCH = 'A-Za-z0-9_\\u4e00-\\u9fff';

/* 一行里字符串（"…"）占用的区间：算调用时跳过，避免把 输出("类型.方法(") 里的内容误当成调用 */
function strSpansOfLine(line) {
  const out = [];
  let i = 0;
  while (i < line.length) {
    const a = line.indexOf('"', i);
    if (a < 0) break;
    const b = line.indexOf('"', a + 1);
    if (b < 0) { out.push([a, line.length]); break; }
    out.push([a, b + 1]);
    i = b + 1;
  }
  return out;
}

/* 类库里是否有该类函数（类型.方法）：有 → 工程里直接调用即可，
   编译（运行/编译/测试/发布）时会自动引入定义，不算「未定义」 */
function libHasKey(key) {
  return ((S.libClass && S.libClass.methods) || []).some((m) => m.owner + '.' + m.name === key);
}

/* 本文件里用到的「类库类函数」调用 → [{owner, name, key, line, col, from, to}]
   （from / to 为**全文绝对下标**（to 指向 '('），供配对括号、删除调用用；
     col 为行内 1 基列号，供提示显示。
     只认 lib/*.class 里确实存在的「类型.方法」，避免把 变量.成员 等误判；
     本文件已定义对应「类函数」的不算。）
   跳过 // 行注释、/* *\/ 块注释与字符串内容 */
function libCallsIn(text) {
  const out = [];
  const libMs = (S.libClass && S.libClass.methods) || [];
  if (!libMs.length) return out;
  const keys = new Set(libMs.map((m) => m.owner + '.' + m.name));
  const defs = new Set(collectMethodDefs(text).map((m) => m.owner + '.' + m.name));
  const re = new RegExp('(^|[^' + _WCH + '$.])([' + _WCH + ']+)\\.([' + _WCH + ']+)[ \\t]*\\(', 'g');
  const rows = String(text == null ? '' : text).split('\n');
  let inBlock = false;                                  // 是否处在跨行块注释里
  let lineStart = 0;                                    // 本行首字符在全文中的下标
  rows.forEach((rawLine, i) => {
    const base = lineStart;
    lineStart = base + rawLine.length + 1;               // 换行符占 1（内容已统一为 LF）
    let line = rawLine;
    if (inBlock) {                                      // 收尾行：把注释部分换成空格（列号不变），后半行照常扫描
      const e0 = line.indexOf('*/');
      if (e0 < 0) return;
      inBlock = false;
      line = line.slice(0, e0 + 2).replace(/[^\s]/g, ' ') + line.slice(e0 + 2);
    }
    const chars = line.split('');
    let inStr = false, cut = line.length;
    for (let j = 0; j < line.length; j++) {
      const c = line.charAt(j);
      if (inStr) { if (c === '"') inStr = false; continue; }
      if (c === '"') { inStr = true; continue; }
      if (c === '/' && line.charAt(j + 1) === '/') { cut = j; break; }        // 行注释：截断
      if (c === '/' && line.charAt(j + 1) === '*') {                          // 块注释
        const e1 = line.indexOf('*/', j + 2);
        if (e1 < 0) { cut = j; inBlock = true; break; }                       // 未闭合 → 后续行都在注释里
        for (let k = j; k <= e1 + 1; k++) chars[k] = ' ';                     // 同行闭合 → 换成空格
        j = e1 + 1;
      }
    }
    const code = chars.join('').slice(0, cut);
    const spans = strSpansOfLine(code);
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(code))) {
      const from = m.index + m[1].length;
      const key = m[2] + '.' + m[3];
      if (!keys.has(key) || defs.has(key)) continue;
      if (spans.some((sp) => from >= sp[0] && from < sp[1])) continue;
      out.push({ owner: m[2], name: m[3], key, line: i + 1, col: from + 1,
                 from: base + from, to: base + m.index + m[0].length - 1 });
    }
  });
  return out;
}

/* 一个文件里的「类函数定义」与「类库类函数调用」（供工程级检查用） */
function fileClassFacts(text) {
  const s = String(text == null ? '' : text);
  return {
    defs: new Set(collectMethodDefs(s).map((m) => m.owner + '.' + m.name)),
    calls: libCallsIn(s).map((c) => ({ key: c.key, owner: c.owner, name: c.name, line: c.line })),
  };
}

/* 扫描工程内所有 .yy 文件 → { byFile: { 路径: {defs, calls} } }
   （已打开的标签用编辑器里的实时内容，其余按需读取；force=true 强制重扫） */
async function scanProjMethodDefs(force) {
  const st = S.projDefs || (S.projDefs = { byFile: null, loading: null });
  if (st.byFile && !force) return st.byFile;
  if (st.loading && !force) return st.loading;
  st.loading = (async () => {
    const byFile = {};
    let rels = [];
    try { rels = projectYyPaths(); } catch (e) { rels = []; }
    for (const rel of rels) {
      const tab = S.tabs.find((x) => x.project === S.project && x.path === rel);
      let text = null;
      if (tab) text = tab.content || '';
      else {
        try {
          const d = await api('GET', '/api/file?project=' + encodeURIComponent(S.project)
            + '&path=' + encodeURIComponent(rel));
          if (!d.binary) text = d.text || '';
        } catch (e) { text = null; }
      }
      byFile[rel] = (text == null) ? null : fileClassFacts(text);
    }
    st.byFile = byFile;
    st.loading = null;
    return byFile;
  })();
  return st.loading;
}

/* 用编辑器里的实时内容更新某文件在工程快照里的条目（不读盘） */
function updateProjDefsForTab(t) {
  const st = S.projDefs;
  if (!st || !st.byFile || !t || t.kind !== 'yy') return;
  if (!(t.path in st.byFile)) return;
  st.byFile[t.path] = fileClassFacts(t.content || '');
}

/* 工程内「已定义的类函数」合集（不含 activePath 的快照条目，改用编辑器里的实时内容） */
function projMethodDefsUnion(activePath) {
  const out = new Set();
  const st = S.projDefs;
  if (st && st.byFile) {
    Object.keys(st.byFile).forEach((p) => {
      const f = st.byFile[p];
      if (!f || p === activePath) return;
      f.defs.forEach((k) => out.add(k));
    });
  }
  const t = activeTab();
  if (t && t.kind === 'yy' && (!activePath || t.path === activePath)) {
    collectMethodDefs(t.content || '').forEach((m) => out.add(m.owner + '.' + m.name));
  }
  return out;
}

/* 用当前快照重算「工程内未定义的类函数调用」→ S.undefHits（不读盘） */
function recomputeUndefHits() {
  const st = S.projDefs;
  S.undefHits = [];
  if (!st || !st.byFile) return S.undefHits;
  const union = new Set();
  Object.keys(st.byFile).forEach((p) => {
    const f = st.byFile[p];
    if (f) f.defs.forEach((k) => union.add(k));
  });
  Object.keys(st.byFile).forEach((p) => {
    const f = st.byFile[p];
    if (!f) return;
    f.calls.forEach((c) => {
      // 类库里有的类函数：编译时自动引入定义，不再算未定义
      if (!union.has(c.key) && !libHasKey(c.key)) {
        S.undefHits.push({ file: p, line: c.line, key: c.key, owner: c.owner, name: c.name });
      }
    });
  });
  return S.undefHits;
}

/* 重新计算某标签的「未定义类函数调用」→ t.undefCalls
    （判据是**整个工程**里有没有定义：工程或类库里定义了就算已定义——
    类库里的会在编译时自动引入，无需手动复制）；
    「问题」面板开着时同步刷新 */
function refreshUndefCalls(t) {
  if (!t || t.kind !== 'yy') { if (t) t.undefCalls = []; return []; }
  const st = S.projDefs;
  if (!st || !st.byFile) return t.undefCalls || [];      // 还没扫过工程 → 暂不判断（避免误报）
  const defs = projMethodDefsUnion(t.path);
  t.undefCalls = libCallsIn(t.content || '').filter((c) => !defs.has(c.key) && !libHasKey(c.key));
  if (S.consoleTab === 'problems') renderProblems();
  return t.undefCalls;
}

/* 本工程其它 .yy 文件里是否还定义着该类函数（多文件工程时避免误报） */
async function defDefinedElsewhere(key, selfPath) {
  if (!S.project) return false;
  try { await scanProjMethodDefs(false); } catch (e) { return false; }
  return projMethodDefsUnion(selfPath).has(key);
}

/* 记录当前文件的「类函数定义」快照（供删除检测对比） */
function snapMethodDefs(t) {
  t._fnSnap = new Set(collectMethodDefs(t.content || '').map((m) => m.owner + '.' + m.name));
}

/* 「类函数定义被删除」检测：与上一次快照对比，被删掉的定义若本文件还有调用，
   就标为未定义并在「问题」面板提示（同一项只提示一次） */
async function checkDeletedDefs(t) {
  if (!t || t.kind !== 'yy' || t.readonly || t.gen) return;
  const now = new Set(collectMethodDefs(t.content || '').map((m) => m.owner + '.' + m.name));
  const prev = t._fnSnap;
  t._fnSnap = now;
  if (!prev || !prev.size) return;                     // 首次分析：只记快照
  const gone = [];
  prev.forEach((k) => { if (!now.has(k)) gone.push(k); });
  if (!gone.length) return;
  const asked = t._undefAsked || (t._undefAsked = new Set());
  const fresh = [];                                    // 本次新发现「定义已删但仍被调用」的类函数
  for (const k of gone) {
    if (libHasKey(k)) continue;                         // 类库里有：编译时自动引入，删除本地副本无妨
    const calls = libCallsIn(t.content || '').filter((c) => c.key === k);
    if (!calls.length) continue;                       // 定义和调用都没了 → 不必提示
    if (await defDefinedElsewhere(k, t.path)) continue;         // 别的文件还定义着 → 不算删除
    if (asked.has(k)) continue;
    asked.add(k);
    fresh.push(k + '（第 ' + calls.map((c) => c.line).join('、') + ' 行还有 ' + calls.length + ' 处调用）');
  }
  refreshUndefCalls(t);
  if (fresh.length) {
    toast('类函数定义已被删除：' + fresh.join('；')
      + ' —— 已在「问题」面板标为未定义；双击「类」选项卡对应条目可补回定义，或右键调用处删除调用', 7200);
  }
}

/* 载入工程后：扫描全部 .yy 文件，报告「调用了、但整个工程和类库里都没有定义」的类库类函数。
    （类库里有的：编译时会自动引入定义，可直接调用，不算问题。）
    结果写入 S.undefHits（「问题」选项卡列出），并刷新当前文件的未定义标记。 */
async function checkProjectClassDefs() {
  if (!S.project) return [];
  S.projDefs = null;                                   // 工程刚载入：强制重扫
  try { await loadLibClasses(); } catch (e) { /* 类库读不到就不做这项检查 */ }
  try { await scanProjMethodDefs(true); } catch (e) { return []; }
  const hits = recomputeUndefHits();
  const t = activeTab();
  if (t) refreshUndefCalls(t);
  if (S.consoleTab === 'problems') renderProblems();
  if (hits.length) {
    const files = new Set(hits.map((h) => h.file));
    toast('工程载入检查：' + hits.length + ' 处调用了未定义的类函数（分布在 ' + files.size
      + ' 个文件）—— 已在「问题」选项卡列出；请检查名称是否写错（类库里也没有该类函数）', 8600);
  }
  return hits;
}

/* 从 '(' 位置向后配对括号 → 对应 ')' 的下标；跨行或找不到时返回 -1 */
function matchParenAt(text, open) {
  if (text.charAt(open) !== '(') return -1;
  let depth = 0, inStr = false;
  for (let i = open; i < text.length; i++) {
    const c = text.charAt(i);
    if (inStr) { if (c === '"') inStr = false; continue; }
    if (c === '"') { inStr = true; continue; }
    if (c === '\n') { if (depth === 1) return -1; continue; }   // 跨行调用不处理（避免误删）
    if (c === '(') depth++;
    else if (c === ')') { depth--; if (depth === 0) return i; }
  }
  return -1;
}

/* 删除本文件里指定类函数的全部调用（连括号一起；该行只剩这段调用时整行删除）。
   返回删除的处数。 */
function removeCallsOfKey(t, key) {
  let text = t.content || '';
  const calls = libCallsIn(text).filter((c) => c.key === key).sort((a, b) => b.from - a.from);
  if (!calls.length) return 0;
  let n = 0;
  calls.forEach((c) => {
    const close = matchParenAt(text, c.to);            // c.to 指向 '('
    if (close < 0) return;
    let a = c.from, b = close + 1;
    const ls = text.lastIndexOf('\n', a - 1) + 1;
    let le = text.indexOf('\n', b);
    if (le < 0) le = text.length;
    if (text.slice(ls, a).trim() === '' && text.slice(b, le).trim() === '') {
      a = ls;                                          // 整行只剩这段调用 → 连行一起删
      b = (le < text.length) ? le + 1 : le;
    }
    text = text.slice(0, a) + text.slice(b);
    n++;
  });
  if (!n) return 0;
  t.content = text;
  t.dirty = true;
  const ta = $('codeInput');
  if (ta && !t.readonly && !t.gen) {
    const caret = Math.min(ta.selectionStart, text.length);
    ta.value = text;
    ta.setSelectionRange(caret, caret);
  }
  histPush(t, true);
  renderTabs();
  drawOverlay(t);
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => saveFile(t), 900);
  updateProjDefsForTab(t);
  recomputeUndefHits();
  refreshUndefCalls(t);
  return n;
}

/* 按 lib 类库里的定义，把「数据类型 类型 + 类函数 类型.方法」补到编辑器（缺的才补） */
function insertDefForCall(u) {
  const lc = S.libClass || {};
  const td = (lc.defs || []).find((d) => d.kind === '类型' && d.owner === u.owner);
  const md = (lc.methods || []).find((m) => m.owner === u.owner && m.name === u.name);
  withEditableTab((t) => {
    const text = t.content || '';
    const parts = [];
    const missing = [];
    if (!collectStructDefs(text)[u.owner] && (td || md)) {
      const raw = (td && td.raw) || '';
      // 类库里有数据类型原文就用原文；只有类函数（如 信息）就补空数据类型（命名空间）
      parts.push(raw || ('数据类型 ' + u.owner + '\n结束数据类型'));
      acEnsureLibType(u.owner, (td && td.fields) || libFields(u.owner));
      missing.push('数据类型 ' + u.owner + (raw ? '' : '（空数据类型·命名空间）'));
    }
    if (md && md.raw
      && !collectMethodDefs(text).some((m) => m.owner === u.owner && m.name === u.name)) {
      parts.push(md.raw);
      missing.push('类函数 ' + u.key);
    }
    if (!parts.length) { toast('本文件已经有「' + u.key + '」的定义'); return; }
    acEnsureLibMethod(u.owner, u.name, md ? md.args : '');
    toast('已把定义复制进本文件：' + missing.join('、')
      + '（不复制也可直接调用，编译时会自动引入类库定义）', 4200);
    insertAtCursor(parts.join('\n\n'), { block: true });
  });
}

/* 内置数据类型（逻辑型 / 整数型 / 文本型 …）→ 符号表 */
function acRegisterBuiltins() {
  BASIC_TYPES.forEach((n) => acEnsure(n, '数据类型', '内置', false));
}

/* 核心库命令 → 符号表（函数）+ 内置数据类型（常量除外：只有输入「#」才弹常量）
   「数据类型」条目（逻辑型 / 整数型 / 双精度小数型 / 子程序指针 …）按**类型**登记：
   不带括号 —— 补出来的就是类型名本身，不是函数调用。 */
function acRegisterCorelib() {
  (S.corelib.cmds || []).forEach((c) => {
    if (c.form === '常量') return;
    if (c.form === '类型') { acEnsure(c.name, '数据类型', c.args, false); return; }
    acEnsure(c.name, '核心库', c.args, true);
  });
}

/* lib/*.class 类库 → 符号表：
   自定义数据类型 / 成员变量 / 类函数命令 */
function acRegisterLibClasses() {
  const lc = S.libClass;
  if (!lc) return;
  // 按 lib/*.class 的定义顺序登记（acList 顺序 = 登记顺序）：
  // 数据类型（含成员）→ 类函数 → 常量 → 子程序 → API 声明，谁先定义谁先登记
  (lc.defs || []).forEach((d) => {
    if (d.kind === '类型') {
      acEnsure(d.owner, '自定义数据类型', '类库', false);
      (d.fields || []).forEach((f) => acEnsure(d.owner + '.' + f.name, '变量', f.type, false));
    } else if (d.kind === '类函数') {
      acEnsureClassMethod(d, '类库');
    } else if (d.kind === '常量') {
      // 常量不进普通补全（输入「#」才弹常量，见 constItems），只存 lc.consts
    } else if (d.kind === '子程序') {
      acEnsure(d.name, d.subKind || '子程序', d.args || '', true);
    } else if (d.kind === 'API') {
      acEnsure(d.name, 'API 声明', '在库 ' + (d.dll || ''), true);
    }
  });
}

/* 从一段源码解析可补全符号 [{name,kind,sig,withCall}]
   覆盖：函数（子程序 / 测试函数 / 类函数 / API）、
   变量（变量 / 全局变量）、常量、自定义数据类型 */
function acTextEntries(text) {
  const out = [];
  const add = (name, kind, sig, withCall) => {
    if (name) out.push({ name, kind, sig: sig || '', withCall: !!withCall });
  };
  const structs = collectStructDefs(text);
  const types = BASIC_TYPES.concat(Object.keys(structs));
  const varTypes = collectVarTypes(text, structs);
  // 变量 / 全局变量（常量不登记：只有输入「#」才弹常量）
  ['变量', '全局变量'].forEach((kw) => {
    collectNames(text, kw, types).forEach((n) => add(n, kw, varTypes[n] || '', false));
  });
  // 函数：子程序 / 测试函数
  parseSubs(text).forEach((s) => add(s.name, s.kind, s.args, true));
  // 函数：Windows API 声明
  const apis = apiDeclMap(text);
  Object.keys(apis).forEach((n) => add(n, 'API', apis[n].args, true));
  // 自定义数据类型 + 类函数（所属类型名一并登记）
  Object.keys(structs).forEach((n) => add(n, '自定义数据类型', '', false));
  // 数据类型成员（owner.成员，供其它文件输入「类名.」后的成员补全用）
  Object.keys(structs).forEach((n) => {
    (structs[n] || []).forEach((f) => add(n + '.' + f.name, '成员', f.type, false));
  });
  collectMethodDefs(text).forEach((m) => {
    add(m.owner, '自定义数据类型', '本工程', false);
    add(m.owner + '.' + m.name, '类函数', m.args, true);
  });
  return out;
}

/* 工程内所有 .yy 文件（优先用文件树，退回工程配置 sources） */
function projectYyPaths() {
  const out = [];
  const walk = (nodes) => (nodes || []).forEach((n) => {
    if (n.dir) walk(n.children);
    else if (/\.yy$/i.test(n.path)) out.push(n.path);
  });
  walk(S.tree);
  if (!out.length) ((S.cfg && S.cfg.sources) || []).forEach((s) => { if (/\.yy$/i.test(s)) out.push(s); });
  return out;
}

/* 载入工程文件：解析其中的函数 / 变量 / 常量等并登记到符号表 */
async function acRegisterProjectSources() {
  const files = projectYyPaths();
  const entries = [];
  const seen = new Set();
  for (const rel of files) {
    let text = null;
    const tab = S.tabs.find((t) => t.project === S.project && t.path === rel);
    if (tab) text = tab.content;                    // 已打开：用内存中的最新内容
    else {
      try {
        const d = await api('GET', '/api/file?project='
          + encodeURIComponent(S.project) + '&path=' + encodeURIComponent(rel));
        if (!d.binary) text = d.text;
      } catch (e) { continue; }
    }
    if (text == null) continue;
    acTextEntries(text).forEach((e) => {
      if (seen.has(e.name)) return;
      seen.add(e.name);
      entries.push(e);
    });
  }
  S.acProjectEntries = entries;
  acRebuild();
}

/* 重建符号表：内置数据类型 + 核心库 + 类库 + 工程文件（顺序登记，acEnsure 自动去重） */
function acRebuild() {
  acReset();
  acRegisterBuiltins();
  acRegisterCorelib();
  acRegisterLibClasses();
  (S.acProjectEntries || []).forEach((e) => acEnsure(e.name, e.kind, e.sig, e.withCall));
}

/* 工程其它 .yy 文件里定义的类函数与数据类型成员（结构化）：
   来自工程符号表登记（acRegisterProjectSources，见 acTextEntries 的类函数/成员条目），
   供「.」后的成员补全合并使用——多文件工程里其它文件的定义也能补出来 */
function projMethodEntries() {
  const methods = [];
  const fields = [];
  ((S.acProjectEntries) || []).forEach((e) => {
    const i = e.name.indexOf('.');
    if (i <= 0) return;
    const owner = e.name.slice(0, i);
    const name = e.name.slice(i + 1);
    if (e.kind === '类函数') methods.push({ owner, name, args: e.sig || '' });
    else if (e.kind === '成员') fields.push({ owner, name, type: e.sig || '' });
  });
  return { methods, fields };
}

/* 「#」后的常量候选：核心库常量 + 当前文件定义的常量（只弹常量，不弹别的） */
function constItems(prefix, t) {
  const p = prefix.toLowerCase();
  const seen = new Set();
  const items = [];
  const add = (name, kind) => {
    if (!name || seen.has(name)) return;
    const py = pinyinOf(name);
    const al = enAliasHit(name, p);          // 英文别名命中（如 red → 颜色_红）
    if (!(name.toLowerCase().startsWith(p) || al
      || (py.full && py.full.startsWith(p))
      || (py.initials && py.initials.startsWith(p)))) return;
    seen.add(name);
    items.push({ name, kind, sig: enAliasSig(name, al), insert: name });   // 「#」已由用户输入，只补名称
  };
  (S.corelib.cmds || []).forEach((c) => {
    if (c.form === '常量') add(c.name, '核心常量');
  });
  // 类库常量（lib/*.class 里的 常量 声明，如 core.class 的 常量1）
  ((S.libClass && S.libClass.consts) || []).forEach((c) => add(c.name, '类库常量'));
  collectNames(t.content, '常量').forEach((n) => add(n, '常量'));
  return items.slice(0, 60);
}

function collectCompletions(prefix, t) {
  const p = prefix.toLowerCase();
  const seen = new Set();
  const items = [];
  const add = (name, kind, sig, withCall) => {
    if (!name || seen.has(name) || seen.has(name.toLowerCase())) return;
    const nm = name.toLowerCase();
    const py = pinyinOf(name);
    const al = enAliasHit(name, p);          // 英文别名命中（如 if → 如果）
    const hit = nm.startsWith(p) || al
      || (py.full && py.full.startsWith(p))
      || (py.initials && py.initials.startsWith(p));
    if (!hit) return;
    seen.add(name);
    // 函数类补全（子程序 / API / 类函数…）：按参数个数在括号里铺好逗号分隔符
    items.push({ name, kind, sig: sig || enAliasSig(name, al),
                 insert: withCall ? acCallInsert(name, sig) : name });
  };
  const text = t.content;
  const structs = collectStructDefs(text);
  const libStructs = (S.libClass && S.libClass.structs) || {};
  const libMethods = (S.libClass && S.libClass.methods) || [];
  const allStructs = Object.assign({}, libStructs, structs);      // 同名时当前文件优先
  // 类型名集合（基本类型 + 当前文件与类库的数据类型）：区分「类型 名称」写法
  const allTypes = BASIC_TYPES.concat(Object.keys(allStructs));
  const varTypes = collectVarTypes(text, allStructs);
  collectNames(text, '变量', allTypes).forEach((n) => add(n, '变量', varTypes[n] || '', false));
  collectNames(text, '全局变量', allTypes).forEach((n) => add(n, '全局变量', varTypes[n] || '', false));
  // 常量不进普通候选：只有输入「#」后才弹常量（见 constItems）
  parseSubs(text).forEach((s0) => add(s0.name, s0.kind, s0.args, true));
  const apis = apiDeclMap(text);
  Object.keys(apis).forEach((n) => add(n, 'API', apis[n].args, true));
  // 全局符号表：核心库命令 / 类函数命令 / 工程文件中的函数、变量、常量等
  // （载入时已逐项 acEnsure 登记；此处按前缀 / 拼音补入，未登记项不会出现）
  (S.acList || []).forEach((it) => {
    if (seen.has(it.name)) return;
    const nm = it.name.toLowerCase();
    const py = pinyinOf(it.name);
    const al = enAliasHit(it.name, p);       // 英文别名命中
    if (!(nm.startsWith(p) || al
      || (py.full && py.full.startsWith(p))
      || (py.initials && py.initials.startsWith(p)))) return;
    seen.add(it.name);
    items.push({ name: it.name, kind: it.kind, sig: it.sig || enAliasSig(it.name, al),
                 insert: it.insert });
  });
  // 语言关键字：变量 / 常量 / 子程序 / 如果 / 结束子程序 / API 等
  YY_KEYWORDS_AC.forEach((k) => add(k.name, '关键字', '', false));
  // 数据类型（内置）+ 源码中定义的自定义数据类型
  BASIC_TYPES.forEach((n) => add(n, '数据类型', '内置', false));
  Object.keys(structs).forEach((n) => add(n, '自定义数据类型', '', false));
  // 类名补全：当前文件中以 类函数 X.函数 声明的宿主 + lib/*.class 类库中的类；
  // 输入类名后接「.」即可列出该类的类函数（如 运算.加法()）
  const fileMethods = collectMethodDefs(text);
  const owners = {};
  fileMethods.forEach((m) => { owners[m.owner] = '本文件'; });
  libMethods.forEach((m) => { if (!(m.owner in owners)) owners[m.owner] = '类库 ' + m.from; });
  Object.keys(libStructs).forEach((n) => { if (!(n in owners)) owners[n] = '类库'; });
  Object.keys(owners).forEach((n) => add(n, '类', owners[n], false));
  // 当前文件定义的类函数 → 补全候选（与类库类函数一致：输入类名即可补出「类名.方法()」）
  fileMethods.forEach((m) => add(m.owner + '.' + m.name, '类函数', m.args, true));
  return items.slice(0, 60);
}

/* 自动完成里的「词字符」：中英文 / 数字 / 下划线（与 fmTokenize 的 isW 一致） */
function acIsWordChar(c) {
  return !!c && /[A-Za-z0-9_\u4e00-\u9fff]/.test(c);
}

/* 光标处「当前词」的范围 [start, end)（只按当前文本实时计算，不依赖候选框打开时的快照）。
   - start：光标前面的连续词字符起点；end：光标后面的连续词字符终点。
   - 光标前没有词字符时（如刚输入「变量.」或「#」）start = end = pos，即「在光标处插入」，
     不会吃掉光标后面的文字。 */
function acWordRangeAt(v, pos) {
  let s = pos;
  while (s > 0 && acIsWordChar(v[s - 1])) s--;
  let e = pos;
  if (s < pos) {                       // 前面确实有词 → 同一词在光标后的残留也算进替换范围
    while (e < v.length && acIsWordChar(v[e])) e++;
  }
  return { start: s, end: e };
}

function hideAutoComplete() {
  S.ac = null;
  const box = $('acBox');
  if (box) box.classList.add('hidden');
}

function autoCompletePosition(ta, t) {
  const pos = ta.selectionStart;
  const line = lineOfOffset(t.content, pos);
  const bol = offsetOfLine(t.content, line);
  const textX = measureCtx().measureText(t.content.slice(bol, pos)).width;
  return {
    left: 4 + textX - ta.scrollLeft,                       // padding-left = 4
    top: line * LINE_H - ta.scrollTop,                     // 显示在光标所在行的下一行顶部
  };
}

function renderAutoComplete() {
  const box = $('acBox');
  const a = S.ac;
  if (!box || !a) return;
  box.innerHTML = a.items.map((it, i) =>
    '<div class="acItem' + (i === a.index ? ' active' : '') + '" data-i="' + i + '">'
    + '<span class="aname">' + escHtml(it.name) + '</span>'
    + (it.sig ? '<span class="asig">' + escHtml(it.sig) + '</span>' : '')
    + '<span class="akind">' + escHtml(it.kind) + '</span></div>').join('');
  box.querySelectorAll('.acItem').forEach((el) => {
    el.onmousedown = (e) => { e.preventDefault(); acApply(parseInt(el.dataset.i, 10)); };
  });
  const act = box.querySelector('.acItem.active');
  if (act) act.scrollIntoView({ block: 'nearest' });
}

function updateAutoComplete() {
  const ta = $('codeInput');
  const t = activeTab();
  const box = $('acBox');
  if (!box) return;
  if (!ta || ta.disabled || !t || t.kind !== 'yy' || t.readonly || t.gen) { hideAutoComplete(); return; }

  const pos = ta.selectionStart;
  const v = ta.value;
  const isWord = acIsWordChar;
  const s = acWordRangeAt(v, pos).start;
  const prefix = v.slice(s, pos);

  // 成员自动补全：输入「变量名.」或「类名.」后，列出所属数据类型的成员与类函数
  // （类名来自当前文件的 数据类型/类函数、工程其它文件 与 lib/*.class 类库，如 运算.加法()）
  let items = null;
  let start = s;
  if (s > 0 && v[s - 1] === '#') {
    // 「#」后：只弹出常量候选（核心库常量 + 当前文件定义的常量），替换「#」之后的词
    items = constItems(prefix, t);
  } else if (s > 0 && v[s - 1] === '.') {
    let b = s - 1;
    while (b > 0 && isWord(v[b - 1])) b--;
    const base = v.slice(b, s - 1).trim();
    if (base) {
      const structs = collectStructDefs(t.content);              // 当前文件的数据类型
      const libStructs = (S.libClass && S.libClass.structs) || {};
      const libMethods = (S.libClass && S.libClass.methods) || [];
      const projEnts = projMethodEntries();                       // 工程其它文件的类函数与成员
      const projMethods = projEnts.methods;
      const allStructs = Object.assign({}, libStructs, structs);  // 同名时当前文件优先
      const varTypes = collectVarTypes(t.content, allStructs);
      const fileMethods = collectMethodDefs(t.content);
      let tp = varTypes[base];                                   // ① base 是已声明的变量
      if (tp === undefined) {                                    // ② base 是类名（本文件 / 工程其它文件 / 类库）
        if (allStructs[base]
          || fileMethods.some((m) => m.owner === base)
          || projMethods.some((m) => m.owner === base)
          || libMethods.some((m) => m.owner === base)) tp = base;
      }
      if (tp !== undefined) {
        const seenF = new Set();                                 // 字段合并去重（本文件 → 类库 → 工程其它文件）
        const fields = [];
        (structs[tp] || []).concat(libStructs[tp] || []).forEach((f) => {
          if (!seenF.has(f.name)) { seenF.add(f.name); fields.push(f); }
        });
        projEnts.fields.forEach((f) => {
          if (f.owner === tp && !seenF.has(f.name)) { seenF.add(f.name); fields.push(f); }
        });
        const seenM = new Set();                                 // 类函数合并去重（本文件 → 工程其它文件 → 类库）
        const methods = [];
        fileMethods.concat(projMethods, libMethods).forEach((m) => {
          if (m.owner === tp && !seenM.has(m.name)) { seenM.add(m.name); methods.push(m); }
        });
        items = memberItems(fields, prefix, methods);
      }
    }
  }
  if (items === null) {                             // 非「.」场景：普通补全
    if (!prefix) { hideAutoComplete(); return; }
    items = collectCompletions(prefix, t);
  }
  if (!items.length) { hideAutoComplete(); return; }

  S.ac = { open: true, items, index: 0, prefix, start };
  renderAutoComplete();

  // 定位到光标处；靠近底部时改为向上弹出
  const p = autoCompletePosition(ta, t);
  box.style.left = Math.max(0, p.left) + 'px';
  let topPx = p.top;
  const ebH = $('editorBox').clientHeight;
  if (topPx + box.offsetHeight + 4 > ebH) {
    topPx = Math.max(0, p.top - LINE_H - box.offsetHeight);
  }
  box.style.top = topPx + 'px';
  box.classList.remove('hidden');
}

function acMove(d) {
  const a = S.ac;
  if (!a || !a.open) return;
  a.index = (a.index + d + a.items.length) % a.items.length;
  renderAutoComplete();
}

function acApply(index) {
  const a = S.ac;
  const ta = $('codeInput');
  const t = activeTab();
  if (!a || !a.open || !ta || !t) { hideAutoComplete(); return; }
  const it = a.items[index !== undefined ? index : a.index];
  if (!it) { hideAutoComplete(); return; }

  const pos = ta.selectionStart;
  const v = ta.value;
  // 选中候选词 = 替换光标所在的整个词：光标前的部分（输入的过滤前缀）连同光标后
  // 同一词的残留一起换掉（如「调试|输出」选「调试输出信息」→「调试输出信息」）；
  // 光标前没有词时（如「变量.」后）就是在光标处插入。范围按当前文本实时求，
  // 候选框打开后光标移动过也不会错位。
  const r = acWordRangeAt(v, pos);
  const start = r.start;
  let insert = it.insert;
  let caretOff = null;
  // 函数类补全：光标后面已经有「(」时就只补名字、不再补一对括号
  // （如 取文本长度|(内容) → 取文本长度(内容)），光标落在已有的「(」后面
  if (acCallCaretOffset(insert) >= 0) {
    let k = r.end;
    while (k < v.length && (v[k] === ' ' || v[k] === '\t')) k++;   // 允许名字与括号之间有空格
    if (v[k] === '(' || v[k] === '（') {
      insert = insert.slice(0, insert.lastIndexOf('('));
      caretOff = insert.length + (k - r.end) + 1;
    }
  }
  ta.value = v.slice(0, start) + insert + v.slice(r.end);
  // 函数类补全：括号里的逗号分隔符已按参数个数铺好，光标停在第一个参数处
  const off = caretOff !== null ? caretOff : acCallCaretOffset(insert);
  const cur = off >= 0 ? start + off : start + insert.length;
  ta.setSelectionRange(cur, cur);
  ta.focus();
  hideAutoComplete();

  t.content = ta.value;
  t.dirty = true;
  histPush(t, true);             // 自动补全插入：独立一步
  renderTabs();
  drawOverlay(t);
  updateStatusBar();
  updateCaret();
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => saveFile(t), 900);
  clearTimeout(S.subTimer);
  S.subTimer = setTimeout(() => { renderSubs(); renderClasses(); }, 400);
}

/* ================= 事件绑定 ================= */
function bindAll() {
  bindEditor();
  bindGutter();                 // 行号栏：单击选整行、▸ 展开折叠
  // 选工程 → 打开；选回「（选择工程…）」→ 取消选择并重载工程列表（见 clearProject）
  $('projectSelect').onchange = () => {
    const v = $('projectSelect').value;
    if (v) selectProject(v); else clearProject();
  };
  // 点开下拉即刷新工程列表（见 refreshProjectList）
  $('projectSelect').addEventListener('mousedown', refreshProjectList);
  $('btnRun').onclick = () => doRun('run', $('modeSelect').value);
  $('btnBuild').onclick = doBuild;
  $('btnTest').onclick = () => doRun('test', $('modeSelect').value);
  $('btnStop').onclick = doStop;
  $('btnRelease').onclick = doRelease;
  $('btnExport').onclick = () => doExport('cpp');
  if ($('btnExportPy')) $('btnExportPy').onclick = () => doExport('python');
  $('btnMakeFile').onclick = doMakeScript;
  $('btnCleanBuild').onclick = doCleanBuild;
  $('btnCI').onclick = doCI;
  $('btnProjCfg').onclick = openProjectConfig;
  if ($('btnDesigner')) $('btnDesigner').onclick = openDesigner;
  if ($('btnDesignerQt')) $('btnDesignerQt').onclick = openQtDesigner;
  dsgGlobalHandlers();
  qdsgGlobalHandlers();     // Qt 设计器同样要挂全局的拖动 / 方向键 / Delete / Esc 监听
  $('stToolchain').onclick = openSettings;
  $('stToolchain').style.cursor = 'pointer';
  $('stToolchain').title = '打开 IDE设置';

  $('btnNewProject').onclick = async () => {
    const f = await modalForm('新建工程', [
      { key: 'name', label: '工程名', placeholder: '例如：计算器', help: '将在工作区创建同名目录，并自动生成 main.yy 示例。' },
      { key: 'subsystem', label: '程序类型', type: 'radio', value: 'console',
        options: [
          { value: 'console', label: '控制台程序', help: '带命令行窗口，输出 / 输入文本可用' },
          { value: 'window', label: '窗口程序', help: 'GUI，不弹命令行窗口（-mwindows）' },
          { value: 'dll', label: 'DLL程序', help: '生成 .dll，导出「导出子程序」' },
        ],
        help: '决定编译方式与 main.yy 示例模板；建好后可在工具栏「程序类型」里随时切换。' },
      { key: 'arch', label: '目标架构', type: 'radio',
        value: ($('archSelect') && $('archSelect').value) || 'x64',
        options: [
          { value: 'x64', label: 'x64（64 位）', help: '用 mingw64 工具链编译（默认）' },
          { value: 'x86', label: 'x86（32 位）', help: '用 mingw32 工具链编译，产物名带 _x86' },
        ],
        help: '保存到工程配置（.yyproj）；下次打开工程时工具栏会自动选中它。' },
      { key: 'mode', label: '编译模式', type: 'radio',
        value: ($('modeSelect') && $('modeSelect').value) || 'debug',
        options: [
          { value: 'debug', label: '调试版', help: '-O0 -g，便于调试' },
          { value: 'release', label: '发布版', help: '-O2，体积更小、运行更快' },
        ],
        help: '保存到工程配置；下次打开工程时工具栏会自动选中它。' },
    ], '创建');
    if (!f || !f.name.trim()) return;
    try {
      const d = await api('POST', '/api/project/new', {
        name: f.name.trim(), subsystem: f.subsystem, arch: f.arch, mode: f.mode,
      });
      await loadProjects();
      await selectProject(d.project.name, true);
      toast('已创建工程「' + d.project.name + '」（' + (d.project.subsystemLabel || '')
        + ' · ' + (d.project.arch || 'x64') + ' · ' + (d.project.modeLabel || '调试版') + '）');
    } catch (e) { reportError('创建失败：' + e.message); }
  };

  $('btnAddFile').onclick = async () => {
    if (!S.project) { toast('请先选择工程'); return; }
    const f = await modalForm('新建源码文件', [
      { key: 'name', label: '文件名', value: '新模块.yy', help: '可在前面加子目录，如 模块/算法.yy' },
    ], '创建');
    if (!f || !f.name.trim()) return;
    const path = f.name.trim();
    if (!/\.yy$/i.test(path)) { toast('源码文件必须以 .yy 结尾'); return; }
    try {
      await api('POST', '/api/file/new', { project: S.project, path, content: "'\n'\n" });
      await refreshTree();
      await openFile(path);
    } catch (e) { reportError('创建失败：' + e.message); }
  };

  // 工程栏 ⟳：刷新文件树，同时把函数栏的源文件也重载一遍（见 syncSubsAfterTreeRefresh）
  $('btnRefreshTree').onclick = async () => {
    if (!S.project) return;
    try { await refreshTree(); } catch (e) { reportError(e.message); return; }
    toast(await syncSubsAfterTreeRefresh());
  };

  // 侧栏选项卡：内层（两栏各一根条：工程/函数 · 核心/类/API）+ 外层（底部：系统 / 工程）
  document.querySelectorAll('.sideTabs .sideTab').forEach((el) => {
    el.onclick = () => switchSideTab(el.dataset.panel);
  });
  document.querySelectorAll('#sideGroups .sideGroupTab').forEach((el) => {
    el.onclick = () => switchSideGroup(el.dataset.group);
  });
  if ($('libSearch')) $('libSearch').addEventListener('input', renderLib);
  if ($('clsSearch')) $('clsSearch').addEventListener('input', renderClasses);
  if ($('apiSearch')) $('apiSearch').addEventListener('input', renderApis);
  if ($('widgetSearch')) $('widgetSearch').addEventListener('input', renderWidgets);
  if ($('sciterSearch')) $('sciterSearch').addEventListener('input', renderSciter);
  if ($('constSearch')) $('constSearch').addEventListener('input', renderConsts);
  if ($('subSearch')) $('subSearch').addEventListener('input', renderSubs);
  // 「类」/「API」栏：重新载入 lib 目录下的 *.class 文件
  const btnRC = $('btnRefreshCls');
  if (btnRC) btnRC.onclick = async () => { await loadLibClasses(true).catch(() => { }); await renderClasses(); toast('已重写载入class文件'); };
  if ($('btnRefreshApis')) $('btnRefreshApis').onclick = async () => { await loadLibClasses(true).catch(() => { }); await renderApis(); toast('已重写载入class文件'); };
  if ($('btnRefreshConsts')) $('btnRefreshConsts').onclick = async () => { await loadLibClasses(true).catch(() => { }); await renderConsts(); toast('已重写载入const文件'); };
  if ($('btnRefreshWidgets')) $('btnRefreshWidgets').onclick = async () => { await loadLibClasses(true).catch(() => { }); await renderWidgets(); toast('已重写载入class文件'); };
  if ($('btnRefreshSciter')) $('btnRefreshSciter').onclick = async () => { await loadLibClasses(true).catch(() => { }); await renderSciter(); toast('已重写载入class文件'); };
  // 「函数」栏 ⟳：重载当前函数列表对应的源文件（读盘）后再重画，不只是重画内存内容
  if ($('btnRefreshSubs')) $('btnRefreshSubs').onclick = () => refreshSubsFromFile();
  if ($('modeSelect')) $('modeSelect').onchange = async () => {
    updateStatusBar();
    // 编译模式（调试版/发布版）：有工程时保存到工程级 .yyproj，无工程时写入全局设置
    const mode = $('modeSelect').value;
    const label = mode === 'release' ? '发布版' : '调试版';
    try {
      if (S.project) {
        const d = await api('POST', '/api/project/mode', { project: S.project, mode });
        S.cfg = Object.assign({}, S.cfg || {}, d.project);
        toast('已切换为「' + label + '」（已保存到工程「' + S.project + '」）');
      } else {
        S.env = await api('POST', '/api/settings', { mode });
        toast('已切换为「' + label + '」（已保存到全局设置）');
      }
    } catch (e) { reportError('保存编译模式失败：' + e.message); }
  };
  // 目标架构（x64/x86）：有工程时保存到工程级 .yyproj 并同步全局，无工程时仅写全局设置
  if ($('archSelect')) {
    $('archSelect').onchange = async () => {
      const arch = $('archSelect').value;
      try {
        if (S.project) {
          const d = await api('POST', '/api/project/arch', { project: S.project, arch });
          S.cfg = Object.assign({}, S.cfg || {}, d.project);
          S.env = d;  // d = {project, env} —— refreshToolchainLabel 读 S.env.env
        } else {
          S.env = await api('POST', '/api/settings', { arch });
        }
        refreshToolchainLabel();
        updateStatusBar();
        // 架构切换后整批重读类库：「类」/「API」/「Qt」三栏按架构载入不同文件
        // （x64 → qt.class/qt.api，x86 → qt_x86.class/qt_x86.api）
        await reloadLibClasses(arch);
        toast('已切换为 ' + (arch === 'x86' ? 'x86（32 位）' : 'x64（64 位）') + ' 编译'
          + '（已保存到' + (S.project ? '工程「' + S.project + '」' : '全局设置') + '）');
      } catch (e) { reportError('保存架构设置失败：' + e.message); }
    };
  }
  // 程序类型（控制台程序 / 窗口程序 / DLL程序）：保存到「当前工程」，无工程时写入全局设置
  if ($('subsysSelect')) {
    $('subsysSelect').onchange = async () => {
      const subsystem = $('subsysSelect').value;
      const hint = subsystem === 'window'
        ? '已切换为「窗口程序」：编译时链接 -mwindows，不弹出命令行窗口'
        : (subsystem === 'dll'
          ? '已切换为「DLL程序」：编译生成 .dll，导出「导出子程序」定义的函数'
          : '已切换为「控制台程序」：保留命令行窗口（输出/输入文本可用）');
      try {
        if (S.project) {
          const d = await api('POST', '/api/project/subsystem', { project: S.project, subsystem });
          S.cfg = Object.assign({}, S.cfg || {}, d.project);
        } else {
          S.env = await api('POST', '/api/settings', { subsystem });
        }
        updateStatusBar();
        toast(hint + '（已保存到' + (S.project ? '工程「' + S.project + '」' : '全局设置') + '）');
      } catch (e) { reportError('保存程序类型失败：' + e.message); }
    };
  }
  switchSideTab('files');
  startStatusBarClock();

  $('btnSettings').onclick = openSettings;
  $('btnGit').onclick = () => { if (S.project) openGit(); else toast('请先选择工程'); };

  // 深色/浅色模式切换（记忆上次偏好，默认深色）
  $('btnTheme').onclick = toggleTheme;

  // 全 IDE 的「字体 / 字号」栏都改成点一下弹选择框（带预览）——见 bindFontPickers
  bindFontPickers();

  // 编辑器字号调节（＋/－，保存偏好）
  initEditorFont();
  applyEditorFont();
  $('btnFontInc').onclick = () => { adjustFont(1); };
  $('btnFontDec').onclick = () => { adjustFont(-1); };

  // 编辑器右侧自绘滚动条：拖动滑块 + ▲ 一键到顶 / ▼ 一键到底 两端按钮
  initEditorScrollbar();
  initAiScrollbar();

  // 侧栏（工程/核心/类/函数）字号调节（＋/－，保存偏好）
  initSideFont();
  applySideFont();
  $('btnSideFontInc').onclick = () => { adjustSideFont(1); };
  $('btnSideFontDec').onclick = () => { adjustSideFont(-1); };

  // 底部控制台（控制台/问题）字号调节（＋/－，保存偏好）
  initConFont();
  applyConFont();
  $('btnConsoleFontInc').onclick = () => { adjustConFont(1); };
  $('btnConsoleFontDec').onclick = () => { adjustConFont(-1); };

  // 顶部菜单栏字号调节（＋/－，保存偏好；与编辑器/侧栏/控制台/智能体同款）
  initTopFont();
  applyTopFont();
  $('btnTopFontInc').onclick = () => { adjustTopFont(1); };
  $('btnTopFontDec').onclick = () => { adjustTopFont(-1); };

  // 注：底部那行「控制台输入框」已删除 —— 程序「输入文本」改用 promptStdInput 的
  // 弹出对话框（见「控制台程序的输入文本」一节），不再需要这里的输入监听与状态轮询

  window.addEventListener('beforeunload', (e) => {
    if (S.tabs.some((t) => t.dirty && !t.readonly && !t.gen)) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  // 完全屏蔽浏览器默认右键菜单（IDE 自带的右键菜单不受影响：
  // 文件树/面板等各自已在自己的 contextmenu 里 preventDefault 并显示自定义菜单）
  document.addEventListener('contextmenu', (e) => e.preventDefault());

  // 快捷键（完整清单见 docs/云易中文编程语言规范.md 第 9 节）
  window.addEventListener('keydown', (e) => {
    // Ctrl+Enter：打开「请输入内容」对话框（程序执行到「输入文本」时会自动弹出）
    if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.key === 'Enter' || e.keyCode === 13)) {
      e.preventDefault();
      openConsoleInput();
      return;
    }
    // Ctrl+Home / Ctrl+End：鼠标所在控件的滚动条移到顶端 / 底端
    if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.key === 'Home' || e.key === 'End')) {
      if (scrollHoveredTo(e.key === 'Home' ? 'top' : 'bottom')) e.preventDefault();
      return;
    }
    if (e.ctrlKey && e.key.toLowerCase() === 'b') { e.preventDefault(); doBuild(); return; }
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'b') { e.preventDefault(); doRelease(); return; }
    if (e.key === 'F5') { e.preventDefault(); doRun('run', $('modeSelect').value); return; }
    if (e.key === 'F6') { e.preventDefault(); doBuild(); return; }
    if (e.key === 'F7') { e.preventDefault(); doRun('test', $('modeSelect').value); return; }
  });

  // 底部控制台初始化
  const cts = $('consoleTabs');
  // 只清掉选项卡本身：行尾的控制台字号条（#consoleFontBar，在 HTML 里）要留着
  Array.prototype.slice.call(cts.querySelectorAll('.tab')).forEach((el) => el.remove());
  ensureConsoleTab('console', '控制台');
  ensureConsoleTab('problems', '问题');
  if (!$('problems')) {
    const plist = document.createElement('div');
    plist.id = 'problems';
    plist.style.display = 'none';
    $('consoleBody').parentNode.insertBefore(plist, $('consoleBody'));
  }
  // 恢复上次打开的底部选项卡与折叠状态
  let savedTab = 'console';
  try {
    if (localStorage.getItem('yyConsoleTab') === 'problems') savedTab = 'problems';
  } catch (e) { /* 忽略 */ }
  switchConsoleTab(savedTab);

  // 底部面板折叠按钮（记忆上次状态）
  const fold = document.createElement('button');
  fold.id = 'btnFold';
  fold.className = 'collapseBtn';
  fold.textContent = '▾';
  fold.title = '收起 / 展开底部面板';
  fold.onclick = toggleBottom;
  cts.appendChild(fold);
  try {
    if (localStorage.getItem('yyBottomFolded') === '1') setBottomFolded(true);
  } catch (e) { /* 忽略 */ }

  // 控制台 / 问题面板：右键复制（选中文本或全部内容）
  bindPanelCopyMenu($('consoleBody'), () =>
    (S[S.consoleTab + 'Lines'] || []).map((l) => l.text).join('\n'));
  bindPanelCopyMenu($('problems'), () =>
    (S.problems || []).filter((p) => p.kind !== 'ok').map(problemLineText).join('\n'));
}

/* ================= 主题（深色/浅色） ================= */
const THEME_KEY = 'yyTheme';
function applyTheme(dark) {
  document.body.classList.toggle('light', !dark);
  const btn = $('btnTheme');
  if (btn) {
    btn.textContent = dark ? '🌙 深色' : '☀ 浅色';
    btn.title = dark ? '切换为浅色模式' : '切换为深色模式';
  }
}
function initTheme() {
  let dark = true;                       // 默认深色
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light') dark = false;
  } catch (e) { /* 忽略 */ }
  applyTheme(dark);
}
function toggleTheme() {
  const isLight = document.body.classList.contains('light');   // 当前是否浅色
  applyTheme(isLight);                                         // 浅色→深色，深色→浅色
  const theme = isLight ? 'dark' : 'light';
  try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* 忽略 */ }
  ideCfgQueueSave({ theme });                                  // 落盘 config/ide_settings.json
}

/* ================= 启动 ================= */
async function init() {
  bindAll();
  initTheme();
  initTokColors();    // 用户自定义的编辑器配色（先按 localStorage 缓存上屏）
  syncIdeConfigLoad(); // 从服务端 config/ide_settings.json 拉取设置并覆盖（配色/主题/字号）
  loadI18n();           // 多语言：拉取 config\*.lng 语言包，非中文界面时开始翻译
  // 读上次快照：恢复当前工程、打开的标签页、运行中的会话（阶段性保存见「IDE 快照」节）
  ideRestore = loadIdeState();
  if (ideRestore) {
    // 预置当前工程：loadProjects 校验存在后自动 selectProject 重开（不存在则自动清空）
    if (ideRestore.project) S.project = ideRestore.project;
    if (ideRestore.sideTab) switchSideTab(ideRestore.sideTab);
  }
  try {
    const env = await api('GET', '/api/env');
    S.env = env;
  } catch (e) {
    $('stToolchain').textContent = '工具链检测失败：' + e.message;
  }
  refreshToolchainLabel();
  checkEnvAtStartup();                    // 启动自检：g++ / make / Git / Python 路径
  // 恢复上次选择的目标架构（x64/x86，保存在服务端配置）
  if ($('archSelect')) $('archSelect').value = (S.env && S.env.env && S.env.env.arch) || 'x64';
  // 恢复上次选择的程序类型（窗口程序 / 控制台程序）
  if ($('subsysSelect')) $('subsysSelect').value = (S.env && S.env.env && S.env.env.subsystem) || 'console';
  // 恢复上次选择的编译模式（调试版 / 发布版，保存在服务端配置）
  if ($('modeSelect')) $('modeSelect').value = (S.env && S.env.env && S.env.env.mode) || 'debug';
  await loadCorelib();
  renderLib();
  loadLibClasses().catch(() => { });      // 预载 lib/*.class 类库（类名 / 类函数自动补全用）
  await loadProjects();                   // S.project 已预置为快照里的工程 → 这里自动重开
  // 工程与标签页已在 loadProjects → selectProject 里按快照恢复完，这里补上运行会话
  if (ideRestore) {
    restoreIdeSession(ideRestore.sess);
    ideRestore = null;                    // 快照只消费一次，之后的切工程走正常流程
  }
  // 阶段性保存：每 15 秒存一次快照；标签页/工程/会话变化处另有防抖保存
  setInterval(saveIdeState, 15000);
  window.addEventListener('beforeunload', saveIdeState);   // 关页/刷新前兜底存一次
}

document.addEventListener('DOMContentLoaded', init);

/* ================= AI 智能体（编辑区右侧面板） =================
   会话与任务由服务端智能体框架维护（server/agent/，对外壳为 server/aiagent.py），
   前端只发 /api/ai/chat 并渲染 SSE 事件流：
     delta（正文增量）/ think（思考增量）/ notice / tool_start / tool_result /
     context（上下文用量）/ done / error
     state（状态机迁移）/ plan（任务与计划）/ skill（技能激活）/
     verify（验证结论）/ recover（恢复策略）/ confirm（人工确认）/ trace
   工具执行后按 meta 同步 IDE（文件树、编辑器内容、问题面板）。 */
const AI = {
  busy: false,          // 正在生成
  abort: null,          // AbortController（停止按钮）
  cfg: null,            // 接口配置
  curMode: 'default',   // 设置面板当前显示的接口方案（default / customN）
  ansEl: null,          // 当前流式回答气泡
  ansText: '',          // 当前回答累计文本
  thinkEl: null,        // 当前思考块
  thinkText: '',
  tools: {},            // id -> 工具卡片元素
  atts: [],             // 待发送附件 [{kind:'img'|'file', name, b64|dataUrl, size}]
  lastUserWrap: null,   // 最近一条用户消息气泡（失败时在左侧加重试按钮）
  lastRetry: null,      // 最近一条消息的重试数据 {text, atts}
  lastStateKey: '',     // 上一条状态徽标的去重 key
};

function aiPanelVisible() { return !$('aiPanel').classList.contains('hidden'); }

function aiToggle(show) {
  const p = $('aiPanel');
  const stub = $('aiStub');
  const will = (show === undefined) ? p.classList.contains('hidden') : !!show;
  p.classList.toggle('hidden', !will);
  // 收起时显示右侧拉手（点击可重新展开）；展开时拉手隐藏。
  // body.ai-collapsed 同时控制主体区域（编辑器列/控制台/状态栏）的右侧让位宽度
  document.body.classList.toggle('ai-collapsed', !will);
  if (stub) stub.classList.toggle('hidden', will);
  try { localStorage.setItem('yyAIPanel', will ? '1' : '0'); } catch (e) { /* 忽略 */ }
  if (will) {
    aiScrollBottom();
    setTimeout(() => { const i = $('aiInput'); if (i) i.focus(); }, 60);
  }
}

function aiScrollBottom() {
  const m = $('aiMsgs');
  if (m) m.scrollTop = m.scrollHeight;
}

function aiSetState(text, busy) {
  const s = $('aiState');
  if (s) { s.textContent = text || '就绪'; s.classList.toggle('busy', !!busy); }
}

function aiSetBusy(on) {
  AI.busy = on;
  const btn = $('aiBtnSend');
  const icon = $('aiSendIcon');
  if (btn) {
    btn.classList.toggle('stop', on);
    btn.title = on ? '停止生成' : '发送（Enter）';
    // 图标：发送 = 空心三角+中竖线；停止 = 方块
    if (icon) {
      icon.innerHTML = on
        ? '<rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor" stroke="none"/>'
        : '<path d="M12 3.5 L21 21 H3 Z" /><line x1="12" y1="3.5" x2="12" y2="21" />';
    }
  }
  const inp = $('aiInput');
  if (inp) inp.disabled = on;
  aiSetState(on ? '思考中…' : '就绪', on);
}

/* mini 渲染：```代码块``` 转 pre；其余 esc 后保留换行（不做完整 markdown） */
function aiRender(text) {
  const parts = String(text || '').split(/```/);
  let html = '';
  for (let i = 0; i < parts.length; i++) {
    let seg = parts[i];
    if (i % 2 === 1) {
      seg = seg.replace(/^[a-zA-Z0-9_+-]*\r?\n/, '');   // 去掉语言标记行
      html += '<pre class="aiCode">' + escHtml(seg.replace(/\n$/, '')) + '</pre>';
    } else if (seg) {
      html += escHtml(seg);
    }
  }
  return html;
}

function aiBubble(kind, html) {
  const wrap = document.createElement('div');
  wrap.className = 'aiMsg ' + kind;
  const b = document.createElement('div');
  b.className = 'bubble';
  b.innerHTML = html;
  wrap.appendChild(b);
  $('aiMsgs').appendChild(wrap);
  aiScrollBottom();
  return b;
}

/* ---- 消息右下角的「复制」图标：点一下复制这条消息的文字 ---- */
const AI_COPY_SVG = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"'
  + ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
  + '<rect x="9" y="9" width="12" height="12" rx="2.5"/>'
  + '<path d="M6 15H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v1"/></svg>';
const AI_OK_SVG = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"'
  + ' stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">'
  + '<path d="M20 6 L9 17 L4 12"/></svg>';

/* 挂在 .aiMsg（气泡的兄弟节点）上，绝对定位到气泡右下角 ——
   这样 AI 回答流式重渲染 .bubble 时按钮不会被冲掉。
   getText 可传字符串或函数：流式回答传函数，取到的始终是最新文本（结束后也能复制）。 */
function aiAttachCopy(wrap, getText) {
  if (!wrap || wrap.querySelector('.aiCopyBtn')) return;
  wrap.classList.add('hasCopy');
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'aiCopyBtn';
  btn.title = '复制这条消息的文字';
  btn.innerHTML = AI_COPY_SVG;
  btn.onclick = (e) => {
    e.stopPropagation();
    const txt = (typeof getText === 'function') ? getText() : String(getText == null ? '' : getText);
    if (!txt) return;
    copyText(txt);                          // 自带「已复制到剪贴板」提示
    btn.classList.add('ok');                // 图标短暂变成 ✓
    btn.innerHTML = AI_OK_SVG;
    clearTimeout(btn._okT);
    btn._okT = setTimeout(() => { btn.classList.remove('ok'); btn.innerHTML = AI_COPY_SVG; }, 1200);
  };
  wrap.appendChild(btn);
}

/* 输入框左下角按钮：把「上一条已发送的消息」放回输入框（文字 + 图片/附件一起复原），
   改完可以直接再发一次。点它不弹任何提示框：直接覆盖输入框内容（光标停在末尾）。
   还没有可复用的消息时，按钮自己闪两下作为反馈。 */
function aiReuseLast() {
  const ta = $('aiInput');
  if (!ta) return;
  const btn = $('aiBtnReuse');
  const pulse = () => {                     // 按钮闪两下（无声反馈）
    if (!btn) return;
    btn.classList.remove('pulse');
    void btn.offsetWidth;                   // 强制重排，动画能重复播放
    btn.classList.add('pulse');
  };
  const raw = AI.lastUserText || '';
  // 纯附件消息在气泡里显示的是占位文字，复用时不把它塞回输入框
  const text = raw.indexOf('（请看附件）') === 0 ? '' : raw;
  const atts = (AI.lastUserAtts || []).slice();
  ta.focus();
  if (!text && !atts.length) { pulse(); return; }   // 没有上一条消息：只闪一下，不弹提示
  ta.value = text;
  ta.setSelectionRange(text.length, text.length);   // 光标停在末尾，接着改最方便
  if (atts.length) {                        // 上一条的图片 / 附件也一并复原
    AI.atts = atts;
    aiRenderAtts();
  }
  pulse();
}

/* ---------- 快捷提示词（复用按钮右侧）：config\prompts.json，点一项直接发给智能体 ---------- */

/* 开/关提示词列表（从按钮上方弹出；首次打开拉取，之后用缓存） */
async function aiTogglePromptMenu() {
  const menu = $('aiPromptMenu');
  if (!menu) return;
  const opening = menu.classList.contains('hidden');
  aiClosePromptMenu();
  if (!opening) return;
  menu.classList.remove('hidden');
  menu.innerHTML = '<div class="aiModelItem miEmpty">加载中…</div>';
  menu.setAttribute('tabindex', '-1');          // 可聚焦容器：失焦（focusout）时自动关闭
  try { menu.focus({ preventScroll: true }); } catch (e) { /* 忽略 */ }
  if (!Array.isArray(AI.prompts)) {
    try {
      const d = await api('GET', '/api/ai/prompts');
      AI.prompts = d.prompts || [];
    } catch (e) {
      AI.prompts = [];
    }
  }
  if (menu.classList.contains('hidden')) return;   // 等待期间用户已关掉
  aiRenderPromptMenu();
}

function aiRenderPromptMenu() {
  const menu = $('aiPromptMenu');
  if (!menu) return;
  menu.innerHTML = '';
  const items = AI.prompts || [];
  if (!items.length) {
    const item = document.createElement('div');
    item.className = 'aiModelItem miEmpty';
    item.textContent = '（暂无提示词：config\\prompts.json）';
    menu.appendChild(item);
    return;
  }
  items.forEach((text) => {
    const item = document.createElement('div');
    item.className = 'aiPromptItem';
    item.title = '点击发送给智能体';
    item.tabIndex = 0;                        // 可聚焦：点它不失焦（否则点击会把焦点丢给 body 而提前收起）
    const span = document.createElement('span');
    span.className = 'piText';
    span.textContent = text;
    item.appendChild(span);
    item.onclick = () => aiPickPrompt(text);  // 点选即提交，aiPickPrompt 里会关闭菜单
    item.onkeydown = (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); aiPickPrompt(text); }
    };
    menu.appendChild(item);
  });
}

function aiClosePromptMenu() {
  const menu = $('aiPromptMenu');
  const btn = $('aiBtnPrompts');
  if (menu) menu.classList.add('hidden');
  if (btn) btn.classList.remove('open');
}

/* 点选一条提示词：关菜单 → 填入输入框 → 走标准发送链路（忙碌时提示先停止） */
async function aiPickPrompt(text) {
  aiClosePromptMenu();
  if (AI.busy) { toast('正在生成中，请先停止当前任务'); return; }
  const ta = $('aiInput');
  if (!ta || !text) return;
  ta.value = text;
  await aiSend();
}

function aiAddUser(text, retryData) {
  const wrap = document.createElement('div');
  wrap.className = 'aiMsg user';
  // 重试按钮（左侧）：仅在请求失败时由 aiSend 标记显示（retryData 含原消息与附件）
  if (retryData) {
    const btn = document.createElement('button');
    btn.className = 'aiRetryBtn';
    btn.textContent = '↻';
    btn.title = '重试：重新发送这条消息';
    btn.onclick = () => aiRetry(retryData);
    wrap.appendChild(btn);
    wrap.classList.add('failed');
  }
  const b = document.createElement('div');
  b.className = 'bubble';
  b.innerHTML = escHtml(text);
  wrap.appendChild(b);
  AI.lastUserText = text;                 // 「复用上一条」按钮取它
  aiAttachCopy(wrap, text);               // 右下角复制图标：复制这条消息的文字
  $('aiMsgs').appendChild(wrap);
  aiScrollBottom();
  return wrap;
}

/* 重试：把原消息文本与附件还原到输入区，再走标准发送链路（与手动重发一致） */
function aiRetry(data) {
  if (AI.busy) { toast('正在生成中，请先停止当前任务'); return; }
  const d = data || AI.lastRetry;
  if (!d) return;
  const ta = $('aiInput');
  ta.value = d.text && d.text.indexOf('（请看附件）') === 0 ? '' : (d.text || '');
  AI.atts = (d.atts || []).slice();
  aiRenderAtts();
  aiSend();
}

function aiAddErr(text) {
  aiBubble('err', escHtml(text));
  aiSetState('出错', false);
}

function aiAddSys(text) {
  aiBubble('sys', escHtml(text));
}

/* ---------- 任务状态机 / 计划 / 验证 / 恢复 / 人工确认（对应服务端新增事件） ---------- */

/* 状态徽标：只在状态真的变化时插一条，避免刷屏 */
function aiStateChip(ev) {
  const key = (ev.state || '') + '|' + (ev.note || '');
  if (AI.lastStateKey === key) return;
  AI.lastStateKey = key;
  const w = document.createElement('div');
  w.className = 'aiMsg aiStateChip';
  const note = ev.note ? '：' + escHtml(ev.note) : '';
  w.innerHTML = '<span class="dot"></span>' + escHtml(ev.label || ev.state || '') + note;
  $('aiMsgs').appendChild(w);
  aiScrollBottom();
  if (ev.label) aiSetState(ev.label, AI.busy);
}

/* 计划卡：同一个任务内原地更新，不堆叠 */
function aiRenderPlan(ev) {
  const t = ev.task || {};
  let card = $('aiMsgs').querySelector('.aiPlan[data-tid="' + t.taskId + '"]');
  if (!card) {
    card = document.createElement('div');
    card.className = 'aiMsg aiPlan';
    card.dataset.tid = t.taskId || '';
    $('aiMsgs').appendChild(card);
  }
  const plan = t.plan || [];
  const pg = t.progress || { done: 0, total: plan.length };
  const pct = pg.total ? Math.round(pg.done * 100 / pg.total) : 0;
  let html = '<div class="pHead">📋 <span class="pGoal">'
    + escHtml(t.goal || '当前任务') + '</span>'
    + '<span>' + pg.done + '/' + pg.total + '</span></div>';
  if (t.planGoal && t.planGoal !== t.goal) {
    html += '<div class="pSub">计划目标：' + escHtml(t.planGoal) + '</div>';
  }
  if (plan.length) {
    html += '<ol>' + plan.map((it) => {
      const cls = { done: 'done', doing: 'doing', failed: 'failed' }[it.status] || '';
      const note = it.note ? '（' + escHtml(it.note) + '）' : '';
      return '<li class="' + cls + '">' + escHtml(it.title || '') + note + '</li>';
    }).join('') + '</ol>';
    html += '<div class="pBar"><i style="width:' + pct + '%"></i></div>';
  }
  // 任务结束时间：完成后显示在计划卡（任务回显）底部 —— 从指标条移到这里
  const mt = t.metrics || {};
  if (mt.finished && mt.endedAt) {
    html += '<div class="pFoot">结束时间 ' + fmtClock(mt.endedAt) + '</div>';
  }
  card.innerHTML = html;
  aiScrollBottom();
}

/* 验证 / 恢复 / 技能：一条轻量提示行 */
function aiNote(text, kind) {
  const w = document.createElement('div');
  w.className = 'aiMsg aiNote ' + (kind || '');
  w.innerHTML = text;
  $('aiMsgs').appendChild(w);
  aiScrollBottom();
}

function aiShowVerify(ev) {
  if (!ev || !ev.target) return;
  if (ev.passed && ev.level === 'info' && !ev.guide) return;   // 常规通过不打扰
  const kind = ev.level === 'block' ? 'bad' : (ev.level === 'warn' ? 'warn' : 'good');
  const icon = ev.passed ? '✅' : '⚠️';
  let html = icon + ' <b>验证</b> ' + escHtml(ev.target) + '：' + escHtml(ev.note || '');
  if (ev.issues && ev.issues.length) {
    html += '<br>' + ev.issues.map((x) => '· ' + escHtml(x)).join('<br>');
  }
  if (ev.guide) html += '<br>→ ' + escHtml(ev.guide);
  aiNote(html, kind);
}

function aiShowRecover(ev) {
  if (!ev || !ev.guide) return;
  const kind = ev.action === 'fix_code' ? 'warn' : '';
  aiNote('🔁 <b>恢复策略</b> ' + escHtml(ev.categoryLabel || ev.category || '')
    + ' → ' + escHtml(ev.action || '') + '<br>→ ' + escHtml(ev.guide), kind);
}

/* 人工确认卡：批准 / 取消（Human-in-the-loop） */
function aiShowConfirm(ev) {
  const w = document.createElement('div');
  w.className = 'aiMsg aiConfirm';
  w.innerHTML = '<div class="cTitle">⚠️ 需要你的确认</div>'
    + '<div class="cRow"><b>动作：</b>' + escHtml(ev.tool || '') + '</div>'
    + '<div class="cRow"><b>原因：</b>' + escHtml(ev.reason || '') + '</div>'
    + '<div class="cRow"><b>影响范围：</b>' + escHtml(ev.impact || '') + '</div>'
    + '<div class="cBtns">'
    + '<button class="aiConfirmBtn all" data-all>全部放行</button>'
    + '<button class="aiConfirmBtn primary" data-yes>确认执行</button>'
    + '<button class="aiConfirmBtn" data-no>取消</button></div>';
  const btns = w.querySelectorAll('.aiConfirmBtn');
  const done = (approve, all) => {
    btns.forEach((b) => { b.disabled = true; });
    aiConfirmSend(approve, all);
  };
  btns[0].onclick = () => done(true, true);   // 全部放行：本次任务后续操作默认放行
  btns[1].onclick = () => done(true);
  btns[2].onclick = () => done(false);
  $('aiMsgs').appendChild(w);
  aiScrollBottom();
}

/* 确认后：先把授权登记到服务端。生成过程中（dsh 后端）服务端正阻塞等这个答复，
   答复完智能体自己继续走，不需要再补一条消息；只有不在生成中时才回一条文本
   （兼容旧的「后端起一个回合来问」的行为）。
   all = 全部放行：本任务剩余的权限请求全部自动批准，不再逐个弹卡。 */
async function aiConfirmSend(approve, all) {
  try { await api('POST', '/api/ai/confirm', { approve: !!approve, all: !!all }); } catch (e) { /* 继续按文本走 */ }
  if (all) aiAddSys('已开启「全部放行」：后续所有需确认的动作将自动批准（持久化，所有窗口/新会话生效），可在智能体设置中关闭。');
  if (AI.busy) return;
  const ta = $('aiInput');
  ta.value = approve ? '确认' : '取消';
  aiSend();
}

/* 提问卡：智能体 ask_user_question 带 options 时渲染成**可点击选项**（workbuddy 风格）。
   点一个选项 = 选中并作为回答直接发送，不用手输序号；无选项则提示用户直接回复。 */
function aiShowAsk(ev) {
  const opts = (ev.options || [])
    .map((o) => String(o == null ? '' : o).trim())
    .filter((s) => s !== '');
  const w = document.createElement('div');
  w.className = 'aiMsg aiAsk';
  const hint = document.createElement('div');
  hint.className = 'aHint';
  hint.textContent = opts.length ? '请选择一个选项：' : '请直接回复你的回答';
  w.appendChild(hint);
  if (opts.length) {
    const row = document.createElement('div');
    row.className = 'aOpts';
    const btns = opts.map((o) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'aiAskOpt';
      b.textContent = o;
      b.onclick = () => {
        btns.forEach((x) => { x.disabled = true; });
        b.classList.add('chosen');
        aiAskChoose(o);
      };
      return b;
    });
    btns.forEach((b) => row.appendChild(b));
    w.appendChild(row);
  }
  $('aiMsgs').appendChild(w);
  aiScrollBottom();
}

/* 用户点了一个选项：把选项文本作为回答发送给智能体 */
function aiAskChoose(text) {
  if (AI.busy) return;
  const ta = $('aiInput');
  ta.value = text;
  aiSend();
}

/* 思考块：流式过程直接追加文字；结束后可折叠 */
function aiThinkAppend(text) {
  if (!AI.thinkEl) {
    const w = document.createElement('div');
    w.className = 'aiThink';
    const head = document.createElement('div');
    head.className = 'thinkHead';
    head.innerHTML = '<span>💭 思考过程</span>';
    const body = document.createElement('div');
    body.className = 'aiThinkBody';
    w.appendChild(head);
    w.appendChild(body);
    head.onclick = () => w.classList.toggle('folded');
    $('aiMsgs').appendChild(w);
    AI.thinkEl = w;
    AI.thinkText = '';
    // 右下角复制图标：复制完整思考过程（折叠了也能复制）
    aiAttachCopy(w, () => body.textContent);
  }
  AI.thinkText += text;
  const body = AI.thinkEl.querySelector('.aiThinkBody');
  if (body) { body.textContent = AI.thinkText; body.scrollTop = body.scrollHeight; }
  aiScrollBottom();
}

function aiThinkDone() {
  if (AI.thinkEl) {
    AI.thinkEl.classList.add('folded');      // 完成后默认收起
    AI.thinkEl = null;
    AI.thinkText = '';
  }
}

/* 回答气泡：流式追加（整气泡每次重渲染，规模小性能足够） */
function aiDeltaAppend(text) {
  if (!AI.ansEl) {
    AI.ansEl = aiBubble('ai', '');
    AI.ansText = '';
    AI.ansRaw = { text: '' };             // 回答结束后 AI.ansText 会被清空，这里留着给复制按钮用
    aiAttachCopy(AI.ansEl.parentNode, () => AI.ansRaw.text);
  }
  AI.ansText += text;
  AI.ansRaw.text = AI.ansText;            // 流式过程中同步更新
  const tail = AI.busy ? '<span class="blink">▌</span>' : '';
  AI.ansEl.innerHTML = aiRender(AI.ansText) + tail;
  aiScrollBottom();
}

/* 工具卡片：start 建卡，result 更新状态与详情 */
function aiToolStart(ev) {
  const card = document.createElement('div');
  card.className = 'aiTool';
  const argsTxt = (() => {
    try {
      const a = ev.args || {};
      const keys = Object.keys(a);
      return keys.map((k) => k + '=' + String(a[k]).slice(0, 40)).join(' ');
    } catch (e) { return ''; }
  })();
  const head = document.createElement('div');
  head.className = 'tHead';
  head.innerHTML = '<span class="tIco">🔧</span>'
    + '<span class="tName">' + escHtml(ev.name || '') + '</span>'
    + '<span class="tSummary">执行中… ' + escHtml(argsTxt).slice(0, 60) + '</span>'
    + '<span class="tCaret">▾</span>';
  const body = document.createElement('div');
  body.className = 'tBody';
  body.textContent = '参数：' + JSON.stringify(ev.args || {});
  card.appendChild(head);
  card.appendChild(body);
  head.onclick = () => card.classList.toggle('open');
  $('aiMsgs').appendChild(card);
  AI.tools[ev.id] = card;
  // 右下角复制图标：复制工具名 + 参数 + 结果（始终取最新内容，折叠也能复制）
  aiAttachCopy(card, () => {
    const b = card.querySelector('.tBody');
    return '工具：' + (ev.name || 'tool') + '\n' + (b ? b.textContent : '');
  });
  aiScrollBottom();
}

function aiToolResult(ev) {
  // 先同步 IDE（新建工程要切过去 / 改过的文件要重载）：这一步**不依赖工具卡片**
  // —— 卡片只是对话流里的展示，缺了它 meta 里的动作照样要做。
  aiApplyMeta(ev.meta);
  const card = AI.tools[ev.id];
  if (!card) return;
  delete AI.tools[ev.id];
  card.classList.add(ev.ok ? 'ok' : 'bad');
  const s = card.querySelector('.tSummary');
  if (s) s.textContent = (ev.ok ? '' : '✗ ') + (ev.summary || ev.name || '');
  const body = card.querySelector('.tBody');
  if (body) body.textContent = '参数：' + JSON.stringify(ev.args || {})
    + (ev.detail ? '\n结果：' + ev.detail : '');
  aiScrollBottom();
}

/* 工具执行后同步 IDE：文件树 / 编辑器内容 / 问题面板 / 工程下拉 */
function aiApplyMeta(meta) {
  if (!meta) return;
  const files = meta.files || [];
  if (files.length) {
    // 当前没有打开工程时（比如刚由 AI 新建），不做树刷新——切到新工程时自然会加载
    if (S.project) refreshTree();
    files.forEach((f) => {
      const i = S.tabs.findIndex((t) => t.path === f && !t.gen && t.project === S.project);
      if (i < 0) return;
      const t = S.tabs[i];
      if (t.dirty) {
        toast('AI 修改了 ' + f + '，但编辑器里有未保存的改动，未自动同步（请手动核对）');
        return;
      }
      aiReloadTab(i);
    });
  }
  if (meta.newProject) {
    // AI 新建了工程：刷新下拉并自动切换过去（含文件树与 main.yy）。
    // 不管当前有没有开着别的工程 —— 新建工程通常意味着接下来的活就在它里面。
    loadProjects()
      .then(() => selectProject(meta.newProject))
      .then(() => toast('已切换到新建的工程「' + meta.newProject + '」'))
      .catch(() => { });
  }
  if (meta.problems) showProblems(meta.problems);
}

/* 任务收尾兜底同步（done / 用户手动停止时各调一次）。
   为什么需要：上面 aiApplyMeta 依赖每个工具事件自带的 meta，只覆盖标准工具 ——
   智能体如果用 shell、run_code（PTC）或在子智能体里建工程 / 改文件，
   这些操作没有 per-tool meta，「选择工程」下拉和已打开的编辑器就会停留在旧内容，
   需要用户手动刷新。这里在任务结束后统一拉一遍：
   · 工程下拉：重读 /api/projects；发现新增工程就自动切过去（新建的工程通常是后续
     工作的落点；切换前会先保存未保存的标签）
   · 文件树：重读
   · 打开的标签页：未保存(dirty)的不动，其余重新读盘（智能体改过就同步进来） */
async function aiFinalSync() {
  try {
    const before = (S.projects || []).map((p) => p.name);
    await loadProjects();
    const added = (S.projects || []).filter((p) => before.indexOf(p.name) < 0);
    // 新出现的工程一律切过去（不再要求「当前没开工程」）：智能体也可能用 run_code /
    // shell / 子智能体建工程，那些路径没有 per-tool meta，这里是唯一的兜底同步点。
    // selectProject 内部会先保存未保存的标签再切换，不会丢内容。
    if (added.length) {
      const name = added[0].name;
      await selectProject(name);
      toast('检测到新工程「' + name + '」，已切换过去');
    }
    if (S.project) {
      refreshTree();
      const reloads = [];
      S.tabs.forEach((t, i) => {
        if (t.project === S.project && !t.gen && !t.readonly && !t.dirty) {
          reloads.push(aiReloadTab(i));
        }
      });
      await Promise.all(reloads);
    }
  } catch (e) { /* 兜底刷新失败不打扰用户 */ }
}

async function aiReloadTab(i) {
  const t = S.tabs[i];
  if (!t) return false;
  try {
    const d = await api('GET', '/api/file?project=' + encodeURIComponent(t.project)
      + '&path=' + encodeURIComponent(t.path));
    if (d.binary) return;
    const raw = (d.text || '').replace(/\r\n?/g, '\n');
    const text = normalizeIndent(raw);
    t.folds = null;                    // 整体换成磁盘内容：放弃折叠状态（避免行号对不上）
    t.content = text;
    t.savedContent = raw;
    t.dirty = text !== raw;
    t.undefCalls = [];
    histReset(t);
    if (S.active === i) { renderTabs(); renderEditor(); }
    renderTabs();
    return true;
  } catch (e) { /* 文件可能刚被删除等：忽略 */ return false; }
}

/* 「函数」列表对应的那个源文件：优先用渲染时记下的标签，它关掉了就退回当前编辑框的 */
function subsSourceTab() {
  if (S.subsTab && S.tabs.indexOf(S.subsTab) >= 0) return S.subsTab;
  return activeTab();
}

/* 从磁盘重载一个已打开的标签；标签不在 / 是生成的 C++ 视图 → false */
async function reloadTabFromDisk(t) {
  if (!t || t.gen) return false;
  const i = S.tabs.indexOf(t);
  return (i >= 0) ? await aiReloadTab(i) : false;
}

/* 重读一次文件树（没开工程就不做；树读不出来也不影响函数列表） */
async function refreshTreeIfProject() {
  if (!S.project) return;
  try { await refreshTree(); } catch (e) { /* 忽略：工程可能刚被删 */ }
}

/* 「函数」栏的 ⟳：把**列表对应的那个源文件从磁盘重读一遍**，再重画列表，
   同时把工程栏的文件树也重读一次（两边都是从磁盘同步一次）。
   为什么必须读盘：renderSubs() 解析的是编辑框里的内存内容，文件被别的程序
   （或 AI、或 git 切分支）在磁盘上改过时，列表不会自己变 —— 以前点 ⟳ 只会
   把同样的内存内容再画一遍，看着像“刷新”其实没刷新。

   有未保存改动时先问一句，绝不静默丢内容：
     确定 = 先保存，再从磁盘重新载入；取消 = 不读盘，只按当前编辑框内容重画。 */
async function refreshSubsFromFile() {
  const t = subsSourceTab();
  if (!t) { toast('未打开文件'); renderSubs(); return; }
  if (t.gen) { renderSubs(); return; }        // 生成的 C++ 视图：没有可重载的源文件
  if (t.dirty && !t.readonly) {
    const ok = confirm('「' + t.path + '」有未保存的改动。\n\n'
      + '确定 = 先保存，再从磁盘重新载入\n取消 = 不读盘，只按当前编辑框内容刷新列表');
    if (!ok || !(await saveFile(t))) { renderSubs(); return; }
  }
  const ok = await reloadTabFromDisk(t);
  await refreshTreeIfProject();               // 同步：工程栏的文件树一起刷新
  renderSubs();
  toast(ok ? ('已重新载入 ' + t.path + '，函数列表与文件树已同步')
           : ('读盘失败，只按当前内容刷新了列表：' + t.path));
}

/* 工程栏 ⟳ 刷完树之后：把「函数」栏的源文件也从磁盘重载一遍（两个 ⟳ 效果一致）。
   有未保存改动时**不弹框**——刷新文件树不该打断操作，保留编辑框内容、只按它重画列表。
   @returns 给调用方 toast 的一句话 */
async function syncSubsAfterTreeRefresh() {
  const t = subsSourceTab();
  if (!t) { renderSubs(); return '已刷新文件树'; }
  if (t.gen) { renderSubs(); return '已刷新文件树'; }
  if (t.dirty && !t.readonly) {
    renderSubs();
    return '文件树已刷新；「' + t.path + '」有未保存改动，未覆盖编辑框内容';
  }
  const ok = await reloadTabFromDisk(t);
  renderSubs();
  return ok ? ('已刷新文件树，并重新载入 ' + t.path)
            : ('已刷新文件树；重新载入 ' + t.path + ' 失败');
}

/* SSE 事件分发 */
function aiHandleEvent(ev) {
  if (!ev || !ev.type) return;
  switch (ev.type) {
    case 'delta': aiDeltaAppend(ev.text || ''); break;
    case 'think': aiThinkAppend(ev.text || ''); break;
    case 'notice': aiAddSys(ev.text || ''); break;
    case 'tool_start': aiToolStart(ev); break;
    case 'tool_result': aiToolResult(ev); aiSetState('执行工具…', true); break;
    case 'context': aiRenderCtxRing(ev.prompt || 0, ev.ctx || 64256, ev.compactions || 0);
      if (ev.task) { aiRenderPlan({ task: ev.task }); aiUpdateStats(ev.task.metrics); }
      break;
    /* ---- 智能体框架新增事件（状态机 / 计划 / 技能 / 验证 / 恢复 / 人工确认） ---- */
    case 'state': aiStateChip(ev); break;
    case 'plan': aiRenderPlan(ev); if (ev.task) aiUpdateStats(ev.task.metrics); break;
    case 'skill': aiNote('🧩 <b>技能</b> ' + escHtml(ev.text || '')); break;
    case 'verify': aiShowVerify(ev); break;
    case 'recover': aiShowRecover(ev); break;
    case 'confirm': aiShowConfirm(ev); break;
    case 'ask': aiShowAsk(ev); break;
    case 'stats': aiUpdateStats(ev.stats); break;   // 每轮用量指标（首 token / tok/s / token 数）
    case 'trace': break;                     // Trace 概要只在服务端落盘，前端不渲染
    case 'done':
      if (AI.ansEl) { AI.ansEl.innerHTML = aiRender(AI.ansText); AI.ansEl = null; AI.ansText = ''; }
      aiThinkDone();
      aiSetState('完成', false);
      if (ev.task) aiUpdateStats(ev.task.metrics);   // 收尾：定住用时并显示结束时间
      aiFinalSync();          // 兜底：工程下拉 / 文件树 / 打开的标签页统一刷新
      break;
    case 'error':
      if (AI.ansEl) { AI.ansEl.innerHTML = aiRender(AI.ansText); AI.ansEl = null; AI.ansText = ''; }
      aiThinkDone();
      aiAddErr(ev.text || '未知错误');
      // 失败：给这条用户消息左侧加重试按钮；附件恢复待发列表（后端已回滚该消息）
      aiMarkRetryable(AI.restoreAtts);
      break;
  }
}

/* 会话恢复：页面加载 / 程序重启后，把服务端持久化的会话历史渲染回聊天区。
   服务端在 .temp/agent/session.json 自动保存，点「新会话」才清空。
   只做「显示层」恢复：user/assistant 气泡 + 折叠的工具卡片；
   【系统状态】等注入消息不显示（它们仍在上下文里起作用）。 */
async function aiRestoreHistory(base = -1) {
  try {
    const d = await api('GET', '/api/ai/history');
    let msgs = d.messages || [];
    // base >= 0：后端有回合在跑（重连恢复），只渲染本轮用户消息之前的历史；
    // 本轮已完成的步骤由 attach 重放的事件补上，避免重复渲染。
    if (base >= 0) msgs = msgs.slice(0, base);
    const box = $('aiMsgs');
    if (base >= 0 || msgs.length) box.innerHTML = '';    // 去掉欢迎页
    if (!msgs.length) return;
    const MAX = 80;
    if (msgs.length > MAX) {
      aiAddSys('（较早的 ' + (msgs.length - MAX) + ' 条历史未显示；完整上下文仍交给模型）');
    }
    for (const m of msgs.slice(-MAX)) {
      if (m.role === 'user') {
        let text = typeof m.content === 'string' ? m.content : '';
        if (!text && Array.isArray(m.content)) {
          text = m.content.filter((p) => p && p.type === 'text')
            .map((p) => p.text).join('\n') || '（图片消息）';
        }
        if (!text || text.indexOf('【系统状态】') === 0) continue;
        aiAddUser(text);
      } else if (m.role === 'assistant') {
        (m.tool_calls || []).forEach((c) => {
          const fn = c.function || {};
          let args = {};
          try {
            args = typeof fn.arguments === 'string' ? JSON.parse(fn.arguments) : (fn.arguments || {});
          } catch (e) { /* 参数解析失败就展示原始串 */ }
          const id = c.id || ('h' + Math.random());
          aiToolStart({ id, name: fn.name || 'tool', args });
          aiToolResult({ id, name: fn.name, ok: true, args,
            summary: fn.name || '工具调用', detail: '（历史记录）' });
        });
        const content = typeof m.content === 'string' ? m.content.trim() : '';
        if (content) {
          const el = aiBubble('ai', '');
          el.innerHTML = aiRender(content);
          aiAttachCopy(el.parentNode, () => content);
        }
      }
      // role === 'tool'：结果已并入上面的工具卡片，不单独渲染
    }
    aiScrollBottom();
  } catch (e) { /* 历史拉取失败：保持欢迎页 */ }
}

/* 刷新恢复进行中的回合：连 GET /api/ai/attach（SSE）。
   后端没有回合在跑 → 回 {"type":"idle"}，照旧走 aiRestoreHistory()；
   有回合在跑 → 回 {"type":"attach", base}：先按 base 截断渲染历史，再重放
   该回合全部事件并跟到结束——忙碌态 / 工具卡片 / 流式回答无缝续上。 */
async function aiReconnect() {
  let mode = '';                       // '' 未定 | 'idle' | 'attach' | 'ended'
  try {
    const resp = await fetch('/api/ai/attach');
    if (!resp.ok || !resp.body) { aiRestoreHistory(); return; }
    const reader = resp.body.getReader();
    const dec = new TextDecoder('utf-8');
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const line = frame.split('\n').find((l) => l.indexOf('data:') === 0);
        if (!line) continue;
        let ev;
        try { ev = JSON.parse(line.slice(5).trim()); } catch (e) { continue; }
        if (!mode) {
          if (ev.type === 'idle') { mode = 'idle'; aiRestoreHistory(); return; }
          if (ev.type === 'attach') {
            mode = 'attach';
            aiRestoreHistory(typeof ev.base === 'number' ? ev.base : -1);
            AI.busy = true;
            aiSetBusy(true);
            aiSetState('恢复任务…', true);
          }
          continue;
        }
        if (ev.type === 'attach' || ev.type === 'idle') continue;
        aiHandleEvent(ev);
        if (ev.type === 'done' || ev.type === 'error') { mode = 'ended'; break; }
      }
      if (mode === 'ended') break;
    }
  } catch (e) { /* 重连中断：历史已渲染，收尾走下面 */ }
  if (mode === 'attach' || mode === 'ended') {
    // 与 aiSend 的收尾一致：停表兜底、清工具卡映射、解锁输入框、刷新上下文环。
    // 注意不碰 AI.abort（重连流没有它）；停止按钮仍走 /api/ai/stop。
    aiStopStats();
    Object.keys(AI.tools).forEach((k) => { delete AI.tools[k]; });
    aiSetBusy(false);
    aiLoadCtx();
  }
}

/* 发送一条消息并流式接收智能体事件 */
async function aiSend() {
  if (AI.busy) {                        // 忙碌时按钮 = 停止
    // 先告诉后端置位取消事件（立刻打断模型流与工具执行，远程模型停止生成），
    // 再断开本条 SSE。只断 SSE 只是停止观看，回合会继续在后台跑完。
    try { await fetch('/api/ai/stop', { method: 'POST' }); } catch (e) { /* 忽略 */ }
    if (AI.abort) { try { AI.abort.abort(); } catch (e) { /* 忽略 */ } }
    // SSE 已断：收不到 finished 统计，本地停表把用时定住
    aiStopStats();
    return;
  }
  const ta = $('aiInput');
  const text = (ta.value || '').trim();
  if (!text && !AI.atts.length) return;   // 纯附件也能发送
  const attCount = AI.atts.length;
  ta.value = '';
  const sentText = text || '（请看附件）' + (attCount ? '（' + attCount + ' 个附件）' : '');
  const userWrap = aiAddUser(sentText);
  // 重试数据（原文本 + 附件快照；失败时给气泡左侧加重试按钮）
  const retryData = { text: sentText, atts: AI.atts.slice() };
  AI.lastUserWrap = userWrap;
  AI.lastRetry = retryData;
  AI.lastUserAtts = retryData.atts;       // 「复用上一条」要把粘贴的图片/附件一起复原
  AI.lastStateKey = '';
  aiSetBusy(true);
  aiSetState('连接 AI…', true);
  // 附带当前编辑器上下文（用户正在看的文件）+ 待发送附件
  const t = activeTab();
  const cur = (t && !t.gen && !t.readonly) ? t : null;
  const imgs = AI.atts.filter((a) => a.kind === 'img').map((a) => a.dataUrl);
  const files = AI.atts.filter((a) => a.kind === 'file').map((a) => ({
    name: a.name, b64: a.b64, size: a.size,
  }));
  const body = {
    message: text,
    project: S.project || '',
    curFile: cur ? cur.path : '',
    // 编辑器内容尽量完整上送（上限 20 万字符只是传输保护），
    // 真正的截断由服务端按运行时参数 ctxChars（0=按模型上下文窗口）执行
    curText: (cur && cur.content && cur.content.length <= 200000) ? cur.content : '',
    images: imgs,
    files,
  };
  const ctl = new AbortController();
  AI.abort = ctl;
  // 附件已随本条消息打包：清空待发送列表；失败时由 aiHandleEvent(error) 恢复
  const sentAtts = AI.atts.slice();
  if (AI.atts.length) { AI.atts = []; aiRenderAtts(); }
  AI.restoreAtts = sentAtts.length ? sentAtts : null;   // error 事件时回填附件
  aiLoadCtx();                       // 发送后刷新上下文环
  let resp;
  try {
    resp = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    if (!resp.body) throw new Error('浏览器不支持流式响应');
    const reader = resp.body.getReader();
    const dec = new TextDecoder('utf-8');
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const line = frame.split('\n').find((l) => l.indexOf('data:') === 0);
        if (!line) continue;
        try { aiHandleEvent(JSON.parse(line.slice(5).trim())); } catch (e) { /* 忽略坏帧 */ }
      }
    }
  } catch (e) {
    if (e && e.name === 'AbortError') {
      if (AI.ansEl) { AI.ansEl.innerHTML = aiRender(AI.ansText) + '\n（已停止）'; AI.ansEl = null; AI.ansText = ''; }
      aiThinkDone();
      if (!AI.sessionReset) aiAddSys('已停止');   // 已切到新会话：不再往聊天区塞残帧
    } else {
      if (AI.ansEl) { AI.ansEl.innerHTML = aiRender(AI.ansText); AI.ansEl = null; AI.ansText = ''; }
      aiThinkDone();
      if (!AI.sessionReset) {
        aiAddErr('AI 请求失败：' + e.message);
        aiMarkRetryable(AI.restoreAtts);
      }
    }
    aiFinalSync().catch(() => {});   // 同步 IDE（智能体可能改过文件），与聊天区无关
  }
  AI.abort = null;
  aiStopStats();     // done/error/断流统一兜底：停表（done 已带 finished 统计，此处幂等）
  Object.keys(AI.tools).forEach((k) => { delete AI.tools[k]; });
  AI.restoreAtts = null;             // 成功走完：不再需要恢复
  AI.lastUserWrap = null;
  AI.lastRetry = null;
  if (!AI.sessionReset) aiSetBusy(false);   // 新会话已自行置 busy=false，避免冲掉新会话的忙碌态
}

/* 发送失败：给最近一条用户消息左侧加重试按钮（并恢复附件到待发列表） */
function aiMarkRetryable(restoreAtts) {
  const wrap = AI.lastUserWrap;
  if (!wrap || wrap.querySelector('.aiRetryBtn')) return;
  const data = AI.lastRetry || { text: '', atts: [] };
  const btn = document.createElement('button');
  btn.className = 'aiRetryBtn';
  btn.textContent = '↻';
  btn.title = '重试：重新发送这条消息';
  btn.onclick = () => aiRetry(data);
  wrap.insertBefore(btn, wrap.firstChild);
  wrap.classList.add('failed');
  // 附件也恢复到待发列表（与重试数据一致；后端已回滚该消息）
  if (restoreAtts && restoreAtts.length && !AI.atts.length) {
    AI.atts = restoreAtts.slice();
    aiRenderAtts();
  }
}

/* ---------- 附件（图片 / 文件）与上下文环形进度圈 ---------- */

/* 读取 File → base64（去 dataURL 前缀） */
function aiFileToB64(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => {
      const s = String(fr.result || '');
      const i = s.indexOf(',');
      res(i >= 0 ? s.slice(i + 1) : s);
    };
    fr.onerror = () => rej(new Error('读取失败'));
    fr.readAsDataURL(file);
  });
}

/* 添加附件（图片或普通文件）到待发送列表并渲染标签 */
async function aiAddFiles(fileList, asImage) {
  const files = Array.from(fileList || []);
  for (const f of files) {
    try {
      const isImg = asImage || /^image\//.test(f.type || '');
      if (isImg) {
        if (f.size > 8 * 1024 * 1024) { toast('图片过大（>8MB）：' + f.name); continue; }
        const dataUrl = await new Promise((res, rej) => {
          const fr = new FileReader();
          fr.onload = () => res(String(fr.result || ''));
          fr.onerror = () => rej(new Error('读取失败'));
          fr.readAsDataURL(f);
        });
        AI.atts.push({ kind: 'img', name: f.name, dataUrl, size: f.size });
      } else {
        if (f.size > 2 * 1024 * 1024) { toast('附件过大（>2MB）：' + f.name); continue; }
        const b64 = await aiFileToB64(f);
        AI.atts.push({ kind: 'file', name: f.name, b64, size: f.size });
      }
    } catch (e) {
      toast('附件读取失败：' + f.name);
    }
  }
  aiRenderAtts();
}

function aiRemoveAtt(i) {
  AI.atts.splice(i, 1);
  aiRenderAtts();
}

function aiRenderAtts() {
  const box = $('aiAttachList');
  if (!box) return;
  box.innerHTML = '';
  AI.atts.forEach((a, i) => {
    const tag = document.createElement('span');
    tag.className = 'aiAttachItem' + (a.kind === 'img' ? ' isImg' : '');
    if (a.kind === 'img' && a.dataUrl) {
      // 图片附件：缩略图预览（点击放大）
      const thumb = document.createElement('img');
      thumb.className = 'attThumb';
      thumb.src = a.dataUrl;
      thumb.alt = a.name;
      thumb.title = '点击放大预览';
      thumb.onclick = (ev) => { ev.stopPropagation(); aiImageLightbox(a.dataUrl, a.name); };
      tag.appendChild(thumb);
    } else {
      const nm0 = document.createElement('span');
      nm0.className = 'attName attIco';
      nm0.textContent = a.kind === 'img' ? '🖼' : '📄';
      tag.appendChild(nm0);
    }
    const nm = document.createElement('span');
    nm.className = 'attName';
    nm.textContent = a.name;
    nm.title = a.name + '（' + fmtSize(a.size) + '）';
    const del = document.createElement('button');
    del.className = 'attDel';
    del.textContent = '×';
    del.title = '移除 ' + a.name;
    del.onclick = () => aiRemoveAtt(i);
    tag.appendChild(nm);
    tag.appendChild(del);
    box.appendChild(tag);
  });
}

/* ---------- 图片附件放大预览（轻量灯箱） ---------- */
function aiImageLightbox(dataUrl, name) {
  let box = document.getElementById('aiAttLightbox');
  if (!box) {
    box = document.createElement('div');
    box.id = 'aiAttLightbox';
    box.className = 'aiAttLightbox';
    const img = document.createElement('img');
    img.className = 'aiAttLightboxImg';
    img.alt = '附件预览';
    const cap = document.createElement('div');
    cap.className = 'aiAttLightboxCap';
    const close = document.createElement('button');
    close.className = 'aiAttLightboxClose';
    close.textContent = '×';
    close.title = '关闭预览';
    box.appendChild(img);
    box.appendChild(cap);
    box.appendChild(close);
    document.body.appendChild(box);
    const closeIt = () => {
      box.classList.remove('show');
      setTimeout(() => box.classList.remove('show'), 0);
      document.removeEventListener('keydown', onKey);
    };
    const onKey = (ev) => { if (ev.key === 'Escape') closeIt(); };
    box.onclick = () => closeIt();
    img.onclick = (ev) => ev.stopPropagation();
    close.onclick = () => closeIt();
  }
  const img = box.querySelector('.aiAttLightboxImg');
  img.src = dataUrl;
  box.querySelector('.aiAttLightboxCap').textContent = name || '图片预览';
  box.classList.add('show');
}

/* ---------- 智能体「指标条」：任务用时 / token 用量 / 结束时间 + 步骤与用量指标 ----------
   数据全部来自服务端实测值：stats 事件、task.metrics（来自模型接口的 usage / timings），
   不按字符数估算。见 server/agent/core/task.py 的 metrics_view()。 */
const AI_STATS = { m: null, at: 0, timer: 0 };

function fmtTok(n) {
  n = Number(n) || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(2) + 'M tok';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K tok';
  return n + ' tok';
}
function fmtDur(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0));
  if (s < 60) return s + ' s';
  const m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + (s % 60) + 's';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
}
function fmtClock(epochSec) {
  const d = epochSec ? new Date(epochSec * 1000) : new Date();
  const p = (n) => (n < 10 ? '0' + n : String(n));
  return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}
function aiSt(id, txt) { const el = $(id); if (el) el.textContent = txt; }

/* 跑动中每秒续走「任务用时」：服务端两次事件之间用本地时钟补齐，
   进度连续跳动，而不是每轮才跳一次。收尾后停表。 */
function aiTickStats() {
  const m = AI_STATS.m;
  if (!m || m.finished || !AI_STATS.at) return;
  aiSt('stTopElapsed', fmtDur(m.elapsed + (Date.now() - AI_STATS.at) / 1000));
}

function aiUpdateStats(m) {
  if (!m) return;
  AI_STATS.m = m;
  AI_STATS.at = Date.now();
  const inTok = Number(m.inTokens) || 0;
  const outTok = Number(m.outTokens) || 0;
  aiSt('stTopElapsed', fmtDur(m.elapsed));
  aiSt('stTopTokens', (inTok + outTok) ? fmtTok(inTok + outTok) : '—');
  aiSt('stSteps', (m.steps || 0) + (m.rounds ? ' / ' + m.rounds + ' 轮' : ''));
  aiSt('stFirstTok', m.firstTokenMs > 0 ? fmtDur(m.firstTokenMs / 1000) : '—');
  aiSt('stTps', m.tps > 0 ? m.tps + ' tok/s' : '—');
  aiSt('stCache', inTok ? (m.cachePct || 0) + '%' : '—');
  aiSt('stIn', inTok ? fmtTok(inTok) : '—');
  aiSt('stOut', outTok ? fmtTok(outTok) : '—');
  if (!AI_STATS.timer) AI_STATS.timer = setInterval(aiTickStats, 1000);
  if (m.finished && AI_STATS.timer) {           // 任务收尾：停表并定住用时
    clearInterval(AI_STATS.timer);
    AI_STATS.timer = 0;
  }
}

/* 停止 / 异常收尾：停掉跑动计时器并把「任务用时」定格在当前值。
   与 aiResetStats 不同：不清零指标——停止后仍想看到已用时间 / token 数。
   done 事件自带 finished 统计会正常停表；这条是断流 / 停止时的兜底。 */
function aiStopStats() {
  if (AI_STATS.timer) { clearInterval(AI_STATS.timer); AI_STATS.timer = 0; }
  const m = AI_STATS.m;
  if (m && !m.finished && AI_STATS.at) {
    m.finished = true;
    m.elapsed = m.elapsed + (Date.now() - AI_STATS.at) / 1000;
    aiSt('stTopElapsed', fmtDur(m.elapsed));
  }
  AI_STATS.at = 0;
}

/* 新会话 / 清空：把指标条（顶部用时·tok + 底部步骤·用量）全部清回「—」并停掉跑动计时器。
   聊天区内容由调用方自己清，这里只负责面板外的「会话态」指标。 */
function aiResetStats() {
  if (AI_STATS.timer) { clearInterval(AI_STATS.timer); AI_STATS.timer = 0; }
  AI_STATS.m = null;
  AI_STATS.at = 0;
  ['stTopElapsed', 'stTopTokens', 'stSteps', 'stFirstTok', 'stTps', 'stCache', 'stIn', 'stOut']
    .forEach((id) => aiSt(id, '—'));
}

/* 已使用上下文：环形进度圈（SVG 双环，中心百分比；≥70% 黄色、≥90% 红色）。
   compactions = 本会话已发生的上下文压缩次数（>0 时在圈旁显示徽标）。 */
function aiRenderCtxRing(prompt, ctxTotal, compactions) {
  const ring = $('aiCtxRing');
  const arc = $('ctxArc');
  const pct = $('aiCtxPct');
  if (!ring || !arc || !pct) return;
  const c = Math.max(1, ctxTotal || 64256);
  prompt = Math.min(Math.max(0, prompt), c);   // 与后端同口径：占用不超过窗口
  const ratio = Math.min(1, Math.max(0, prompt / c));
  const circ = 2 * Math.PI * 15.5;          // 周长 ≈ 97.4
  arc.setAttribute('stroke-dasharray', circ.toFixed(1));
  arc.setAttribute('stroke-dashoffset', (circ * (1 - ratio)).toFixed(1));
  const shown = Math.round(ratio * 100);
  pct.textContent = shown >= 100 ? '100' : shown + '';
  const n = Math.max(0, Math.floor(compactions || 0));
  const badge = $('aiCompactBadge');
  if (badge) {
    if (n > 0) { badge.hidden = false; badge.textContent = '已压缩 ' + n; }
    else { badge.hidden = true; badge.textContent = ''; }
  }
  ring.classList.toggle('compacted', n > 0);
  ring.title = '已使用上下文：约 ' + prompt + ' / ' + c + ' tok（' + shown + '%）'
    + (n > 0 ? '，已压缩 ' + n + ' 次' : '');
  ring.classList.toggle('warn', ratio >= 0.7 && ratio < 0.9);
  ring.classList.toggle('full', ratio >= 0.9);
}

async function aiLoadCtx() {
  try {
    const d = await api('GET', '/api/ai/context');
    if (d && d.ctx) aiRenderCtxRing(d.prompt || 0, d.ctx, d.compactions || 0);
  } catch (e) { /* 忽略 */ }
}

/* ---------- 接口设置 ---------- */

/* 全部接口方案（与后端 AI_MODES 一致：默认 + 三个自定义） */
const AI_MODES = ['default', 'custom1', 'custom2', 'custom3'];
const AI_MODE_LABEL = {
  default: '默认接口', custom1: '自定义接口 1', custom2: '自定义接口 2', custom3: '自定义接口 3',
};

function aiDraftCfg() {
  /* 把设置面板当前显示的字段暂存进 AI.cfg[AI.curMode]（草稿，未点保存不落盘） */
  if (!AI.cfg) AI.cfg = { mode: 'default', default: {}, custom1: {}, custom2: {}, custom3: {} };
  if (!AI.cfg[AI.curMode]) AI.cfg[AI.curMode] = {};
  AI.cfg[AI.curMode] = {
    url: $('aiUrl').value.trim(),
    model: $('aiModel').value.trim(),
    alias: $('aiAlias').value.trim(),
    key: $('aiKey').value,
  };
  if (!AI.stored) AI.stored = {};
  AI.stored[AI.curMode] = Object.assign({}, AI.cfg[AI.curMode]);   // 草稿也同步给模型列表
}

/* 只填字段与提示文字；方案下拉的选中状态由用户操作 / aiSyncModeSelect 管理，这里绝不回写 */
function aiFillCfgFields(which) {
  AI.curMode = which;
  // 只填「磁盘上真正保存的」数据：接口没配置过时字段就是空的，
  // 不拿内置默认值（DEFAULT_CFG）冒充用户填的内容。
  const c = AI.stored || {};
  const part = c[which] || {};
  $('aiUrl').value = part.url || '';
  $('aiModel').value = part.model || '';
  $('aiAlias').value = part.alias || '';
  $('aiKey').value = part.key || '';
  $('aiModeHint').textContent = which === 'default'
    ? '默认接口：内置本地大模型服务（OpenAI 兼容，可按需修改参数）'
    : (AI_MODE_LABEL[which] || which) + '：任意 OpenAI 兼容服务（地址 / 模型 / 密钥）';
}

function aiSyncModeSelect(mode) {
  const sel = $('aiModeSelect');
  if (sel && AI_MODES.indexOf(mode) >= 0) sel.value = mode;
}

/* 切换接口方案：先暂存当前方案的草稿，再显示另一方案（未保存的修改不丢） */
function aiSwitchMode(which) {
  if (AI.curMode !== which) aiDraftCfg();
  aiFillCfgFields(which);
}

async function aiLoadCfg() {
  try {
    const d = await api('GET', '/api/ai/config');
    AI.cfg = d.cfg || {};
    AI.stored = d.stored || {};      // 磁盘上真正保存的（没配置过的接口是空的）
    // 设置面板正开着时同步显示；否则等用户打开时再填
    const box = $('aiCfg');
    if (box && !box.classList.contains('hidden')) {
      const which = AI_MODES.indexOf(AI.cfg.mode) >= 0 ? AI.cfg.mode : 'default';
      aiSyncModeSelect(which);
      aiFillCfgFields(which);
    }
    aiRefreshModels();
  } catch (e) { /* 后端未就绪时保持默认 */ }
}

async function aiSaveCfg() {
  aiDraftCfg();                                   // 当前方案字段并入 cfg
  const mode = AI.curMode;
  const cur = AI.cfg[mode] || {};
  const cfg = JSON.parse(JSON.stringify(AI.cfg
    || { mode, default: {}, custom1: {}, custom2: {}, custom3: {} }));
  cfg.mode = mode;
  if (mode !== 'default' && !cur.url) { toast('自定义接口需要填写 API 地址'); return; }
  try {
    // 只提交当前方案的变更，避免内存里的陈旧状态覆盖磁盘上其它方案
    const d = await api('POST', '/api/ai/config', { mode, [mode]: cfg[mode] });
    AI.cfg = d.cfg || cfg;
    if (d.stored) AI.stored = d.stored;
    aiRefreshModels();
    toast('已保存：「' + (AI_MODE_LABEL[mode] || mode) + '」'
      + (mode !== 'default' && !cur.key ? '（提醒：密钥为空，调用可能被拒绝）' : ''));
  } catch (e) {
    toast('保存失败：' + e.message);
  }
}

async function aiTestConnect() {
  const out = $('aiTestResult');
  out.className = 'aiTestResult';
  out.textContent = '正在测试连接…';
  // 测试当前显示的这组参数（方案下拉 + 字段所见即所测）
  const mode = AI.curMode;
  const cur = { url: $('aiUrl').value.trim(), model: $('aiModel').value.trim(), key: $('aiKey').value };
  try {
    // 后端按这里传的方案与字段来测（所见即所测），不是磁盘上当前生效的那个接口
    const d = await api('POST', '/api/ai/test', { mode, [mode]: cur });
    const t = d.tested || {};
    const who = (AI_MODE_LABEL[mode] || mode) + (t.model ? ' · ' + t.model : '');
    if (d.ok) {
      out.className = 'aiTestResult ok';
      out.textContent = '✓ ' + who + ' 连接成功（' + (d.ms || 0) + ' ms）'
        + (d.models && d.models.length ? '，可用模型：' + d.models.slice(0, 5).join('、') : '');
    } else {
      out.className = 'aiTestResult err';
      out.textContent = '✗ ' + who + ' 连接失败：' + (d.note || '未知原因');
    }
  } catch (e) {
    out.className = 'aiTestResult err';
    out.textContent = '✗ 测试失败：' + e.message;
  }
}

/* ---------- 智能体设置对话框（接口 + 全部运行时参数） ---------- */

/* 运行时参数的分组与字段说明（与 server/agent/config.py DEFAULT_RUNTIME 一一对应）。
   type: num=数字输入 / sel=下拉 / chk=复选框；opts 为下拉的 [值, 显示文字]。 */
const AI_RT_GROUPS = [
  { title: '预算 / 停止条件', items: [
    { k: 'maxSteps', label: '最大步骤数', type: 'num', hint: '一个任务内最多「模型轮次」（当前版本仅记录，dsh 运行时自己管步数与预算）' },
    { k: 'maxToolCalls', label: '最大工具调用', type: 'num', hint: '一个任务内最多工具调用次数（当前版本仅记录，dsh 运行时自己管步数与预算）' },
    { k: 'maxSeconds', label: '时间上限（秒）', type: 'num', hint: '一个任务的墙钟时间上限（当前版本仅记录，dsh 运行时自己管步数与预算）' },
    { k: 'maxConsecutiveFailures', label: '连续失败阈值', type: 'num', hint: '连续失败几次后停下来问用户（当前版本仅记录，dsh 运行时自己管步数与预算）' },
    { k: 'maxRetriesPerTool', label: '单工具重试次数', type: 'num', hint: '单个工具失败后的最大重试次数（当前版本仅记录，dsh 运行时自己管步数与预算）' },
  ]},
  { title: '上下文 · 输入', items: [
    { k: 'ctxTokens', label: '上下文窗口（tok）', type: 'num', hint: '输入上下文的容量上限（进度圈的满格线）；0 = 按当前模型自动探测（推荐）。填小可以逼着每轮少发历史，明显加快响应' },
    { k: 'historyKeep', label: '历史保留条数', type: 'num', hint: '会话历史保留条数（超过从最早裁剪）。设得很大等于不裁剪，每轮都要重发全部历史，会越来越慢' },
    { k: 'ctxChars', label: '编辑框内容上限（字符）', type: 'num', hint: '当前编辑器内容注入上下文的字符上限；0 = 用默认 20000 字符' },
    { k: 'toolResultChars', label: '结果回填上限（字符）', type: 'num', hint: '回填给模型的单条工具结果字符数上限' },
    { k: 'toolResultKeepChars', label: '旧结果压缩保留（字符）', type: 'num', hint: '历史里旧工具结果压缩后的保留长度' },
  ]},
  { title: '上下文 · 输出', items: [
    { k: 'maxOutputTokens', label: '输出上限（tok）', type: 'num', hint: '单次回复的最大输出 tok 数（≈ 1 tok 1~2 个汉字）；0 = 不限制，由接口自己的默认值决定' },
  ]},
  { title: '上下文压缩', items: [
    { k: 'ctxCompaction', label: '自动压缩历史', type: 'chk', hint: '上下文占用达到阈值时，自动把较老的历史压缩成摘要（dsh compaction-basic），长任务不再撑爆窗口' },
    { k: 'ctxCompactThreshold', label: '触发阈值（% 窗口）', type: 'num', hint: '上下文占用达到窗口的这个百分比时触发压缩；0 = 用后端默认（80%）' },
    { k: 'ctxCompactRetain', label: '保留近期（% 窗口）', type: 'num', hint: '压缩时原样保留的近期历史占比（必须小于触发阈值，超了会被自动夹住）；0 = 用后端默认（16%）' },
  ]},
  { title: 'PTC 程序化工具调用', items: [
    { k: 'toolsMode', label: '工具呈现模式', type: 'sel', hint: 'native=逐个原生调用 / ptc=只给 run_code 让模型写程序组合调用（执行 Python）/ both=同时呈现',
      opts: [['native', 'native：原生逐个调用'], ['ptc', 'ptc：程序化调用（run_code）'], ['both', 'both：两者同时']] },
    { k: 'ptcTimeoutMs', label: '程序预算（毫秒）', type: 'num', hint: '单次 PTC 程序的时间预算，0=用后端默认值（120 秒）' },
    { k: 'ptcSandboxMode', label: 'PTC 沙箱', type: 'sel', hint: 'PTC 程序发起的子调用允许的写入范围',
      opts: [['read-only', 'read-only：只读'], ['workspace-write', 'workspace-write：工程内可写']] },
    { k: 'maxParallelSubCalls', label: '并行工具调用上限', type: 'num', hint: '每一轮模型发出多条原生工具调用时的并行执行上限（1=逐个执行）；PTC 程序内部的 tools.*() 是顺序执行，不受此项限制' },
  ]},
  { title: '记忆（当前版本仅记录：dsh 尚无对应能力，开了也不会注入）', items: [
    { k: 'memoryEnabled', label: '启用记忆', type: 'chk', hint: '往期任务摘要与稳定知识自动注入上下文（当前版本仅记录）' },
    { k: 'semanticTopK', label: '知识注入条数', type: 'num', hint: '注入上下文的稳定知识条数（当前版本仅记录）' },
    { k: 'episodicTopK', label: '往期任务条数', type: 'num', hint: '注入上下文的往期任务条数（当前版本仅记录）' },
  ]},
  { title: '安全', items: [
    { k: 'sandboxEnabled', label: '启用沙箱', type: 'chk', hint: '关闭后不做命令黑名单/路径越界检查（不建议）' },
    { k: 'approveDestructive', label: '高危动作需确认', type: 'chk', hint: '删除、强推等破坏性操作先问用户' },
    { k: 'approveNetwork', label: '网络访问需授权', type: 'chk', hint: '首次访问外部地址时请求授权' },
    { k: 'allowNetwork', label: '允许网络工具', type: 'chk', hint: '关掉则完全禁用网络类工具' },
    { k: 'allowExecute', label: '允许执行命令', type: 'chk', hint: '关掉则完全禁用命令/脚本类工具' },
    { k: 'writeInsideProjectOnly', label: '写操作仅限工程内', type: 'chk', hint: '文件写入只允许落在当前工程目录内' },
    { k: 'allowAll', label: '全部放行（免确认）', type: 'chk', hint: '开启后所有超出沙箱自动放行范围的动作都自动批准，不再逐个弹确认卡；在确认卡点「全部放行」也会打开它。取消勾选即可关闭（持久化，所有窗口/新会话生效）。' },
    { k: 'thinkIntensity', label: '思考强度', type: 'sel', hint: '控制智能体与模型的思考深度：关闭=直接回答；低=最简方案；中=权衡后行动（默认）；高=逐步推理并自检。作用于模型推理档位与智能体行为',
      opts: [['off', '关闭（直接回答）'], ['low', '低'], ['medium', '中（默认）'], ['high', '高']] },
  ]},
  { title: '可观测性', items: [
    { k: 'traceEnabled', label: '启用 Trace', type: 'chk', hint: '记录每步工具调用的结构化轨迹' },
    { k: 'logLevel', label: '日志级别', type: 'sel', hint: '结构化日志的详细程度',
      opts: [['off', 'off'], ['error', 'error'], ['warn', 'warn'], ['info', 'info'], ['debug', 'debug']] },
  ]},
  { title: 'Multi-Agent', items: [
    { k: 'multiAgentEnabled', label: '启用多智能体', type: 'chk', hint: '允许主智能体派出子智能体并行干活（默认关）' },
    { k: 'maxSubAgents', label: '子智能体上限', type: 'num', hint: '同时存活的子智能体数量上限（当前版本仅记录，dsh 子智能体并发由自身调度器管理）' },
  ]},
  { title: '运维', items: [
    { k: 'attachmentsMaxImageMB', label: '图片附件上限（MB）', type: 'num', hint: '上传图片的单个大小上限' },
    { k: 'attachmentsMaxFileMB', label: '文件附件上限（MB）', type: 'num', hint: '上传附件的单个大小上限' },
    { k: 'aiTimeout', label: '模型请求超时（秒）', type: 'num', hint: '单次调用大模型接口的超时时间' },
  ]},
];

/* 渲染运行时参数表单；每个控件的引用挂到 wrap._rt[k]，保存时统一收集 */
function aiRenderRuntimeGroups(wrap, rt) {
  wrap.innerHTML = '';
  wrap._rt = {};
  AI_RT_GROUPS.forEach((g) => {
    const gt = document.createElement('div');
    gt.className = 'aiRtGroupTitle';
    gt.textContent = g.title;
    wrap.appendChild(gt);
    const grid = document.createElement('div');
    grid.className = 'aiRtGrid';
    g.items.forEach((it) => {
      const row = document.createElement('div');
      row.className = 'aiRtItem' + (it.type === 'chk' ? ' aiRtChk' : '');
      const lab = document.createElement('label');
      lab.textContent = it.label;
      row.title = it.hint || '';
      row.appendChild(lab);
      let el;
      if (it.type === 'chk') {
        el = document.createElement('input');
        el.type = 'checkbox';
        el.checked = !!rt[it.k];
      } else if (it.type === 'sel') {
        el = document.createElement('select');
        (it.opts || []).forEach((pair) => {
          const op = document.createElement('option');
          op.value = pair[0];
          op.textContent = pair[1];
          el.appendChild(op);
        });
        // 显式按 option.value 匹配选中项，不依赖 select.value 的读写在各渲染内核下的一致性
        // （否则某些内核 select.value 取的是文本，匹配失败会回退到第一项「关闭」）。
        const sv = String(rt[it.k] !== undefined ? rt[it.k] : '');
        let _idx = -1;
        for (let _i = 0; _i < el.options.length; _i++) {
          if (el.options[_i].value === sv) { _idx = _i; break; }
        }
        el.selectedIndex = _idx >= 0 ? _idx : 0;
        // 选中值直接缓存到 el._rtVal：某些内核 select.value 取的是文本、且 selectedIndex 可能不随下拉更新，
        // 收集时若读到文本就写错值（回退成第一项「关闭」）。onchange 时把 option.value 记下来最稳。
        el._rtVal = _idx >= 0 ? el.options[_idx].value : (el.options[0] ? el.options[0].value : '');
        el.onchange = () => {
          for (let _i = 0; _i < el.options.length; _i++) {
            if (el.options[_i].selected) { el._rtVal = el.options[_i].value; return; }
          }
        };
      } else {
        el = document.createElement('input');
        el.type = 'number';
        el.dataset.num = '1';
        el.value = rt[it.k] !== undefined && rt[it.k] !== null ? String(rt[it.k]) : '';
      }
      row.appendChild(el);
      wrap._rt[it.k] = el;
      grid.appendChild(row);
    });
    wrap.appendChild(grid);
  });
  const note = document.createElement('div');
  note.className = 'aiRtNote';
  note.textContent = '参数保存在 config/agent.json，保存后立即生效；接口配置保存在 config/ai_agent.json。';
  wrap.appendChild(note);
}

/* 收集运行时表单并保存。数字留空=保持原值；类型按声明转换（后端按类型校验，类型不对会被忽略） */
async function aiSaveRuntime() {
  const wrap = $('aiRtWrap');
  if (!wrap || !wrap._rt) return;
  const payload = {};
  Object.keys(wrap._rt).forEach((k) => {
    const el = wrap._rt[k];
    if (el.type === 'checkbox') {
      payload[k] = el.checked;
    } else if (el.options && el.options.length) {
      // 优先用下拉项 onchange 时缓存的 option.value（el._rtVal），避免内核 select.value 取文本导致写错值
      payload[k] = (el._rtVal !== undefined && el._rtVal !== '')
        ? el._rtVal
        : (el.options[el.selectedIndex] ? el.options[el.selectedIndex].value : el.value);
    } else if (el.dataset && el.dataset.num === '1') {
      const v = String(el.value).trim();
      if (v !== '') payload[k] = Number(v);      // 留空 = 不动这项
    } else {
      payload[k] = el.value;
    }
  });
  try {
    const d = await api('POST', '/api/ai/runtime', { runtime: payload });
    toast('运行时参数已保存');
    aiRenderRuntimeGroups(wrap, d.runtime || {});
  } catch (e) {
    toast('保存参数失败：' + e.message);
  }
}

/* 关闭智能体设置对话框：把接口面板放回 AI 面板原位（恢复收起状态） */
function closeAgentSettings() {
  const box = $('aiCfg');
  const panel = $('aiPanel');
  if (box && panel && box.parentElement !== panel) {
    const head = panel.querySelector('.aiHead');
    if (head) panel.insertBefore(box, head.nextSibling);
    else panel.appendChild(box);
  }
  if (box) box.classList.add('hidden');
  $('modalMask').classList.add('hidden');
}

/* 点 AI 面板的 ⚙ 按钮：弹出对话框 = 接口设置（复用现有 aiCfg 面板节点）
   + 全部运行时参数（GET/POST /api/ai/runtime） */
async function openAgentSettings() {
  setModalWide(true);
  $('modalHead').textContent = 'AI 智能体设置';
  const body = $('modalBody');
  /* 先抓住接口面板的引用再清空弹窗体：它可能还留在上一次的弹窗里 */
  const cfgBox = $('aiCfg');
  body.innerHTML = '';
  const head = document.createElement('div');
  head.className = 'aiRtGroupTitle';
  head.textContent = '接口（OpenAI 兼容）';
  body.appendChild(head);
  if (cfgBox) {
    cfgBox.classList.remove('hidden');
    body.appendChild(cfgBox);
  }
  const rtHead = document.createElement('div');
  rtHead.className = 'aiRtGroupTitle';
  rtHead.textContent = '运行时参数';
  body.appendChild(rtHead);
  const wrap = document.createElement('div');
  wrap.id = 'aiRtWrap';
  wrap.className = 'aiRtWrap';
  wrap.innerHTML = '<div class="aiRtLoading">正在加载运行时参数…</div>';
  body.appendChild(wrap);
  const foot = $('modalFoot');
  foot.innerHTML = '';
  const mkBtn = (label, fn, accent) => {
    const b = document.createElement('button');
    b.textContent = label;
    if (accent) b.className = 'accent';
    b.onclick = fn;
    foot.appendChild(b);
    return b;
  };
  mkBtn('✗ 关闭', closeAgentSettings).style.marginRight = 'auto';
  mkBtn('保存参数', aiSaveRuntime, true);
  $('modalMask').classList.remove('hidden');
  /* 接口字段按已保存配置回显（与原面板打开时的行为一致） */
  const which = (AI.cfg && AI_MODES.indexOf(AI.cfg.mode) >= 0) ? AI.cfg.mode : 'default';
  aiSyncModeSelect(which);
  aiFillCfgFields(which);
  /* 拉运行时参数 */
  try {
    const d = await api('GET', '/api/ai/runtime');
    aiRenderRuntimeGroups(wrap, d.runtime || {});
  } catch (e) {
    wrap.innerHTML = '<div class="aiRtLoading">运行时参数加载失败：' + escHtml(e.message) + '</div>';
  }
}

/* ---------- 模型选择（发送按钮左侧，向上弹出的自定义下拉） ---------- */

/* 刷新模型下拉选项：只显示各接口方案里配置的模型（别名优先，跨方案带标注），
   不拉取接口的实时模型列表（「测试连接」看到的模型仅作文字提示，不进这里）。
   选中即整套切换接口方案并保存生效。 */
function aiRefreshModels() {
  const menu = $('aiModelMenu');
  if (!menu) return;
  const cfg = AI.stored || {};              // 只列「真正配置过」的接口
  const mode0 = (AI.cfg || {}).mode;        // 当前生效方案仍以保存的配置为准
  const activeMode = AI_MODES.indexOf(mode0) >= 0 ? mode0 : 'default';
  const activeModel = (cfg[activeMode] || {}).model || '';
  const entries = [];                       // {mode, model}
  const seen = {};
  AI_MODES.forEach((m) => {
    const part = cfg[m] || {};
    // 地址与模型都填了才算「有数据」：接口数据为空 → 不显示它的模型
    if (!(part.url || '').trim()) return;
    const model = (part.model || '').trim();
    if (!model) return;
    const key = m + '|' + model;
    if (!seen[key]) { seen[key] = 1; entries.push({ mode: m, model }); }
  });
  // 渲染选项：优先显示模型别名（设置里可配），无别名显示模型名
  const dispName = (mode, model) => {
    const part = (AI.stored || {})[mode] || {};
    return (part.alias || '').trim() || model;
  };
  menu.innerHTML = '';
  let activeVal = '';
  entries.forEach((e) => {
    const item = document.createElement('div');
    item.className = 'aiModelItem';
    item.dataset.value = e.mode + '|' + e.model;
    const name = dispName(e.mode, e.model);
    // 跨方案的模型带方案标注，当前方案的直接显示名字
    item.innerHTML = '<span class="miCheck"></span>'
      + '<span class="miName">' + escHtml(name)
      + (e.mode !== activeMode
        ? '<span class="miTag">（' + escHtml(AI_MODE_LABEL[e.mode]) + '）</span>' : '')
      + '</span>';
    if (e.mode === activeMode && e.model === activeModel) {
      item.classList.add('active');
      item.querySelector('.miCheck').textContent = '✓';
      activeVal = item.dataset.value;
    }
    item.onclick = () => { aiCloseModelMenu(); aiPickModel(item.dataset.value); };
    menu.appendChild(item);
  });
  if (!entries.length) {
    const item = document.createElement('div');
    item.className = 'aiModelItem miEmpty';
    item.textContent = dispName(activeMode, activeModel) || '（未配置模型）';
    menu.appendChild(item);
  }
  // 触发按钮显示当前模型（别名优先）
  const label = $('aiModelName');
  if (label) {
    label.textContent = dispName(activeMode, activeModel)
      || (activeMode !== 'default' ? AI_MODE_LABEL[activeMode] : '未配置模型');
    label.title = (cfg[activeMode] || {}).model || '';
  }
}

/* 菜单开/关（向上弹出；点外部关闭） */
function aiCloseModelMenu() {
  const menu = $('aiModelMenu');
  const btn = $('aiModelBtn');
  if (menu) menu.classList.add('hidden');
  if (btn) btn.classList.remove('open');
}

function aiToggleModelMenu() {
  const menu = $('aiModelMenu');
  if (!menu) return;
  const opening = menu.classList.contains('hidden');
  aiCloseModelMenu();
  if (opening) {
    menu.classList.remove('hidden');
    $('aiModelBtn').classList.add('open');
    const act = menu.querySelector('.aiModelItem.active');
    if (act) act.scrollIntoView({ block: 'nearest' });
  }
}

/* 选择模型：跨方案 → 整套切换；当前方案 → 只换模型。均立即保存生效 */
async function aiPickModel(val) {
  if (!val) return;
  const bar = val.indexOf('|');
  if (bar < 0) return;
  const mode = val.slice(0, bar);
  const model = val.slice(bar + 1);
  if (AI_MODES.indexOf(mode) < 0) return;
  if (!AI.cfg) AI.cfg = {};
  if (!AI.cfg[mode]) AI.cfg[mode] = {};
  // 设置面板正开着且要切方案：先暂存草稿再切换显示
  const box = $('aiCfg');
  if (box && !box.classList.contains('hidden') && mode !== AI.curMode) {
    aiDraftCfg();
    aiFillCfgFields(mode);
  }
  AI.cfg.mode = mode;
  AI.cfg[mode].model = model;
  try {
    // 只提交目标方案的变更，避免内存里的陈旧状态覆盖磁盘上其它方案
    const d = await api('POST', '/api/ai/config', { mode, [mode]: AI.cfg[mode] });
    AI.cfg = d.cfg || AI.cfg;
    if (d.stored) AI.stored = d.stored;
    // 切换成功不弹提示（模型名就显示在下拉按钮上，不用再提示一次）
  } catch (e) {
    toast('模型切换失败：' + e.message);      // 只有真的失败才提示
  }
  aiRefreshModels();
}

/* ---------- 智能体字号（免责行右侧 ＋/－ 调节，保存到 localStorage） ---------- */
const AI_FONT_KEY = 'yyAiFontSize';
let aiFont = 13;                  // 当前字号（px），与控制台默认一致
function applyAiFont() {
  document.documentElement.style.setProperty('--ai-font', aiFont + 'px');
  const lab = $('aiFontSizeLabel');
  if (lab) lab.textContent = aiFont;
}
function initAiFont() {
  let f = 13;
  try {
    const v = parseInt(localStorage.getItem(AI_FONT_KEY), 10);
    if (v >= 9 && v <= 32) f = v;
  } catch (e) { /* 忽略 */ }
  aiFont = f;
}
function adjustAiFont(delta) {
  let f = aiFont + delta;
  if (f < 9) f = 9;
  if (f > 32) f = 32;
  aiFont = f;
  applyAiFont();
  saveFontPref('ai', AI_FONT_KEY, f);
}

/* ---------- 输入框：粘贴图片 / 富文本 / 右键菜单 / 格式化文本 ---------- */

/* 在光标处插入文本（替换当前选区），并触发 input 同步 */
function aiInsertText(ta, text) {
  ta.focus();
  ta.setRangeText(text, ta.selectionStart, ta.selectionEnd, 'end');
  ta.dispatchEvent(new Event('input', { bubbles: true }));
}

/* 轻度清洗（保持结构，不破坏代码缩进）：
   CRLF 归一、不间断空格→普通空格、去除零宽字符与软连字符 */
function aiCleanText(s) {
  return String(s || '')
    .replace(/\r\n?/g, '\n')
    .replace(/\u00a0/g, ' ')
    .replace(/[\u200b\u200c\u200d\ufeff\u00ad]/g, '');
}

/* 去格式化（右键菜单「格式化文本」用）：
   在轻度清洗基础上，全角空格→普通空格、连续空白折叠、行首尾去空、空行压缩 */
function aiDeformatText(s) {
  return aiCleanText(s)
    .replace(/\u3000/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/* HTML 剪贴板 → 干净文本：块级元素转行、<br> 转换行；保留代码缩进（只做轻度清洗） */
function aiHtmlToText(html) {
  const d = document.createElement('div');
  d.innerHTML = String(html || '');
  d.querySelectorAll('script,style,noscript').forEach((n) => n.remove());
  d.querySelectorAll('br').forEach((br) => br.replaceWith('\n'));
  d.querySelectorAll('p,div,li,tr,h1,h2,h3,h4,h5,h6,pre,blockquote,table,ul,ol')
    .forEach((b) => b.appendChild(document.createTextNode('\n')));
  return aiCleanText(d.textContent || '').trim();
}

/* 粘贴事件：剪贴板图片 → 添加为图片附件；只有 HTML 的富文本 → 提取干净文本插入；
   其余（普通纯文本）走浏览器默认粘贴 */
function aiBindPaste(ta) {
  ta.addEventListener('paste', (e) => {
    const cd = e.clipboardData;
    if (!cd) return;
    // ① 剪贴板里的图片（截图 / 复制的图片）→ 图片附件
    const imgs = [];
    const items = cd.items || [];
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (it.kind === 'file' && it.type && it.type.startsWith('image/')) {
        const f = it.getAsFile();
        if (f) imgs.push(f);
      }
    }
    if (imgs.length) {
      aiAddFiles(imgs, true);
      toast('已添加 ' + imgs.length + ' 张图片附件，随下一条消息发送');
      // 剪贴板同时有文本时（如网页里连图带字复制）让默认粘贴继续插入文本
      if (!cd.getData('text/plain')) e.preventDefault();
      return;
    }
    // ② 带格式的文本：无纯文本、只有 HTML 时，从 HTML 提取（块级转行）
    if (!cd.getData('text/plain')) {
      const html = cd.getData('text/html');
      if (html) {
        e.preventDefault();
        aiInsertText(ta, aiHtmlToText(html));
      }
    }
    // ③ 普通纯文本：默认粘贴（保持原样，缩进不破坏）
  });
}

/* 右键菜单「粘贴」：读系统剪贴板（图片→附件；文本→插入）；无权限时提示 Ctrl+V */
async function aiMenuPaste() {
  const ta = $('aiInput');
  try {
    if (navigator.clipboard && navigator.clipboard.read) {
      const items = await navigator.clipboard.read();
      const imgs = [];
      let text = '';
      for (const item of items) {
        const imgType = (item.types || []).find((t) => t.startsWith('image/'));
        if (imgType) {
          const blob = await item.getType(imgType);
          const ext = (imgType.split('/')[1] || 'png').split('+')[0];
          imgs.push(new File([blob], '剪贴板图片.' + ext, { type: imgType }));
        } else if ((item.types || []).indexOf('text/plain') >= 0) {
          text = await (await item.getType('text/plain')).text();
        }
      }
      if (imgs.length) {
        aiAddFiles(imgs, true);
        toast('已添加 ' + imgs.length + ' 张图片附件，随下一条消息发送');
      }
      if (text) aiInsertText(ta, aiCleanText(text));
      if (!imgs.length && !text) toast('剪贴板没有可粘贴的内容');
      return;
    }
  } catch (err) { /* 权限被拒 / 接口不可用 → 提示手动粘贴 */ }
  ta.focus();
  toast('无法直接读取剪贴板，请在输入框中按 Ctrl+V 粘贴');
}

/* 右键菜单「格式化文本」：有选区 → 去格式化选区；无选区 → 去格式化整个输入框 */
function aiDeformatInput() {
  const ta = $('aiInput');
  ta.focus();
  const s = ta.selectionStart, e = ta.selectionEnd;
  if (s !== e) {
    ta.setRangeText(aiDeformatText(ta.value.slice(s, e)), s, e, 'select');
  } else if (ta.value) {
    ta.value = aiDeformatText(ta.value);
    ta.setSelectionRange(ta.value.length, ta.value.length);
  } else {
    toast('输入框没有内容');
    return;
  }
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  toast('已去除文本格式（清理空格/空行/特殊空白字符）');
}

/* 输入框右键菜单：复制 / 剪切 / 粘贴 / 全选 / 格式化文本 */
function aiShowInputMenu(e) {
  const ta = $('aiInput');
  const sel = ta.selectionStart !== ta.selectionEnd;
  const selText = sel ? ta.value.slice(ta.selectionStart, ta.selectionEnd) : '';
  const items = [];
  if (sel) {
    items.push({ label: '复制', act: () => copyText(selText) });
    items.push({
      label: '剪切',
      act: () => {
        copyText(selText);
        ta.focus();
        ta.setRangeText('', ta.selectionStart, ta.selectionEnd, 'end');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      },
    });
  }
  items.push({ label: '粘贴', act: () => { aiMenuPaste(); } });
  if (ta.value) items.push({ label: '全选', act: () => { ta.focus(); ta.select(); } });
  items.push({ sep: true });
  items.push({
    label: sel ? '格式化所选文本（去格式）' : '格式化文本（去格式）',
    act: () => aiDeformatInput(),
  });
  showContextMenu(e, items);
}

/* ---------- 初始化 ---------- */

function aiInit() {
  $('btnAI').onclick = () => aiToggle();
  $('aiStub').onclick = () => aiToggle(true);
  $('aiBtnClose').onclick = () => aiToggle(false);
  $('aiBtnSend').onclick = aiSend;
  // 输入框左侧按钮：把上一条已发送的消息放回输入框
  if ($('aiBtnReuse')) $('aiBtnReuse').onclick = aiReuseLast;
  // 快捷提示词按钮：弹出 prompts.json 列表；点面板外/再点按钮/失焦/Esc 关闭
  if ($('aiBtnPrompts')) {
    $('aiBtnPrompts').onclick = (e) => { e.stopPropagation(); aiTogglePromptMenu(); };
    document.addEventListener('mousedown', (e) => {
      const menu = $('aiPromptMenu');
      const btn = $('aiBtnPrompts');
      if (menu && btn && !menu.contains(e.target) && !btn.contains(e.target)) aiClosePromptMenu();
    });
    const pMenu = $('aiPromptMenu');
    if (pMenu) {
      // 失焦自动关闭：焦点从菜单/按钮内移到外面（如点击了不可聚焦区域）就收起
      pMenu.addEventListener('focusout', (e) => {
        const to = e.relatedTarget;
        const btn = $('aiBtnPrompts');
        if (!pMenu.contains(to) && !(btn && btn.contains(to))) aiClosePromptMenu();
      });
      pMenu.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { e.stopPropagation(); aiClosePromptMenu(); }
      });
    }
  }
  $('aiBtnNew').onclick = async () => {
    // 1) 先断开可能在跑的任务（SSE 流），避免它继续往会话里写
    if (AI.busy && AI.abort) { try { AI.abort.abort(); } catch (e) { /* 忽略 */ } }
    // 2) 立刻把会话态切到「新会话」——不再 await 后端 clear：后端 clear 要拿 SS.LOCK，
    //    而运行中任务（stream_chat 全程持锁）在「下一次写流」才察觉断连并解锁，这段
    //    等待会让界面几百毫秒~几秒毫无反应，表现为「点了新会话卡住 / 加载不出来」。
    AI.busy = false; AI.abort = null;
    AI.ansEl = null; AI.thinkEl = null; AI.ansText = ''; AI.thinkText = '';
    AI.sessionReset = true;            // 抑制被中断任务随后可能到达的「已停止」残帧
    $('aiMsgs').innerHTML = '<div class="aiWelcome">'
      + '<div class="aiWelcomeTitle">🤖 云易 IDE 智能体</div>'
      + '<div>新会话已开始。我能操作这个 IDE 的全部功能：新建工程、读写代码、编译、运行、测试，并根据报错自主修复。</div></div>';
    aiResetStats();               // 清空任务指标条（用时 / tok / 步骤 / 用量）并停表
    aiSetState('就绪', false);
    aiLoadCtx();                  // 重新拉上下文用量，进度圈回到基线
    toast('已开始新会话');
    // 3) 后端清空 best-effort（不阻塞界面）：被会话锁挡住时，旧任务流断开后会自动完成；
    //    即便清空晚到一瞬，新会话视图此刻已经就绪，不会再有「加载不出来」的卡顿。
    api('POST', '/api/ai/clear', {}).catch(() => {});
    setTimeout(() => { AI.sessionReset = false; }, 600);
  };
  $('aiBtnCfg').onclick = openAgentSettings;
  $('aiModeSelect').onchange = () => aiSwitchMode($('aiModeSelect').value);
  // 模型选择：点按钮向上弹出菜单；点面板外/再点按钮关闭
  $('aiModelBtn').onclick = (e) => { e.stopPropagation(); aiToggleModelMenu(); };
  document.addEventListener('mousedown', (e) => {
    const drop = $('aiModelDrop');
    if (drop && !drop.contains(e.target)) aiCloseModelMenu();
  });
  $('aiBtnTest').onclick = aiTestConnect;
  $('aiBtnSaveCfg').onclick = () => aiSaveCfg();
  // 智能体字号（免责行右侧 ＋/－）
  if ($('btnAiFontDec')) $('btnAiFontDec').onclick = () => adjustAiFont(-1);
  if ($('btnAiFontInc')) $('btnAiFontInc').onclick = () => adjustAiFont(1);
  initAiFont();
  applyAiFont();
  // 附件：上传图片 / 上传附件（拖拽到输入框也支持）
  $('aiBtnImg').onclick = () => $('aiImgInput').click();
  $('aiBtnFile').onclick = () => $('aiFileInput').click();
  $('aiImgInput').onchange = () => { aiAddFiles($('aiImgInput').files, true); $('aiImgInput').value = ''; };
  $('aiFileInput').onchange = () => { aiAddFiles($('aiFileInput').files, false); $('aiFileInput').value = ''; };
  const aiTa = $('aiInput');
  aiTa.addEventListener('dragover', (e) => { e.preventDefault(); e.stopPropagation(); });
  aiTa.addEventListener('drop', (e) => {
    e.preventDefault(); e.stopPropagation();
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
      aiAddFiles(e.dataTransfer.files, false);   // 自动按类型分流（图片走多模态）
    }
  });
  // 粘贴：剪贴板图片 → 图片附件；富文本（HTML）→ 提取干净文本
  aiBindPaste(aiTa);
  // 右键菜单：复制 / 剪切 / 粘贴 / 全选 / 格式化文本（去格式）
  aiTa.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    aiShowInputMenu(e);
  });
  // 上下文环形进度圈：启动时拉一次
  aiLoadCtx();
  const inp = $('aiInput');
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) {
      e.preventDefault();
      aiSend();
    }
  });
  // 恢复上次面板状态（默认展开；收起时右侧显示拉手按钮）
  let show = true;
  try { if (localStorage.getItem('yyAIPanel') === '0') show = false; } catch (e) { /* 忽略 */ }
  aiToggle(show);
  aiLoadCfg();
  aiReconnect();   // 恢复上次会话；若后端还有回合在跑则重连补看（刷新不丢任务）
  // 面板宽度：左边缘拖拽调整（右侧固定不动，只有左边框可拖）。
  // 实时改 body 的 --ai-w —— 面板宽度与编辑区/控制台的右侧让位引用同一变量。
  // 宽度记进 localStorage，双击热区恢复默认（小屏 300 / 其余 360）。
  const rz = $('aiResize');
  if (rz) {
    const AI_W_KEY = 'yyAIW';
    const aiSetW = (w) => {
      w = Math.max(300, Math.min(w, window.innerWidth - 430, 680));
      document.body.style.setProperty('--ai-w', Math.round(w) + 'px');
      return Math.round(w);
    };
    try {
      const v = parseInt(localStorage.getItem(AI_W_KEY), 10);
      if (isFinite(v) && v >= 300 && v <= 680) aiSetW(v);
    } catch (e) { /* 忽略 */ }
    rz.onpointerdown = (e) => {
      e.preventDefault();
      try { rz.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ }
      document.body.style.userSelect = 'none';
      rz.classList.add('dragging');
      const move = (ev) => aiSetW(window.innerWidth - 10 - ev.clientX);
      const up = () => {
        rz.removeEventListener('pointermove', move);
        rz.removeEventListener('pointerup', up);
        rz.removeEventListener('pointercancel', up);
        rz.classList.remove('dragging');
        document.body.style.userSelect = '';
        try {
          const w = parseInt(document.body.style.getPropertyValue('--ai-w'), 10);
          if (isFinite(w)) localStorage.setItem(AI_W_KEY, String(w));
        } catch (err) { /* 忽略 */ }
      };
      rz.addEventListener('pointermove', move);
      rz.addEventListener('pointerup', up);
      rz.addEventListener('pointercancel', up);
    };
    rz.ondblclick = () => {
      document.body.style.removeProperty('--ai-w');
      try { localStorage.removeItem(AI_W_KEY); } catch (e) { /* 忽略 */ }
    };
  }
  // 面板顶边从顶栏下方开始：实测顶栏高度写入 --tb-h（顶栏内容换行时高度会变，
  // 用 ResizeObserver 跟随；不支持时退化为窗口 resize 监听）
  const tb = $('topbar');
  if (tb) {
    const setTbH = () => document.documentElement.style.setProperty(
      '--tb-h', tb.offsetHeight + 'px');
    setTbH();
    if (window.ResizeObserver) {
      try { new ResizeObserver(setTbH).observe(tb); } catch (e) { /* 忽略 */ }
    } else {
      window.addEventListener('resize', setTbH);
    }
  }
}

document.addEventListener('DOMContentLoaded', aiInit);
