// 云易 / C++ 语法高亮（轻量字符级扫描）
'use strict';

const YY_KEYWORDS = new Set([
  '如果','否则如果','否则','结束如果','如果真','结束如果真','那么',
  '计次循环','当循环','判断循环首','判断循环尾','循环判断首','循环判断尾','结束循环',
  '跳出循环','到循环尾','返回','子程序','测试函数','导出子程序','结束子程序','参考','传址',
  '且','或','非','真','假','全局变量','常量','变量','API','在库',
  '数据类型','结束数据类型','类函数','结束类函数',
  'asm','结束asm','结束汇编'
]);
const YY_TYPES = new Set(['逻辑型','字节型','短整数型','整数型','长整数型','小数型','文本型','字节集','空',
  '日期时间型','双精度小数型','子程序指针']);
// 流程控制分类下的全部命令（与 corelib.py 的 流程控制 分类保持一致）
const YY_FLOW = new Set([
  '如果','如果真','判断','结束判断','判断循环首','判断循环尾','循环判断首','循环判断尾',
  '计次循环首','变量循环首','到循环尾','跳出循环','返回','结束'
]);
// 核心库常量（与 corelib.const_names() 保持一致）：时间/文件/共享/位置/属性/按钮/结果/
// 声音/注册/注册表/颜色/拼音/播放 等；另含逻辑常量 真/假
const YY_CONSTS = new Set([
  '真','假',
  '时间_年','时间_月','时间_日','时间_时','时间_分','时间_秒','时间_星期','时间_全部',
  '时间_仅日期','时间_仅时间','文件_读入','文件_重写','文件_改写','文件_随机读写',
  '共享_无','共享_读','共享_写','共享_完全','位置_文件首','位置_当前','位置_文件尾',
  '属性_只读','属性_隐藏','属性_系统','属性_目录','属性_存档','文件时间_创建','文件时间_访问',
  '文件时间_修改','按钮_确定','按钮_确定取消','按钮_是否','按钮_是否取消','按钮_重试取消',
  '按钮_终止重试忽略','结果_确定','结果_取消','结果_终止','结果_重试','结果_忽略','结果_是',
  '结果_否','声音_默认','声音_警告','声音_错误','声音_问号','注册_类别目录','注册_现行用户',
  '注册_本地机器','注册_用户','注册_当前配置','注册表_自动','注册表_文本','注册表_二进制',
  '注册表_数值','颜色_黑','颜色_白','颜色_红','颜色_绿','颜色_蓝','颜色_黄','颜色_青',
  '颜色_紫','拼音_带数字声调','拼音_带声调符号','拼音_无音调','播放_已停止','播放_播放中',
  '播放_已暂停'
]);
const YY_BUILTINS = new Set([
  '输出','调试输出','输入文本','信息框',
  '到文本','到整数','到长整数','到小数','到逻辑',
  '取文本长度','取文本左边','取文本右边','取文本中间','寻找文本','倒找文本',
  '替换文本','到大写','到小写','删首尾空','取空白文本',
  '取绝对值','取整','四舍五入','求平方根','取随机数','整除','取数组成员数',
  '取当前时间','断言','置入代码','调用子程序'
]);

function escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

const NUM_RE = /^(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$|^0[xX][0-9a-fA-F]+$/;

function isWordStart(ch) {
  if (!ch) return false;
  const code = ch.charCodeAt(0);
  return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch === '_' || code > 127;
}
function isWordPart(ch) {
  if (!ch) return false;
  const code = ch.charCodeAt(0);
  return isWordStart(ch) || (ch >= '0' && ch <= '9');
}

// 将源码着色为 HTML 片段（保留 \n）。
// 注意：先把 \r\n / 孤立 \r 统一归一为 \n —— 否则注释等整段捕获会把行尾 \r
// 带进 <span>，浏览器把 \r 当换行渲染，高亮层行数就会多于行号栏（整体错位）。
function normalizeNl(text) {
  return (text || '').replace(/\r\n?/g, '\n');
}

// 块结构关键字（开始 → 可选结束关键字集合）：与 app.js 的 GUIDE_OPEN 保持一致。
// 高亮时按相同规则入栈/出栈，为「如果 / 结束如果」等配对关键字标注 d0/d1/d2
// 深度 class，使其颜色与所在嵌套层级的连接辅助线一致（开头与结尾同色）。
const YY_GUIDE_OPEN_FALLBACK = {
  '如果': ['结束如果'], '如果真': ['结束如果真'],
  '计次循环': ['结束循环'], '当循环': ['结束循环'],
  '判断循环首': ['判断循环尾', '结束循环'],
  '循环判断首': ['循环判断尾'],
  '子程序': ['结束子程序'], '测试函数': ['结束子程序'], '导出子程序': ['结束子程序'],
  '数据类型': ['结束数据类型'], '类函数': ['结束类函数'],
  'asm': ['结束asm', '结束汇编'],
};
function yyGuideOpen() {
  // app.js 已定义 GUIDE_OPEN 时直接复用，避免两份配对表不同步
  return (typeof GUIDE_OPEN === 'object' && GUIDE_OPEN) ? GUIDE_OPEN : YY_GUIDE_OPEN_FALLBACK;
}

// varNames：本文件声明的「变量 / 全局变量 / 子程序参数」名集合（动态，由编辑器传入）；
// constNames：本文件声明的「常量」名集合（动态，由编辑器传入）。
// 两者都只影响 .yy 文件，且优先级低于关键字 / 内置 / 核心常量等静态集合。
function highlightToHtml(text, varNames, constNames) {
  text = normalizeNl(text);
  const out = [];
  let i = 0, n = text.length;
  // 块深度跟踪：与 app.js buildGuides 的入栈/出栈规则一致（注释内不会触发，
  // 因为注释分支整段消费，不会产生单词 token）
  const GUIDE = yyGuideOpen();
  const stack = [];    // 已打开、尚未遇到结束关键字的块（元素为该块的结束关键字集合）
  let atHead = true;   // 是否处于「行首第一个词」之前（空白不改变，其余内容置否）
  while (i < n) {
    const c = text[i];

    if (c === '\n') { out.push('\n'); i++; atHead = true; continue; }
    if (c === '\r') { i++; continue; }
    if (c === ' ' || c === '\t') {
      const s = i; while (i < n && (text[i] === ' ' || text[i] === '\t')) i++;
      out.push(escHtml(text.slice(s, i))); continue;
    }
    if (c === '/' && text[i + 1] === '/') {
      const s = i; while (i < n && text[i] !== '\n') i++;
      out.push('<span class="tok-com">' + escHtml(text.slice(s, i)) + '</span>'); continue;
    }
    if (c === "'") {
      const s = i; while (i < n && text[i] !== '\n') i++;
      out.push('<span class="tok-com">' + escHtml(text.slice(s, i)) + '</span>'); continue;
    }
    if (c === '/' && text[i + 1] === '*') {
      const s = i; i += 2;
      while (i < n && !(text[i] === '*' && text[i + 1] === '/')) i++;
      if (i < n) i += 2;
      const seg = text.slice(s, i).split('\n');
      atHead = false;
      for (let k = 0; k < seg.length; k++) {
        if (k > 0) out.push('\n');
        if (seg[k]) out.push('<span class="tok-com">' + escHtml(seg[k]) + '</span>');
      }
      continue;
    }
    if (c === '"') {
      atHead = false;
      let s = i; i++;
      while (i < n) {
        if (text[i] === '\\') { i += 2; continue; }
        if (text[i] === '"') { i++; break; }
        if (text[i] === '\n') break;
        i++;
      }
      out.push('<span class="tok-str">' + escHtml(text.slice(s, i)) + '</span>'); continue;
    }
    if (c === '#') {
      atHead = false;
      // 常量引用：#名称 一律按常量着色（后跟词字符才成对，孤立 # 原样输出）
      let j = i + 1;
      while (j < n && isWordPart(text[j])) j++;
      if (j > i + 1) {
        out.push('<span class="tok-const">' + escHtml(text.slice(i, j)) + '</span>');
        i = j; continue;
      }
      out.push(escHtml('#')); i++; continue;
    }
    if (isWordStart(c)) {
      const s = i;
      while (i < n && isWordPart(text[i])) i++;
      const w = text.slice(s, i);
      const head = atHead;
      atHead = false;
      // 行首块关键字：按 buildGuides 相同的入栈/出栈规则取嵌套深度，
      // 开头（如果/如果真/子程序…）、结尾（结束如果/结束如果真/结束子程序…）
      // 与分支（否则/否则如果）标注 d0/d1/d2，与所属连接辅助线同色
      let flowCls = '';
      if (head) {
        // 与 buildGuides 的行首正则一致：全角括号前的前缀才是关键字本体
        const kw = w.split('（')[0];
        if (GUIDE[kw]) {
          flowCls = ' d' + (stack.length % 3);
          stack.push(GUIDE[kw]);
        } else if (stack.length && stack[stack.length - 1].indexOf(kw) >= 0) {
          flowCls = ' d' + ((stack.length - 1) % 3);
          stack.pop();
        } else if ((kw === '否则' || kw === '否则如果') && stack.length) {
          flowCls = ' d' + ((stack.length - 1) % 3);
        }
      }
      if (NUM_RE.test(w)) out.push('<span class="tok-num">' + escHtml(w) + '</span>');
      else       if (YY_TYPES.has(w)) out.push('<span class="tok-type">' + escHtml(w) + '</span>');
      else if (YY_FLOW.has(w) || flowCls) out.push('<span class="tok-flow' + flowCls + '">' + escHtml(w) + '</span>');
      else if (YY_CONSTS.has(w)) out.push('<span class="tok-const">' + escHtml(w) + '</span>');
      else if (YY_KEYWORDS.has(w)) out.push('<span class="tok-kw">' + escHtml(w) + '</span>');
      else if (YY_BUILTINS.has(w)) out.push('<span class="tok-fn">' + escHtml(w) + '</span>');
      else if (varNames && varNames.has(w)) out.push('<span class="tok-var">' + escHtml(w) + '</span>');
      else if (constNames && constNames.has(w)) out.push('<span class="tok-const">' + escHtml(w) + '</span>');
      else out.push(escHtml(w));
      continue;
    }
    if (c >= '0' && c <= '9') {
      atHead = false;
      const s = i;
      while (i < n && /[0-9a-zA-Z_.+-]/.test(text[i])) {
        if ((text[i] === '+' || text[i] === '-') && !/[eE]/.test(text[i - 1] || '')) break;
        i++;
      }
      const w = text.slice(s, i);
      out.push(NUM_RE.test(w) ? '<span class="tok-num">' + escHtml(w) + '</span>' : escHtml(w));
      continue;
    }
    // 其它符号
    atHead = false;
    const isOp = /[+\-*/%\\=<>!&|()\[\]{},;.]/.test(c);
    out.push(isOp ? '<span class="tok-op">' + escHtml(c) + '</span>' : escHtml(c));
    i++;
  }
  return out.join('');
}

// 供 C++/配置等文件使用的通用高亮（类型少一些）
function highlightCppToHtml(text) {
  text = normalizeNl(text);
  const K = new Set(['if','else','for','while','do','return','int','void','bool','true','false','double','long','short','unsigned','char','using','std','const','constexpr','inline','template','namespace','break','continue','struct','class','auto','new','delete','static','string']);
  const out = [];
  let i = 0, n = text.length;
  while (i < n) {
    const c = text[i];
    if (c === '\n') { out.push('\n'); i++; continue; }
    if (c === '/' && (text[i + 1] === '/' || text[i + 1] === '*')) {
      const s = i;
      if (text[i + 1] === '/') { while (i < n && text[i] !== '\n') i++; }
      else { i += 2; while (i < n && !(text[i] === '*' && text[i + 1] === '/')) i++; if (i < n) i += 2; }
      out.push('<span class="tok-com">' + escHtml(text.slice(s, i)) + '</span>'); continue;
    }
    if (c === '"' || c === "'") {
      const q = c, s = i; i++;
      while (i < n) {
        if (text[i] === '\\') { i += 2; continue; }
        if (text[i] === q) { i++; break; }
        if (text[i] === '\n') break;
        i++;
      }
      out.push('<span class="tok-str">' + escHtml(text.slice(s, i)) + '</span>'); continue;
    }
    if (isWordStart(c)) {
      const s = i; while (i < n && isWordPart(text[i])) i++;
      const w = text.slice(s, i);
      if (K.has(w)) out.push('<span class="tok-kw">' + escHtml(w) + '</span>');
      else out.push(escHtml(w));
      continue;
    }
    out.push(escHtml(c)); i++;
  }
  return out.join('');
}

function highlighterFor(filename) {
  return /\.yy$/i.test(filename) ? highlightToHtml : highlightCppToHtml;
}
