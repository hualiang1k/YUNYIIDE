# 自定义 Skill 目录（`server/skills/`）

把新 Skill 放在这里就能被智能体发现，**不需要改任何代码**（这是设计方案的完成标准之一）。

## 怎么加一个 Skill

在本目录下新建一个子目录，里面放 `SKILL.md`：

```
server/skills/
└── 我的技能/
    └── SKILL.md
```

也支持按分组多一层（便于归类）：

```
server/skills/
└── 数据库/
    └── sqlite/
        └── SKILL.md
```

## SKILL.md 写法

前导 front matter（可选）声明元数据，正文用 `##` 章节写方法论：

```markdown
---
name: sqlite
description: 用 SQLite 做本地数据存取与查询
group: database
priority: P1
version: 1.0
enabled: true
requires: []
keywords: [数据库, 表, 查询, sqlite, sql]
tools: [run_script, read_file, write_file]
---

# SQLite Skill

## Purpose
一两句话说明这个 Skill 解决什么问题。

## When to use
- 什么时候该用它

## When not to use
- 什么时候不该用它

## Tools
- 用到哪些工具，各自干什么

## Workflow
1. 步骤一
2. 步骤二

## Verification
- 怎么证明做对了

## Failure recovery
- 出错时怎么处理

## Safety
- 有哪些红线

## Examples
- 一个具体例子
```

字段说明：

| front matter 字段 | 作用 |
|---|---|
| `name` | Skill 名（不填则用目录名），`load_skill(name)` 用它 |
| `description` | 一句话用途，会进 Skill 索引 |
| `group` | 分组，只用于展示与过滤 |
| `priority` | `P0` / `P1` / `P2`，影响索引排序与自动激活打分 |
| `version` | 版本号 |
| `enabled` | `false` 则登记但不启用（例如本环境缺少依赖的工具） |
| `requires` | 外部依赖标记，如 `git`、`network`、`playwright` |
| `dependencies` | 依赖的其他 Skill 名；缺失时本 Skill 自动停用并给出原因 |
| `keywords` | 关键词，命中时更容易被自动激活 |
| `tools` | 该 Skill 常用/需要的工具名 |

## 已内置 Skill（翻译自 DeepSeek Harness 的技能库）

以下技能由 F:\Harness 下 deepseek-harness 的 `.agents/skills/` 技能库翻译改写而来：
方法论内核保留，dsh 特有的工具链（pnpm/Vitest/Cordis/gh stack/双语对）已替换为本项目的实际形态
（纯 Python 服务端 + web 前端 + `启动云易IDE.bat`）。

| 技能 | 来源 | 用途 |
|---|---|---|
| `code-review` | dsh-code-review | 审查代码改动：先懂设计再看 diff，阻塞问题/建议分级 |
| `prose-standard` | dsh-prose-standard | 任何文字的行文规范：保留完整命题，删过程叙述与装饰 |
| `trim-cot-leakage` | dsh-trim-cot-leakage | 修剪「思维链泄漏」：设计稿引用、改动叙述、审查对话残留 |
| `test-reliability` | dsh-ci-test-reliability | 可靠测试：资源原子分配、全局状态圈住、Windows 平台语义、拒绝掩盖偶发 |
| `find-simplifications` | dsh-find-simplifications | 找简化点：强候选标准、逐候选证明或否决、行内 TODO 约定 |
| `perf-optimization` | dsh-speed-up-perf | 性能优化：测量卡、先证明回归再移除工作、行为不变 |
| `doc-writing` | dsh-doc | 文档写作：读者优先、分类定模板、「跑一遍再写」核实程序 |
| `pre-delivery-checks` | dsh-pre-push-checks | 交付前自检：按 diff 选最小相关检查、版本号更新（ABOUT.version） |
| `record-gif` | record-browser-gif | 录制界面演示 GIF（scripts/encode_gif.py，需 ffmpeg） |

未移植（依赖本项目不存在的基础设施）：`dsh-translate-docs`（双语对机制）、
`dsh-merging-stacked-prs`（gh stack 工作流）、`dsh-archive-agent-notes`（Agent Note 语料）、
Cordis 两个 preset 技能（dsh 已从本项目移除）。

## 覆盖内置 Skill

在 `server/agent/skills/builtin/` 里同名目录会被本目录（`server/skills/`）下的同名 Skill 覆盖，
所以想改内置 Skill 的行为，不用改包里的文件，在这儿放一份新的即可。

## 生效方式

- 保存后下一次对话自动重新加载
- 也可以调 `POST /api/ai/skills`（action=`reload`）立即重载
- 智能体会先看到「Skill 索引」（名称 + 用途 + 适用场景），判断相关时再 `load_skill` 取全文
