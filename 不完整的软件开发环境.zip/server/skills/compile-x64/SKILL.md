---
name: compile-x64
description: 用云易IDE内置 x64 工具链编译/运行/测试云易（.yy）工程。用户要求编译 64 位程序、或提到 x64 / 64位 时使用。
---

# 云易工程编译（x64）

用 IDE 自带的命令行工具 `server/yunyi_cli.py` 编译云易工程，**固定目标架构 x64**（编译器用 `tools/mingw64` 的 g++）。

## 命令

在 IDE 工作区目录（本智能体的工作目录）下执行，裸 `python` 就是 IDE 自带解释器：

```
python ../server/yunyi_cli.py build <工程目录> --arch x64            # 翻译 .yy → C++ → g++ 编译
python ../server/yunyi_cli.py run   <工程目录> --arch x64            # 编译并运行
python ../server/yunyi_cli.py test  <工程目录> --arch x64            # 编译并执行测试函数（退出码 0 = 全部通过）
python ../server/yunyi_cli.py clean <工程目录> --dry-run             # 先看会删哪些产物，再去掉 --dry-run 真删
```

- `<工程目录>` 是工作区下的相对路径（如 `test`），**不要写绝对路径**（g++ 对中文/盘符路径会乱码）。
- `--mode debug`（默认）/ `--mode release` 可选；留空用工程 `.yyproj` 里保存的模式。
- 工程里没有「测试函数」时 `test` 会报「工程中没有测试函数」——属正常现象，改用 `build` / `run` 即可。
- 加 `--json` 可得到结构化结果（ok / exe / log / messages）。

## 产物

- 输出在 `<工程目录>/build/<模式>/<目标名>.exe`（x64 无后缀）。
- 编译会自动结束占用输出文件的残留进程；失败时看 log 里的 gcc 报错（`文件.yy:行:列` 可直接定位源码）。

## 测试工程

验证编译链用工作区里的 `test` 工程：

```
python ../server/yunyi_cli.py build test --arch x64
python ../server/yunyi_cli.py test  test --arch x64
```
