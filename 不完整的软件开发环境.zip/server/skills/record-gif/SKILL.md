---
name: record-gif
description: 把浏览器/Web 界面的交互演示录制成优化过的 GIF——用浏览器自动化（或截图序列）捕获真实运行中的云易IDE，再用自带脚本确定性地编码；被要求「录个 GIF / 演示动画」时使用
group: media
priority: P2
version: 1.0
enabled: true
requires: [ffmpeg]
keywords: [GIF, 录屏, 演示, 动画, 截图, 浏览器]
tools: [run_command, read_file, write_file]
---

# 录制界面演示 GIF

产出一个短小、真实的界面演示 GIF。录制与后续使用是分开的两步：录制只产出本地视频/截图和一个 `.gif` 工件，不改任何远程状态；GIF 默认留在本地，只有在任务明确要求发布（贴进 issue、文档、README）时才做后续发布，且绝不把 GIF 提交进代码分支的长期历史。

## 摆好应用

GIF 是证据：它演示的是本次改动后的真实 IDE，不是理想化的场景。

1. 确认工作树干净（若在 git 仓库内），记录确切提交 `git rev-parse HEAD`；对未提交的工作区改动，如实注明演示包含未提交修改。
2. 用正常路径启动 IDE：仓库根的 `启动云易IDE.bat`。需要干净状态时，先清掉受影响会话的本地状态，并给浏览器一个干净的 profile（或导航前清掉该 origin 的 cookie 与站点存储），让持久化的客户端状态不污染证据。
3. 一个分镜脚本 = 一次证据运行：所有发布的帧都来自同一台服务器、同一份状态。捕获自动化失败就丢弃帧、从干净状态重跑；绝不拼接不同运行的帧。
4. 在不同演示之间切换时，按 PID 或命令行精确匹配停掉旧服务器；宽泛的 `pkill -f`/`Stop-Process -Name` 模式可能误杀启动它的 shell——包括你自己的。
5. 绝不读取或暴露凭据；不捕获隐私数据、无关标签页、系统通知。保持全程同一视口。

## 录制流程

优先用可用的浏览器自动化（如 Playwright）；它支持 `recordVideo` 时开启视频捕获更多中间帧。浏览器自动化不可用时才退回截图序列，并在捕获说明里声明这次回退。

录制脚本、原始视频、计时笔记、QA 帧、GIF 统一放在仓库的 gitignore 路径下（如 `.temp/gif/<运行名>/`），先建运行目录。

### 捕获视频

`viewport` 与 `recordVideo.size` 要显式一致，否则 Playwright 会缩到 800×800 导致界面文字不可读：

```js
const { chromium } = require('playwright')
const browser = await chromium.launch()
const size = { width: 1440, height: 900 }
const context = await browser.newContext({
  viewport: size,
  recordVideo: { dir: runDir + '/videos', size },
})
try {
  const page = await context.newPage()
  const video = page.video()
  // 在这里导航并操作真实应用
  await context.close()
  await video.saveAs(runDir + '/demo.webm')
} finally {
  await context.close()
  await browser.close()
}
```

在关闭页面前先保存它的 video 句柄；先 `context.close()` 再 `saveAs()`/编码——只关浏览器不保证视频落盘。每页有自己的视频：明确选择被演示的页面，不拼接无关页面或运行。失败的运行只作诊断。

选一个 3–6 个有意义状态的短故事。动作前等唯一的语义定位符（无障碍名用 `exact: true`）；固定等待只可在状态验证后用作阅读停顿，绝不用来建立就绪。演示工具调用、报错、恢复时，展开它的详情面板，让视频拍到工具身份、状态或稳定错误码、以及下游结果。瞬态运行态重要时，选一个慢的前台操作并观察其具体 DOM 标记。给模型一个简短的收尾哨兵锚定完成；真实请求的运行在演示状态可见后就停。

### 截图捕获

连续视频不可用或用户要分镜图时：从同一次隔离运行捕获 3–6 个已验证状态，保存为 `00-initial.png`、`01-typed.png`…… 尺寸与裁剪一致；瞬态状态在同一浏览器脚本调用内轮询其 DOM 标记并捕获。

## 编码 GIF

需要 `python3` 与 `ffmpeg`/`ffprobe`。缺媒体组件就报告依赖，未经授权不擅自安装。本项目可直接用自带解释器 `tools/python/bin/python3.14.exe`。脚本路径基于本技能目录：

```sh
python tools/python/bin/python3.14.exe server/skills/record-gif/scripts/encode_gif.py \
  <demo.webm 的绝对路径> <demo.gif 的绝对路径> \
  --start 2 --end 32 --speed 2 --final-hold 3 \
  --fps 10 --max-width 1200 --colors 128
```

`--start`/`--end` 选一段连续的源区间（秒）。默认保留全片 1× 速度并加两秒收尾定格。`--speed` 改播放速度——必须在 GIF 旁边注明变速与所选区间，让演示不能暗示实测响应延迟。用视频里的观测时间，不用猜测的墙钟偏移；保留被演示行为的完整因果与结果。收尾定格重复最后一帧。`--fps` 是编码帧率：提高它补不回源录制没拍到的运动。保留原始 WebM 作 QA；不拼接不同运行、不合成缺失状态。

编码器探测 WebM 时长、先裁剪变速再调色板转换，并检查编码后的时长、动画、宽度与字节大小。区间为空/越界、短于两帧、参数与模式不符、意外覆盖都会被拒绝。产物过大先减 `--max-width`，再减 `--colors` 或 `--fps`；以可读的文字为先。

截图目录输入：

```sh
python tools/python/bin/python3.14.exe server/skills/record-gif/scripts/encode_gif.py \
  <帧目录的绝对路径> <demo.gif> \
  --durations 1.5,1.5,1.5,3.5 --fps 10 --max-width 1200 --colors 128
```

一个 duration 应用于全部截图；否则每帧一个正时长，落定状态持有最久。视频计时参数只对视频文件有效；`--durations`/`--pattern` 只对截图目录有效。

## 验证工件

1. 读编码器的 JSON 摘要，确认输出路径、源区间与速度（或截图数）、帧数、尺寸、时长、字节大小。
2. 用眼睛读编码后的 GIF 本身，而不只是源帧：过渡清晰、末态停留够久、无敏感内容。查看器只显示首帧时，用 `ffmpeg` 从编码后的 GIF 解出代表性帧检查；编码前的截图证明不了编码后的顺序、调色板与收尾定格。
3. `git status --short`（如适用）确认原始视频、QA 帧与工件只落在被忽略的路径。
4. 返回 GIF 的绝对路径并如实注明录制用的是真实服务还是夹具。任务不含发布时，到此为止。

编码器维护：`python -m unittest discover -s <技能目录>/scripts -p 'test_*.py' -v`（需先装好 ffmpeg）。
