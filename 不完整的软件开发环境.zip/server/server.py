# -*- coding: utf-8 -*-
"""云易IDE 本地服务端：静态资源 + JSON API（文件/编译/运行/git/发布）。"""
from __future__ import annotations
import base64
import importlib
import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    ROOT = os.path.dirname(os.path.abspath(sys.executable))
sys.path.insert(0, ROOT)
from yunyi import project as P            # noqa: E402
from yunyi import builder as B            # noqa: E402
from yunyi import buildsys as BS          # noqa: E402
from yunyi import ci as CI                # noqa: E402
from yunyi import codec as CODEC          # noqa: E402 编码通道表（见 yunyi/codec.py）
from yunyi import toolchain as T          # noqa: E402
from server import sessions as S          # noqa: E402
from server.locks import BUILD_LOCK as _build_lock   # noqa: E402

# ---------------- 统一 UTF-8（全链路） ----------------
# 1) 让本进程及其**所有子进程**（自带 Python、编译器脚本、智能体工具、用户脚本）
#    默认按 UTF-8 读写文件与标准流；Windows 默认是 GBK，中文会乱码（依据见 yunyi/textio.py）。
#    直接用 `python server/server.py` 启动、或从其它入口进来时，同样拿到这套环境。
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
# 2) 本进程的 stdout/stderr 也按 UTF-8 输出（服务日志 / 自检输出不再乱码）
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def _find_web_dir() -> str:
    """前端界面目录（server/web/）。

    两个位置都试，因为打包后入口脚本的位置变了：
      · 源码运行：本文件就在 server\\ 下 → server\\web\\；
      · 打包成 exe（PyInstaller）：入口脚本被放到解包根 _MEIPASS\\server.py，
        同目录下**没有** web\\，真实位置是 _MEIPASS\\server\\web\\（--add-data 放的）。
    只按第一种算，打包后就会整站 404。
    """
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "web"), os.path.join(here, "server", "web")):
        if os.path.isdir(cand):
            return cand
    return os.path.join(here, "web")


WEB_DIR = _find_web_dir()

# ---------------- AI 后端选择 ----------------
# 后端对外接口一致，可以整体替换：
#   hope2 = 纯 Python 智能体（唯一后端），代码在 server\The_future_is_promising\；
#           只用标准库、跑在 IDE 自带解释器上，无 Node / 无子进程。
#   hope  = 旧 Node 版 dsh，hope\ 目录已删除、不再作为可选后端；历史配置里的
#           "hope" 值认不到时自动回落默认后端，不用手工改 settings.json。
# 逻辑名 → 模块名的映射：配置里写的是逻辑名，包挪位置只改这张表。
# 优先级：环境变量 YUNYI_AI_BACKEND > config/settings.json 的 aiBackend > 默认 hope2。
AI_BACKENDS = ("hope2",)
DEFAULT_AI_BACKEND = "hope2"
_AI_MODULES = {
    "hope2": "server.The_future_is_promising",
}
_AI_BACKEND = {"name": "", "module": None}


def ai_backend_name() -> str:
    """当前生效的后端逻辑名（hope2）。"""
    name = (os.environ.get("YUNYI_AI_BACKEND") or "").strip().lower()
    if name in AI_BACKENDS:
        return name
    try:
        name = str((T.get_settings() or {}).get("aiBackend") or "").strip().lower()
    except Exception:
        name = ""
    return name if name in AI_BACKENDS else DEFAULT_AI_BACKEND


def ai_backend():
    """当前生效的后端模块（同名模块只 import 一次，切换后才重新取）。"""
    name = ai_backend_name()
    cached = _AI_BACKEND.get("module")
    if cached is not None and _AI_BACKEND.get("name") == name:
        return cached
    module_name = _AI_MODULES.get(name) or name
    try:
        module = importlib.import_module(module_name)
    except Exception as e:                                        # noqa: BLE001
        raise RuntimeError("AI 后端 %s（模块 %s）加载失败：%s"
                           % (name, module_name, e)) from None
    _AI_BACKEND["name"] = name
    _AI_BACKEND["module"] = module
    return module
HIDE_DIRS = {"build", "发布", "导出C++", "导出Python", ".git", "__pycache__", ".idea", ".vscode"}
HIDE_EXTS = {".exe", ".o", ".obj", ".pyc"}
PORT = 8405                     # 默认端口（实际以 config/settings.json 的 port 为准）

# 当前服务运行状态：/api/settings 修改端口后由 _switch_port 热切换
_state = {"port": PORT, "httpd": None}

# IDE 界面设置（IDE配色 / 主题 / 字号这类「设置选项」）：
# 统一存到 config 目录（config/ide_settings.json），与 settings.json / ai_agent.json
# / agent.json 放在一起；工程级设置（.yyproj）不受影响。
# 前端 localStorage 里只留一份即时缓存（启动先按缓存上屏，再用这里的配置覆盖）。
IDE_CFG_FILE = os.path.join(ROOT, "config", "ide_settings.json")
PROMPTS_FILE = os.path.join(ROOT, "config", "prompts.json")


def _read_ide_config() -> dict:
    """读取 IDE 界面设置。文件缺失 / 损坏按空配置处理（前端有缓存与默认值兜底）。"""
    try:
        with open(IDE_CFG_FILE, "rb") as f:
            obj = json.loads(f.read().decode("utf-8"))
        return obj if isinstance(obj, dict) else {}
    except (OSError, ValueError):
        return {}


def _read_prompts() -> list:
    """读取快捷提示词（config/prompts.json）。
    格式宽松：JSON 对象取各键的值，数组取各项；只收非空字符串。
    文件缺失 / 非法 JSON 返回空表（前端弹「暂无提示词」，不影响其它功能）。"""
    try:
        with open(PROMPTS_FILE, "rb") as f:
            obj = json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError):
        return []
    if isinstance(obj, dict):
        items = list(obj.values())
    elif isinstance(obj, list):
        items = list(obj)
    else:
        return []
    return [v for v in items if isinstance(v, str) and v.strip()]


def _write_ide_config(cfg: dict) -> dict:
    """合并保存 IDE 界面设置（先读旧值合并再原子写回）。
    对象值（如 fonts）做一级深合并——前端防抖补丁只带改过的键，不能整包顶掉旧的。"""
    os.makedirs(os.path.dirname(IDE_CFG_FILE), exist_ok=True)
    cur = _read_ide_config()
    for k, v in (cfg or {}).items():
        if not isinstance(k, str):
            continue
        if isinstance(v, dict) and isinstance(cur.get(k), dict):
            cur[k].update(v)
        else:
            cur[k] = v
    tmp = IDE_CFG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(cur, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, IDE_CFG_FILE)
    return cur

# ---------------- 多语言（config\*.lng 语言包） ----------------
# 语言包是「键=值」文本文件：键 = 界面中文原文，值 = 译文（值留空表示保持原文）；
# 行首 # / ; 为注释，@label=… 是该语言包在下拉框里的显示名。
# 当前语言存 config/settings.json 的 "language"（值 = 文件主名，如 zh_cn / en_us）。

def _lng_path(name: str) -> str:
    """语言包名 → config 目录内的完整路径。只接受纯文件名（挡目录穿越），
    .lng 后缀可省略（en_us == en_us.lng）。"""
    name = os.path.basename(str(name or "").strip())
    if not name.endswith(".lng"):
        name += ".lng"
    return os.path.join(ROOT, "config", name)


def _read_lng(name: str) -> dict:
    """解析一个语言包 → {name, label, dict}。文件缺失抛 ValueError（调用方回 404）。"""
    fp = _lng_path(name)
    base = os.path.basename(fp)[:-4]
    if not os.path.isfile(fp):
        raise ValueError("语言包不存在：" + base)
    label = base
    table: dict = {}
    with open(fp, "rb") as f:
        raw = f.read().decode("utf-8-sig", errors="replace")
    for ln in raw.splitlines():
        s = ln.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        if s.startswith("@label="):
            label = s[len("@label="):].strip() or label
            continue
        # 键里可以含等号：写作 \=（先换成占位符，按第一个未转义的 = 切开，再还原）
        work = s.replace("\\=", "\x00")
        if "=" not in work:
            continue
        k, v = work.split("=", 1)
        k = k.replace("\x00", "=").strip()
        v = v.replace("\x00", "=").strip()
        if k:
            table[k] = v
    return {"name": base, "label": label, "dict": table}


def _list_lngs() -> list:
    """config 目录下所有 *.lng 语言包 → [{name, label}]（按文件名排序）。"""
    d = os.path.join(ROOT, "config")
    try:
        names = sorted(n for n in os.listdir(d) if n.lower().endswith(".lng"))
    except OSError:
        names = []
    out = []
    for n in names:
        try:
            info = _read_lng(n)
            out.append({"name": info["name"], "label": info["label"]})
        except Exception:                     # 损坏的语言包也列出来（选了读不出 → 保持原文）
            out.append({"name": n[:-4], "label": n[:-4]})
    return out


# ---------------- 「导出 C++」异步任务（供前端进度条轮询） ----------------
_EXPORT_TASKS: dict = {}
_EXPORT_LOCK = threading.Lock()
_EXPORT_SEQ = [0]


def _start_export_task(proj_dir: str, cfg: dict, kind: str = "cpp") -> int:
    """后台线程执行导出（kind: cpp=纯正 C++ / python=Python），进度写入 _EXPORT_TASKS 供轮询。"""
    with _EXPORT_LOCK:
        _EXPORT_SEQ[0] += 1
        tid = _EXPORT_SEQ[0]
        _EXPORT_TASKS[tid] = {"done": False, "ok": False, "percent": 0,
                              "phase": "准备导出", "dir": "", "native": False,
                              "messages": []}

    def progress(percent, text):
        t = _EXPORT_TASKS.get(tid)
        if t is not None:
            t["percent"] = int(percent)
            t["phase"] = text

    def worker():
        t = _EXPORT_TASKS.get(tid)
        try:
            with _build_lock:
                if kind == "python":
                    res = B.export_python(proj_dir, cfg, "release", "run",
                                          progress=progress)
                else:
                    res = B.export_cpp(proj_dir, cfg, "release", "run",
                                       native=True, progress=progress)
        except Exception as e:  # noqa: BLE001 任何异常都要反馈到进度条
            res = {"ok": False,
                   "messages": [{"kind": "error", "file": "", "line": 0, "col": 0,
                                 "text": f"导出失败：{e}"}]}
        t["ok"] = bool(res.get("ok"))
        t["dir"] = res.get("dir", "")
        t["native"] = bool(res.get("native"))
        msgs = list(res.get("messages") or [])
        if not t["ok"] and not msgs:
            msgs = [{"kind": "error", "file": "", "line": 0, "col": 0,
                     "text": "导出失败（无详细信息）"}]
        t["messages"] = msgs
        t["done"] = True

    threading.Thread(target=worker, daemon=True).start()
    return tid


def get_port() -> int:
    """配置的服务端口（config/settings.json -> port，默认 8405）。"""
    try:
        p = int(T.get_settings().get("port") or PORT)
    except (TypeError, ValueError):
        p = PORT
    return p


def port_available(port: int) -> bool:
    """检测本机端口是否可用：
    1) 有活动服务在监听（能连上）→ 被占用；
    2) 无监听但刚才有连接残留（TIME_WAIT）→ 不算占用（服务启动用 SO_REUSEADDR 可正常绑定）。"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        if s.connect_ex(("127.0.0.1", port)) == 0:
            return False
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def _list_ide_pids() -> list:
    """列出「其它」正在运行的云易IDE 服务进程 PID。

    两种运行形态都要认（否则打包后重启会误判「端口被别的程序占用」而拒绝启动）：
      · 源码运行：`python*.exe`，且命令行里含 `server\\server.py`；
      · 打包运行（PyInstaller 打的 云易IDE.exe）：**进程名就是 exe 自己**，
        命令行里根本没有 server.py，只认 python* 会漏掉它。
    结果还会与「正占着该端口的进程」取交集，所以条件放宽也不会误杀用户的其它程序。
    """
    if os.name != "nt":
        return []
    me = os.getpid()
    cond = "($_.Name -like 'python*' -and $_.CommandLine -like '*server\\server.py*')"
    exe = os.path.basename(sys.executable or "")
    if exe and not exe.lower().startswith("python"):
        cond = "(" + cond + " -or $_.Name -ieq '" + exe + "')"
    ps = ("Get-CimInstance Win32_Process | Where-Object { " + cond +
          " } | ForEach-Object { $_.ProcessId }")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                             capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return []
    pids = []
    for ln in (out or "").splitlines():
        ln = ln.strip()
        if ln.isdigit() and int(ln) != me:
            pids.append(int(ln))
    return pids


def _port_owner_pids(port: int) -> list:
    """占着指定端口（LISTENING）的进程 PID 列表；查不到返回空列表。"""
    if os.name != "nt":
        return []
    ps = ("Get-NetTCPConnection -LocalPort %d -State Listen -ErrorAction SilentlyContinue "
          "| Select-Object -ExpandProperty OwningProcess" % port)
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                             capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return []
    pids = []
    for ln in (out or "").splitlines():
        ln = ln.strip()
        if ln.isdigit():
            pids.append(int(ln))
    return pids


def _ensure_port_free(port: int) -> None:
    """启动前确保端口归自己用；被上一次残留的 IDE 占着就先把它结束掉。

    为什么必须做：``http.server`` 默认 ``allow_reuse_address = 1``，而 **Windows 的
    SO_REUSEADDR 允许两个进程同时绑定同一端口** —— 后启动的那个「启动成功却收不到
    任何连接」，旧进程继续服务全部请求。表现就是「代码改了、IDE 也重启了，行为却
    还是旧的」，极难排查（见 2026-09-19 的 Sciter 运行库不拷贝事件）。

    **只结束「确实占着这个端口、且是云易IDE 服务」的进程**：
      · 别的程序占着这个端口 → 不杀，抛 RuntimeError 让用户换端口；
      · 别的 IDE 实例占着**别的**端口 → 完全不受影响（不能连坐）。
    """
    if port_available(port):          # 没人在监听（TIME_WAIT 不算）→ 直接用
        return
    owners = set(_port_owner_pids(port))                    # 谁占着这个端口
    doomed = [p for p in _list_ide_pids() if p in owners]   # 其中属于云易IDE 的
    if doomed:
        print("检测到上一次的云易IDE 服务仍占着端口 %d（PID %s），先结束它再启动 ..."
              % (port, ", ".join(str(p) for p in doomed)))
        for p in doomed:
            try:
                subprocess.run(["taskkill", "/f", "/pid", str(p)],
                               capture_output=True, timeout=10)
            except Exception:
                pass
        for _ in range(30):           # 最多等 3 秒让端口释放
            if port_available(port):
                print("旧实例已结束。")
                return
            time.sleep(0.1)
    raise RuntimeError(
        "端口 %d 已被其它程序占用，无法启动云易IDE。\n"
        "  · 请关闭占用该端口的程序；或\n"
        "  · 在 config/settings.json 里改 \"port\"（例如 8406）后重新启动。" % port)


def port_check_report() -> dict:
    """「检查环境」用的端口报告：
    配置端口就是当前服务端口 → 直接跳过检查；否则做一次可绑定检测。"""
    cfg = get_port()
    cur = _state["port"]
    if cfg == cur:
        return {"port": cfg, "portCurrent": True,
                "portNote": "当前端口，跳过检查"}
    if port_available(cfg):
        return {"port": cfg, "portCurrent": False, "portNote": "可用"}
    return {"port": cfg, "portCurrent": False, "portNote": "被占用，无法切换"}


def workspace_dir() -> str:
    # 工程目录（工作区）：默认 IDE 根目录下的「工作区」，随整个目录搬家（绿色版）。
    # 用户可在「环境设置」里改成别处；落在 IDE 目录内的会被压回相对路径存，
    # 落在目录外的（跟随不了的）才保留绝对路径。
    # getcwd() 兜底：直接以别的工作目录跑 server.py 时仍能落到下级的「工作区」。
    ws = T.get_settings().get("workspace") or os.path.join(os.getcwd(), "工作区")
    os.makedirs(ws, exist_ok=True)
    return ws


def _read_lib_classes(arch: str = "") -> list:
    """读取 IDE 根目录的类库文件（供侧栏「类」/「API」/「控件库」栏展示）：

    · ``*.class`` → 数据类型 + 类函数（core 系排最前，其余按名称排序）
    · ``*.api``   → API 声明（core 系排最前，其余按名称排序）
    · ``*.const`` → 常量声明（core.const 优先，其余按名称排序）

    返回 ``[{file, kind, text}]``（kind = class / api / const），前端按 kind 分别解析：
    .class 只取类型与类函数，.api 只取 API 声明，.const 只取常量声明。

    架构过滤：**所有名字带 ``_x86`` 的文件都按 x64 / x86 成对切换，只返回属于
    当前架构的那一份**（qt.class ↔ qt_x86.class、sciter.api ↔ sciter_x86.api、
    core.class ↔ core_x86.class ……）；没有 ``_x86`` 对应版本的文件不受影响。

    ``arch`` 由调用方（前端）按**当前工程记录的架构**显式传入 —— 三个栏的内容
    都是「编译类型决定载入哪套文件」，跟着工具栏那个列表框走才不会串版本；
    留空或非法值时回落到全局设置（toolchain.get_arch()）。
    """
    out = []

    # 架构过滤：所有 *_x86.* 文件成对切换 —— x64 只加载 x64 版，x86 只加载 _x86 版
    # （与编译侧 libauto._names_of 同一规则；core 系文件排最优先加载）
    from yunyi import toolchain as TC
    arch = (arch or "").strip().lower()
    if arch not in ("x86", "x64"):
        arch = (TC.get_arch() or "x64").strip().lower()   # 未指定 / 非法 → 全局设置
    if arch not in ("x86", "x64"):
        arch = "x64"                                       # 全局值也异常 → 按 x64 处理

    # 文件表与编译链共用（libauto.lib_files）：界面语言非中文时优先取
    # lib\<语言>\ 下的同名文件（如 lib\en_us\core.class），其余文件从 lib 兜底。
    from yunyi.libauto import _arch_skip_names, lib_files
    fmap = lib_files()
    if not fmap:
        return out
    names = list(fmap.keys())
    skip_set = _arch_skip_names(names, arch)

    def pick(ext, first):
        got = sorted((n for n in names if n.lower().endswith(ext) and n not in skip_set),
                     key=lambda n: n.lower())
        # core 前缀文件排最前：按优先级取第一个在场的候选（x86 时 core_x86.* 优先）。
        # 按文件名（basename）匹配 —— 语言目录里的文件相对名带前缀（en_us/core.class）。
        for cand in ([first] if isinstance(first, str) else first):
            hit = next((n for n in got if os.path.basename(n).lower() == cand.lower()), None)
            if hit is not None:
                got.sort(key=lambda n: n != hit)
                break
        return got

    # classlib 通道（探测式）：非 UTF-8（GBK）的类库也能读
    for ext, first in ((".class", ("core.class", "core_x86.class")),
                       (".api", ("core.api", "core_x86.api")),
                       (".const", "core.const")):
        for n in pick(ext, first):
            try:
                with open(fmap[n], "rb") as f:
                    out.append({"file": n, "kind": ext[1:],
                                "text": CODEC.decode("classlib", f.read())})
            except Exception:
                pass
    return out


def project_dir(name: str) -> str:
    if not name:
        raise ValueError("缺少 project 参数")
    base = os.path.abspath(workspace_dir())
    p = os.path.normpath(os.path.join(base, name))
    if os.path.commonpath([base, p]) != base or not os.path.isdir(p):
        raise ValueError("工程不存在：" + name)
    return p


def proj_choices(name: str):
    """载入工程并套用工程标记（程序类型 / 架构 / 模式），返回 (工程目录, 配置)。

    - 未标记的工程按内容 / 编译产物自动识别并写回 .yyproj（与打开工程一致）；
    - 工程架构同步到全局设置 —— 编译器选择、代码生成、Qt 运行库部署都读全局架构。

    编译 / 运行 / 测试 / 导出 / 发布 / 构建脚本等入口都经过这里，
    保证「当前工程用的是 x64 还是 x86、调试版还是发布版」在整条流水线上生效。"""
    d = project_dir(name)
    cfg = P.load_project(d)
    try:
        P.apply_project_env(d, cfg)
    except Exception:
        pass
    return d, cfg


def _path_inside(base: str, rel: str) -> str:
    base = os.path.abspath(base)
    p = os.path.normpath(os.path.join(base, rel))
    if os.path.commonpath([base, p]) != base:
        raise ValueError("非法路径：" + rel)
    return p


def _read_json_body(handler) -> dict:
    length = int(handler.headers.get("Content-Length") or 0)
    raw = handler.rfile.read(length) if length else b"{}"
    try:
        # http 通道：请求体按 UTF-8 解（非法字节按本机代码页兜底，不再直接判死）
        return json.loads(CODEC.decode("http", raw))
    except Exception:
        return {}


def list_installed_fonts():
    """列出系统已安装的**字体族名**（给设计器 / 属性面板的「字体选择框」用）。

    用 Windows 自带的 GDI 枚举（ctypes 直调 EnumFontFamiliesExW，不需要第三方库、
    也不用起子进程）：拿到的是**本地化的族名** —— 中文系统上就是「微软雅黑」「宋体」
    「黑体」这些，正好能直接填进 font-family / 生成的代码里；
    按风格重复的条目（Arial Bold / Arial Italic…）会由去重合并掉。
    枚举不到（非 Windows / 出错）就返回空表 —— 前端会退回内置的常用字体表。
    """
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return []

    class LOGFONTW(ctypes.Structure):
        _fields_ = [("lfHeight", wintypes.LONG), ("lfWidth", wintypes.LONG),
                    ("lfEscapement", wintypes.LONG), ("lfOrientation", wintypes.LONG),
                    ("lfWeight", wintypes.LONG), ("lfItalic", ctypes.c_ubyte),
                    ("lfUnderline", ctypes.c_ubyte), ("lfStrikeOut", ctypes.c_ubyte),
                    ("lfCharSet", ctypes.c_ubyte), ("lfOutPrecision", ctypes.c_ubyte),
                    ("lfClipPrecision", ctypes.c_ubyte), ("lfQuality", ctypes.c_ubyte),
                    ("lfPitchAndFamily", ctypes.c_ubyte), ("lfFaceName", ctypes.c_wchar * 32)]

    class ENUMLOGFONTEXW(ctypes.Structure):
        _fields_ = [("elfLogFont", LOGFONTW), ("elfFullName", ctypes.c_wchar * 64),
                    ("elfStyle", ctypes.c_wchar * 32), ("elfScript", ctypes.c_wchar * 32)]

    names = []
    try:
        gdi32 = ctypes.WinDLL("gdi32")
        user32 = ctypes.WinDLL("user32")
        CB = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.POINTER(ENUMLOGFONTEXW),
                                ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)

        def _cb(lf, _tm, _ft, _lp):
            face = lf.contents.elfLogFont.lfFaceName
            if face and not face.startswith("@"):     # "@微软雅黑" 是竖排变体，不要
                names.append(face)
            return 1

        hdc = user32.GetDC(None)
        try:
            lf = LOGFONTW()
            lf.lfCharSet = 1                          # DEFAULT_CHARSET：中英文字体都列出来
            gdi32.EnumFontFamiliesExW(hdc, ctypes.byref(lf), CB(_cb), None, 0)
        finally:
            if hdc:
                user32.ReleaseDC(None, hdc)
    except Exception:
        return []

    out, seen = [], set()
    for n in names:
        k = n.lower()
        if k not in seen:
            seen.add(k)
            out.append(n)
    # 中文名（中文 IDE 用得多）排前面，其余按字母序
    return sorted(out, key=lambda s: (0 if any("\u4e00" <= c <= "\u9fff" for c in s) else 1, s.lower()))


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "YunYiIDE/1.0"

    # ---------- 基础 ----------
    def log_message(self, *a):
        pass

    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_err(self, msg, code=400):
        self._send_json({"ok": False, "error": msg}, code)

    def _ok(self, **kw):
        self._send_json({"ok": True, **kw})

    def do_GET(self):  # noqa: N802
        try:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path.startswith("/api/"):
                self._route_get(parsed)
            else:
                self._serve_static(parsed.path)
        except BrokenPipeError:
            pass
        except Exception as e:
            try:
                self._send_err(str(e), 500)
            except Exception:
                pass

    def do_POST(self):  # noqa: N802
        try:
            parsed = urllib.parse.urlparse(self.path)
            if not parsed.path.startswith("/api/"):
                self._send_err("not found", 404)
                return
            body = _read_json_body(self)
            self._route_post(parsed.path, body)
        except BrokenPipeError:
            pass
        except ValueError as e:
            self._send_err(str(e))
        except Exception as e:
            try:
                self._send_err(str(e), 500)
            except Exception:
                pass

    # ---------- 静态文件 ----------
    def _serve_static(self, path: str):
        rel = urllib.parse.unquote(path.lstrip("/"))
        if not rel or rel.endswith("/"):
            rel += "index.html"
        fp = os.path.normpath(os.path.join(WEB_DIR, rel))
        if os.path.commonpath([WEB_DIR, fp]) != WEB_DIR or not os.path.isfile(fp):
            self.send_error(404)
            return
        ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/json", "image/svg+xml"):
            ctype += "; charset=utf-8"
        with open(fp, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ---------- GET 路由 ----------
    def _route_get(self, parsed):
        q = urllib.parse.parse_qs(parsed.query)
        p = parsed.path

        def one(k, d=""):
            return (q.get(k) or [d])[0]

        if p == "/api/export/status":
            # 「导出 C++」进度查询（前端进度条每 200ms 轮询一次）
            tid = int(one("tid", "0") or 0)
            t = _EXPORT_TASKS.get(tid)
            if t is None:
                self._send_err("导出任务不存在", 404)
                return
            self._send_json({"ok": True, **dict(t)})
        elif p == "/api/env":
            # 工具链路径自动填入：tools 子目录下存在就用 tools 里的，
            # 不存在才检查系统（结果写回 settings.json；已手动指定过的路径不覆盖）
            for fn in (T.core_autofill, T.bash_autofill, T.node_autofill,
                       T.pip_autofill, T.packages_autofill):
                try:
                    fn()
                except Exception:
                    pass
            self._ok(env=T.env_report(), **port_check_report())
        elif p == "/api/corelib":
            # 核心库命令表（供侧栏「核心库」展示，数据源 yunyi/corelib.py）
            from yunyi import corelib as CL
            self._ok(categories=CL.categories(), commands=CL.commands())
        elif p == "/api/lib/classes":
            # 「类」/「API」/「控件库」栏：读取 lib 目录下的 *.class（数据类型 + 类函数）
            # 与 *.api（API 声明）；core.class / core.api 各排最前。
            # arch 决定载入哪一套控件库（x64 → qt.* / sciter.*，x86 → qt_x86.* / sciter_x86.*）：
            # 前端按「当前工程记录的架构」显式传来，避免与全局设置不一致时载错版本。
            want = (one("arch") or "").strip().lower()
            self._ok(files=_read_lib_classes(want),
                     arch=(want if want in ("x86", "x64") else T.get_arch()))
        elif p == "/api/ideconfig":
            # IDE 界面设置（config/ide_settings.json：IDE配色 / 主题 / 字号）
            self._ok(config=_read_ide_config())
        elif p == "/api/langs":
            # 多语言：config\*.lng 语言包列表 + 当前语言（settings.json 的 language）
            cur = str(T.get_settings().get("language") or "zh_cn").strip() or "zh_cn"
            self._ok(current=cur, langs=_list_lngs())
        elif p == "/api/lang":
            # 读一个语言包 → {name, label, dict}（键 = 界面原文，值 = 译文）
            try:
                self._ok(**_read_lng(one("name", "zh_cn")))
            except ValueError as e:
                self._send_err(str(e), 404)
        elif p == "/api/projects":
            self._ok(projects=P.list_projects(workspace_dir()), workspace=workspace_dir())
        elif p == "/api/fonts":
            # 设计器 / 属性面板的「字体」选择框：系统已安装的字体族名（读注册表，很快）
            self._ok(fonts=list_installed_fonts())
        elif p == "/api/tree":
            self._ok(tree=self._tree(project_dir(one("project"))))
        elif p == "/api/file":
            base = project_dir(one("project"))
            fp = _path_inside(base, one("path"))
            if os.path.isdir(fp):
                self._ok(isDir=True, path=one("path"))
                return
            if not os.path.isfile(fp):
                # 文件不存在（如某工程还没保存过设计文件）→ 404，让客户端按「没有」处理，
                # 而不是抛 FileNotFoundError 变成 500（控制台/日志里会显得像出了问题）
                self._send_err("文件不存在：" + one("path"), 404)
                return
            with open(fp, "rb") as f:
                data = f.read()
            # frontend 通道：前端编辑器固定 UTF-8。能按 UTF-8（含 BOM）当文本读就当文本，
            # 否则 base64 + binary 交给前端提示「非文本文件」（GBK 的 .yy 也不例外）。
            text, enc = CODEC.decode_ex("frontend", data)
            if enc.startswith("utf-8") and not enc.endswith("*"):
                self._ok(text=text, binary=False)
            else:
                self._ok(b64=base64.b64encode(data).decode("ascii"), binary=True)
        elif p == "/api/project/load":
            name = one("project")
            d = project_dir(name)
            cfg = P.load_project(d)
            # 打开工程：程序类型已标记则沿用；未标记则按内容自动识别并写回 .yyproj（打标记）
            sub, auto = P.ensure_subsystem(d, cfg)
            cfg["subsystem"] = sub
            cfg["subsystemLabel"] = P.SUBSYS_LABEL.get(sub, sub)
            cfg["subsystemAuto"] = auto
            # 目标架构（x64/x86）：已标记则沿用；未标记则自动识别并写回
            arch, arch_auto = P.ensure_arch(d, cfg)
            cfg["arch"] = arch
            cfg["archLabel"] = P.ARCH_LABEL.get(arch, arch)
            cfg["archAuto"] = arch_auto
            # 编译模式（调试版/发布版）：已标记则沿用；未标记则自动识别并写回
            mode, mode_auto = P.ensure_mode(d, cfg)
            cfg["mode"] = mode
            cfg["modeLabel"] = P.MODE_LABEL.get(mode, mode)
            cfg["modeAuto"] = mode_auto
            # 同步全局设置：编译链（g++ / Qt 运行库 / 代码生成）读 toolchain.get_arch()；
            # 模式作为「上次使用」的记忆，新建工程 / 无工程启动时作为默认值
            T.save_settings({"arch": arch, "mode": mode})
            cfg["sources"] = P.list_sources(d)
            self._ok(project=cfg)
        elif p == "/api/git/status":
            self._ok(**git_status(project_dir(one("project"))))
        elif p == "/api/git/log":
            self._ok(**git_log(project_dir(one("project"))))
        elif p == "/api/git/diff":
            self._ok(**git_diff(project_dir(one("project"))))
        elif p == "/api/git/branches":
            self._ok(**git_branches(project_dir(one("project"))))
        elif p.startswith("/api/session/"):
            parts = p.split("/")
            sid = int(parts[3])
            sess = S.SESSIONS.get(sid)
            if not sess:
                self._send_err("会话不存在", 404)
                return
            since = int(one("since", "0") or 0)
            self._ok(**sess.poll(since))
        elif p == "/api/ai/config":
            # AI 智能体接口配置（默认接口 / 三个自定义接口）
            #   cfg    = 实际生效用的配置（缺项由内置默认值兜底）
            #   stored = 磁盘上**真正保存**的配置（设置面板与模型列表用它：
            #            没配置过的接口在界面上就是空的，不拿内置默认值冒充用户数据）
            AI = ai_backend()
            self._ok(cfg=AI.load_cfg(), stored=AI.stored_cfg())
        elif p == "/api/ai/context":
            # 当前会话上下文用量（输入框右侧环形进度圈）
            AI = ai_backend()
            self._ok(**AI.context_usage())
        elif p == "/api/ai/session":
            # 当前会话概况（会话 id / 条数 / sticky 工程 / 运行时是否就绪）
            AI = ai_backend()
            self._ok(**AI.session_info())
        elif p == "/api/ai/status":
            # 后端健康状态（The future is promising. 运行时 / 对话模式 / 沙箱 / 最近错误）
            AI = ai_backend()
            self._ok(**AI.status())
        elif p == "/api/ai/history":
            # 会话历史（OpenAI 格式 messages）：页面刷新 / 程序重启后恢复聊天记录。
            # 只保存「显示层转录」，落在 .temp/agent/session.json，点「新会话」才清空。
            AI = ai_backend()
            self._ok(**AI.history())
        elif p == "/api/ai/attach":
            # 刷新后重连（SSE）：若后端还有回合在跑，先回 {"type":"attach","base"}
            # 再重放该回合已发生的全部事件并跟到结束；没有回合在跑则回
            # {"type":"idle"}，前端照旧走历史恢复。base = 渲染历史时只取转录前
            # base 条，本轮已完成的步骤由重放事件补上，不会重复。
            AI = ai_backend()
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            gen = AI.attach_stream()
            try:
                for ev in gen:
                    data = json.dumps(ev, ensure_ascii=False)
                    self.wfile.write(("data: " + data + "\n\n").encode("utf-8"))
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                pass
            return
        elif p == "/api/ai/runtime":
            # 智能体运行时参数（预算 / PTC 对话模式 / 安全开关 / 可观测性 / Multi-Agent）
            AI = ai_backend()
            self._ok(runtime=AI.load_runtime())
        elif p == "/api/ai/prompts":
            # 快捷提示词列表（config/prompts.json）：前端弹出选择，点一项直接发给智能体
            self._ok(prompts=_read_prompts())
        elif p == "/api/ai/backend":
            # 当前 AI 后端（hope2 = 纯 Python 智能体，server\The_future_is_promising\）
            self._ok(backend=ai_backend_name(), available=list(AI_BACKENDS))
        else:
            self._send_err("no such api", 404)

    def _tree(self, base):
        items = []

        def scan(d, rel):
            out = []
            for name in sorted(os.listdir(d)):
                if name in HIDE_DIRS:
                    continue
                fp = os.path.join(d, name)
                rp = (rel + "/" + name) if rel else name
                if os.path.isdir(fp):
                    kids = scan(fp, rp)
                    out.append({"path": rp.replace("\\", "/"), "name": name,
                                "dir": True, "children": kids})
                else:
                    ext = os.path.splitext(name)[1].lower()
                    if ext in HIDE_EXTS:
                        continue
                    out.append({"path": rp.replace("\\", "/"), "name": name,
                                "dir": False, "size": os.path.getsize(fp)})
            return out

        items = scan(base, "")
        return items

    # ---------- POST 路由 ----------
    def _route_post(self, path, body):
        p = path
        if p == "/api/settings":
            updates = {k: v for k, v in body.items() if k in (
                "gxx", "make", "git", "python", "pip", "bash", "node",
                "qt", "qtx86", "sciter", "sciterx86", "zstd", "workspace")}
            if (body.get("arch") or "").strip().lower() in ("x86", "x64"):
                updates["arch"] = body["arch"].strip().lower()
            # 程序类型：window（窗口程序，-mwindows）/ console（控制台程序）/ dll（DLL 程序，-shared）
            if (body.get("subsystem") or "").strip().lower() in ("console", "window", "dll"):
                updates["subsystem"] = body["subsystem"].strip().lower()
            # 编译模式：debug（调试版 -O0 -g）/ release（发布版 -O2）
            if (body.get("mode") or "").strip().lower() in ("debug", "release"):
                updates["mode"] = body["mode"].strip().lower()
            # 界面语言：config 目录下必须存在对应的 *.lng 语言包才接受（值 = 文件主名）
            if (body.get("language") or "").strip():
                want = str(body["language"]).strip()
                if os.path.isfile(_lng_path(want)):
                    updates["language"] = os.path.basename(_lng_path(want))[:-4]
            port_changed = None
            if body.get("port") not in (None, ""):
                try:
                    new_port = int(body["port"])
                except (TypeError, ValueError):
                    raise ValueError("端口必须是数字：" + str(body["port"]))
                if not (1 <= new_port <= 65535):
                    raise ValueError("端口超出范围（1~65535）：" + str(new_port))
                cur = _state["port"]
                if new_port != cur and not port_available(new_port):
                    raise ValueError("端口 %d 已被占用，请换一个端口" % new_port)
                updates["port"] = new_port
                if new_port != cur:
                    port_changed = new_port
            T.save_settings(updates)
            if port_changed:
                # 保存成功后热切换端口（先绑新端口再关旧的，失败则保持原端口）
                threading.Timer(0.2, _switch_port, args=(port_changed,)).start()
                self._ok(env=T.env_report(), port=port_changed,
                         portChanged=True, portCurrent=False,
                         portNote="已切换，稍后自动跳转到新地址")
            else:
                self._ok(env=T.env_report(), **port_check_report())
        elif p == "/api/ideconfig":
            # 保存 IDE 界面设置（前端把镜像整包发来，这里与磁盘上的合并后写回）
            if not isinstance(body, dict):
                raise ValueError("ideconfig 需要 JSON 对象")
            self._ok(config=_write_ide_config(body))
        elif p == "/api/workspace":
            ws = body.get("workspace", "")
            if not os.path.isdir(ws):
                raise ValueError("目录不存在：" + ws)
            T.save_settings({"workspace": ws})
            self._ok(projects=P.list_projects(ws), workspace=ws)
        elif p == "/api/project/new":
            name = (body.get("name") or "").strip()
            subsystem = (body.get("subsystem") or "console").strip().lower()
            # 架构 / 模式可一并指定；留空 → 新建工程时不打标记，首次打开按产物自动识别
            arch = (body.get("arch") or "").strip().lower()
            mode = (body.get("mode") or "").strip().lower()
            info = P.create_project(workspace_dir(), name, subsystem, arch, mode)
            self._ok(project=info)
        elif p == "/api/project/delete":
            # 删除工程：整个工程目录一起删掉（源码 .yy / 工程配置 .yyproj /
            # 构建脚本与 build / 发布 / 导出产物），不可恢复。
            # 只接受工作区的**直接子目录**（project_dir 已做越界校验，这里再挡一道，
            # 免得 name 为 "." 之类把工作区本身端了）。
            name = (body.get("project") or "").strip()
            d = project_dir(name)
            if os.path.dirname(os.path.abspath(d)) != os.path.abspath(workspace_dir()):
                raise ValueError("只能删除工作区下的工程目录：" + name)
            shutil.rmtree(d)
            self._ok(projects=P.list_projects(workspace_dir()),
                     workspace=workspace_dir(), name=name)
        elif p == "/api/project/subsystem":
            # 工具栏「程序类型」：写入当前工程的 .yyproj（工程级设置）
            name = body.get("project")
            subsystem = (body.get("subsystem") or "").strip().lower()
            if subsystem not in P.SUBSYS_LABEL:
                raise ValueError("未知程序类型：" + str(subsystem))
            d = project_dir(name)
            cfg = P.load_project(d)
            cfg["subsystem"] = subsystem
            cfg2 = P.save_project_config(d, cfg)
            cfg2["subsystemLabel"] = P.SUBSYS_LABEL.get(subsystem, subsystem)
            self._ok(project=cfg2)
        elif p == "/api/project/arch":
            # 工具栏「目标架构」：写入当前工程的 .yyproj（工程级）并同步全局设置
            name = body.get("project")
            arch = (body.get("arch") or "").strip().lower()
            if arch not in P.ARCH_LABEL:
                raise ValueError("未知架构：" + str(arch))
            d = project_dir(name)
            cfg = P.load_project(d)
            cfg["arch"] = arch
            cfg2 = P.save_project_config(d, cfg)
            cfg2["archLabel"] = P.ARCH_LABEL.get(arch, arch)
            # 同步全局设置（编译链通过 toolchain.get_arch() 读取全局值）
            T.save_settings({"arch": arch})
            self._ok(project=cfg2, env=T.env_report())
        elif p == "/api/project/mode":
            # 工具栏「编译模式」：写入当前工程的 .yyproj（工程级设置）
            name = body.get("project")
            mode = (body.get("mode") or "").strip().lower()
            if mode not in P.MODE_LABEL:
                raise ValueError("未知编译模式：" + str(mode))
            d = project_dir(name)
            cfg = P.load_project(d)
            cfg["mode"] = mode
            cfg2 = P.save_project_config(d, cfg)
            cfg2["modeLabel"] = P.MODE_LABEL.get(mode, mode)
            # 同步全局设置（作为新建工程 / 下次启动的默认模式）
            T.save_settings({"mode": mode})
            self._ok(project=cfg2)
        elif p == "/api/project/save":
            name = body.get("project")
            cfg = body.get("config") or {}
            d = project_dir(name)
            cfg2 = P.save_project_config(d, cfg)
            self._ok(project=cfg2)
        elif p == "/api/file":
            base = project_dir(body.get("project", ""))
            rel = body.get("path", "")
            fp = _path_inside(base, rel)
            content = body.get("content")
            if content is None:
                raise ValueError("缺少 content")
            os.makedirs(os.path.dirname(fp), exist_ok=True)
            CODEC.write("frontend", fp, content)     # 编辑器保存：frontend 通道（UTF-8）
            self._ok(path=rel)
        elif p == "/api/file/new":
            base = project_dir(body.get("project", ""))
            rel = body.get("path", "")
            fp = _path_inside(base, rel)
            if os.path.exists(fp):
                raise ValueError("文件已存在：" + rel)
            os.makedirs(os.path.dirname(fp), exist_ok=True)
            CODEC.write("frontend", fp, body.get("content") or "")
            self._ok(path=rel)
        elif p == "/api/file/delete":
            base = project_dir(body.get("project", ""))
            fp = _path_inside(base, body.get("path", ""))
            if os.path.isdir(fp):
                shutil.rmtree(fp)        # 模块顶部已 import shutil（这里不能写局部 import，
                                         # 否则整个 _route_post 里 shutil 都成了局部变量）
            else:
                os.remove(fp)
            self._ok()
        elif p == "/api/file/rename":
            base = project_dir(body.get("project", ""))
            old = _path_inside(base, body.get("old", ""))
            new = _path_inside(base, body.get("new", ""))
            os.rename(old, new)
            self._ok()
        elif p == "/api/translate":
            name = body.get("project")
            d, cfg = proj_choices(name)
            target = body.get("target", "run")
            mode = body.get("mode") or P.resolve_mode(d, cfg)
            res = B.compile_yunyi(d, cfg, mode, target)
            if res["ok"]:
                self._ok(cpp=res["artifacts"]["cpp"], messages=res["messages"])
            else:
                self._send_err(res["messages"][-1]["text"] if res["messages"] else "翻译失败", 422)
        elif p == "/api/build":
            name = body.get("project")
            d, cfg = proj_choices(name)
            # 编译模式：请求未指定则用「本工程的模式」（调试版 / 发布版）
            mode = body.get("mode") or P.resolve_mode(d, cfg)
            target = body.get("target", "run")
            with _build_lock:
                res = B.compile_yunyi(d, cfg, mode, target)
            self._send_json({"ok": res["ok"], "result": res})
        elif p == "/api/run":
            name = body.get("project")
            d, cfg = proj_choices(name)
            mode = body.get("mode") or P.resolve_mode(d, cfg)
            target = body.get("target", "run")
            with _build_lock:
                res = B.compile_yunyi(d, cfg, mode, target)
            if not res["ok"]:
                self._send_json({"ok": False, "result": res})
                return
            sess = S.new_run_session([res["artifacts"]["exe"]],
                                     cwd=os.path.dirname(res["artifacts"]["exe"]),
                                     title=f"{name} [{target}]")
            self._ok(sid=sess.id, result=res)
        elif p.startswith("/api/session/"):
            parts = p.split("/")
            sid = int(parts[3])
            act = parts[4] if len(parts) > 4 else ""
            sess = S.SESSIONS.get(sid)
            if not sess:
                self._send_err("会话不存在", 404)
                return
            if act == "input":
                self._ok(sent=sess.send_input(body.get("data", "")))
            elif act == "kill":
                sess.kill()
                self._ok()
            else:
                self._send_err("no such api", 404)
        elif p == "/api/export":
            # 异步启动导出（后台线程执行），前端凭 tid 轮询 /api/export/status 画进度条
            # kind: cpp（默认，纯正 C++）| python（导出 Python 工程）
            name = body.get("project")
            kind = body.get("kind") or "cpp"
            d, cfg = proj_choices(name)
            tid = _start_export_task(d, cfg, kind)
            self._ok(tid=tid)
        elif p == "/api/release":
            name = body.get("project")
            d, cfg = proj_choices(name)
            with _build_lock:
                res = B.release_project(d, cfg)
            if res["ok"]:
                self._ok(dir=res["dir"], zip=res["zip"], exe=res["exe"])
            else:
                self._send_err(res["messages"][-1]["text"], 422)
        elif p == "/api/git/init":
            self._ok(**git_init(project_dir(body.get("project", ""))))
        elif p == "/api/git/commit":
            self._ok(**git_commit(project_dir(body.get("project", "")),
                                  body.get("message", "更新")))
        elif p == "/api/git/branch":
            self._ok(**git_branch_op(project_dir(body.get("project", "")),
                                     body.get("action", "list"),
                                     body.get("name", "")))
        elif p == "/api/git/remote":
            self._ok(**git_remote_op(project_dir(body.get("project", "")),
                                     body.get("action", "list"),
                                     body.get("url", "")))
        elif p == "/api/git/sync":
            self._ok(**git_sync(project_dir(body.get("project", "")),
                                body.get("action", "pull"),
                                body.get("remote", "origin"),
                                body.get("branch", "")))
        elif p == "/api/build/script":
            # 第 7 项：生成 Makefile / CMakeLists.txt / 构建.bat / .gitignore
            d, cfg = proj_choices(body.get("project", ""))
            self._ok(**BS.generate_build_scripts(d, cfg, body.get("mode", "")))
        elif p == "/api/build/make":
            # 第 7 项：调用内置 make 依据 Makefile 构建
            d, cfg = proj_choices(body.get("project", ""))
            with _build_lock:
                res = BS.run_make(d, cfg, body.get("mode", ""),
                                  body.get("makeTarget", "all"))
            self._send_json({"ok": res["ok"], "result": res})
        elif p == "/api/build/clean":
            # 清理可重构的构建产物（build / 发布 / 导出C++）；dryRun 只统计不删除
            d, cfg = proj_choices(body.get("project", ""))
            with _build_lock:
                res = B.clean_build(d, cfg, bool(body.get("dryRun")))
            self._ok(clean=res)
        elif p == "/api/ci":
            # 第 10 项：生成 CI/CD 流水线配置
            d, cfg = proj_choices(body.get("project", ""))
            providers = body.get("providers") or ["github", "gitlab", "gitea"]
            self._ok(**CI.generate_ci(d, cfg, providers, repo_root=ROOT))
        elif p == "/api/ai/chat":
            # AI 智能体对话（SSE 流式事件：delta / think / tool_start / tool_result /
            # context / stats / notice / done / error）。干活的是 The future is promising. 运行时。
            AI = ai_backend()
            msg = (body.get("message") or "").strip()
            if not msg and not (body.get("images") or body.get("files")):
                raise ValueError("消息不能为空")
            ctx = {"project": body.get("project") or "",
                   "curFile": body.get("curFile") or "",
                   "curText": body.get("curText") or ""}
            # 附件：images（dataURL 列表）与 files（[{name,b64,size}] 列表）
            images = body.get("images") if isinstance(body.get("images"), list) else []
            files = body.get("files") if isinstance(body.get("files"), list) else []
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            gen = AI.stream_chat(msg, ctx.get("project"), ctx,
                                 images=images, files=files)
            try:
                for ev in gen:
                    data = json.dumps(ev, ensure_ascii=False)
                    self.wfile.write(("data: " + data + "\n\n").encode("utf-8"))
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                # 前端停止 SSE / 刷新页面：显式关闭生成器。回合与连接已解耦，
                # 关闭只是「停止观看」，后台回合继续跑、事件继续累积，
                # 前端刷新后经 GET /api/ai/attach 重连补看。
                try:
                    gen.close()
                except Exception:
                    pass
            except Exception as e:
                try:
                    data = json.dumps({"type": "error", "text": str(e)},
                                      ensure_ascii=False)
                    self.wfile.write(("data: " + data + "\n\n").encode("utf-8"))
                except Exception:
                    pass
            return
        elif p == "/api/ai/config":
            # 保存 AI 接口配置（body: {mode, default:{url,model,key}, custom:{...}}）
            AI = ai_backend()
            self._ok(cfg=AI.save_cfg(body or {}), stored=AI.stored_cfg())
        elif p == "/api/ai/test":
            # 测试连接：**优先测请求体里正在编辑的那套参数**（所见即所测），
            # 请求体没带才测已保存的当前接口。返回 ok / 延迟 / 可用模型列表 / tested
            AI = ai_backend()
            self._ok(**AI.test_connect_with(body))
        elif p == "/api/ai/clear":
            # 新会话：清空转录与会话缓冲（下一条消息开一个全新会话）
            AI = ai_backend()
            AI.clear_session()
            self._ok()
        elif p == "/api/ai/stop":
            # 停止当前回合：前端点「停止」时**先**打这里，后端置位取消事件
            # （立刻打断模型流与工具执行，远程模型停止生成），随后前端再断开
            # SSE 连接收尾。只断 SSE 只是停止观看，回合会自己在后台跑完。
            AI = ai_backend()
            self._send_json(AI.stop_turn())
        elif p == "/api/ai/confirm":
            # 人工确认（Human-in-the-loop）：工具想执行超出沙箱自动许可范围的
            # 动作时，后端把它转成前端的确认卡；用户点「确认执行 / 取消」就是
            # 这里把答复送回后端。
            #   body: {approve?: bool, all?: bool}（approve 默认 true；
            #         all = 「全部放行」：本任务剩余权限请求全部自动批准）
            AI = ai_backend()
            approve = body.get("approve")
            approve = True if approve is None else bool(approve)
            self._send_json(AI.answer_confirm(approve, bool(body.get("all"))))
        elif p == "/api/ai/runtime":
            # 保存智能体运行时参数（预算 / PTC 对话模式 / 安全开关 / 可观测性 / Multi-Agent）
            AI = ai_backend()
            self._ok(runtime=AI.save_runtime(body.get("runtime") or body or {}))
            # 设置面板可能改了 allowAll 开关：把持久化标记同步回当前进程的活动态
            AI.sync_allow_all()
        elif p == "/api/ai/backend":
            # 设置 AI 后端：{backend: "hope2"}，写进 config/settings.json 的
            # aiBackend（环境变量 YUNYI_AI_BACKEND 优先，设了它这里就改不动）。
            want = str((body or {}).get("backend") or "").strip().lower()
            if want not in AI_BACKENDS:
                self._send_err("后端只能是 %s" % " / ".join(AI_BACKENDS), 400)
                return
            if os.environ.get("YUNYI_AI_BACKEND", "").strip().lower() in AI_BACKENDS:
                self._send_err("已用环境变量 YUNYI_AI_BACKEND 锁定后端，请先去掉它", 400)
                return
            try:
                T.save_settings({"aiBackend": want})
            except Exception as e:                                # noqa: BLE001
                self._send_err("保存后端设置失败：%s" % e, 500)
                return
            self._ok(backend=ai_backend_name(), available=list(AI_BACKENDS))
        else:
            self._send_err("no such api", 404)


# ---------------- Git 集成 ----------------
def _run_git(proj, args):
    # -c core.quotepath=false：中文文件名按 UTF-8 原样输出；否则 git 会把它们转义成
    # \344\270\255 这类八进制串，界面/模型看到的就是看不懂的乱码
    return T.run(["git", "-c", "core.quotepath=false"] + args, cwd=proj, timeout=60)


def git_init(proj) -> dict:
    if os.path.isdir(os.path.join(proj, ".git")):
        return {"repo": True, "note": "已是 Git 仓库"}
    code, so, se = _run_git(proj, ["init"])
    return {"repo": code == 0,
            "note": CODEC.decode("shell_bash", se or so).strip() or "已初始化"}


def git_status(proj) -> dict:
    if not os.path.isdir(os.path.join(proj, ".git")):
        return {"repo": False, "lines": [], "branch": ""}
    code, so, se = _run_git(proj, ["status", "--short", "--branch"])
    text = CODEC.decode("shell_bash", so or se)
    lines = [ln for ln in text.splitlines() if ln.strip()]
    branch = ""
    for ln in lines:
        if ln.startswith("##"):
            branch = ln[2:].split("...")[0].strip()
    return {"repo": True, "lines": lines, "branch": branch}


def git_commit(proj, message) -> dict:
    _run_git(proj, ["add", "-A"])
    code, so, se = _run_git(proj, ["commit", "-m", message])
    note = CODEC.decode("shell_bash", so or se).strip()
    if code != 0 and "nothing to commit" in note:
        return {"ok": True, "note": "没有需要提交的更改"}
    return {"ok": code == 0, "note": note or "提交成功"}


def git_log(proj) -> dict:
    if not os.path.isdir(os.path.join(proj, ".git")):
        return {"repo": False, "commits": []}
    code, so, se = _run_git(proj, ["log", "--oneline", "-n", "30"])
    text = CODEC.decode("shell_bash", so or se)
    commits = [ln for ln in text.splitlines() if ln.strip()]
    return {"repo": True, "commits": commits}


def git_diff(proj) -> dict:
    """工作区改动明细（未提交）。"""
    if not os.path.isdir(os.path.join(proj, ".git")):
        return {"repo": False, "text": ""}
    code, so, se = _run_git(proj, ["diff", "--stat"])
    stat = CODEC.decode("shell_bash", so or se)
    code2, so2, se2 = _run_git(proj, ["diff"])
    full = CODEC.decode("shell_bash", so2 or se2)
    return {"repo": True, "stat": stat.strip() or "（无改动）", "text": full[:200000]}


def git_branches(proj) -> dict:
    if not os.path.isdir(os.path.join(proj, ".git")):
        return {"repo": False, "branches": [], "branch": ""}
    code, so, se = _run_git(proj, ["branch", "--list"])
    names = [ln.strip().lstrip("* ").strip()
             for ln in CODEC.decode("shell_bash", so or se).splitlines() if ln.strip()]
    return {"repo": True, "branches": names, "branch": git_status(proj).get("branch", "")}


def git_branch_op(proj, action: str, name: str) -> dict:
    if action == "create":
        if not name.strip():
            return {"ok": False, "note": "请填写分支名"}
        code, so, se = _run_git(proj, ["checkout", "-b", name.strip()])
    elif action == "checkout":
        if not name.strip():
            return {"ok": False, "note": "请选择分支"}
        code, so, se = _run_git(proj, ["checkout", name.strip()])
    elif action == "list":
        return git_branches(proj)
    else:
        return {"ok": False, "note": "不支持的操作：" + action}
    note = CODEC.decode("shell_bash", so or se).strip()
    return {"ok": code == 0, "note": note or "操作完成", **git_branches(proj)}


def git_remote_op(proj, action: str, url: str = "") -> dict:
    if action == "list":
        code, so, se = _run_git(proj, ["remote", "-v"])
        text = CODEC.decode("shell_bash", so or se).strip()
        return {"ok": True, "text": text or "（未配置远程仓库）"}
    if action == "set":
        if not url.strip():
            return {"ok": False, "note": "请填写远程仓库地址"}
        _run_git(proj, ["remote", "remove", "origin"])
        code, so, se = _run_git(proj, ["remote", "add", "origin", url.strip()])
        note = CODEC.decode("shell_bash", so or se).strip()
        return {"ok": code == 0, "note": note or "已设置 origin"}
    return {"ok": False, "note": "不支持的操作：" + action}


def git_sync(proj, action: str, remote: str = "origin", branch: str = "") -> dict:
    """拉取 / 推送（依赖本机 git 凭据配置）。"""
    if not os.path.isdir(os.path.join(proj, ".git")):
        return {"ok": False, "note": "还不是 Git 仓库"}
    if action == "pull":
        args = ["pull", remote] + ([branch] if branch else [])
    elif action == "push":
        cur = branch or git_status(proj).get("branch", "")
        args = ["push", "-u", remote] + ([cur] if cur else [])
    else:
        return {"ok": False, "note": "不支持的操作：" + action}
    code, so, se = _run_git(proj, args)
    note = CODEC.decode("shell_bash", (so or b"") + (se or b"")).strip()
    return {"ok": code == 0, "note": note or ("拉取完成" if action == "pull" else "推送完成")}


def _switch_port(new_port: int):
    """把服务从当前端口切到 new_port：先绑新端口（成功后才关旧的），失败保持原端口。"""
    try:
        new_httpd = ThreadingHTTPServer(("127.0.0.1", new_port), Handler)
    except OSError as e:
        print("端口切换失败，继续使用 %d：%s" % (_state["port"], e))
        return
    old = _state["httpd"]
    _state["port"] = new_port
    _state["httpd"] = new_httpd
    if old is not None:
        old.shutdown()      # 让旧 serve_forever 返回，主循环接管新端口
        old.server_close()  # 释放旧端口监听 socket（否则旧端口一直显示被占用）
    print("云易IDE 服务已切换端口：http://127.0.0.1:%d" % new_port)


def main(port=None):
    import webbrowser
    try:
        # 启动时把各工具链路径填进设置（tools 优先，其次系统），顺带预热工具链探测
        T.core_autofill()
        T.bash_autofill()
        T.node_autofill()
        T.packages_autofill()
        T.env_report()
    except Exception:
        pass
    # AI 后端自检：后端由 config/settings.json 的 aiBackend（或环境变量
    # YUNYI_AI_BACKEND）决定，默认 hope2（纯 Python 智能体，只用标准库，
    # 无需 Node / 依赖树 / 构建产物）。
    print("AI 后端：" + ai_backend_name())
    try:
        _backend = ai_backend()
        layout = _backend.ensure_layout()
        if layout.get("action") != "none":
            print("AI 后端依赖自检：" + str(layout.get("note")))
        if not layout.get("ok"):
            print("  · 智能体对话在依赖/构建就绪前不可用。")
    except Exception as e:
        print("AI 后端依赖检查失败：" + str(e))
    port = port or get_port()
    # 端口守卫：Windows 允许两个进程同时绑同一端口（SO_REUSEADDR），旧实例会继续
    # 接收全部请求 → 必须先清掉上一次的 IDE，否则「重启后行为没变」（详见 _ensure_port_free）
    try:
        _ensure_port_free(port)
        httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except RuntimeError as e:
        print(str(e))
        sys.exit(2)
    except OSError as e:
        print("端口 %d 绑定失败：%s\n"
              "  请关闭占用该端口的程序，或改 config/settings.json 里的 \"port\" 后重启。"
              % (port, e))
        sys.exit(2)
    _state["port"] = port
    _state["httpd"] = httpd
    print("云易IDE 服务已启动：http://127.0.0.1:%d" % port)
    threading.Timer(0.8, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    # serve_forever 正常阻塞；只有在设置中修改端口被 _switch_port shutdown 后
    # 才会返回，此时 _state 里已是绑定好新端口的服务器，继续循环为其服务
    while True:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            break
        nxt = _state["httpd"]
        if nxt is httpd:
            break
        httpd = nxt
        port = _state["port"]
    httpd.server_close()


if __name__ == "__main__":
    main()
