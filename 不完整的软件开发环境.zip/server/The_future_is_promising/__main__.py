# -*- coding: utf-8 -*-
"""The_future_is_promising 的命令行入口（自检 / 冒烟用，正常使用时 IDE 直接 import The_future_is_promising）。

    python -m server.The_future_is_promising              打印运行环境与当前后端状态
    python -m server.The_future_is_promising --test       测试当前接口连通性（模型列表 + 一次极短对话）
    python -m server.The_future_is_promising --chat "…"   真跑一个回合，把 SSE 事件打到标准输出
    python -m server.The_future_is_promising --tools      列出当前对话模式下会呈现给模型的工具
"""
from __future__ import annotations
import json
import sys


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    from . import config as CFG
    from . import runtime as RT
    from . import agent as AGENT
    from . import tools as TOOLS

    runtime = CFG.load_runtime()

    if "--tools" in argv:
        mode = str(runtime.get("toolsMode") or "ptc")
        names = TOOLS.visible_names(mode, runtime)
        print("对话模式 toolsMode = %s" % mode)
        for name in names:
            print("  · %s" % name)
        return 0

    if "--test" in argv:
        print(json.dumps(RT.test_connect_with({}), ensure_ascii=False, indent=2))
        return 0

    if "--chat" in argv:
        index = argv.index("--chat")
        message = " ".join(argv[index + 1:]).strip()
        if not message:
            print("用法：python -m server.The_future_is_promising --chat \"你的问题\"")
            return 2
        for event in RT.stream_chat(message, "", {"curFile": "", "curText": ""}):
            print(json.dumps(event, ensure_ascii=False))
        return 0

    layout = CFG.ensure_layout()
    print("运行环境：" + str(layout.get("note")))
    print("IDE 根目录：" + CFG.ROOT)
    print("工作区：" + CFG.workspace_dir())
    print("依赖自检：" + ("正常" if layout.get("ok") else "不可用"))
    print(json.dumps(RT.status(), ensure_ascii=False, indent=2))
    print("上下文窗口探测：%d tok" % AGENT.probe_context_window(
        str(CFG.active_api().get("url") or ""), str(CFG.active_api().get("key") or "")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
