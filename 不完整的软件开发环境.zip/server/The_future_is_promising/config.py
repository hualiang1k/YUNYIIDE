# -*- coding: utf-8 -*-
"""The_future_is_promising 的配置读写：接口（config/ai_agent.json）与运行时参数（config/agent.json）。

字段与 `hope/config.py` **完全一致**，两个配置文件也还是那两个，所以前端「AI 智能体
设置」面板、已保存的用户配置都无需任何改动 —— 换后端只是换实现，不是换契约。

与 hope（dsh，Node/TypeScript）的区别只有一处：The_future_is_promising 是纯 Python 智能体，不需要
node_modules、不需要构建产物、不需要 tools/node，因此没有 `ensure_layout()` 里那套
依赖树自检（这里永远 ok）。

运行环境（都在 IDE 根目录下，与本文件的上级目录同级）：
  tools/python/bin/python3.14.exe   IDE 自带解释器（The_future_is_promising 就跑在它上面）
"""
from __future__ import annotations
import json
import os
import sys
import threading

CONFIG_DIR_NAME = "config"
CFG_FILE_NAME = "ai_agent.json"
RT_FILE_NAME = "agent.json"

LOCK = threading.RLock()


def ide_root() -> str:
    """IDE 根目录（config / lib / docs / 工作区 / tools 所在处）。

    打包成 exe（PyInstaller）后资源都在 exe 旁边，取 exe 目录 —— 与 server/server.py
    一致。源码运行则**从本包所在目录向上找**：第一个「含 config\\ 或 server\\」的
    祖先目录就是根。这样本包放在 IDE 根下（The_future_is_promising\\）还是放在 server\\ 下
    （server\\The_future_is_promising\\）都能正确定位，以后再挪位置也不用改代码。
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    here = os.path.dirname(os.path.abspath(__file__))
    for _ in range(5):
        parent = os.path.dirname(here)
        if parent == here:
            break
        if os.path.isdir(os.path.join(parent, CONFIG_DIR_NAME)) \
                or os.path.isdir(os.path.join(parent, "server")):
            return parent
        here = parent
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


ROOT = ide_root()
CONFIG_DIR = os.path.join(ROOT, CONFIG_DIR_NAME)
CFG_FILE = os.path.join(CONFIG_DIR, CFG_FILE_NAME)
RT_FILE = os.path.join(CONFIG_DIR, RT_FILE_NAME)


def package_dir() -> str:
    """本包所在目录（server\\The_future_is_promising\\）。"""
    return os.path.dirname(os.path.abspath(__file__))


def temp_name() -> str:
    """运行期数据目录名（.temp 下的子目录）。"""
    return os.path.basename(package_dir())


def ensure_layout() -> dict:
    """运行环境自检：The_future_is_promising 只需要标准库，永远可用。

    保留这个函数是因为 server/server.py 启动时会调它做一次可见性自检；这里顺带
    回报后端形态，让「现在跑的是 Python 智能体」在启动日志里看得见。
    """
    return {"ok": True, "action": "none",
            "note": "The_future_is_promising 纯 Python 智能体（无需 Node / node_modules / 构建产物）"}


AI_MODES = ("default", "custom1", "custom2", "custom3")
AI_MODE_LABEL = {
    "default": "默认接口",
    "custom1": "自定义接口 1",
    "custom2": "自定义接口 2",
    "custom3": "自定义接口 3",
}

# 内置默认接口：本地大模型服务（OpenAI 兼容）。
# 只作为「文件缺失 / 字段缺失」时的兜底；设置面板回显只认磁盘上真正保存的值。
DEFAULT_CFG = {
    "mode": "default",
    "default": {
        "url": "https://ai.24992499.xyz/v1",
        "model": "Qwen3.8-27B-CRACK-Q4_K_M",
        "key": "free",
        "alias": "Qwen3.8-27B-CRACK",
    },
    "custom1": {"url": "", "model": "", "key": "", "alias": ""},
    "custom2": {"url": "", "model": "", "key": "", "alias": ""},
    "custom3": {"url": "", "model": "", "key": "", "alias": ""},
}

# 运行时参数默认值（字段与前端 app.js 的 AI_RT_GROUPS 一一对应）。
DEFAULT_RUNTIME = {
    # 预算 / 停止条件
    "maxSteps": 999,
    "maxToolCalls": 999,
    "maxSeconds": 90000,
    "maxConsecutiveFailures": 3,
    "maxRetriesPerTool": 3,
    # 上下文 · 输入 / 输出
    "ctxTokens": 0,
    "historyKeep": 5,
    "ctxChars": 20000,
    "toolResultChars": 20000,
    "toolResultKeepChars": 2000,
    "maxOutputTokens": 0,
    # PTC 程序化工具调用 —— toolsMode 就是「对话模式」
    #   native = 逐个原生工具调用；ptc = 只给 run_code；both = 两者都给
    #   The_future_is_promising 的 run_code 执行 **Python**（dsh 那边执行的是 TypeScript）。
    "toolsMode": "ptc",
    "ptcTimeoutMs": 0,
    "ptcSandboxMode": "workspace-write",
    "maxParallelSubCalls": 10,
    # 记忆（The_future_is_promising 无对应能力；仅保留字段以免面板丢项）
    "memoryEnabled": True,
    "semanticTopK": 5,
    "episodicTopK": 5,
    # 安全
    "sandboxEnabled": True,
    "approveDestructive": True,
    "approveNetwork": True,
    "allowNetwork": True,
    "allowExecute": True,
    "writeInsideProjectOnly": True,
    # 全部放行（免确认）
    "allowAll": False,
    # 思考强度
    "thinkIntensity": "off",
    # 可观测性
    "traceEnabled": True,
    "logLevel": "info",
    # Multi-Agent
    "multiAgentEnabled": True,
    "maxSubAgents": 3,
    # 运维
    "attachmentsMaxImageMB": 100,
    "attachmentsMaxFileMB": 100,
    "aiTimeout": 300,
    # 模型没有上报上下文窗口时使用的兜底值
    "ctxTokensFallback": 65536,
    # 上下文压缩
    "ctxCompaction": True,
    "ctxCompactThreshold": 80,
    "ctxCompactRetain": 0,
}


def _read_json(path: str) -> dict:
    try:
        with open(path, "rb") as f:
            raw = f.read()
        for enc in ("utf-8-sig", "utf-8", "gbk"):
            try:
                obj = json.loads(raw.decode(enc))
                return obj if isinstance(obj, dict) else {}
            except (UnicodeDecodeError, ValueError):
                continue
    except OSError:
        pass
    return {}


def _write_json(path: str, obj: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def _norm_api(part) -> dict:
    part = part if isinstance(part, dict) else {}
    return {
        "url": str(part.get("url") or "").strip(),
        "model": str(part.get("model") or "").strip(),
        "alias": str(part.get("alias") or "").strip(),
        "key": str(part.get("key") or ""),
    }


# ---------------- 接口配置 ----------------

def stored_cfg() -> dict:
    """磁盘上**真正保存**的接口配置（没配置过的方案就是空字段）。"""
    disk = _read_json(CFG_FILE)
    out = {"mode": str(disk.get("mode") or "default")}
    if out["mode"] not in AI_MODES:
        out["mode"] = "default"
    for m in AI_MODES:
        out[m] = _norm_api(disk.get(m))
    return out


def load_cfg() -> dict:
    """实际生效用的接口配置：磁盘值优先，缺项用内置默认值兜底。"""
    disk = stored_cfg()
    out = {"mode": disk["mode"]}
    for m in AI_MODES:
        d = dict(DEFAULT_CFG[m])
        for k, v in disk[m].items():
            if v:
                d[k] = v
        out[m] = d
    return out


def save_cfg(body: dict) -> dict:
    """保存接口配置。body 形如 {mode, <mode>:{url,model,alias,key}}。"""
    with LOCK:
        cur = stored_cfg()
        mode = str((body or {}).get("mode") or "").strip()
        if mode in AI_MODES:
            cur["mode"] = mode
            part = _norm_api((body or {}).get(mode))
            if any(part.values()) or mode != "default":
                cur[mode] = part
        elif "default" in (body or {}):
            cur["default"] = _norm_api(body["default"])
        _write_json(CFG_FILE, cur)
        return load_cfg()


def active_api(cfg: dict | None = None) -> dict:
    """当前生效的接口（含 mode / url / model / alias / key）。"""
    cfg = cfg or load_cfg()
    mode = cfg.get("mode") if cfg.get("mode") in AI_MODES else "default"
    api = dict(cfg.get(mode) or {})
    api["mode"] = mode
    if not api.get("url"):
        api = dict(DEFAULT_CFG["default"])
        api["mode"] = "default"
        api["fallback"] = True
    return api


# ---------------- 运行时参数 ----------------

def load_runtime() -> dict:
    disk = _read_json(RT_FILE)
    out = dict(DEFAULT_RUNTIME)
    for k, v in disk.items():
        if v is None:
            continue
        if k in out and isinstance(out[k], bool) and not isinstance(v, bool):
            continue
        if k in out and isinstance(out[k], int) and not isinstance(out[k], bool) \
                and not isinstance(v, (int, float)):
            continue
        out[k] = v
    return out


def save_runtime(body: dict) -> dict:
    """保存运行时参数：只接受已知键，并按默认值声明做类型校验。"""
    with LOCK:
        cur = load_runtime()
        body = body if isinstance(body, dict) else {}
        for k, v in body.items():
            if k not in DEFAULT_RUNTIME:
                continue
            ref = DEFAULT_RUNTIME[k]
            if isinstance(ref, bool):
                if isinstance(v, bool):
                    cur[k] = v
            elif isinstance(ref, int) and not isinstance(ref, bool):
                if isinstance(v, bool):
                    continue
                if isinstance(v, (int, float)):
                    cur[k] = int(v)
                elif isinstance(v, str) and v.strip().lstrip("-").isdigit():
                    cur[k] = int(v.strip())
            else:
                cur[k] = v
        disk = {k: cur[k] for k in DEFAULT_RUNTIME}
        _write_json(RT_FILE, disk)
        return load_runtime()


# ---------------- 路径 ----------------

def workspace_dir() -> str:
    """工程目录（工作区）：设置里显式指定优先，否则取「当前目录下的 工作区」。"""
    try:
        from yunyi import toolchain as T
        ws = T.get_settings().get("workspace") or os.path.join(os.getcwd(), "工作区")
    except Exception:
        ws = os.path.join(os.getcwd(), "工作区")
    ws = os.path.abspath(ws)
    os.makedirs(ws, exist_ok=True)
    return ws


def temp_dir() -> str:
    """运行期数据目录（会话持久化 / 转录 / 日志）：.temp\\<包名>\\。

    目录名跟着包名走（现在是 .temp\\The_future_is_promising），挪位置/改名后自动
    跟着变，不会跟别的后端撞目录。
    """
    d = os.path.join(ROOT, ".temp", temp_name())
    os.makedirs(d, exist_ok=True)
    return d


def context_window(runtime: dict, model: str = "") -> int:
    """进度圈满格线（模型上下文窗口 tok）：显式配置 > 兜底值。"""
    try:
        n = int(runtime.get("ctxTokens") or 0)
    except (TypeError, ValueError):
        n = 0
    if n > 0:
        return n
    try:
        return int(runtime.get("ctxTokensFallback") or 0) or 65536
    except (TypeError, ValueError):
        return 65536
