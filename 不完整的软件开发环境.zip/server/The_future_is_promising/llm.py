# -*- coding: utf-8 -*-
"""OpenAI 兼容接口的流式客户端（纯标准库）。

为什么自己写而不用 requests/openai SDK：The_future_is_promising 跑在 IDE **自带的** Python 里，
那个解释器只有标准库（见 hope/rpc.py 的同一条约束）。所以这里用 http.client
直接读 SSE 流。

支持：
  · 流式（stream=true）与非流式（服务端忽略 stream 时自动退回）
  · 文本 / 推理（reasoning_content、reasoning）/ 工具调用增量
  · 用量（prompt/completion/total + 各家缓存命中字段）+ 首 token 用时与解码用时
  · 图片内容块（data:image/...;base64）
  · 空闲超时（模型半天不吐一个 token 就算超时）与整体超时
  · 取消（threading.Event）：流还在跑也能立刻中断
"""
from __future__ import annotations
import http.client
import json
import socket
import ssl
import threading
import time
import urllib.parse

UA = "YunYiIDE-agent/2.0 (The_future_is_promising)"


class LLMError(RuntimeError):
    """模型服务不可用 / 返回异常。"""


def _split_url(base: str, tail: str) -> tuple:
    """把 OpenAI 兼容地址拆成 (https, host, port, path)。"""
    base = (base or "").strip().rstrip("/")
    if not base:
        raise LLMError("接口地址为空")
    u = urllib.parse.urlsplit(base if "://" in base else "http://" + base)
    scheme = (u.scheme or "http").lower()
    https = scheme == "https"
    port = u.port or (443 if https else 80)
    path = (u.path or "").rstrip("/") + tail
    return https, (u.hostname or "127.0.0.1"), port, path


def _connect(https: bool, host: str, port: int, timeout: float, insecure: bool = False):
    ctx = None
    if https:
        ctx = ssl.create_default_context()
        if insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
    if https:
        return http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
    return http.client.HTTPConnection(host, port, timeout=timeout)


def http_json(method: str, url: str, api_key: str = "", body=None,
              timeout: float = 15.0, insecure: bool = False):
    """一次普通的 JSON 请求（/models、/props 这类）。"""
    https, host, port, path = _split_url(url, "")
    u = urllib.parse.urlsplit(url if "://" in url else "http://" + url)
    path = (u.path or "").rstrip("/") or "/"
    conn = _connect(https, host, port, timeout, insecure)
    try:
        headers = {"Authorization": "Bearer " + (api_key or ""),
                   "Content-Type": "application/json",
                   "Accept": "application/json",
                   "User-Agent": UA}
        payload = None
        if body is not None:
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        conn.request(method, path, body=payload, headers=headers)
        resp = conn.getresponse()
        raw = resp.read()
        if resp.status >= 400:
            raise LLMError("HTTP %s %s" % (resp.status, (raw[:200].decode("utf-8", "replace"))))
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8", "replace"))
    except (http.client.HTTPException, socket.error, OSError) as e:
        raise LLMError("%s" % e) from None
    except ValueError as e:
        raise LLMError("响应不是 JSON：%s" % e) from None
    finally:
        try:
            conn.close()
        except Exception:
            pass


class AssistantMessage:
    """一次模型回复的汇总。"""

    def __init__(self):
        self.text = ""
        self.reasoning = ""
        self.tool_calls = []          # [{id, name, arguments(str)}]
        self.finish_reason = ""
        self.usage = {}               # {input, output, cache_read, total}
        self.ttft_ms = 0              # 首 token 用时
        self.decode_ms = 0            # 解码用时（首 token → 收尾）

    @property
    def has_calls(self) -> bool:
        return bool(self.tool_calls)


class LLM:
    """一个 OpenAI 兼容路由的对话客户端。"""

    def __init__(self, url: str, model: str, api_key: str = "",
                 timeout: float = 300.0, idle_timeout: float = 0.0,
                 max_output_tokens: int = 0, reasoning_effort: str = "",
                 insecure: bool = False):
        self.url = (url or "").strip().rstrip("/")
        self.model = model or ""
        self.api_key = api_key or ""
        self.timeout = float(timeout or 300.0)
        self.idle_timeout = float(idle_timeout or 0.0) or float(timeout or 300.0)
        self.max_output_tokens = int(max_output_tokens or 0)
        self.reasoning_effort = (reasoning_effort or "").strip()
        self.insecure = bool(insecure)
        self.https, self.host, self.port, self.path = _split_url(self.url, "/chat/completions")

    # ---------- 主入口 ----------

    def chat(self, messages, tools=None, cancel: threading.Event | None = None,
             on_text=None, on_reason=None) -> AssistantMessage:
        """发一轮对话；on_text/on_reason 收到增量文本（可为空）。"""
        body = {
            "model": self.model,
            "messages": list(messages),
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if self.max_output_tokens > 0:
            body["max_tokens"] = self.max_output_tokens
        if self.reasoning_effort and self.reasoning_effort != "off":
            body["reasoning_effort"] = self.reasoning_effort
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"

        out = AssistantMessage()
        started = time.time()
        deadline = started + self.timeout
        hdr_at = 0.0            # 收到响应头的时刻（0 = 还没收到，处于 30s 预处理窗口）
        conn = _connect(self.https, self.host, self.port, min(self.timeout, 30.0), self.insecure)
        try:
            headers = {"Authorization": "Bearer " + self.api_key,
                       "Content-Type": "application/json",
                       "Accept": "text/event-stream",
                       "User-Agent": UA}
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
            try:
                conn.request("POST", self.path, body=payload, headers=headers)
            except (http.client.HTTPException, socket.error, OSError) as e:
                raise LLMError("无法连接模型服务 %s：%s" % (self.url, e)) from None
            resp = conn.getresponse()
            if resp.status >= 400:
                detail = resp.read()[:400].decode("utf-8", "replace")
                raise LLMError("模型服务返回 HTTP %s：%s" % (resp.status, detail))
            hdr_at = time.time()
            ctype = (resp.getheader("Content-Type") or "").lower()
            if "event-stream" in ctype:
                self._read_stream(resp, out, cancel, on_text, on_reason, deadline, started)
            else:
                self._read_json(resp, out, on_text, on_reason)
        except (socket.timeout, TimeoutError):
            if hdr_at:
                # 流已建立后 idle 超时：报真实无数据的秒数（不应恒等于 idle_timeout）
                raise LLMError("模型响应超时（%.0fs 无数据）" % (time.time() - hdr_at)) from None
            # 连响应头都没等到：请求已被接受但服务端预处理（长提示词 prefill /
            # 排队等前一个请求）超过 min(timeout, 30s) 的响应头窗口
            raise LLMError("模型服务 %.0fs 内未返回响应头"
                           "（提示词过长或服务端排队时会出现；可调大 aiTimeout）"
                           % min(self.timeout, 30.0)) from None
        except (http.client.HTTPException, socket.error, OSError) as e:
            raise LLMError("模型连接中断：%s" % e) from None
        finally:
            try:
                conn.close()
            except Exception:
                pass
        if out.decode_ms <= 0:
            out.decode_ms = int(max(0.0, time.time() - started) * 1000)
        return out

    # ---------- 流读取 ----------

    def _idle(self, resp, seconds: float) -> None:
        """给底层 socket 设空闲超时（流已经拿到响应头之后才安全）。"""
        sock = getattr(resp, "fp", None)
        sock = getattr(sock, "raw", sock)
        sock = getattr(sock, "_sock", sock)
        try:
            sock.settimeout(seconds)
        except Exception:
            pass

    def _read_stream(self, resp, out: AssistantMessage, cancel, on_text, on_reason,
                     deadline: float, started: float) -> None:
        self._idle(resp, self.idle_timeout)
        calls: dict = {}
        buf: list = []
        first_at = 0.0
        while True:
            if cancel is not None and cancel.is_set():
                out.finish_reason = out.finish_reason or "cancelled"
                return
            if time.time() > deadline:
                raise LLMError("模型响应超过整体时限（%ss）" % self.timeout)
            line = resp.readline()
            if not line:
                break
            if isinstance(line, bytes):
                line = line.decode("utf-8", "replace")
            line = line.rstrip("\r\n")
            if not line:
                if buf:
                    self._consume(buf, out, calls, on_text, on_reason)
                    buf = []
                # 首 token 计时：这一批里出现了任何实质输出，就算到了首个 token
                if not first_at and (out.text or out.reasoning or out.tool_calls):
                    first_at = time.time()
                    out.ttft_ms = int(max(0.0, first_at - started) * 1000)
                continue
            if line.startswith(":"):            # SSE 注释（心跳）
                continue
            if line.startswith("data:"):
                buf.append(line[5:].strip())
                continue
            # 其它字段（event: / id: / retry:）忽略
        if first_at:
            out.decode_ms = int(max(0.0, time.time() - first_at) * 1000)

    def _consume(self, datas, out: AssistantMessage, calls: dict,
                 on_text, on_reason) -> None:
        for data in datas:
            if data == "[DONE]":
                return
            try:
                chunk = json.loads(data)
            except ValueError:
                continue
            if not isinstance(chunk, dict):
                continue
            if chunk.get("usage"):
                out.usage = _usage(chunk["usage"])
            choices = chunk.get("choices")
            if not choices:
                continue
            choice = choices[0] if isinstance(choices[0], dict) else {}
            delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
            _absorb_delta(delta, out, calls, on_text, on_reason)
            if choice.get("finish_reason"):
                out.finish_reason = str(choice["finish_reason"])
            msg = choice.get("message")           # 非流式的兜底
            if isinstance(msg, dict) and msg:
                _absorb_delta(msg, out, calls, on_text, on_reason)

    def _read_json(self, resp, out: AssistantMessage, on_text, on_reason) -> None:
        raw = resp.read()
        try:
            payload = json.loads(raw.decode("utf-8", "replace"))
        except ValueError as e:
            raise LLMError("模型响应不是 JSON：%s" % e) from None
        if not isinstance(payload, dict):
            return
        out.usage = _usage(payload.get("usage"))
        choices = payload.get("choices")
        if not isinstance(choices, list) or not choices:
            return
        choice = choices[0] if isinstance(choices[0], dict) else {}
        out.finish_reason = str(choice.get("finish_reason") or "")
        calls: dict = {}
        _absorb_delta(choice.get("message") or {}, out, calls, on_text, on_reason)


def _absorb_delta(delta: dict, out: AssistantMessage, calls: dict,
                  on_text, on_reason) -> None:
    """把一个 delta / message 并进汇总结果。"""
    text = delta.get("content")
    if isinstance(text, str) and text:
        out.text += text
        if on_text is not None:
            on_text(text)
    elif isinstance(text, list):                 # 少数服务把 content 给成块数组
        for part in text:
            if isinstance(part, dict) and part.get("type") == "text":
                piece = str(part.get("text") or "")
                if piece:
                    out.text += piece
                    if on_text is not None:
                        on_text(piece)
    for key in ("reasoning_content", "reasoning", "thinking"):
        think = delta.get(key)
        if isinstance(think, str) and think:
            out.reasoning += think
            if on_reason is not None:
                on_reason(think)
            break
    raw_calls = delta.get("tool_calls")
    if isinstance(raw_calls, list):
        for item in raw_calls:
            if not isinstance(item, dict):
                continue
            index = item.get("index")
            index = index if isinstance(index, int) else len(calls)
            slot = calls.get(index)
            if slot is None:
                slot = calls[index] = {"id": "", "name": "", "arguments": ""}
                out.tool_calls.append(slot)
            if item.get("id"):
                slot["id"] = str(item["id"])
            fn = item.get("function") if isinstance(item.get("function"), dict) else {}
            if fn.get("name"):
                slot["name"] = str(fn["name"])
                if not slot["id"]:
                    slot["id"] = "call_%d" % index
            if isinstance(fn.get("arguments"), str):
                slot["arguments"] += fn["arguments"]


def _usage(raw) -> dict:
    """各家用量字段归一到 {input, output, cache_read, total}。"""
    if not isinstance(raw, dict):
        return {}
    first = _int(raw, "prompt_tokens", "input_tokens", "promptTokens")
    out = _int(raw, "completion_tokens", "output_tokens", "outputTokens", "completionTokens")
    total = _int(raw, "total_tokens", "totalTokens")
    cache = 0
    details = raw.get("prompt_tokens_details")
    if isinstance(details, dict):
        cache = _int(details, "cached_tokens", "cachedTokens")
    if not cache:
        # DeepSeek：prompt_cache_hit_tokens；部分自建服务：cache_read_tokens
        cache = _int(raw, "prompt_cache_hit_tokens", "cache_read_tokens",
                     "cacheReadTokens", "cached_tokens")
    if not total:
        total = first + out
    return {"input": first, "output": out, "cache_read": cache, "total": total}


def _int(source: dict, *keys) -> int:
    for key in keys:
        value = source.get(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)) and value >= 0:
            return int(value)
    return 0


def image_part(mime: str, b64: str) -> dict:
    """一个图片内容块（data URL 形式，OpenAI 兼容服务都认）。"""
    return {"type": "image_url",
            "image_url": {"url": "data:%s;base64,%s" % (mime, b64)}}
