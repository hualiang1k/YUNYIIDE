# -*- coding: utf-8 -*-
"""The_future_is_promising 的智能体本体：系统提示 + 回合主循环 + 工具执行 + 上下文压缩。

产出的事件就是 dsh ACP 桥那一套 session/update（见 packages/acp/acp/src/updates.ts），
所以 IDE 侧的翻译层（runtime.py）与前端渲染全部不用改：

    agent_thought_chunk / agent_message_chunk / tool_call / tool_call_update /
    usage_update / compaction_update

stopReason 也沿用 ACP 的词表：end_turn / cancelled / max_tokens /
max_turn_requests / refusal。
"""
from __future__ import annotations
import json
import os
import threading
import time
import uuid

from . import config as CFG
from . import llm as LLM
from . import sandbox as SB
from . import tools as TOOLS
from .session import Session

# 云易IDE 的 persona：与 hope/patch.py 里下发给 dsh 的完全一致（切换后端后
# 模型看到的系统提示不变，行为才不会漂移）。
PERSONA_PREFIX = (
    "You are 云易IDE's built-in coding agent, powered by the {{model}} model.\n"
    "云易IDE is an integrated development environment for 云易 (YunYi), a Chinese"
    " programming language whose `.yy` sources the IDE translates to C++ and compiles"
    " with its bundled MinGW toolchain.\n"
    "Reply in the user's language (Chinese by default)."
)

PERSONA_SUFFIX = (
    "Your working directory is {{cwd}} — it is the IDE workspace, and every 云易 project"
    " lives in its own subdirectory there. Work inside the workspace unless the user asks"
    " otherwise. Always use RELATIVE paths (relative to the working directory); never"
    " invent absolute paths.\n"
    "Build/run/test a 云易 project through the IDE's compile skills FIRST: before the"
    " first build/run/test of a project, invoke the `use_skill` tool with name `compile-x64`"
    " (64 位，默认) or `compile-x86` (32 位，用户提到 x86/32位 时) and follow the loaded"
    " skill instructions. Only if the skill tool or that skill is unavailable, or invoking"
    " it fails, fall back to running the IDE's own CLI directly (the IDE root is the"
    " parent of the workspace, so the CLI is one level up) — do not stop to ask, just"
    " proceed with the fallback. ALWAYS invoke it with the IDE's BUNDLED"
    " Python below — never a bare `python`, which may resolve to some other installation"
    " on PATH and then fail to start (`0xc0000142`) inside your sandbox:\n"
    "  ../tools/python/bin/python3.14.exe ../server/yunyi_cli.py build \"<project>\" --json\n"
    "  ../tools/python/bin/python3.14.exe ../server/yunyi_cli.py run \"<project>\" --json    # 编译并运行\n"
    "  ../tools/python/bin/python3.14.exe ../server/yunyi_cli.py test \"<project>\" --json   # 编译并跑测试函数\n"
    "  ../tools/python/bin/python3.14.exe ../server/yunyi_cli.py env  --json                # 查看工具链（g++ / make）\n"
    "Every command accepts --json for a machine-readable result; read `messages` for"
    " compiler errors and `ok` for the outcome. Prefer that CLI over calling g++ directly."
)

THINK_DIRECTIVES = {
    "off": "",
    "low": "\n\n思考强度：低。优先采用最直接可行的方案，尽量缩短推理与验证步骤。",
    "medium": "\n\n思考强度：中。先理解任务、权衡主要可选方案，再动手；遇到明显歧义时简短确认。",
    "high": "\n\n思考强度：高。逐步推理、列出并比较多种方案，动手前先验证思路，完成后再自检一遍。",
}

GUARDRAILS = (
    "\n\n【工作方式】\n"
    "1. 先看清现状再动手：不确定就先 list_dir / search_content / read_file，别猜。\n"
    "2. 改动前先读文件；edit_file 的 old 必须唯一，写不出唯一片段就先 read_file 确认。\n"
    "3. 命令用完就看退出码与输出，失败要给出原因，不要假装成功。\n"
    "4. 一次只推进一件事，做不完就说清楚做到哪一步、下一步是什么。\n"
    "5. 回答用中文；除非用户明确要求，不要输出大段代码以外的无关解释。"
)


def _think_directive(runtime: dict) -> str:
    level = str((runtime or {}).get("thinkIntensity") or "off").strip().lower()
    return THINK_DIRECTIVES.get(level, "")


class Agent:
    """一个会话的智能体（IDE 同时只有一个）。"""

    def __init__(self, cfg: dict, runtime: dict, workspace: str,
                 emit=None, confirm=None, cancel: threading.Event | None = None,
                 skill_dirs=None, session: Session | None = None):
        self.cfg = cfg or CFG.load_cfg()
        self.runtime = runtime or {}
        self.workspace = os.path.abspath(workspace or CFG.workspace_dir())
        self.emit = emit or (lambda update: None)
        self.confirm = confirm
        self.cancel = cancel or threading.Event()
        self.skill_dirs = list(skill_dirs or [])
        self.session = session or Session(cwd=self.workspace)
        self.sandbox = SB.Sandbox(self.runtime, self.workspace)
        self.last_used = 0
        self.ctx_window = 0
        self.turn = 0
        self.step = 0
        self.metrics = {"ttft_ms": 0, "decode_ms": 0, "out_tokens": 0,
                        "in_tokens": 0, "cache_read": 0, "steps": 0}
        self.error = ""
        # IDE 当前打开的工程（前端才知道）：用于把改动的文件换算成工程内相对路径，
        # 也让「新建工程自动切过去」有参照基线。由 runtime 每次回合前灌进来。
        self.project = ""
        self._known_projects: set | None = None

    # ---------- 模型 ----------

    def llm(self) -> LLM.LLM:
        api = CFG.active_api(self.cfg)
        try:
            idle = int(self.runtime.get("aiTimeout") or 0) or 300
        except (TypeError, ValueError):
            idle = 300
        try:
            max_out = int(self.runtime.get("maxOutputTokens") or 0)
        except (TypeError, ValueError):
            max_out = 0
        return LLM.LLM(api.get("url") or "", api.get("model") or "", api.get("key") or "",
                       timeout=float(max(30, idle)), idle_timeout=float(max(10, idle)),
                       max_output_tokens=max_out,
                       reasoning_effort=str(self.runtime.get("thinkIntensity") or "off"))

    def model_label(self) -> str:
        api = CFG.active_api(self.cfg)
        return "%s / %s" % (api.get("alias") or api.get("mode") or "", api.get("model") or "")

    # ---------- 系统提示 ----------

    def system_prompt(self) -> str:
        model = CFG.active_api(self.cfg).get("model") or ""
        prefix = PERSONA_PREFIX.replace("{{model}}", model)
        suffix = (PERSONA_SUFFIX.replace("{{cwd}}", self.workspace)
                  + _think_directive(self.runtime)
                  + GUARDRAILS)
        return prefix + "\n" + suffix

    def _messages(self) -> list:
        out = [{"role": "system", "content": self.system_prompt()}]
        out.extend(self.session.messages)
        return out

    # ---------- 上下文窗口 ----------

    def resolve_ctx_window(self) -> int:
        try:
            n = int(self.runtime.get("ctxTokens") or 0)
        except (TypeError, ValueError):
            n = 0
        if n <= 0:
            api = CFG.active_api(self.cfg)
            n = probe_context_window(str(api.get("url") or ""), str(api.get("key") or ""))
        if n <= 0:
            n = CFG.context_window(self.runtime)
        self.ctx_window = n
        return n

    # ---------- 事件 ----------

    def _update(self, update_kind: str, **fields) -> None:
        """把一条 session/update 交给上层（字段名里也有个 kind，别跟它撞）。"""
        payload = {"sessionUpdate": update_kind}
        payload.update(fields)
        self.emit(payload)

    def _emit_usage(self) -> None:
        used = self.last_used or self.session.estimate()
        self._update("usage_update", used=used, size=self.ctx_window)

    # ---------- 一个回合 ----------

    def prompt(self, content) -> str:
        """跑一个用户回合；返回 ACP 的 stopReason。"""
        ctx_window = self.resolve_ctx_window()
        self.turn += 1
        self.step = 0
        self.metrics = {"ttft_ms": 0, "decode_ms": 0, "out_tokens": 0,
                        "in_tokens": 0, "cache_read": 0, "steps": 0}
        self.session.turn = self.turn
        self.session.add_user(content)
        # 回合开始先记下「已有哪些工程」：之后新出现的才算新建（否则第一次调用会把
        # 刚建好的工程当成基线，反而报不出来）。
        self._known_projects = self._list_projects()

        tool_names = TOOLS.visible_names(str(self.runtime.get("toolsMode") or "ptc"),
                                         self.runtime)
        schemas = TOOLS.schemas(tool_names)
        max_steps = _int(self.runtime.get("maxSteps"), 999, 1, 999)
        max_calls = _int(self.runtime.get("maxToolCalls"), 999, 1, 9999)
        deadline = time.time() + _int(self.runtime.get("maxSeconds"), 90000, 1, 86400)
        parallel = _int(self.runtime.get("maxParallelSubCalls"), 1, 1, 16)
        calls_used = 0

        while True:
            if self.cancel.is_set():
                return "cancelled"
            if self.step >= max_steps:
                return "max_turn_requests"
            if time.time() > deadline:
                return "max_turn_requests"
            self.step += 1
            self.metrics["steps"] = self.step

            model = self.llm()
            try:
                reply = model.chat(self._messages(), schemas, cancel=self.cancel,
                                   on_text=lambda t: self._update(
                                       "agent_message_chunk",
                                       content={"type": "text", "text": t}),
                                   on_reason=lambda t: self._update(
                                       "agent_thought_chunk",
                                       content={"type": "text", "text": t}))
            except LLM.LLMError as e:
                self.error = str(e)
                raise

            if self.metrics["ttft_ms"] == 0 and reply.ttft_ms:
                self.metrics["ttft_ms"] = reply.ttft_ms
            self.metrics["decode_ms"] += reply.decode_ms
            self.metrics["out_tokens"] += reply.usage.get("output", 0)
            self.metrics["in_tokens"] += reply.usage.get("input", 0)
            self.metrics["cache_read"] += reply.usage.get("cache_read", 0)
            if reply.usage.get("input"):
                self.last_used = reply.usage["input"]
            self._emit_usage()

            if self.cancel.is_set():
                self.session.add_assistant(reply.text, None)
                return "cancelled"

            calls = _normalize_calls(reply.tool_calls)
            if not calls:
                self.session.add_assistant(reply.text, None)
                if reply.finish_reason == "length":
                    return "max_tokens"
                return "end_turn"

            self.session.add_assistant(reply.text, calls)
            for call in calls:
                self._update("tool_call", toolCallId=call["id"], title=call["name"],
                             kind="other", status="in_progress",
                             rawInput=_safe_args(call["arguments"]))

            calls_used += len(calls)
            if calls_used > max_calls:
                return "max_turn_requests"

            results = self._execute(calls, parallel)
            for call, (text, failed, meta) in zip(calls, results):
                self._update("tool_call_update", toolCallId=call["id"],
                             status="failed" if failed else "completed",
                             content=[{"type": "content",
                                       "content": {"type": "text", "text": text}}],
                             **({"meta": meta} if meta else {}))
                self.session.add_tool_result(call["id"], call["name"], text, not failed)

            self._emit_usage()
            if self.runtime.get("ctxCompaction", True) and self.session.should_compact(
                    self.last_used, ctx_window, self.runtime):
                shadowed = self.session.compact(self.llm(), ctx_window, self.runtime,
                                                self.cancel)
                if shadowed:
                    self._update("compaction_update", phase="summary",
                                 shadowedTokenCount=self.session.estimate())
                    self.last_used = self.session.estimate()
                    self._emit_usage()

    # ---------- 工具执行 ----------

    def _tool_context(self) -> TOOLS.ToolContext:
        return TOOLS.ToolContext(
            workspace=self.workspace, runtime=self.runtime, sandbox=self.sandbox,
            confirm=self._confirm, cancel=self.cancel, note=self._note,
            skill_dirs=self.skill_dirs, llm_factory=self.llm,
            subagent_limit=_int(self.runtime.get("maxSubAgents"), 3, 0, 16))

    def _confirm(self, title: str, reason: str) -> bool:
        if self.confirm is None:
            return False
        return bool(self.confirm(title, reason))

    def _note(self, text: str) -> None:
        """工具想在聊天里说一句话（如「提交了一份交付物」）。"""
        self.emit({"sessionUpdate": "_notice", "text": str(text)})

    def _execute(self, calls: list, parallel: int) -> list:
        ctx = self._tool_context()
        if len(calls) == 1 or parallel <= 1:
            return [self._run_one(ctx, call) for call in calls]
        slots = [None] * len(calls)

        def work(index: int, call: dict):
            slots[index] = self._run_one(ctx, call)

        threads = [threading.Thread(target=work, args=(i, call), name="agent-tool",
                                    daemon=True)
                   for i, call in enumerate(calls)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        return [slot or ("（工具没有返回结果）", True, {}) for slot in slots]

    def _run_one(self, ctx: TOOLS.ToolContext, call: dict) -> tuple:
        """执行一个工具调用，返回 (结果文本, 是否出错, 给 IDE 的 meta)。"""
        name = call["name"]
        args = _safe_args(call["arguments"])
        if self.cancel.is_set():
            return "回合已被用户停止", True, {}
        # 审批与实际放行都收在 run_guarded 里（PTC 内部调用走同一道闸）
        text, failed = TOOLS.run_guarded(ctx, name, args, self.cancel)
        return text, failed, self._tool_meta(name, args)

    # ---------- 工具结果 → IDE 同步（meta） ----------
    # 前端 aiApplyMeta() 认三个字段：
    #   files      = 改过的文件（相对**当前工程**的路径）→ 刷文件树 + 重载已打开的标签
    #   newProject = 新建的工程名 → 刷新工程下拉并自动切过去
    #   problems   = 问题面板条目

    _MUTATING = ("write_file", "edit_file")

    def _list_projects(self) -> set:
        """工作区里现有的工程（含 <同名>.yyproj 的目录）。"""
        try:
            from yunyi import project as P
            items = P.list_projects(self.workspace)
            return {str(it.get("name") or "")
                    for it in items if isinstance(it, dict) and it.get("name")}
        except Exception:                                         # noqa: BLE001
            return set()

    def _new_projects(self) -> list:
        """自上次查看以来新出现的工程（首次调用只记基线）。"""
        now = self._list_projects()
        if self._known_projects is None:
            self._known_projects = now
            return []
        added = sorted(now - self._known_projects)
        if added:
            self._known_projects |= now
        return added

    def _rel_for_ide(self, abs_path: str) -> str:
        """把绝对路径换成前端认的路径：优先相对当前工程，其次相对工作区。"""
        for base in (os.path.join(self.workspace, self.project) if self.project else "",
                     self.workspace):
            if not base:
                continue
            try:
                rel = os.path.relpath(abs_path, base)
            except ValueError:
                continue
            if rel and not rel.startswith(".."):
                return rel.replace("\\", "/")
        return ""

    def _tool_meta(self, name: str, args: dict) -> dict:
        """算这一次工具调用要给 IDE 的同步信息。"""
        meta: dict = {}
        if name in self._MUTATING:
            try:
                path = self.sandbox.resolve(str(args.get("path") or ""), writing=True)
            except Exception:                                     # noqa: BLE001
                path = ""
            if path and os.path.isfile(path):
                rel = self._rel_for_ide(path)
                if rel:
                    meta["files"] = [rel]
        added = self._new_projects()          # shell / PTC 建的工程也要能发现
        if added:
            meta["newProject"] = added[0]
        return meta


class SubAgent:
    """子智能体：只读工具 + 有限步数，把结论作为字符串交回父智能体。"""

    MAX_STEPS = 12

    def __init__(self, ctx: TOOLS.ToolContext, prelude: str = ""):
        self.ctx = ctx
        self.prelude = prelude

    def run(self, task: str) -> str:
        if self.ctx.llm_factory is None:
            return "子智能体不可用：当前会话没有模型连接"
        model = self.ctx.llm_factory()
        messages = [{"role": "system", "content":
                     "你是一个只读调研子智能体。只能用搜索与读取类工具弄清事实，"
                     "不要修改任何文件。最后用中文给出结构化结论："
                     "发现了什么（带 路径:行号 证据）、结论、建议的下一步。"}]
        if self.prelude:
            messages.append({"role": "user", "content": "【已有上下文】\n" + self.prelude[:20000]})
        messages.append({"role": "user", "content": task})
        names = [n for n in TOOLS.visible_names("native", self.ctx.runtime)
                 if n not in ("subagent", "run_code", "write_file", "edit_file",
                              "run_command", "web_fetch", "web_search")]
        schemas = TOOLS.schemas(names)
        for _ in range(self.MAX_STEPS):
            if self.ctx.cancel is not None and self.ctx.cancel.is_set():
                return "（子任务被停止）"
            try:
                reply = model.chat(messages, schemas, cancel=self.ctx.cancel)
            except Exception as e:                                # noqa: BLE001
                return "子智能体调用模型失败：%s" % e
            calls = _normalize_calls(reply.tool_calls)
            if not calls:
                return (reply.text or "").strip() or "（子智能体没有给出结论）"
            messages.append({"role": "assistant", "content": reply.text or "",
                             "tool_calls": [{"id": c["id"], "type": "function",
                                             "function": {"name": c["name"],
                                                          "arguments": c["arguments"]}}
                                            for c in calls]})
            for call in calls:
                text, _failed = TOOLS.run(self.ctx, call["name"],
                                          _safe_args(call["arguments"]))
                messages.append({"role": "tool", "tool_call_id": call["id"],
                                 "name": call["name"], "content": text})
        return "（子智能体达到步数上限，结论可能不完整）"


# ---------------------------------------------------------------- 辅助

def _safe_args(raw) -> dict:
    """模型给的 arguments 是字符串；解析不出来就原样包起来（别丢调用）。"""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return {}
        try:
            obj = json.loads(text)
            return obj if isinstance(obj, dict) else {"value": obj}
        except ValueError:
            return {"value": text}
    return {}


def _normalize_calls(raw_calls) -> list:
    """规整模型的 tool_calls：补 id、丢弃没有名字的。"""
    out = []
    for i, item in enumerate(raw_calls or []):
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        out.append({"id": str(item.get("id") or "") or ("call_%d_%s" % (i, uuid.uuid4().hex[:8])),
                    "name": name,
                    "arguments": item.get("arguments") or ""})
    return out


def _int(value, default: int, low: int, high: int) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, n))


# ---------------------------------------------------------------- 接口探测

_CTX_CACHE: dict = {}


def probe_context_window(url: str, api_key: str) -> int:
    """问一次模型服务它的上下文窗口（llama.cpp 的 /props → n_ctx），探不到返回 0。"""
    url = (url or "").strip().rstrip("/")
    if not url:
        return 0
    if url in _CTX_CACHE:
        return _CTX_CACHE[url]
    roots = [url]
    if url.endswith("/v1"):
        roots.append(url[:-3])
    n = 0
    for root in roots:
        try:
            payload = LLM.http_json("GET", root + "/props", api_key, timeout=6)
        except Exception:                                         # noqa: BLE001
            continue
        if isinstance(payload, dict):
            settings = payload.get("default_generation_settings")
            if isinstance(settings, dict):
                try:
                    n = int(settings.get("n_ctx") or 0)
                except (TypeError, ValueError):
                    n = 0
            if not n:
                try:
                    n = int(payload.get("n_ctx") or 0)
                except (TypeError, ValueError):
                    n = 0
        if n >= 1024:
            break
    if n < 1024:
        n = 0
    _CTX_CACHE[url] = n
    return n
