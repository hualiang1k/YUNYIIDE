# -*- coding: utf-8 -*-
"""The_future_is_promising 的 IDE 侧桥接：会话管理 + 智能体事件 → 前端 SSE 事件。

对外接口与已弃用的 `hope/runtime.py`（dsh 版）**逐个同名同签名**，所以
server/server.py 的 `ai_backend()` 按名字取模块即可切换后端，前端零改动。

与 dsh 版的关键差别（都是变好的方向）：
  · 智能体跑在 **IDE 自己的 Python 进程里**，没有子进程、没有 stdio JSON-RPC、
    没有 Node —— 也就没有「dsh 起不来 / 端口被 taskkill 后变孤儿进程」这类问题；
  · 停止 = 置一个 threading.Event，立刻生效；
  · 指标（首 token / tok/s / 缓存命中）直接来自模型回报，不用再去解 zstd 会话日志；
  · 改接口 / 运行时参数立即生效，不需要按指纹重启子进程。
"""
from __future__ import annotations
import base64
import json
import os
import queue
import threading
import time

from . import config as CFG
from . import sandbox as SB
from . import agent as AGENT
from .session import Session

IMG_MIME = ("image/png", "image/jpeg", "image/webp", "image/gif")
MAX_TOOL_DETAIL = 6000
CONFIRM_TIMEOUT = 600.0

STATE = {
    "session_id": "",
    "transcript": [],
    "project": "",
    "busy": False,
    "agent": None,
    "usage": {},
    "compactions": 0,
    "ctx_window": 0,
    "allow_all": False,
    "stop_requested": False,
    "error": "",
    "confirm": None,
    "updates": queue.Queue(),
    "turn": None,          # 当前/最近一个回合（事件缓冲，供刷新后重连补看）
    "turn_cancel": None,   # 当前回合的取消事件
    "turn_seq": 0,
}
LOCK = threading.RLock()
CONFIRM_LOCK = threading.RLock()
SESSION_FILE = os.path.join(CFG.temp_dir(), "session.json")

try:
    STATE["allow_all"] = bool(CFG.load_runtime().get("allowAll"))
except Exception:
    pass


# ---------------- 转录（前端刷新后恢复聊天记录） ----------------

def _load_session() -> None:
    try:
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            STATE["session_id"] = str(data.get("sessionId") or "")
            STATE["project"] = str(data.get("project") or "")
            msgs = data.get("messages")
            STATE["transcript"] = msgs if isinstance(msgs, list) else []
            STATE["compactions"] = int(data.get("compactions") or 0)
    except (OSError, ValueError):
        pass


def _save_session() -> None:
    try:
        with open(SESSION_FILE, "w", encoding="utf-8", newline="\n") as f:
            json.dump({"sessionId": STATE["session_id"],
                       "project": STATE["project"],
                       "compactions": STATE.get("compactions") or 0,
                       "messages": STATE["transcript"][-400:]},
                      f, ensure_ascii=False, indent=2)
    except OSError:
        pass


_load_session()


# ---------------- 智能体实例 ----------------

def _skill_dirs() -> list:
    import sys
    out = []
    for base in (CFG.ROOT, getattr(sys, "_MEIPASS", "")):
        if not base:
            continue
        cand = os.path.join(base, "server", "skills")
        if os.path.isdir(cand):
            out.append(cand)
    return out


def _emit(update: dict) -> None:
    STATE["updates"].put({"method": "session/update", "params": {"update": update}})


def _ask_confirm(title: str, reason: str) -> bool:
    """工具想做一个超出沙箱自动许可的动作：弹确认卡，阻塞等用户表态。

    「全部放行」（allowAll）开启时不再弹卡，直接放行 —— 与前端确认卡上那个
    「全部放行」按钮和设置面板里的开关共用同一份持久化标记。

    没有正在流式输出的回合时（没人能点按钮）直接拒绝，绝不干等。
    """
    if STATE.get("allow_all"):
        return True
    if not STATE["busy"]:
        return False
    holder = {"event": threading.Event(), "answer": False}
    with CONFIRM_LOCK:
        previous = STATE.get("confirm")
        STATE["confirm"] = holder
    if previous is not None:
        previous["answer"] = False
        previous["event"].set()
    try:
        STATE["updates"].put({"method": "_confirm",
                              "params": {"type": "confirm", "tool": title,
                                         "reason": reason,
                                         "impact": "同意＝本次放行；取消＝这次调用失败，"
                                                   "模型会另想办法。"}})
        holder["event"].wait(CONFIRM_TIMEOUT)
        return bool(holder["answer"])
    finally:
        with CONFIRM_LOCK:
            if STATE.get("confirm") is holder:
                STATE["confirm"] = None


def ensure_agent(cfg: dict, runtime: dict, workspace: str) -> AGENT.Agent:
    """保证有一个挂在当前会话上的智能体（配置每次都重新灌进去，改完立即生效）。"""
    agent = STATE.get("agent")
    sid = STATE.get("session_id") or Session.latest()
    if agent is None:
        session = Session.load(sid, workspace) if sid else None
        if session is None:
            session = Session(cwd=workspace)
        agent = AGENT.Agent(cfg, runtime, workspace, emit=_emit, confirm=_ask_confirm,
                            skill_dirs=_skill_dirs(), session=session)
        STATE["agent"] = agent
        STATE["session_id"] = agent.session.id
        _save_session()
    agent.cfg = cfg
    agent.runtime = runtime
    agent.workspace = workspace
    agent.sandbox = SB.Sandbox(runtime, workspace)
    agent.skill_dirs = _skill_dirs()
    agent.session.cwd = workspace
    # 当前打开的工程：改过的文件要换算成工程内相对路径，前端才能重载对应的标签页；
    # 同时它是「新建工程自动切过去」的基线（工程变了才报 newProject）。
    agent.project = STATE.get("project") or ""
    return agent


# ---------------- 事件翻译（智能体 update → 前端 SSE） ----------------

def _short(text: str, limit: int = 160) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[:limit] + "…"


def _chunk_text(content) -> str:
    if isinstance(content, dict) and content.get("type") == "text":
        return str(content.get("text") or "")
    return ""


def _update_text(content) -> str:
    if not isinstance(content, list):
        return ""
    return "".join(_chunk_text(item.get("content"))
                   for item in content if isinstance(item, dict) and item.get("type") == "content")


class TurnState:
    """一个回合内的累积状态（转录 / 用量 / 指标）。"""

    def __init__(self, ctx_total: int):
        self.t0 = time.time()
        self.ctx_total = ctx_total
        self.steps = 0
        self.max_prompt = 0
        self.calls = {}
        self.step_text = ""
        self.step_calls = []
        self.flushed_calls = set()
        self.answer = ""

    def stats(self, finished: bool = False) -> dict:
        agent = STATE.get("agent")
        m = agent.metrics if agent is not None else {}
        elapsed = max(0.0, time.time() - self.t0)
        decode = m.get("decode_ms") or 0
        out_tokens = m.get("out_tokens") or 0
        tps = round(out_tokens / (decode / 1000.0), 1) if decode > 0 else 0.0
        cache = m.get("cache_read") or 0
        prompt = m.get("in_tokens") or self.max_prompt
        return {"inTokens": m.get("in_tokens") or self.max_prompt,
                "ctxUsed": self.max_prompt,
                "outTokens": out_tokens,
                "elapsed": round(elapsed, 1),
                "steps": m.get("steps") or self.steps,
                "attempts": m.get("steps") or self.steps,
                "rounds": m.get("steps") or self.steps,
                "firstTokenMs": m.get("ttft_ms") or 0,
                "tps": tps,
                "cachePct": cache_hit_percent(cache, prompt),
                "finished": bool(finished),
                "endedAt": int(time.time()) if finished else 0}


def cache_hit_percent(cache_read: int, prompt: int):
    """缓存命中百分比：真的全中才是 100，差一点点也不四舍五入成 100。"""
    if prompt <= 0:
        return None
    if cache_read >= prompt:
        return 100.0
    pct = cache_read * 100.0 / prompt
    if pct >= 99.995:
        return 99.99
    return round(pct, 2)


def translate(update: dict, ts: TurnState) -> list:
    """把一条智能体 update 翻成若干条前端 SSE 事件。"""
    if not isinstance(update, dict):
        return []
    kind = update.get("sessionUpdate")
    out = []

    if kind == "agent_message_chunk":
        text = _chunk_text(update.get("content"))
        if text:
            ts.step_text += text
            ts.answer += text
            out.append({"type": "delta", "text": text})
        return out

    if kind == "agent_thought_chunk":
        text = _chunk_text(update.get("content"))
        if text:
            out.append({"type": "think", "text": text})
        return out

    if kind == "tool_call":
        ts.steps += 1
        call_id = str(update.get("toolCallId") or "")
        name = str(update.get("title") or "tool")
        args = update.get("rawInput")
        args = args if isinstance(args, dict) else {"value": args}
        ts.calls[call_id] = {"name": name, "args": args}
        if call_id not in ts.flushed_calls:
            ts.flushed_calls.add(call_id)
            ts.step_calls.append({"id": call_id, "name": name, "args": args})
        out.append({"type": "tool_start", "id": call_id, "name": name, "args": args})
        return out

    if kind == "tool_call_update":
        call_id = str(update.get("toolCallId") or "")
        known = ts.calls.get(call_id) or {}
        detail = _update_text(update.get("content"))
        ok = str(update.get("status") or "completed") != "failed"
        event = {"type": "tool_result", "id": call_id,
                 "name": known.get("name") or "tool",
                 "args": known.get("args") or {}, "ok": ok,
                 "summary": _short(detail) or (known.get("name") or "tool"),
                 "detail": detail[:MAX_TOOL_DETAIL]}
        # meta：给 IDE 的同步指令（改过的文件 / 新建的工程）—— 前端 aiApplyMeta() 消费
        meta = update.get("meta")
        if isinstance(meta, dict) and meta:
            event["meta"] = meta
        out.append(event)
        return out

    if kind == "usage_update":
        try:
            used = int(update.get("used") or 0)
            size = int(update.get("size") or 0)
        except (TypeError, ValueError):
            return []
        if size > 0:
            ts.ctx_total = size
            STATE["ctx_window"] = size
        ts.max_prompt = max(ts.max_prompt, used)
        out.append({"type": "context", "prompt": used, "ctx": ts.ctx_total,
                    "compactions": int(STATE.get("compactions") or 0)})
        out.append({"type": "stats", "stats": ts.stats()})
        return out

    if kind == "compaction_update":
        if str(update.get("phase") or "") == "summary":
            STATE["compactions"] = int(STATE.get("compactions") or 0) + 1
            try:
                shadowed = int(update.get("shadowedTokenCount") or 0)
            except (TypeError, ValueError):
                shadowed = 0
            out.append({"type": "notice",
                        "text": "上下文已压缩（第 %d 次）：约 %d tok 的较老历史已并入摘要"
                                % (STATE["compactions"], shadowed)})
        else:
            err = str(update.get("error") or "")
            if err:
                out.append({"type": "notice", "text": "上下文压缩失败：%s" % err})
        return out

    if kind == "_notice":
        out.append({"type": "notice", "text": str(update.get("text") or "")})
        return out

    return out


def _flush_step(ts: TurnState) -> None:
    text = ts.step_text.strip()
    calls = ts.step_calls
    if not text and not calls:
        return
    entry = {"role": "assistant", "content": text}
    if calls:
        entry["tool_calls"] = [{
            "id": c["id"], "type": "function",
            "function": {"name": c["name"],
                         "arguments": json.dumps(c["args"], ensure_ascii=False)},
        } for c in calls]
    STATE["transcript"].append(entry)
    ts.step_text = ""
    ts.step_calls = []
    ts.flushed_calls = set()


# ---------------- 提示词 / 附件 ----------------

def _context_text(project: str, ctx: dict, runtime: dict) -> str:
    ws = CFG.workspace_dir()
    lines = ["【云易IDE 会话上下文】",
             "工作区：即你的当前工作目录（工程是当前目录下的子目录，请一律用相对路径）"]
    if project:
        lines.append("当前工程：" + project
                     + ("（当前目录下的 " + project + "/ 子目录）"
                        if os.path.isdir(os.path.join(ws, project)) else "（尚未创建）"))
    cur = (ctx or {}).get("curFile") or ""
    text = (ctx or {}).get("curText") or ""
    if cur:
        lines.append("当前打开的文件：" + str(cur))
    if cur and text:
        try:
            limit = int(runtime.get("ctxChars") or 0) or 20000
        except (TypeError, ValueError):
            limit = 20000
        body = str(text)
        if len(body) > limit:
            body = body[:limit] + "\n…（内容过长已截断）"
        lines.append("【当前文件内容】\n```\n" + body + "\n```")
    return "\n".join(lines)


def _decode_data_url(data_url: str):
    if not isinstance(data_url, str) or not data_url.startswith("data:"):
        return None
    head, _, payload = data_url.partition(",")
    if ";base64" not in head:
        return None
    mime = head[5:].split(";")[0].strip().lower()
    if mime not in IMG_MIME:
        return None
    return mime, payload


def build_blocks(message: str, project: str, ctx: dict, runtime: dict,
                 images=None, files=None) -> list:
    """把一条前端消息打包成模型的内容块（文本 / 图片 / 附件）。"""
    blocks = []
    preamble = _context_text(project, ctx, runtime)
    body = (message or "").strip()
    text = preamble + "\n\n【用户要求】\n" + (body or "（用户未输入文字，请看附件）")
    blocks.append({"type": "text", "text": text})
    notices = []

    try:
        max_mb = float(runtime.get("attachmentsMaxImageMB") or 0)
    except (TypeError, ValueError):
        max_mb = 0
    for url in (images or []):
        got = _decode_data_url(url)
        if got is None:
            notices.append("有一张图片格式不受支持（仅支持 png / jpeg / webp / gif），已跳过")
            continue
        mime, payload = got
        if max_mb > 0 and len(payload) * 3 / 4 > max_mb * 1024 * 1024:
            notices.append("有一张图片超过 %gMB 上限，已跳过" % max_mb)
            continue
        blocks.append({"type": "image_url",
                       "image_url": {"url": "data:%s;base64,%s" % (mime, payload)}})

    try:
        max_file_mb = float(runtime.get("attachmentsMaxFileMB") or 0)
    except (TypeError, ValueError):
        max_file_mb = 0
    for f in (files or []):
        if not isinstance(f, dict):
            continue
        name = str(f.get("name") or "附件")
        raw_b64 = f.get("b64")
        if not isinstance(raw_b64, str):
            continue
        try:
            raw = base64.b64decode(raw_b64, validate=False)
        except Exception:
            notices.append("附件「%s」解码失败，已跳过" % name)
            continue
        if max_file_mb > 0 and len(raw) > max_file_mb * 1024 * 1024:
            notices.append("附件「%s」超过 %gMB 上限，已跳过" % (name, max_file_mb))
            continue
        try:
            from yunyi import codec as CODEC
            decoded, enc = CODEC.decode_ex("frontend", raw)
        except Exception:
            decoded, enc = None, "binary"
        if decoded is None or str(enc).endswith("*"):
            notices.append("附件「%s」不是文本文件（%d 字节），已跳过" % (name, len(raw)))
            continue
        cap = 60000
        text_body = decoded if len(decoded) <= cap else decoded[:cap] + "\n…（附件过长已截断）"
        blocks.append({"type": "text", "text": "【附件 %s】\n```\n%s\n```" % (name, text_body)})

    if notices:
        blocks.append({"type": "text", "text": "（附件提示：" + "；".join(notices) + "）"})
    return blocks


# ---------------- 对话主流程 ----------------

STOP_NOTE = {
    "end_turn": "任务已完成",
    "cancelled": "已取消",
    "max_tokens": "达到输出上限，回答可能被截断",
    "max_turn_requests": "达到回合上限",
    "refusal": "模型拒绝了这个请求",
}


def _start_turn(message: str, project: str, ctx: dict | None = None,
                images=None, files=None):
    """开一个新回合：后台线程跑智能体，泵线程把事件累积进回合对象。

    返回 (turn, None) 或 (None, 错误文案)。回合与 SSE 连接解耦：连接断了
    回合照跑，事件留在 turn["events"] 里，前端刷新后经 attach_stream 补看。
    """
    ctx = ctx or {}
    with LOCK:
        if STATE["busy"]:
            return None, "上一次任务还在进行中，请先停止或等待它结束。"
        STATE["busy"] = True
    try:
        cfg = CFG.load_cfg()
        runtime = CFG.load_runtime()
        workspace = CFG.workspace_dir()
        # 先把当前工程定下来，再建/取智能体：agent 要用它把改动换算成工程内路径，
        # 并作为「新建工程才报 newProject」的基线。
        STATE["project"] = project or STATE["project"]
        agent = ensure_agent(cfg, runtime, workspace)
        # 每回合一个独立的取消事件。若上一回合的线程还残着，先把它的取消事件
        # 置位——否则它会改挂到这个新事件上，永远收不到停止通知，
        # 远程模型的流也断不掉。
        prev_cancel = STATE.get("turn_cancel")
        if isinstance(prev_cancel, threading.Event):
            prev_cancel.set()
        agent.cancel = threading.Event()
        STATE["turn_cancel"] = agent.cancel
        STATE["stop_requested"] = False
        ts = TurnState(STATE.get("ctx_window") or CFG.context_window(runtime))
        blocks = build_blocks(message, project, ctx, runtime, images, files)
        STATE["transcript"].append({"role": "user", "content": message})
        # base：本轮用户消息在内、已入转录的条数 —— 刷新重连时前端只渲染转录
        # 前 base 条历史；本轮已完成的步骤由事件重放补上，不会重复。
        base = len(STATE["transcript"])
        _save_session()
        # 排空上一回合可能残留在队列里的通知
        while True:
            try:
                STATE["updates"].get_nowait()
            except queue.Empty:
                break
        turn = {"cancel": agent.cancel, "cond": threading.Condition(),
                "events": [], "ts": ts, "base": base, "done": False}
        STATE["turn"] = turn
    except Exception as e:                                        # noqa: BLE001
        STATE["busy"] = False
        STATE["error"] = "%s: %s" % (type(e).__name__, e)
        return None, "AI 后端异常：%s" % e

    holder: dict = {}

    def _run():
        try:
            holder["reason"] = agent.prompt(blocks)
        except BaseException as exc:                          # noqa: BLE001
            holder["error"] = exc
        finally:
            STATE["updates"].put({"method": "_finished"})

    worker = threading.Thread(target=_run, name="agent-turn", daemon=True)
    worker.start()

    def _pump():
        """消费智能体通知队列：翻成前端事件累积进回合对象，唤醒观看者。"""
        done = False
        while not done:
            try:
                msg = STATE["updates"].get(timeout=0.2)
            except queue.Empty:
                if worker.is_alive():
                    continue
                # 线程已结束：排空剩余通知
                while True:
                    try:
                        msg = STATE["updates"].get_nowait()
                    except queue.Empty:
                        break
                    _absorb(msg, turn)
                    if msg.get("method") == "_finished":
                        done = True
                if not done:
                    continue
                break
            _absorb(msg, turn)
            if msg.get("method") == "_finished":
                done = True
        _finish_turn(turn, holder, worker)

    threading.Thread(target=_pump, name="agent-pump", daemon=True).start()
    return turn, None


def _absorb(msg: dict, turn: dict) -> None:
    """把一条队列消息翻成前端事件并累积进回合对象（唤醒观看者）。"""
    if not isinstance(msg, dict):
        return
    method = msg.get("method")
    if method == "session/update":
        events = translate((msg.get("params") or {}).get("update") or {}, turn["ts"])
    elif method == "_confirm":
        events = [msg.get("params") or {"type": "confirm"}]
    else:
        events = []
    if not events:
        return
    with turn["cond"]:
        turn["events"].extend(events)
        turn["cond"].notify_all()


def _finish_turn(turn: dict, holder: dict, worker) -> None:
    """回合收尾：补最终事件、落盘并释放忙碌标记（不管有没有人在看）。"""
    ts = turn["ts"]
    events: list = []
    try:
        worker.join(timeout=5)
        if "error" in holder:
            raise holder["error"]
        if "reason" not in holder:
            # 线程结束了却既没有 stopReason 也没有异常：智能体意外退出，
            # 不能当成正常完成来收尾。
            raise RuntimeError("智能体线程没有返回结果，可能被意外终止")
        reason = str(holder.get("reason") or "end_turn")
        note = STOP_NOTE.get(reason, "回合结束（%s）" % reason)
        _flush_step(ts)
        STATE["usage"] = ts.stats(finished=True)
        events.append({"type": "stats", "stats": ts.stats(finished=True)})
        if note:
            events.append({"type": "notice", "text": note})
        if STATE.get("stop_requested"):
            events.append({"type": "notice", "text": "已停止"})
        events.append({"type": "done"})
    except Exception as e:                                        # noqa: BLE001
        STATE["error"] = "%s: %s" % (type(e).__name__, e)
        events.append({"type": "error", "text": "智能体意外退出：AI 后端异常：%s" % e})
    finally:
        STATE["busy"] = False
        STATE["stop_requested"] = False
        deny_pending_confirm()
        _save_session()
        with turn["cond"]:
            turn["events"].extend(events)
            turn["done"] = True
            turn["cond"].notify_all()


def _follow(turn: dict, start: int = 0):
    """按序产出回合事件直到回合结束（生成器）。

    生成器被 close 只是停止观看，绝不影响后台回合——刷新页面后事件仍在
    累积，前端重连（attach_stream）能从头发补看。真正的停止只有两条路：
    用户点「停止」（置取消事件，打断模型流与工具执行），或回合自身出错。
    """
    cursor = max(0, int(start))
    while True:
        with turn["cond"]:
            while cursor >= len(turn["events"]) and not turn["done"]:
                turn["cond"].wait(timeout=1.0)
            new = turn["events"][cursor:]
            cursor = len(turn["events"])
            done = turn["done"]
        for ev in new:
            yield ev
        if done:
            return


def stream_chat(message: str, project: str, ctx: dict | None = None,
                images=None, files=None):
    """一个用户回合：开后台回合并按序产出前端 SSE 事件（生成器）。"""
    turn, err = _start_turn(message, project, ctx, images, files)
    if turn is None:
        yield {"type": "error", "text": err}
        return
    yield from _follow(turn)


def attach_stream():
    """刷新后重连：重放进行中回合的全部事件并跟到结束（生成器）。

    没有进行中的回合时回 {"type":"idle"}——前端照旧走历史恢复即可。
    """
    turn = STATE.get("turn")
    if not isinstance(turn, dict) or turn.get("done"):
        yield {"type": "idle"}
        return
    yield {"type": "attach", "base": int(turn.get("base") or 0)}
    yield from _follow(turn)


# ---------------- 停止 / 确认 ----------------

def stop_turn() -> dict:
    """前端点「停止」：置停止标记并打断智能体（模型流与工具执行都会看这个标记）。"""
    with LOCK:
        busy = bool(STATE.get("busy"))
        STATE["stop_requested"] = True
    agent = STATE.get("agent")
    if agent is not None:
        agent.cancel.set()
    if busy:
        deny_pending_confirm()
    return {"ok": True, "busy": busy}


def set_allow_all(on: bool) -> None:
    on = bool(on)
    try:
        CFG.save_runtime({"allowAll": on})
    except Exception:
        pass
    STATE["allow_all"] = on


def sync_allow_all() -> None:
    try:
        STATE["allow_all"] = bool(CFG.load_runtime().get("allowAll"))
    except Exception:
        pass


def answer_confirm(approve: bool, approve_all: bool = False) -> dict:
    """前端确认卡点了按钮（POST /api/ai/confirm）。"""
    if approve_all:
        set_allow_all(True)
    with CONFIRM_LOCK:
        holder = STATE.get("confirm")
    if holder is not None:
        holder["answer"] = bool(approve)
        holder["event"].set()
    return {"ok": True, "approved": bool(approve), "allowAll": bool(STATE.get("allow_all"))}


def deny_pending_confirm() -> None:
    with CONFIRM_LOCK:
        holder = STATE.get("confirm")
    if holder is not None:
        holder["answer"] = False
        holder["event"].set()


# ---------------- 查询接口 ----------------

def session_info() -> dict:
    return {"sessionId": STATE["session_id"],
            "messages": len(STATE["transcript"]),
            "project": STATE["project"],
            "busy": STATE["busy"],
            "ready": True,
            "backend": "python-agent"}


def history() -> dict:
    return {"messages": list(STATE["transcript"]), "project": STATE["project"],
            "sessionId": STATE["session_id"]}


def context_usage() -> dict:
    usage = STATE.get("usage") or {}
    ctx = STATE.get("ctx_window") or CFG.context_window(CFG.load_runtime())
    prompt = int(usage.get("ctxUsed") or 0)
    if prompt <= 0:
        prompt = int(usage.get("inTokens") or 0)
    if ctx > 0:
        prompt = min(prompt, ctx)
    return {"prompt": prompt, "ctx": ctx, "sessionId": STATE["session_id"],
            "compactions": int(STATE.get("compactions") or 0)}


def clear_session() -> None:
    """新会话：丢掉旧会话与转录，下一条消息开一个全新会话。"""
    # 回合可能还在跑（前端断开 SSE 后立刻点新会话，收尾还没走完）：先置位
    # 取消事件，让远程模型的流断掉、回合线程尽快退出。
    ev = STATE.get("turn_cancel")
    if isinstance(ev, threading.Event):
        ev.set()
    with LOCK:
        agent = STATE.get("agent")
        if agent is not None:
            try:
                agent.session.delete()
            except Exception:
                pass
        STATE["agent"] = None
        STATE["session_id"] = ""
        STATE["transcript"] = []
        STATE["turn"] = None
        STATE["usage"] = {}
        STATE["compactions"] = 0
        STATE["project"] = ""
        _save_session()


def status() -> dict:
    runtime = CFG.load_runtime()
    cfg = CFG.stored_cfg()
    api = CFG.active_api(CFG.load_cfg())
    agent = STATE.get("agent")
    return {"backend": "python-agent",
            "profile": "python",
            "ready": True,
            "busy": STATE["busy"],
            "sessionId": STATE["session_id"],
            "provider": api.get("alias") or api.get("mode") or "",
            "model": api.get("model") or "",
            "toolsMode": runtime.get("toolsMode"),
            "ctxWindow": STATE.get("ctx_window") or CFG.context_window(runtime),
            "sandbox": SB.sandbox_mode(runtime),
            "dshBin": "", "dshBinFound": True,
            "patchFile": "", "mode": cfg.get("mode"),
            "lastError": STATE.get("error", ""),
            "steps": (agent.metrics.get("steps") if agent is not None else 0)}


# ---------------- 接口连通性测试 ----------------

def _model_ids(payload) -> list:
    out = []
    if isinstance(payload, dict):
        data = payload.get("data")
        if isinstance(data, list):
            for it in data:
                if isinstance(it, dict):
                    out.append(str(it.get("id") or it.get("name") or ""))
        models = payload.get("models")
        if isinstance(models, list):
            for it in models:
                if isinstance(it, dict):
                    out.append(str(it.get("name") or it.get("model") or it.get("id") or ""))
                elif isinstance(it, str):
                    out.append(it)
    seen, uniq = set(), []
    for m in out:
        m = m.strip()
        if m and m not in seen:
            seen.add(m)
            uniq.append(m)
    return uniq


def test_connect_with(body: dict) -> dict:
    """测试一组接口参数（所见即所测）：先拉模型列表，失败再发一次极短的对话请求。"""
    from . import llm as LLM
    body = body if isinstance(body, dict) else {}
    mode = body.get("mode") if body.get("mode") in CFG.AI_MODES else "default"
    part = body.get(mode) if isinstance(body.get(mode), dict) else None
    if part is None:
        part = CFG.load_cfg().get(mode) or {}
    url = str(part.get("url") or "").strip().rstrip("/")
    model = str(part.get("model") or "").strip()
    key = str(part.get("key") or "")
    tested = {"mode": mode, "url": url, "model": model}
    if not url:
        return {"ok": False, "ms": 0, "note": "接口地址为空", "tested": tested, "models": []}

    t0 = time.time()
    try:
        payload = LLM.http_json("GET", url + "/models", key, timeout=15)
        ids = _model_ids(payload)
        ms = int((time.time() - t0) * 1000)
        note = "已连接（模型列表 %d 个）" % len(ids)
        n_ctx = AGENT.probe_context_window(url, key)
        if n_ctx:
            note += "；上下文窗口 %d tok" % n_ctx
        if model and ids and model not in ids:
            note += "；注意：列表里没有「%s」" % model
        return {"ok": True, "ms": ms, "note": note, "tested": tested,
                "ctx": n_ctx, "models": ids[:200]}
    except Exception as e:                                        # noqa: BLE001
        first = "%s" % e
    try:
        client = LLM.LLM(url, model or "test", key, timeout=30, idle_timeout=30)
        client.chat([{"role": "user", "content": "ping"}])
        ms = int((time.time() - t0) * 1000)
        return {"ok": True, "ms": ms, "note": "对话接口可用（模型列表不可读：%s）" % first,
                "tested": tested, "models": []}
    except Exception as e:                                        # noqa: BLE001
        ms = int((time.time() - t0) * 1000)
        return {"ok": False, "ms": ms, "note": "模型列表：%s；对话接口：%s" % (first, e),
                "tested": tested, "models": []}
