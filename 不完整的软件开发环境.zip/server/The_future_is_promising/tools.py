# -*- coding: utf-8 -*-
"""The_future_is_promising 的工具注册表与内建工具。

与 dsh 的 standard preset 对齐（见 hope/packages/preset/agent-presets/presets/
standard/agent.cordis.yml）：文件系统、shell、技能、todo、委派子智能体、联网、
展示交付物。PTC 模式下的 `run_code` 在 The_future_is_promising 里执行的是 **Python**（dsh 那边是
TypeScript）——这是转到 Python 之后最自然的一处变化：程序化工具调用也用 Python 写。

每个工具都是 fn(ctx, args) -> str；注册表同时导出 OpenAI 的 function schema。
"""
from __future__ import annotations
import base64
import html
import io
import json
import os
import re
import subprocess
import threading
import time
import urllib.parse
import urllib.request

from . import sandbox as SB

# 二进制 / 噪声目录：搜索时一律跳过
SKIP_DIRS = {".git", ".svn", ".hg", "node_modules", "__pycache__", ".temp",
             ".venv", "venv", "build", "dist", ".idea", ".vscode", "tools"}
SKIP_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".exe",
             ".dll", ".so", ".dylib", ".class", ".pyc", ".zip", ".gz", ".zst",
             ".tar", ".7z", ".pdf", ".woff", ".woff2", ".ttf", ".eot"}

MAX_LIST = 400
MAX_GREP = 200


# ---------------------------------------------------------------- 工具上下文

class ToolContext:
    """一次工具调用能看到的一切。"""

    def __init__(self, workspace: str, runtime: dict, sandbox: SB.Sandbox,
                 confirm=None, cancel: threading.Event | None = None, note=None,
                 skill_dirs=None, llm_factory=None, subagent_limit=3):
        self.workspace = os.path.abspath(workspace or os.getcwd())
        self.runtime = runtime or {}
        self.sandbox = sandbox
        self.confirm = confirm              # (title, reason) -> bool
        self.cancel = cancel                # 用户点「停止」
        self.note = note or (lambda text: None)
        self.skill_dirs = list(skill_dirs or [])
        self.llm_factory = llm_factory      # () -> LLM，子智能体用
        self.subagent_limit = int(subagent_limit or 0)
        self.todos: list = []
        self.presented: list = []
        self.subagents_used = 0

    def for_call(self, granted: bool = False) -> "ToolContext":
        """派生一份用于单次工具调用的上下文。

        granted=True 表示用户已在确认卡上放行：这一次的沙箱检查要真的让路
        （否则批准只是形式，工具内部 resolve() 仍会拦下来）。
        并行工具调用各自派生，互不干扰。
        """
        if not granted:
            return self
        import copy
        clone = copy.copy(self)
        clone.sandbox = self.sandbox.escalated(True)
        return clone

    # ---------- 统一的结果截断 ----------

    def cap(self, text: str) -> str:
        """按运行时参数截断工具结果（对应 dsh 的 tool-result-pruner）。"""
        try:
            total = int(self.runtime.get("toolResultChars") or 0) or 20000
        except (TypeError, ValueError):
            total = 20000
        if len(text) <= total:
            return text
        try:
            keep = int(self.runtime.get("toolResultKeepChars") or 0) or 2000
        except (TypeError, ValueError):
            keep = 2000
        head = max(0, min(keep, total // 2))
        tail = max(0, min(keep, total - head))
        return (text[:head]
                + "\n…（已截断 %d 字符）…\n" % (len(text) - head - tail)
                + (text[-tail:] if tail else ""))

    def ask(self, title: str, reason: str) -> bool:
        """弹确认卡（沙箱策略要求问的时候才调）。"""
        if self.confirm is None:
            return False
        return bool(self.confirm(title, reason))


# ---------------------------------------------------------------- 小工具

def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def _read_text(path: str) -> str:
    with open(path, "rb") as f:
        return _decode(f.read())


def _walk(base: str, include_hidden: bool = False):
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames
                       if (include_hidden or not d.startswith(".")) and d not in SKIP_DIRS]
        for name in filenames:
            yield dirpath, name


def _rel(workspace: str, path: str) -> str:
    try:
        rel = os.path.relpath(path, workspace)
    except ValueError:
        return path
    return rel.replace("\\", "/")


# ---------------------------------------------------------------- 文件系统

def t_read_file(ctx: ToolContext, args: dict) -> str:
    path = ctx.sandbox.resolve(str(args.get("path") or ""), writing=False)
    if not os.path.isfile(path):
        return "文件不存在：%s" % ctx.sandbox.display(path)
    try:
        offset = int(args.get("offset") or 0)
    except (TypeError, ValueError):
        offset = 0
    try:
        limit = int(args.get("limit") or 0)
    except (TypeError, ValueError):
        limit = 0
    text = _read_text(path)
    lines = text.splitlines()
    start = max(0, offset - 1) if offset > 0 else 0
    end = len(lines) if limit <= 0 else min(len(lines), start + limit)
    picked = lines[start:end]
    width = len(str(end))
    body = "\n".join("%*d| %s" % (width, start + i + 1, line) for i, line in enumerate(picked))
    return ctx.cap("%s（共 %d 行，显示 %d–%d）\n%s"
                   % (ctx.sandbox.display(path), len(lines), start + 1, end, body))


def t_write_file(ctx: ToolContext, args: dict) -> str:
    path = ctx.sandbox.resolve(str(args.get("path") or ""), writing=True)
    content = args.get("content")
    if not isinstance(content, str):
        return "缺少 content"
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    existed = os.path.isfile(path)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    return ("已写入 %s（%d 字符，%s）"
            % (ctx.sandbox.display(path), len(content), "覆盖" if existed else "新建"))


def t_edit_file(ctx: ToolContext, args: dict) -> str:
    path = ctx.sandbox.resolve(str(args.get("path") or ""), writing=True)
    old = args.get("old")
    new = args.get("new")
    if not isinstance(old, str) or not isinstance(new, str):
        return "edit_file 需要 old 与 new 两个字符串"
    if not os.path.isfile(path):
        return "文件不存在：%s" % ctx.sandbox.display(path)
    text = _read_text(path)
    count = text.count(old)
    if count == 0:
        return "没找到要替换的内容：\n%s" % old[:400]
    try:
        want = int(args.get("count") or 0)
    except (TypeError, ValueError):
        want = 0
    if want and count > want:
        return "要替换的内容出现了 %d 次，请给出更精确的上下文（或指定 count）" % count
    if count > 1:
        return "要替换的内容出现了 %d 次，不确定改哪一处：请补更多上下文" % count
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text.replace(old, new))
    return "已修改 %s" % ctx.sandbox.display(path)


def t_list_dir(ctx: ToolContext, args: dict) -> str:
    base = ctx.sandbox.resolve(str(args.get("path") or "."), writing=False)
    if not os.path.isdir(base):
        return "目录不存在：%s" % ctx.sandbox.display(base)
    try:
        depth = int(args.get("depth") or 1)
    except (TypeError, ValueError):
        depth = 1
    depth = max(1, min(depth, 4))
    out = []
    count = 0

    def scan(dirpath: str, rel: str, level: int):
        nonlocal count
        if level > depth or count >= MAX_LIST:
            return
        try:
            entries = sorted(os.listdir(dirpath))
        except OSError:
            return
        dirs, files = [], []
        for name in entries:
            if name.startswith(".") or name in SKIP_DIRS:
                continue
            full = os.path.join(dirpath, name)
            (dirs if os.path.isdir(full) else files).append(name)
        for name in dirs:
            count += 1
            out.append("  " * (level - 1) + "[dir]  " + (rel + name if rel else name) + "/")
            scan(os.path.join(dirpath, name), (rel + name + "/" if rel else name + "/"), level + 1)
        for name in files:
            count += 1
            out.append("  " * (level - 1) + "       " + (rel + name if rel else name))

    scan(base, "", 1)
    head = "目录 %s（depth=%d）\n" % (ctx.sandbox.display(base), depth)
    tail = "\n…（超过 %d 项，已截断）" % MAX_LIST if count >= MAX_LIST else ""
    return ctx.cap(head + "\n".join(out) + tail)


def t_search_files(ctx: ToolContext, args: dict) -> str:
    """按文件名 glob 找文件。"""
    import fnmatch
    pattern = str(args.get("pattern") or "").strip()
    if not pattern:
        return "缺少 pattern"
    base = ctx.sandbox.resolve(str(args.get("path") or "."), writing=False)
    if not os.path.isdir(base):
        base = ctx.workspace
    hits = []
    for dirpath, name in _walk(base):
        if fnmatch.fnmatch(name.lower(), pattern.lower()):
            hits.append(_rel(ctx.workspace, os.path.join(dirpath, name)))
            if len(hits) >= MAX_LIST:
                break
    if not hits:
        return "没有匹配 %s 的文件" % pattern
    tail = "\n…（超过 %d 个，已截断）" % MAX_LIST if len(hits) >= MAX_LIST else ""
    return ctx.cap("匹配 %s 的文件 %d 个：\n%s" % (pattern, len(hits), "\n".join(sorted(hits))) + tail)


def t_search_content(ctx: ToolContext, args: dict) -> str:
    """在文件内容里正则搜索。"""
    pattern = str(args.get("pattern") or "").strip()
    if not pattern:
        return "缺少 pattern"
    try:
        rx = re.compile(pattern, re.IGNORECASE if args.get("ignore_case", True) else 0)
    except re.error as e:
        return "正则表达式不合法：%s" % e
    base = ctx.sandbox.resolve(str(args.get("path") or "."), writing=False)
    if not os.path.isdir(base):
        base = ctx.workspace
    include = str(args.get("include") or "").strip()
    import fnmatch
    hits = []
    files = 0
    for dirpath, name in _walk(base):
        if include and not fnmatch.fnmatch(name.lower(), include.lower()):
            continue
        if os.path.splitext(name)[1].lower() in SKIP_EXTS:
            continue
        full = os.path.join(dirpath, name)
        try:
            if os.path.getsize(full) > 2 * 1024 * 1024:
                continue
            text = _read_text(full)
        except (OSError, ValueError):
            continue
        files += 1
        for i, line in enumerate(text.splitlines(), 1):
            if rx.search(line):
                hits.append("%s:%d: %s" % (_rel(ctx.workspace, full), i, line.strip()[:300]))
                if len(hits) >= MAX_GREP:
                    break
        if len(hits) >= MAX_GREP:
            break
    if not hits:
        return "在 %d 个文件里没搜到 %s" % (files, pattern)
    tail = "\n…（超过 %d 条，已截断）" % MAX_GREP if len(hits) >= MAX_GREP else ""
    return ctx.cap("搜到 %d 条（扫过 %d 个文件）：\n%s" % (len(hits), files, "\n".join(hits)) + tail)


# ---------------------------------------------------------------- shell

def _shell_argv(command: str) -> list:
    if os.name == "nt":
        return ["powershell", "-NoProfile", "-NonInteractive", "-Command", command]
    return ["bash", "-lc", command]


def t_run_command(ctx: ToolContext, args: dict) -> str:
    command = str(args.get("command") or "").strip()
    if not command:
        return "缺少 command"
    try:
        timeout = int(args.get("timeout") or 0)
    except (TypeError, ValueError):
        timeout = 0
    if timeout <= 0:
        timeout = 120
    timeout = max(1, min(timeout, 600))
    ctx.sandbox.check_command(command)
    cwd = ctx.workspace
    rel = str(args.get("cwd") or "").strip()
    if rel:
        try:
            cwd = ctx.sandbox.resolve(rel, writing=False)
        except SB.SandboxError as e:
            return str(e)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.run(_shell_argv(command), cwd=cwd, timeout=timeout,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              creationflags=flags)
    except subprocess.TimeoutExpired:
        return "命令超时（%ds）后仍未结束：%s" % (timeout, command[:200])
    except OSError as e:
        return "命令无法启动：%s（%s）" % (e, command[:200])
    out = _decode(proc.stdout or b"").strip()
    head = "$ %s\n（退出码 %d）\n" % (command[:400], proc.returncode)
    if not out:
        out = "（无输出）"
    return ctx.cap(head + out)


# ---------------------------------------------------------------- 联网

def _strip_html(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?s)<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    return re.sub(r"[ \t\r\f\v]+", " ", re.sub(r"\n{3,}", "\n\n", raw)).strip()


def t_web_fetch(ctx: ToolContext, args: dict) -> str:
    url = str(args.get("url") or "").strip()
    if not url:
        return "缺少 url"
    if not ctx.runtime.get("allowNetwork", True):
        return "运行时参数已关闭网络访问（allowNetwork=false）"
    try:
        limit = int(args.get("max_chars") or 0)
    except (TypeError, ValueError):
        limit = 0
    if limit <= 0:
        limit = 20000
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (YunYiIDE-agent/2.0)",
            "Accept": "text/html,application/json,text/plain,*/*"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read(2 * 1024 * 1024)
            ctype = (resp.headers.get("Content-Type") or "").lower()
    except Exception as e:                                        # noqa: BLE001
        return "抓取失败：%s" % e
    text = _decode(raw)
    if "html" in ctype or text.lstrip()[:200].lower().startswith("<!doctype"):
        text = _strip_html(text)
    return ctx.cap(text[:limit])


def t_web_search(ctx: ToolContext, args: dict) -> str:
    query = str(args.get("query") or "").strip()
    if not query:
        return "缺少 query"
    if not ctx.runtime.get("allowNetwork", True):
        return "运行时参数已关闭网络访问（allowNetwork=false）"
    try:
        data = urllib.parse.urlencode({"q": query}).encode("utf-8")
        req = urllib.request.Request(
            "https://html.duckduckgo.com/html/",
            data=data,
            headers={"User-Agent": "Mozilla/5.0 (YunYiIDE-agent/2.0)",
                     "Accept": "text/html"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
    except Exception as e:                                        # noqa: BLE001
        return "搜索失败：%s" % e
    items = []
    for match in re.finditer(
            r'(?is)<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?'
            r'class="result__snippet"[^>]*>(.*?)</a>', _decode(raw)):
        link, title, snippet = match.group(1), match.group(2), match.group(3)
        link = urllib.parse.unquote(link)
        found = re.search(r"uddg=([^&]+)", link)
        if found:
            link = urllib.parse.unquote(found.group(1))
        items.append("- %s\n  %s\n  %s" % (_strip_html(title), link,
                                           _strip_html(snippet)))
        if len(items) >= 10:
            break
    if not items:
        return "没有搜到结果：%s" % query
    return ctx.cap("搜索「%s」的结果：\n%s" % (query, "\n".join(items)))


# ---------------------------------------------------------------- 技能 / todo / 交互

# 技能根的相对写法（相对「工程根」）：与 dsh 的 skill-filesystem 对齐 ——
# 它扫 <工程根>\.dsh\skills、<工程根>\.agents\skills、customSkillDirs、
# $DSH_HOME\skills、~\.agents\skills。这里把两种 agents 写法（单/复数）都认，
# 免得换个写法就搜不到。
_SKILL_SUBDIRS = ((".agents", "skills"), (".agent", "skills"), (".dsh", "skills"))


def _git_root(start: str) -> str:
    r"""从 start 向上找最近的 .git（目录或文件），找不到返回空串。

    dsh 的 findProjectRoot 就是这么定位「工程根」的：cwd 可能在子目录里，
    技能却放在仓库根的 .agents\skills 下。
    """
    current = os.path.abspath(start or ".")
    while True:
        if os.path.exists(os.path.join(current, ".git")):
            return current
        parent = os.path.dirname(current)
        if parent == current:
            return ""
        current = parent


def _skill_roots(ctx: ToolContext) -> list:
    """当前会话要扫的技能根（按优先级从高到低，去重保序）。"""
    roots: list = []
    bases: list = []

    def add(path: str):
        if not path:
            return
        try:
            norm = os.path.normcase(os.path.abspath(path))
        except OSError:
            return
        if norm not in roots:
            roots.append(norm)

    for path in (ctx.skill_dirs or []):        # IDE 自带：server\skills / _MEIPASS
        add(path)
    workspace = os.path.abspath(ctx.workspace or ".")
    bases.append(workspace)
    git_root = _git_root(workspace)            # 工程根（最近 .git 祖先）
    if git_root and os.path.normcase(git_root) != os.path.normcase(workspace):
        bases.insert(0, git_root)
    for base in bases:
        for rel in _SKILL_SUBDIRS:
            add(os.path.join(base, *rel))
    home = os.path.expanduser("~")             # 用户级（对应 dsh 的 ~\.agents\skills）
    if home:
        add(os.path.join(home, ".agents", "skills"))
        add(os.path.join(home, ".dsh", "skills"))
    return roots


def _skill_catalog(ctx: ToolContext) -> list:
    r"""扫出所有可用技能：[(name, path, desc)]。

    两种形态都认（与 dsh 一致）：
      · 目录包：<根>\<技能名>\SKILL.md（可多一层分组目录）
      · 扁平 Markdown：<根>\<技能名>.md（必须有 YAML frontmatter，
        否则像 README.md 这种说明文档会被误当成技能）
    """
    found: list = []
    seen: set = set()
    for root in _skill_roots(ctx):
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            depth = 0 if os.path.normcase(dirpath) == root else \
                len(os.path.relpath(dirpath, root).split(os.sep))
            if depth > 2:                      # 只往下看两层（分组目录 + 技能目录）
                dirnames[:] = []
                continue
            for name in sorted(filenames):
                lower = name.lower()
                if depth == 0:
                    if not lower.endswith(".md"):
                        continue               # 根下只认扁平 .md
                    full = os.path.join(dirpath, name)
                    # 扁平 .md 必须有 frontmatter：否则 README.md 这类说明文档会被当成技能
                    if not _has_frontmatter(full):
                        continue
                    skill_name = os.path.splitext(name)[0]
                else:
                    if lower != "skill.md":
                        continue
                    full = os.path.join(dirpath, name)
                    skill_name = os.path.basename(dirpath)
                try:
                    key = os.path.normcase(os.path.realpath(full))
                except OSError:
                    key = os.path.normcase(full)
                if key in seen:                # 同技能可能从多个根重复命中
                    continue
                seen.add(key)
                found.append((skill_name, full, _skill_desc(full)))
    return found


def _has_frontmatter(path: str) -> bool:
    """文件是否以 YAML frontmatter（`---` 开头）起头。"""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.readline().strip() == "---"
    except OSError:
        return False


def _skill_desc(path: str) -> str:
    """从 SKILL.md 取一句描述：优先 YAML frontmatter 的 description/name，
    其次第一个标题，最后才是第一行非空正文（跳过 `---` 分隔线与纯符号行）。"""
    try:
        text = _read_text(path)
    except OSError:
        return ""
    lines = text.splitlines()
    if lines and lines[0].strip() == "---":
        for line in lines[1:]:
            if line.strip() == "---":
                break
            stripped = line.strip()
            for key in ("description:", "description =", "desc:"):
                if stripped.lower().startswith(key):
                    value = stripped.split(":", 1)[1].strip().strip("'\"")
                    if value:
                        return value[:120]
    for line in lines:
        stripped = line.strip()
        if not stripped or set(stripped) <= set("-=_*# ") or stripped.startswith("---"):
            continue
        if stripped.startswith("#"):
            title = stripped.lstrip("#").strip()
            if title:
                return title[:120]
        return stripped[:120]
    return ""


def t_use_skill(ctx: ToolContext, args: dict) -> str:
    name = str(args.get("name") or "").strip()
    catalog = _skill_catalog(ctx)
    if not name:
        if not catalog:
            return "没有可用的技能"
        return "可用技能：\n" + "\n".join("- %s：%s" % (n, d) for n, _p, d in catalog)
    for skill_name, path, _desc in catalog:
        if skill_name.lower() == name.lower() or name.lower() in skill_name.lower():
            try:
                return ctx.cap("【技能 %s】\n%s" % (skill_name, _read_text(path)))
            except OSError as e:
                return "技能读取失败：%s" % e
    return "没有名为「%s」的技能。可用：%s" % (name, ", ".join(n for n, _p, _d in catalog))


def t_todo_write(ctx: ToolContext, args: dict) -> str:
    items = args.get("items")
    if isinstance(items, str):
        items = [x.strip() for x in items.splitlines() if x.strip()]
    if not isinstance(items, list):
        return "缺少 items（字符串数组或每行一条）"
    ctx.todos = [str(x) for x in items][:50]
    return "已记录 %d 条待办：\n%s" % (
        len(ctx.todos), "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(ctx.todos)))


def t_ask_user(ctx: ToolContext, args: dict) -> str:
    question = str(args.get("question") or "").strip()
    if not question:
        return "缺少 question"
    ok = ctx.ask("智能体提问", question)
    return ("用户确认：" if ok else "用户未确认：") + question


def t_present(ctx: ToolContext, args: dict) -> str:
    content = str(args.get("content") or args.get("text") or "").strip()
    if not content:
        return "缺少 content"
    ctx.presented.append(content)
    ctx.note("智能体提交了一份交付物")
    return "已提交交付物（%d 字符）" % len(content)


# ---------------------------------------------------------------- 子智能体

def t_subagent(ctx: ToolContext, args: dict) -> str:
    task = str(args.get("task") or args.get("prompt") or "").strip()
    if not task:
        return "缺少 task"
    if not ctx.runtime.get("multiAgentEnabled", True):
        return "运行时参数已关闭 Multi-Agent（multiAgentEnabled=false）"
    if ctx.subagent_limit and ctx.subagents_used >= ctx.subagent_limit:
        return "本回合派生子智能体已达上限（%d 个）" % ctx.subagent_limit
    if ctx.llm_factory is None:
        return "当前会话不支持派生子智能体"
    ctx.subagents_used += 1
    from . import agent as AGENT          # 延迟导入：agent 依赖 tools
    paths = args.get("context_paths")
    if not isinstance(paths, list):
        paths = []
    prelude = []
    for rel in paths[:10]:
        try:
            abs_path = ctx.sandbox.resolve(str(rel), writing=False)
            if os.path.isfile(abs_path):
                prelude.append("【%s】\n%s" % (rel, _read_text(abs_path)[:20000]))
        except (SB.SandboxError, OSError):
            continue
    sub = AGENT.SubAgent(ctx, "\n\n".join(prelude))
    return ctx.cap(sub.run(task))


# ---------------------------------------------------------------- PTC：run_code

class ToolsBridge:
    """`run_code` 里暴露给程序的 tools.*（Python 版 PTC）。"""

    def __init__(self, ctx: ToolContext):
        self._ctx = ctx
        self.result = None

    def read_file(self, path, offset=0, limit=0):
        return run_guarded(self._ctx, "read_file",
                           {"path": path, "offset": offset, "limit": limit},
                           self._ctx.cancel)[0]

    def write_file(self, path, content):
        return run_guarded(self._ctx, "write_file",
                           {"path": path, "content": content}, self._ctx.cancel)[0]

    def edit_file(self, path, old, new):
        return run_guarded(self._ctx, "edit_file",
                           {"path": path, "old": old, "new": new}, self._ctx.cancel)[0]

    def list_dir(self, path=".", depth=2):
        return run_guarded(self._ctx, "list_dir", {"path": path, "depth": depth},
                           self._ctx.cancel)[0]

    def search_files(self, pattern, path="."):
        return run_guarded(self._ctx, "search_files", {"pattern": pattern, "path": path},
                           self._ctx.cancel)[0]

    def search_content(self, pattern, path=".", include="", ignore_case=True):
        return run_guarded(self._ctx, "search_content",
                           {"pattern": pattern, "path": path, "include": include,
                            "ignore_case": ignore_case}, self._ctx.cancel)[0]

    def run_command(self, command, timeout=120):
        return run_guarded(self._ctx, "run_command",
                           {"command": command, "timeout": timeout}, self._ctx.cancel)[0]

    def web_fetch(self, url, max_chars=20000):
        return run_guarded(self._ctx, "web_fetch", {"url": url, "max_chars": max_chars},
                           self._ctx.cancel)[0]

    def note(self, text):
        self._ctx.note(str(text))
        return ""

    def log(self, *parts):
        self._ctx.note(" ".join(str(p) for p in parts))
        return ""


def t_run_code(ctx: ToolContext, args: dict) -> str:
    """PTC：执行一段 Python 程序，程序里用 tools.*() 组合调用其它工具。"""
    code = args.get("code")
    if not isinstance(code, str) or not code.strip():
        return "缺少 code"
    try:
        timeout = int(ctx.runtime.get("ptcTimeoutMs") or 0)
    except (TypeError, ValueError):
        timeout = 0
    if timeout <= 0:
        timeout = 120000
    seconds = max(1, min(timeout / 1000.0, 600.0))

    bridge = ToolsBridge(ctx)
    holder = {}

    def _work():
        buf = io.StringIO()
        try:
            import contextlib
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                namespace = {"tools": bridge, "result": None, "ctx": ctx.workspace}
                exec(compile(code, "<run_code>", "exec"), namespace)      # noqa: S102
                holder["result"] = namespace.get("result")
        except BaseException as exc:                            # noqa: BLE001
            holder["error"] = "%s: %s" % (type(exc).__name__, exc)
        holder["stdout"] = buf.getvalue()

    thread = threading.Thread(target=_work, name="agent-ptc", daemon=True)
    thread.start()
    thread.join(seconds)
    if thread.is_alive():
        return ("程序超过 %gs 仍未结束（已在后台继续跑；请改用更短的程序或 run_command）"
                % seconds)
    if "error" in holder:
        return "程序出错：%s\n%s" % (holder["error"], (holder.get("stdout") or "")[:4000])
    out = (holder.get("stdout") or "").strip()
    parts = []
    if bridge.result is not None:
        parts.append("result = " + json.dumps(bridge.result, ensure_ascii=False)[:8000])
    if out:
        parts.append(out)
    return ctx.cap("\n".join(parts) or "（程序没有输出；把要带出去的值赋给 result 或 print 出来）")


# ---------------------------------------------------------------- 注册表

def _schema(properties: dict, required: list) -> dict:
    return {"type": "object", "properties": properties, "required": required,
            "additionalProperties": False}


REGISTRY = [
    {
        "name": "read_file", "group": "fs",
        "description": "读取文件内容（带行号）。相对路径按工作区解析。",
        "parameters": _schema({
            "path": {"type": "string", "description": "文件路径（相对工作区）"},
            "offset": {"type": "integer", "description": "起始行号（1 起，0 = 从头）"},
            "limit": {"type": "integer", "description": "最多读多少行（0 = 全部）"},
        }, ["path"]),
        "fn": t_read_file,
    },
    {
        "name": "write_file", "group": "fs",
        "description": "整文件写入（新建或覆盖）。改小段内容优先用 edit_file。",
        "parameters": _schema({
            "path": {"type": "string", "description": "文件路径（相对工作区）"},
            "content": {"type": "string", "description": "完整文件内容"},
        }, ["path", "content"]),
        "fn": t_write_file,
    },
    {
        "name": "edit_file", "group": "fs",
        "description": "把文件里唯一的一段原文替换成新文本（old 必须在文件中唯一）。",
        "parameters": _schema({
            "path": {"type": "string", "description": "文件路径（相对工作区）"},
            "old": {"type": "string", "description": "要替换的原文（需唯一）"},
            "new": {"type": "string", "description": "替换后的文本"},
        }, ["path", "old", "new"]),
        "fn": t_edit_file,
    },
    {
        "name": "list_dir", "group": "fs",
        "description": "列出目录结构（跳过 .git / node_modules 等噪声目录）。",
        "parameters": _schema({
            "path": {"type": "string", "description": "目录路径（默认工作区根）"},
            "depth": {"type": "integer", "description": "递归层数 1–4（默认 1）"},
        }, []),
        "fn": t_list_dir,
    },
    {
        "name": "search_files", "group": "fs",
        "description": "按文件名通配符找文件（如 *.yy、*test*）。",
        "parameters": _schema({
            "pattern": {"type": "string", "description": "文件名通配符"},
            "path": {"type": "string", "description": "起始目录（默认工作区根）"},
        }, ["pattern"]),
        "fn": t_search_files,
    },
    {
        "name": "search_content", "group": "fs",
        "description": "在文件内容里正则搜索，返回 路径:行号:内容。",
        "parameters": _schema({
            "pattern": {"type": "string", "description": "正则表达式"},
            "path": {"type": "string", "description": "起始目录（默认工作区根）"},
            "include": {"type": "string", "description": "文件名通配符过滤，如 *.yy"},
            "ignore_case": {"type": "boolean", "description": "忽略大小写（默认 true）"},
        }, ["pattern"]),
        "fn": t_search_content,
    },
    {
        "name": "run_command", "group": "shell",
        "description": "在工作区里执行一条 shell 命令（Windows 用 PowerShell，其它用 bash）"
                       "，返回合并后的输出与退出码。",
        "parameters": _schema({
            "command": {"type": "string", "description": "要执行的命令"},
            "cwd": {"type": "string", "description": "工作目录（相对工作区，默认工作区根）"},
            "timeout": {"type": "integer", "description": "超时秒数（1–600，默认 120）"},
        }, ["command"]),
        "fn": t_run_command,
    },
    {
        "name": "run_code", "group": "ptc",
        "description": "PTC：执行一段 **Python** 程序批量编排工具。程序里可用 "
                       "tools.read_file(path) / tools.write_file(path, content) / "
                       "tools.edit_file(path, old, new) / tools.list_dir(path) / "
                       "tools.search_files(pattern) / tools.search_content(pattern) / "
                       "tools.run_command(cmd) / tools.note(text)；把要带出去的值赋给 "
                       "result 或 print 出来。适合一次读改多个文件、批量搜索。",
        "parameters": _schema({
            "code": {"type": "string", "description": "Python 程序源码"},
        }, ["code"]),
        "fn": t_run_code,
    },
    {
        "name": "use_skill", "group": "skill",
        "description": "加载一个技能（SKILL.md）的完整说明并按它执行；不带 name 时列出可用技能。",
        "parameters": _schema({
            "name": {"type": "string", "description": "技能名（留空＝列出全部）"},
        }, []),
        "fn": t_use_skill,
    },
    {
        "name": "todo_write", "group": "todo",
        "description": "记录/更新本任务的待办清单（覆盖式）。",
        "parameters": _schema({
            "items": {"type": "array", "items": {"type": "string"},
                      "description": "待办条目"},
        }, ["items"]),
        "fn": t_todo_write,
    },
    {
        "name": "ask_user_question", "group": "interaction",
        "description": "向用户提一个必须由人决定的问题（会弹确认卡）。",
        "parameters": _schema({
            "question": {"type": "string", "description": "问题正文"},
        }, ["question"]),
        "fn": t_ask_user,
    },
    {
        "name": "present", "group": "interaction",
        "description": "把最终成果（说明 / 报告 / 方案）提交给用户。",
        "parameters": _schema({
            "content": {"type": "string", "description": "交付内容（Markdown）"},
        }, ["content"]),
        "fn": t_present,
    },
    {
        "name": "subagent", "group": "agent",
        "description": "派生一个子智能体去做一件可独立验收的子任务（只读调研最合适），"
                       "返回它的结论。",
        "parameters": _schema({
            "task": {"type": "string", "description": "子任务描述（要写清目标与验收标准）"},
            "context_paths": {"type": "array", "items": {"type": "string"},
                              "description": "要一并带上的文件（相对工作区，最多 10 个）"},
        }, ["task"]),
        "fn": t_subagent,
    },
    {
        "name": "web_fetch", "group": "web",
        "description": "抓取一个网页/接口的内容（自动去掉 HTML 标签）。",
        "parameters": _schema({
            "url": {"type": "string", "description": "完整 URL"},
            "max_chars": {"type": "integer", "description": "最多保留多少字符（默认 20000）"},
        }, ["url"]),
        "fn": t_web_fetch,
    },
    {
        "name": "web_search", "group": "web",
        "description": "联网搜索（返回标题 / 链接 / 摘要）。",
        "parameters": _schema({
            "query": {"type": "string", "description": "搜索词"},
        }, ["query"]),
        "fn": t_web_search,
    },
]

BY_NAME = {item["name"]: item for item in REGISTRY}

# 对话模式 → 呈现给模型的工具（对应 dsh 的 tools.mode）
MODE_NATIVE = {"fs", "shell", "skill", "todo", "interaction", "agent", "web"}


def visible_names(mode: str, runtime: dict) -> list:
    """按 toolsMode 决定工具呈现：ptc = 只给 run_code；both = 全给。"""
    mode = (mode or "ptc").strip().lower()
    if mode not in ("native", "ptc", "both"):
        mode = "ptc"
    names = []
    for item in REGISTRY:
        if item["group"] == "web" and not runtime.get("allowNetwork", True):
            continue
        if item["group"] == "shell" and not runtime.get("allowExecute", True):
            continue
        if item["group"] == "agent" and not runtime.get("multiAgentEnabled", True):
            continue
        if mode == "ptc":
            if item["name"] == "run_code":
                names.append(item["name"])
            continue
        if mode == "native" and item["group"] == "ptc":
            continue
        names.append(item["name"])
    return names


def schemas(names) -> list:
    """导出 OpenAI 的 tools 数组。"""
    out = []
    for name in names:
        item = BY_NAME.get(name)
        if item is None:
            continue
        out.append({"type": "function",
                    "function": {"name": item["name"],
                                 "description": item["description"],
                                 "parameters": item["parameters"]}})
    return out


def run_guarded(ctx: ToolContext, name: str, args, cancel=None) -> tuple:
    """带审批地执行一个工具，返回 (文本结果, 是否出错)。

    正常的工具调用和 **PTC 程序里的 tools.*()** 都走这里：先问要不要确认，
    用户放行才真正越过沙箱。少了这一步，模型只要把高危命令写进 run_code
    就能绕过确认卡。
    """
    args = args if isinstance(args, dict) else {"value": args}
    if cancel is not None and cancel.is_set():
        return "回合已被用户停止", True
    granted = False
    if ctx.sandbox.needs_approval(name, args):
        if not ctx.ask(name, ctx.sandbox.reason(name, args)):
            return "用户取消了这个动作", True
        granted = True
    return run(ctx.for_call(granted), name, args)


def run(ctx: ToolContext, name: str, args) -> tuple:
    """执行一个工具，返回 (文本结果, 是否出错)。"""
    item = BY_NAME.get(name)
    if item is None:
        return "没有名为「%s」的工具。可用：%s" % (name, ", ".join(BY_NAME)), True
    if not isinstance(args, dict):
        args = {"value": args}
    try:
        return str(item["fn"](ctx, args)), False
    except SB.SandboxError as e:
        return "沙箱拒绝：%s" % e, True
    except Exception as e:                                        # noqa: BLE001
        return "%s 执行失败：%s: %s" % (name, type(e).__name__, e), True
