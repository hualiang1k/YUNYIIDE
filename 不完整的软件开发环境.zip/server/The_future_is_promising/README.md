# The_future_is_promising —— 云易IDE 的纯 Python 智能体

位置：`server\The_future_is_promising\`（IDE 根目录下执行 `python -m server.The_future_is_promising`）。

`hope` 是原 **Node + TypeScript** 的智能体（dsh / deepseek-harness）：IDE 用
`tools/node/node.exe` 拉起 `hope/apps/cli/lib/bin.js --profile acp`，再经 stdio JSON-RPC
跟它对话。本包把这套智能体**整体用 Python 重写**了：

- **只依赖标准库**，跑在 IDE 自带的 `tools/python/bin/python3.14.exe` 上；
- **不需要 Node、node_modules、构建产物**，也不需要 pnpm install；
- 智能体跑在 IDE 自己的进程里，**没有子进程、没有 stdio JSON-RPC**。

对外接口与 `hope` **逐个同名同签名**，`server/server.py` 的 `ai_backend()` 按名字取模块，
前端零改动。

## 目录

| 文件 | 职责 |
| --- | --- |
| `config.py` | 接口（config/ai_agent.json）与运行时参数（config/agent.json）——字段与 hope 完全一致 |
| `llm.py` | OpenAI 兼容流式客户端（SSE 增量、工具调用、用量、首 token 计时、取消） |
| `sandbox.py` | 沙箱边界（read-only / workspace-write / 全放行）与「要不要弹确认卡」的判定 |
| `tools.py` | 工具注册表：文件系统、shell、技能、todo、子智能体、联网、PTC |
| `session.py` | 会话持久化（JSONL）与上下文压缩 |
| `agent.py` | 系统提示 + 回合主循环 + 工具执行 + 指标 |
| `runtime.py` | 会话管理 + 智能体事件 → 前端 SSE 事件 |
| `__main__.py` | 命令行自检（`--tools` / `--test` / `--chat`） |

包内一律用**相对导入**（`from . import config`），`config.ide_root()` 从包目录向上找
「含 `config\` 的祖先」定位 IDE 根目录 —— 所以整个包挪到别处也不用改代码。

## 与 dsh 的对应关系

| dsh（hope） | 本包 |
| --- | --- |
| `apps/cli` + `packages/*`（约 5000 个 .ts 文件） | 上面这 7 个 .py 文件 |
| ACP profile（stdio JSON-RPC 子进程） | 同进程直接调用（事件形状与 ACP 的 session/update 一致） |
| `llm-pi-ai` 多 provider 路由 | `llm.LLM`（OpenAI 兼容；`--patch` 那套 Cordis 配置层不再需要） |
| `tool-bash` / `tool-pwsh`、`tool-fs`、`tool-fs-search` | `run_command`、`read_file/write_file/edit_file`、`list_dir/search_files/search_content` |
| `tool-skill` + `skill-filesystem` | `use_skill`（扫 `server/skills`、`<工作区>/.dsh/skills`、`<工作区>/.agent/skills`） |
| `tool-subagent` / `tool-workflow` | `subagent`（只读子智能体，有限步数） |
| `tool-todo`、`tool-ask-user`、`tool-present` | `todo_write`、`ask_user_question`、`present` |
| `tool-web`（fetch / search） | `web_fetch`、`web_search` |
| PTC：`run_code` 执行 **TypeScript** | PTC：`run_code` 执行 **Python**，程序里用 `tools.*()` 组合调用 |
| `compaction-basic` + `tool-result-pruner` | `session.compact()` + `ToolContext.cap()` |
| `hooks / mcp / lsp / ssh / browser-use / computer-use` | 未移植（IDE 侧用不到，见下） |

## 刻意没有移植的部分

`packages/` 里有很多东西是 **dsh 自己的产品形态**，不是「智能体能力」：

- `client`（React 界面）、`apps/desktop`（Electron）、`apps/web` —— 云易IDE 有自己的前端；
- `experimental`（1500+ 文件）、`mcp`、`lsp`、`ssh`、`browser-use`、`computer-use`、
  `webhook`、`schedule` —— IDE 的对话面板用不到这些通道；
- `packages/session/*` 的 v0→v3 迁移链、`zstd` 会话日志 —— 本包持久化就是自己的
  JSONL，不需要兼容 dsh 的历史文件。

如果以后需要其中某一项，按 `tools.py` 的注册表加一个工具即可，不用动主循环。

## 后端选择 / 切换

`server/server.py` 里的 `ai_backend()` **按逻辑名取模块**，逻辑名 → 模块名的映射在
`server/server.py` 的 `_AI_MODULES`：

```python
_AI_MODULES = {"hope2": "server.The_future_is_promising"}
```

逻辑名沿用 `hope2`（旧配置不用改），模块现在指向本目录。旧 Node 版 dsh 的
`hope\` 目录已删除：历史配置里残留的 `"aiBackend": "hope"` 认不到时会自动
回落 `hope2`，不用手工改 settings.json。
优先级：`环境变量 YUNYI_AI_BACKEND` > `config/settings.json` 的 `aiBackend` > 默认 `hope2`。

```powershell
# 1) 环境变量（临时试一下 / 打包成 exe 时锁定后端）
$env:YUNYI_AI_BACKEND = 'hope2'
.\启动云易IDE.bat

# 2) 写进设置（持久）
python -c "from yunyi import toolchain as T; T.save_settings({'aiBackend':'hope2'})"
```

浏览器 / curl：

```
GET  /api/ai/backend            -> {"backend":"hope2","available":["hope2"]}
POST /api/ai/backend  {"backend":"hope2"}
```

改完**下一次请求立即生效**，不用重启 IDE。启动日志第一行会打印 `AI 后端：xxx`。

## 自检

```powershell
.\tools\python\bin\python3.14.exe -m server.The_future_is_promising
.\tools\python\bin\python3.14.exe -m server.The_future_is_promising --test
.\tools\python\bin\python3.14.exe -m server.The_future_is_promising --tools
```

要求：IDE 根目录在 `sys.path` 上（在根目录里执行即可）。

## 运行期数据

目录名跟着包名走（`config.temp_name()`）：

- 会话持久化：`.temp\The_future_is_promising\sessions\<会话id>.jsonl`
- 显示层转录：`.temp\The_future_is_promising\session.json`（刷新页面后恢复聊天记录用）
