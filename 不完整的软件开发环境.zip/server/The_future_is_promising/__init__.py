# -*- coding: utf-8 -*-
"""云易IDE 的 AI 后端（server\\The_future_is_promising\\）：**纯 Python 智能体**。

与已弃用的 `hope`（dsh，Node/TypeScript + stdio JSON-RPC 子进程）对外**接口完全一致**，
所以 server/server.py 的 `ai_backend()` 按名字取模块即可，两套后端可以互换：

    server/The_future_is_promising/config.py    接口（config/ai_agent.json）与运行时参数（config/agent.json）
    server/The_future_is_promising/llm.py       OpenAI 兼容流式客户端（纯标准库）
    server/The_future_is_promising/sandbox.py   沙箱边界（read-only / workspace-write / 全放行）与审批判定
    server/The_future_is_promising/tools.py     工具注册表：文件系统 / shell / 技能 / todo / 子智能体 / 联网 / PTC
    server/The_future_is_promising/session.py   会话持久化（JSONL）与上下文压缩
    server/The_future_is_promising/agent.py     智能体主循环（系统提示 + 多步工具调用 + 指标）
    server/The_future_is_promising/runtime.py   会话管理 + 智能体事件 → 前端 SSE 事件

运行环境：只用到 Python 标准库，跑在 IDE 自带的 tools/python 上。
**不再需要 Node、node_modules 与任何构建产物。**

对话模式（toolsMode）：
  native = 逐个原生工具调用；ptc = 只给 run_code（这里执行 **Python**，dsh 那边是
  TypeScript）；both = 两者都给。

导入方式：`from server import The_future_is_promising`（包内一律用相对导入，
所以整体挪到别处也不用改代码；`ide_root()` 会自动向上定位 IDE 根目录）。
"""
from __future__ import annotations

from .config import (                    # noqa: F401
    AI_MODES, AI_MODE_LABEL, DEFAULT_CFG, DEFAULT_RUNTIME,
    active_api, ensure_layout, load_cfg, load_runtime, save_cfg, save_runtime,
    stored_cfg, workspace_dir, context_window,
)
from .runtime import (                   # noqa: F401
    answer_confirm, clear_session, context_usage, history, session_info, status,
    stop_turn, stream_chat, sync_allow_all, test_connect_with,
)
from .llm import LLMError

DshError = LLMError                           # 与 hope 的同名异常保持兼容

__all__ = [
    "AI_MODES", "AI_MODE_LABEL", "DEFAULT_CFG", "DEFAULT_RUNTIME",
    "active_api", "ensure_layout", "load_cfg", "load_runtime", "save_cfg",
    "save_runtime", "stored_cfg",
    "workspace_dir", "context_window",
    "answer_confirm", "clear_session", "context_usage", "history", "session_info", "status",
    "stop_turn", "stream_chat", "sync_allow_all", "test_connect_with",
    "DshError", "LLMError",
]
