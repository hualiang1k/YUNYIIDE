# -*- coding: utf-8 -*-
"""会话持久化与上下文压缩。

持久化格式：每个会话一个 JSONL 文件（.temp/server/The_future_is_promising/sessions/<id>.jsonl），
第一行是元信息，之后每行一条 OpenAI 风格消息 —— 纯文本、可增量追加、坏了也不
会连累别的会话（dsh 那边是 zstd 的 session.vN.jsonl，The_future_is_promising 不需要压缩：量小，
且省掉一个 zstd 解码依赖）。

压缩：模型每次都会回报真实用量，所以以「最近一次 prompt 占用 / 上下文窗口」为准；
超阈值就把较老的历史交给模型压成一段摘要，只保留近期的若干条原文。
"""
from __future__ import annotations
import json
import os
import time
import uuid

from . import config as CFG

_SUMMARY_PROMPT = (
    "请把下面这段「智能体与用户的对话历史」压缩成一份紧凑的上下文摘要，供后续接续工作使用。\n"
    "要求：\n"
    "1. 保留：用户的核心目标与约束、已经确认的事实、已做出的决定；\n"
    "2. 保留：已经改动过的文件（路径 + 改了什么）、正在进行的步骤、还没做的事；\n"
    "3. 保留：出现过的报错与其结论；\n"
    "4. 丢弃：寒暄、重复内容、已被覆盖的中间结论、工具调用的大段输出；\n"
    "5. 用中文，纯文本，不超过 2000 字，不要加标题以外的 Markdown 装饰。\n\n"
    "----- 历史开始 -----\n%s\n----- 历史结束 -----")


def _chars(messages) -> int:
    """粗估提示词体积（没有真实用量时的兜底：中文按 1 字 ≈ 1.2 token 折算）。"""
    total = 0
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, str):
            total += len(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    total += len(str(part.get("text") or ""))
        for call in (msg.get("tool_calls") or []):
            fn = call.get("function") if isinstance(call, dict) else {}
            total += len(str(fn.get("arguments") or ""))
    return int(total * 1.2)


class Session:
    """一个可恢复的会话。"""

    def __init__(self, session_id: str = "", cwd: str = ""):
        self.id = session_id or ("s-" + uuid.uuid4().hex[:16])
        self.cwd = cwd or CFG.workspace_dir()
        self.messages: list = []
        self.turn = 0
        self.compactions = 0
        self.created = int(time.time())
        self.dir = os.path.join(CFG.temp_dir(), "sessions")
        os.makedirs(self.dir, exist_ok=True)
        self.path = os.path.join(self.dir, self.id + ".jsonl")

    # ---------- 持久化 ----------

    @classmethod
    def storage_dir(cls) -> str:
        d = os.path.join(CFG.temp_dir(), "sessions")
        os.makedirs(d, exist_ok=True)
        return d

    @classmethod
    def load(cls, session_id: str, cwd: str = "") -> "Session | None":
        if not session_id:
            return None
        self = cls(session_id, cwd)
        if not os.path.isfile(self.path):
            return None
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
        except OSError:
            return None
        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if i == 0 and isinstance(obj, dict) and "meta" in obj:
                meta = obj["meta"] if isinstance(obj["meta"], dict) else {}
                self.cwd = meta.get("cwd") or self.cwd
                self.turn = int(meta.get("turn") or 0)
                self.compactions = int(meta.get("compactions") or 0)
                self.created = int(meta.get("created") or self.created)
                continue
            if isinstance(obj, dict):
                self.messages.append(obj)
        return self

    @classmethod
    def latest(cls) -> str:
        """最近改过的会话 id（IDE 启动时自动续上）。"""
        d = cls.storage_dir()
        best, best_mtime = "", 0.0
        try:
            for name in os.listdir(d):
                if not name.endswith(".jsonl"):
                    continue
                full = os.path.join(d, name)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if mtime > best_mtime:
                    best, best_mtime = name[:-6], mtime
        except OSError:
            pass
        return best

    def save(self) -> None:
        try:
            with open(self.path, "w", encoding="utf-8", newline="\n") as f:
                f.write(json.dumps({"meta": {"cwd": self.cwd, "turn": self.turn,
                                             "compactions": self.compactions,
                                             "created": self.created}},
                                   ensure_ascii=False) + "\n")
                for msg in self.messages:
                    f.write(json.dumps(msg, ensure_ascii=False) + "\n")
        except OSError:
            pass

    def delete(self) -> None:
        try:
            os.remove(self.path)
        except OSError:
            pass

    # ---------- 消息 ----------

    def add(self, message: dict) -> None:
        self.messages.append(message)
        self.save()

    def add_user(self, content) -> None:
        self.add({"role": "user", "content": content})

    def add_assistant(self, text: str, calls=None) -> None:
        msg = {"role": "assistant", "content": text or ""}
        if calls:
            msg["tool_calls"] = [{
                "id": c["id"], "type": "function",
                "function": {"name": c["name"], "arguments": c["arguments"]},
            } for c in calls]
        self.add(msg)

    def add_tool_result(self, call_id: str, name: str, text: str, ok: bool = True) -> None:
        if not ok:
            text = "（工具执行失败）" + text
        self.add({"role": "tool", "tool_call_id": call_id, "name": name, "content": text})

    def estimate(self) -> int:
        return _chars(self.messages)

    # ---------- 压缩 ----------

    def compaction_ratios(self, runtime: dict) -> tuple:
        try:
            th = int(runtime.get("ctxCompactThreshold") or 0)
        except (TypeError, ValueError):
            th = 0
        try:
            ret = int(runtime.get("ctxCompactRetain") or 0)
        except (TypeError, ValueError):
            ret = 0
        threshold = th if 0 < th <= 100 else 80
        retain = ret if 0 < ret <= 100 else 16
        if retain >= threshold:
            retain = threshold - 5 if threshold > 5 else threshold // 2
        return bool(runtime.get("ctxCompaction", True)), threshold, retain

    def should_compact(self, used: int, ctx_window: int, runtime: dict) -> bool:
        auto, threshold, _retain = self.compaction_ratios(runtime)
        if not auto or ctx_window <= 0:
            return False
        if used <= 0:
            used = self.estimate()
        return used >= int(ctx_window * threshold / 100.0)

    def compact(self, llm, ctx_window: int, runtime: dict, cancel=None) -> int:
        """把较老的历史压成摘要；返回被并入摘要的消息条数（0 = 没压）。"""
        _auto, _threshold, retain = self.compaction_ratios(runtime)
        # 保留近期原文：按条数近似 retain% 的窗口占比，至少留 4 条、至多留 20 条
        keep = max(4, min(20, max(2, len(self.messages) * retain // 100)))
        if len(self.messages) <= keep + 2:
            return 0
        older = self.messages[:-keep]
        if not older:
            return 0
        chunks = []
        for msg in older:
            role = msg.get("role")
            content = msg.get("content")
            if isinstance(content, list):
                content = "\n".join(str(p.get("text") or "")
                                    for p in content if isinstance(p, dict))
            if not isinstance(content, str):
                content = ""
            if role == "tool":
                chunks.append("[工具结果 %s]\n%s" % (msg.get("name") or "", content[:1500]))
            elif role == "assistant":
                calls = msg.get("tool_calls") or []
                if calls:
                    names = ", ".join(str((c.get("function") or {}).get("name") or "")
                                      for c in calls)
                    chunks.append("[助手] 调用了 %s\n%s" % (names, content[:1500]))
                elif content.strip():
                    chunks.append("[助手]\n%s" % content[:1500])
            elif role == "user" and content.strip():
                chunks.append("[用户]\n%s" % content[:3000])
            elif role == "system" and content.strip():
                chunks.append("[系统]\n%s" % content[:1500])
        if not chunks:
            return 0
        try:
            reply = llm.chat(
                [{"role": "user", "content": _SUMMARY_PROMPT % "\n\n".join(chunks)[:60000]}],
                tools=None, cancel=cancel)
            summary = (reply.text or "").strip()
        except Exception:                                         # noqa: BLE001
            return 0                                              # 压缩失败不该影响对话
        if not summary:
            return 0
        shadowed = len(older)
        self.messages = [{"role": "user",
                          "content": "【此前对话的压缩摘要】\n" + summary}] + self.messages[-keep:]
        self.compactions += 1
        self.save()
        return shadowed
