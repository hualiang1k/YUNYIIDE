# -*- coding: utf-8 -*-
"""沙箱（文件效果边界）与审批判定。

对应 dsh 里的 sandbox-policy + approval 两行：
  · 边界：read-only / workspace-write / danger-full-access（IDE 设置里的
    「启用沙箱」+「只在工程内写入」+「PTC 沙箱」共同决定，换算与 hope/patch.py
    的 sandbox_mode() 完全一致）
  · 审批：ask = 越界或高危动作弹确认卡（前端「确认执行 / 取消」）；never = 放行
"""
from __future__ import annotations
import os
import re

READ_ONLY = "read-only"
WORKSPACE_WRITE = "workspace-write"
FULL_ACCESS = "danger-full-access"


class SandboxError(RuntimeError):
    """动作越过了当前沙箱边界。"""


def sandbox_mode(runtime: dict) -> str:
    """与 hope/patch.py 的 sandbox_mode() 同一套换算，保证切换后端行为不变。"""
    if not runtime.get("sandboxEnabled", True):
        return FULL_ACCESS
    if not runtime.get("writeInsideProjectOnly", True):
        return FULL_ACCESS
    mode = str(runtime.get("ptcSandboxMode") or "").strip().lower()
    return mode if mode in (READ_ONLY, WORKSPACE_WRITE) else WORKSPACE_WRITE


def approval_policy(runtime: dict) -> str:
    """ask = 越界/高危动作先问；never = 一路放行。"""
    if not runtime.get("sandboxEnabled", True):
        return "never"
    return "ask" if runtime.get("approveDestructive", True) else "never"


# 高危命令片段：命中就要么被拦（不允许执行时）要么弹确认卡。
# 只做「明显危险」的粗筛 —— 精细判定永远做不完，宁可多问一次。
_DANGER = (
    r"\brm\s+(-[frR]+\s+)*(/|[A-Za-z]:\\|\*)",     # rm -rf / 之类
    r"\brm\s+-[frR]",
    r"\bdel\s+/[fqs]",
    r"\brmdir\s+/s",
    r"\bRemove-Item\b.*-(Recurse|Force)",
    r"\bformat\b", r"\bmkfs\b", r"\bdd\s+if=",
    r"\bshutdown\b", r"\breboot\b", r"\bStop-Computer\b", r"\bRestart-Computer\b",
    r"\bgit\s+push\b.*(--force|-f\b)",
    r"\bgit\s+reset\s+--hard\b", r"\bgit\s+clean\s+-[fd]",
    r"\bchmod\s+(-R\s+)?777\b", r"\bchown\s+-R\b",
    r"\btaskkill\b", r"\bStop-Process\b", r"\bkill\s+-9\b",
    r"\breg\s+(delete|add)\b", r"\bnet\s+user\b", r"\bSet-ExecutionPolicy\b",
    r"\bcertutil\b", r"\bpowershell\b.*-(Enc|EncodedCommand)",
)
_DANGER_RE = [re.compile(p, re.IGNORECASE) for p in _DANGER]

# 联网命令：allowNetwork 关闭时直接拦；开着时按 approveNetwork 决定问不问。
_NETWORK = (
    r"\bcurl\b", r"\bwget\b", r"\bInvoke-WebRequest\b", r"\bInvoke-RestMethod\b",
    r"\bssh\b", r"\bscp\b", r"\brsync\b", r"\bftp\b",
    r"\bpip\s+install\b", r"\bnpm\s+(install|i)\b", r"\bpnpm\s+(install|add)\b",
    r"\bgit\s+clone\b", r"\bgit\s+push\b", r"\bgit\s+pull\b", r"\bgit\s+fetch\b",
    r"\bapt(-get)?\s+install\b", r"\bwinget\b", r"\bchoco\b",
)
_NETWORK_RE = [re.compile(p, re.IGNORECASE) for p in _NETWORK]


class Sandbox:
    """一次会话的文件边界与审批判定。"""

    def __init__(self, runtime: dict, workspace: str, granted: bool = False):
        self.mode = sandbox_mode(runtime)
        self.policy = approval_policy(runtime)
        self.workspace = os.path.abspath(workspace or os.getcwd())
        self.allow_execute = bool(runtime.get("allowExecute", True))
        self.allow_network = bool(runtime.get("allowNetwork", True))
        self.approve_network = bool(runtime.get("approveNetwork", True))
        # 本次调用已被用户放行：越过边界检查（见 escalated()）
        self.granted = bool(granted)

    def escalated(self, granted: bool = True) -> "Sandbox":
        """返回一份「已放行」的副本（不改原对象，避免并发调用互相影响）。

        用户在确认卡上点了「确认执行」后，这一次调用必须真的能越界执行 ——
        否则批准只是走个形式：工具里 resolve() 会二次拦截，模型照样拿不到结果。
        """
        if not granted:
            return self
        import copy
        clone = copy.copy(self)
        clone.granted = True
        return clone

    # ---------- 路径 ----------

    def violation(self, path: str, writing: bool = False) -> str:
        """这个路径越了哪条界（不越界返回空串）。只判断，不抛错。"""
        text = (path or "").strip()
        if not text:
            return "路径为空"
        if not os.path.isabs(text):
            text = os.path.join(self.workspace, text)
        abs_path = os.path.normpath(os.path.abspath(text))
        if self.mode == FULL_ACCESS:
            return ""
        if not self._inside(abs_path):
            return "路径越出工作区（沙箱 %s）：%s" % (self.mode, abs_path)
        if self.mode == READ_ONLY and writing:
            return "沙箱为只读，不允许写入：%s" % abs_path
        return ""

    def resolve(self, path: str, writing: bool = False) -> str:
        """把模型给的路径解析成绝对路径，越界直接抛错。

        相对路径按工作区解析（与 dsh 一致：模型一律用相对路径）。
        用户已放行（granted）时不再拦——批准必须真的生效。
        """
        text = (path or "").strip()
        if not text:
            raise SandboxError("路径为空")
        if not os.path.isabs(text):
            text = os.path.join(self.workspace, text)
        abs_path = os.path.normpath(os.path.abspath(text))
        if self.granted or self.mode == FULL_ACCESS:
            return abs_path
        if not self._inside(abs_path):
            raise SandboxError(
                "路径越出工作区（沙箱模式 %s）：%s\n工作区：%s"
                % (self.mode, abs_path, self.workspace))
        if self.mode == READ_ONLY and writing:
            raise SandboxError("沙箱为只读，不允许写入：%s" % abs_path)
        return abs_path

    def _inside(self, abs_path: str) -> bool:
        try:
            common = os.path.commonpath([self.workspace, abs_path])
        except ValueError:                       # 不同盘符
            return False
        return common == self.workspace

    def display(self, abs_path: str) -> str:
        """给模型看的路径：工作区内的一律回成相对路径。"""
        try:
            rel = os.path.relpath(abs_path, self.workspace)
        except ValueError:
            return abs_path
        if rel.startswith(".."):
            return abs_path
        return rel.replace("\\", "/")

    # ---------- 命令 ----------

    def check_command(self, command: str) -> None:
        """不允许执行的命令直接抛错（不弹卡，因为开关是用户显式关的）。

        已被用户放行时不拦——批准必须真的生效。
        """
        if self.granted:
            return
        if not self.allow_execute:
            raise SandboxError("运行时参数已关闭命令执行（allowExecute=false）")
        if not self.allow_network:
            hit = _match(_NETWORK_RE, command)
            if hit:
                raise SandboxError("运行时参数已关闭网络访问（allowNetwork=false）：命中 %s" % hit)

    # ---------- 审批 ----------

    # 需要按 path 参数判越界的工具（读也要问：越界读取同样该由用户定夺）
    _PATH_TOOLS = {
        "read_file": False, "list_dir": False, "search_files": False,
        "search_content": False, "write_file": True, "edit_file": True,
    }

    def needs_approval(self, tool: str, args: dict) -> bool:
        """这个动作要不要弹确认卡。policy=never 时一律不问。"""
        if self.policy != "ask":
            return False
        args = args if isinstance(args, dict) else {}
        if tool == "run_command":
            command = str(args.get("command") or "")
            if _match(_DANGER_RE, command):
                return True
            if self.approve_network and _match(_NETWORK_RE, command):
                return True
            return False
        if tool in self._PATH_TOOLS:
            # 越界（含只读模式下的越界写入）→ 弹卡交给用户定夺
            return bool(self.violation(str(args.get("path") or "."),
                                       writing=self._PATH_TOOLS[tool]))
        if tool == "run_code":
            # PTC 程序内部的每一次写入都会各自过一遍 resolve()，这里不再逐程序弹卡
            return False
        if tool in ("web_fetch", "web_search"):
            return self.approve_network
        return False

    def reason(self, tool: str, args: dict) -> str:
        """确认卡上「为什么要问」的一句话（要点名具体越了什么界）。"""
        args = args if isinstance(args, dict) else {}
        if tool == "run_command":
            command = str(args.get("command") or "")
            hit = _match(_DANGER_RE, command)
            if hit:
                return "命令命中高危模式（%s）：%s" % (hit, _short(command, 120))
            return "命令会访问网络：%s" % _short(command, 120)
        if tool in self._PATH_TOOLS:
            why = self.violation(str(args.get("path") or "."),
                                 writing=self._PATH_TOOLS[tool])
            if why:
                return why + "；工作区：" + self.workspace
            return "该动作超出沙箱自动放行范围"
        if tool in ("web_fetch", "web_search"):
            return "该动作会访问网络（%s）" % _short(
                str(args.get("url") or args.get("query") or ""), 120)
        return "该动作超出了沙箱「自动放行」的范围（写工作区之外或执行程序）"


def _short(text: str, limit: int = 120) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[:limit] + "…"


def _match(patterns, text: str) -> str:
    for pattern in patterns:
        found = pattern.search(text or "")
        if found:
            return found.group(0).strip()
    return ""
