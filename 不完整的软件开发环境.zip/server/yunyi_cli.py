# -*- coding: utf-8 -*-
"""云易命令行工具 —— 构建系统（Makefile / CMake）与 CI/CD 流水线的统一入口。

用法（在 IDE 根目录下执行）：
  python server/yunyi_cli.py env
  python server/yunyi_cli.py translate <工程目录> [--mode debug|release] [--arch x64|x86] [--target run|test]
  python server/yunyi_cli.py build     <工程目录> [--mode ...] [--arch ...] [--target ...] [--gxx 路径] [--run]
  python server/yunyi_cli.py test      <工程目录> [--mode ...] [--arch ...] [--gxx 路径]
  python server/yunyi_cli.py run       <工程目录> [--mode ...] [--arch ...] [--gxx 路径]
  python server/yunyi_cli.py make      <工程目录> [--mode ...] [--arch ...] [--target all|clean]
  python server/yunyi_cli.py script    <工程目录> [--mode ...]     生成 Makefile / CMakeLists.txt
（--mode / --arch 留空时使用工程 .yyproj 里保存的配置 —— 与 IDE 工具栏选的一致）
  python server/yunyi_cli.py export    <工程目录>
  python server/yunyi_cli.py release   <工程目录>
  python server/yunyi_cli.py ci        <工程目录> [--github] [--gitlab] [--gitea]
  python server/yunyi_cli.py clean     <工程目录> [--dry-run]
所有命令均可加 --json 输出结构化结果（供其他工具解析）。
"""
from __future__ import annotations
import argparse
import json
import os
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 本脚本位于 server/ 下；IDE 根目录（yunyi 包所在处）是它的上一级，加进 sys.path
IDE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    IDE_ROOT = os.path.dirname(os.path.abspath(sys.executable))
sys.path.insert(0, IDE_ROOT)

from yunyi import builder as B              # noqa: E402
from yunyi import buildsys as BS            # noqa: E402
from yunyi import ci as CI                  # noqa: E402
from yunyi import project as P              # noqa: E402
from yunyi import toolchain as T            # noqa: E402


def _print_messages(msgs, log=""):
    for m in msgs or []:
        tag = {"error": "错误", "warning": "警告", "ok": "完成"}.get(m["kind"], m["kind"])
        where = f'（{os.path.basename(m["file"])}:{m["line"]}）' if m.get("file") else ""
        print(f'[{tag}] {m["text"]}{where}')
    if log.strip():
        print(log.strip())


def cmd_env(a):
    rep = T.env_report()
    if a.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0
    for k in ("gxx", "gxxVer", "make", "git", "python", "workspace"):
        print(f"{k:9s}: {rep.get(k, '')}")
    return 0 if rep.get("gxx") else 1


def _load(a):
    proj = os.path.abspath(a.project)
    if not os.path.isdir(proj):
        raise SystemExit("工程目录不存在：" + proj)
    cfg = P.load_project(proj)
    # --arch / --mode 覆盖「本次构建」的架构与模式（只作用于内存中的配置，不写回工程文件）；
    # 不传则用工程自己的标记（.yyproj 里保存的架构 / 模式，二者就是 IDE 工具栏选的那两个）
    arch = (getattr(a, "arch", "") or "").strip().lower()
    if arch in P.ARCH_LABEL:
        cfg["arch"] = arch
    mode = (getattr(a, "mode", "") or "").strip().lower()
    if mode in P.MODE_LABEL:
        cfg["mode"] = mode
    return proj, cfg


def cmd_translate(a):
    proj, cfg = _load(a)
    r = B.translate(proj, cfg, a.target, a.mode)
    if a.json:
        print(json.dumps({"ok": r["ok"], "cpp": r.get("genPath", ""),
                          "messages": r["messages"]}, ensure_ascii=False, indent=2))
    else:
        _print_messages(r["messages"])
    return 0 if r["ok"] else 1


def cmd_build(a):
    proj, cfg = _load(a)
    r = B.compile_yunyi(proj, cfg, a.mode, a.target)
    if a.json:
        print(json.dumps({"ok": r["ok"], "exe": r["artifacts"].get("exe", ""),
                          "log": r.get("log", ""), "messages": r["messages"]},
                         ensure_ascii=False, indent=2))
    else:
        _print_messages(r["messages"], r.get("log", ""))
    if not r["ok"]:
        return 1
    if a.run:
        return subprocess.run([r["artifacts"]["exe"]], cwd=proj).returncode
    return 0


def _build_then_run(proj, cfg, mode, target):
    r = B.compile_yunyi(proj, cfg, mode, target)
    if not r["ok"]:
        _print_messages(r["messages"], r.get("log", ""))
        return r, None
    exe = r["artifacts"]["exe"]
    p = subprocess.run([exe], cwd=os.path.dirname(exe))
    return r, p.returncode


def cmd_run(a):
    proj, cfg = _load(a)
    r, code = _build_then_run(proj, cfg, a.mode, "run")
    if a.json:
        print(json.dumps({"ok": r["ok"], "exitCode": code}, ensure_ascii=False))
    return 0 if r["ok"] and code == 0 else 1


def cmd_test(a):
    proj, cfg = _load(a)
    r, code = _build_then_run(proj, cfg, a.mode, "test")
    if a.json:
        print(json.dumps({"ok": r["ok"], "exitCode": code,
                          "messages": r["messages"]}, ensure_ascii=False, indent=2))
    else:
        _print_messages(r["messages"], r.get("log", ""))
    return 0 if r["ok"] and code == 0 else 1


def cmd_make(a):
    proj, cfg = _load(a)
    r = BS.run_make(proj, cfg, a.mode, a.target)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        _print_messages(r["messages"], r.get("log", ""))
        if r["ok"]:
            print("[完成] " + r["exe"])
    return 0 if r["ok"] or a.target == "clean" else 1


def cmd_script(a):
    proj, cfg = _load(a)
    r = BS.generate_build_scripts(proj, cfg, a.mode)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        for f in r["files"]:
            print("[生成] " + f)
    return 0


def cmd_ci(a):
    proj, cfg = _load(a)
    providers = [p for p in ("github", "gitlab", "gitea") if getattr(a, p)]
    if not providers:
        providers = ["github", "gitlab", "gitea"]
    r = CI.generate_ci(proj, cfg, providers, repo_root=a.repo_root)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        for f in r["files"]:
            print("[生成] " + f)
    return 0


def cmd_export(a):
    """导出 C++ 工程：默认导出「纯正 C++」（main.cpp，无中文运行库）；
    --compat 走旧式导出（main_gen.cpp + yunyi_rt.hpp）。与菜单「导出C++」同一条线路。"""
    proj, cfg = _load(a)
    r = B.export_cpp(proj, cfg, a.mode, "run",
                     native=not getattr(a, "compat", False))
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("[导出] " + (r.get("dir") or "失败"))
        _print_messages(r.get("messages", []))
    return 0 if r["ok"] else 1


def cmd_clean(a):
    """清理可重构的构建产物（build / 发布 / 导出C++）。"""
    proj, cfg = _load(a)
    r = B.clean_build(proj, cfg, dry_run=bool(a.dry_run))
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        _print_messages(r["messages"])
    return 0 if r["ok"] else 1


def cmd_release(a):
    proj, cfg = _load(a)
    r = B.release_project(proj, cfg)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("[程序] " + (r.get("exe") or ""))
        print("[压缩包] " + (r.get("zip") or ""))
    return 0 if r["ok"] else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description="云易中文编程语言 命令行工具")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_text):
        s = sub.add_parser(name, help=help_text)
        s.add_argument("project", nargs="?")
        # 留空 = 用工程自己保存的标记（.yyproj 里的 mode / arch，即 IDE 工具栏选的那两个）
        s.add_argument("--mode", default="", choices=["", "debug", "release"],
                       help="编译模式：debug 调试版 / release 发布版（留空取工程配置）")
        s.add_argument("--arch", default="", choices=["", "x64", "x86"],
                       help="目标架构：x64 / x86（留空取工程配置）")
        s.add_argument("--target", default="run")
        s.add_argument("--gxx", default="")
        s.add_argument("--run", action="store_true")
        s.add_argument("--json", action="store_true")
        s.add_argument("--repo-root", dest="repo_root", default="")
        for f in ("github", "gitlab", "gitea"):
            s.add_argument("--" + f, action="store_true")
        s.set_defaults(fn=fn)
        return s

    sub.add_parser("env", help="显示工具链环境").set_defaults(fn=cmd_env, json=False)
    add("translate", cmd_translate, "把 .yy 源码翻译为 C++")
    add("build", cmd_build, "翻译并编译为可执行文件")
    add("run", cmd_run, "编译并运行")
    add("test", cmd_test, "编译并执行测试函数")
    pm = add("make", cmd_make, "用 Makefile 构建（内置 make）")
    pm.set_defaults(target="all")
    add("script", cmd_script, "生成 Makefile / CMakeLists.txt / 构建.bat")
    add("ci", cmd_ci, "生成 CI/CD 流水线配置")
    pe = add("export", cmd_export, "导出纯 C++ 工程")
    pe.add_argument("--compat", action="store_true",
                    help="旧式导出（main_gen.cpp + 中文运行库 yunyi_rt.hpp）")
    add("release", cmd_release, "发布打包")
    cl = add("clean", cmd_clean, "清理可重构的构建产物（build / 发布 / 导出C++）")
    cl.add_argument("--dry-run", dest="dry_run", action="store_true", help="只统计，不删除")

    a = ap.parse_args(argv)
    if getattr(a, "gxx", ""):
        os.environ["YUNYI_GXX"] = a.gxx
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
