﻿# Clean caches / rebuildable artifacts in the YunyiIDE project
# ------------------------------------------------------------
# Usage (run from the repo root):
#   powershell -ExecutionPolicy Bypass -File 清理缓存.ps1          # preview only, no deletion
#   powershell -ExecutionPolicy Bypass -File 清理缓存.ps1 -Force   # actually delete
#
# 路径约定：仓库根目录取“脚本自身所在目录”（$PSScriptRoot），不写死任何绝对盘符路径；
# 输出时再把绝对路径转成相对仓库根的路径显示，便于移植与阅读。
#
# By default it only PREVIEWS what would be cleaned and prints sizes;
# add -Force to really delete. Items are handled INLINE as they are found
# during scanning (no collect-then-delete list).
#
# Protected (never deleted):
#   .codebuddy            project data folder
#   tools                 MinGW / Qt / Node / Git toolchain
#                         (tools\node 是自带 Node 解释器；The future is promising. 的依赖树
#                          已改为根目录 hope\node_modules 真实目录，不再托管在 tools\node)
#   debug                 kept safe (purpose unclear)
#   any subpath of the above (incl. the tools\mingw64\opt junction -> server\python)
#
# Cleaned:
#   1) all __pycache__ dirs, *.pyc / *.pyo files (Python bytecode, regenerable)
#   2) root-level pyinstaller temp: build / dist / __pyinstaller__*
#   3) per-project build outputs under the workspace folder: build / (release) / (export C++) / (generated C++ code)
#      (source files .yy / .yyproj / .yydesign are NOT touched)
# ------------------------------------------------------------
[CmdletBinding()]
param(
    [switch]$Force
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Repo = $PSScriptRoot
if (-not $Repo) { $Repo = $PWD.Path }

# 把绝对路径转成“相对仓库根”的显示路径（避免打印一长串绝对盘符路径）
function RelToRepo($p) {
    Push-Location $Repo
    try { return (Resolve-Path -LiteralPath $p -Relative -ErrorAction Stop).Replace('\', '/') }
    finally { Pop-Location }
}

# Chinese folder names used by the IDE, built from code points so this script stays ASCII-safe
$WSL = [char]0x5DE5 + [char]0x4F5C + [char]0x533A                                   # workspace folder (工作区)
$ArtBuild   = 'build'
$ArtRelease = [char]0x53D1 + [char]0x5E03                                           # 发布
$ArtExport  = [char]0x5BFC + [char]0x51FA + 'C++'                                   # 导出C++
$ArtExportPy = [char]0x5BFC + [char]0x51FA + 'Python'                               # 导出Python
$ArtGenCpp  = '__' + [char]0x751F + [char]0x6210 + [char]0x7684 + 'C++' + [char]0x4EE3 + [char]0x7801 + '__'   # __生成的C++代码__

$Protect = @(
    (Join-Path $Repo '.codebuddy'),
    (Join-Path $Repo 'tools'),
    (Join-Path $Repo 'debug')
)

function IsProtected($path) {
    foreach ($p in $Protect) {
        if (($path -eq $p) -or $path.StartsWith($p + '\') -or $path.StartsWith($p + '/')) {
            return $true
        }
    }
    return $false
}

$total = 0
$count = 0

# 边扫边处理：发现一项就统计大小并删除（-Force）或预览输出，不先攒列表
function HandleItem($path, $kind) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $sz = (Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue |
           Measure-Object -Property Length -Sum).Sum
    if ($null -eq $sz) { $sz = 0 }
    $script:total += $sz
    $script:count++
    # 相对路径要在删除前算好，删完 Resolve-Path 就找不到了
    $rel = RelToRepo $path
    if ($Force) {
        # junction / symlink dir: remove only the link itself, do not recurse into target
        $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        if ($item -and ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        } else {
            Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue
        }
        Write-Host ('  deleted [{0}] {1}  ({2:N0} bytes)' -f $kind, $rel, $sz)
    } else {
        Write-Host ('  [preview] [{0}] {1}  ({2:N0} bytes)' -f $kind, $rel, $sz)
    }
}

$mode = if ($Force) { 'DELETE' } else { 'PREVIEW' }
Write-Host ('=== 清理缓存 [{0}] 仓库根: {1}' -f $mode, $Repo)
Write-Host ''

# 1) top-level dirs (except protected) -> recurse for __pycache__ dirs and *.pyc / *.pyo files
Write-Host '[1/3] 扫描 __pycache__ 目录与 *.pyc / *.pyo 文件 ...'
Get-ChildItem -Path $Repo -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { -not (IsProtected $_.FullName) } |
    ForEach-Object {
        $base = $_.FullName
        Get-ChildItem -Path $base -Recurse -Directory -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq '__pycache__' } |
            ForEach-Object { HandleItem $_.FullName 'dir' }
        Get-ChildItem -Path $base -Recurse -Force -File -ErrorAction SilentlyContinue -Include *.pyc, *.pyo |
            ForEach-Object { HandleItem $_.FullName 'file' }
    }

# 2) root-level pyinstaller temp dirs
Write-Host '[2/3] 扫描根目录 pyinstaller 临时目录 (build / dist / __pyinstaller__*) ...'
Get-ChildItem -Path $Repo -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { ($_.Name -eq 'build') -or ($_.Name -eq 'dist') -or ($_.Name -like '__pyinstaller__*') } |
    ForEach-Object { HandleItem $_.FullName 'dir' }

# 3) per-project build outputs under the workspace folder (source not touched)
Write-Host ('[3/3] 扫描 {0} 下各项目的构建产物 (build / 发布 / 导出C++ / 导出Python / __生成的C++代码__) ...' -f $WSL)
$ws = Join-Path $Repo $WSL
if (Test-Path $ws) {
    $arts = @($ArtBuild, $ArtRelease, $ArtExport, $ArtExportPy, $ArtGenCpp)
    Get-ChildItem -Path $ws -Directory -Force -ErrorAction SilentlyContinue |
        ForEach-Object {
            $proj = $_.FullName
            foreach ($a in $arts) {
                $ap = Join-Path $proj $a
                HandleItem $ap 'dir'
            }
        }
}

Write-Host ''
if ($count -eq 0) {
    Write-Host 'No cache found to clean.'
} elseif ($Force) {
    Write-Host ('Done: removed {0} items, freed about {1:N0} bytes ({2:N2} MB).' -f $count, $total, ($total / 1MB))
} else {
    Write-Host ('Preview: will clean {0} items, about {1:N0} bytes ({2:N2} MB).' -f $count, $total, ($total / 1MB))
    Write-Host 'This was a preview; nothing was deleted. Add -Force to actually delete.'
}
