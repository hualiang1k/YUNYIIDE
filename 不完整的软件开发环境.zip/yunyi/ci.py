# -*- coding: utf-8 -*-
"""第 10 项：发布 / 部署 / CI-CD —— 生成 GitHub Actions、GitLab CI 等流水线配置。"""
from __future__ import annotations
import os

from . import codec
from . import project as project_mod


def rel_in_repo(proj_dir: str, repo_root: str = None) -> str:
    """工程目录相对仓库根（默认仓库根为工程目录本身）的路径，使用正斜杠。"""
    if repo_root:
        try:
            rel = os.path.relpath(proj_dir, repo_root)
            return rel.replace("\\", "/")
        except ValueError:
            pass
    return os.path.basename(proj_dir.rstrip("/\\"))


def github_actions_text(proj_rel: str, cfg: dict) -> str:
    name = cfg.get("name") or "云易程序"
    return f"""# 云易IDE 自动生成 —— GitHub Actions 持续集成
# 推送到 main/master 或发起 PR 时自动翻译并编译，产物为 Windows EXE。
name: 云易构建

on:
  push:
    branches: [ main, master ]
  pull_request:
  workflow_dispatch:

jobs:
  build:
    runs-on: windows-latest
    steps:
      - name: 检出代码
        uses: actions/checkout@v4

      - name: 准备 Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: 安装 MinGW-w64 编译器
        shell: pwsh
        run: |
          choco install mingw -y --no-progress
          echo "C:\\tools\\mingw64\\bin" | Out-File -FilePath $env:GITHUB_PATH -Encoding utf8 -Append

      - name: 翻译并编译（{name}）
        shell: pwsh
        run: python server/yunyi_cli.py build "{proj_rel}" --mode release

      - name: 运行测试
        shell: pwsh
        run: python server/yunyi_cli.py test "{proj_rel}" --mode debug

      - name: 上传可执行文件
        uses: actions/upload-artifact@v4
        with:
          name: {name}-windows-exe
          path: {proj_rel}/build/release/*.exe
"""


def gitlab_ci_text(proj_rel: str, cfg: dict) -> str:
    name = cfg.get("name") or "云易程序"
    return f"""# 云易IDE 自动生成 —— GitLab CI 持续集成
# Linux 容器 + mingw-w64 交叉编译，产出 Windows EXE。
stages:
  - build

build:
  stage: build
  image: debian:bookworm
  before_script:
    - apt-get update -qq && apt-get install -y -qq python3 g++-mingw-w64-x86-64
  script:
    - python3 server/yunyi_cli.py build "{proj_rel}" --mode release --gxx x86_64-w64-mingw32-g++
    - python3 server/yunyi_cli.py test "{proj_rel}" --mode debug --gxx x86_64-w64-mingw32-g++
  artifacts:
    name: {name}-windows-exe
    paths:
      - {proj_rel}/build/release/*.exe
    expire_in: 1 week
"""


def gitea_actions_text(proj_rel: str, cfg: dict) -> str:
    """Gitea/Drone 通用的 shell 流水线脚本（自建 CI 可直接调用）。"""
    name = cfg.get("name") or "云易程序"
    return f"""#!/usr/bin/env bash
# 云易IDE 自动生成 —— 通用 CI 构建脚本（Gitea Actions / 自建 CI 可用）
set -e
echo "== 构建 {name} =="
GXX_ARG=""
if [ -n "$YUNYI_GXX" ]; then GXX_ARG="--gxx $YUNYI_GXX"; fi
python3 server/yunyi_cli.py build "{proj_rel}" --mode release $GXX_ARG
python3 server/yunyi_cli.py test "{proj_rel}" --mode debug $GXX_ARG
echo "== 构建完成，产物：{proj_rel}/build/release/ =="
"""


def generate_ci(proj_dir: str, cfg: dict = None, providers=None,
                repo_root: str = None) -> dict:
    """在工程目录下生成 CI 配置文件。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    providers = providers or ["github", "gitlab", "gitea"]
    rel = rel_in_repo(proj_dir, repo_root)
    written = []

    if "github" in providers:
        d = os.path.join(proj_dir, ".github", "workflows")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "yunyi-build.yml")
        with codec.open_text("build_script", p, "w") as fp:
            fp.write(github_actions_text(rel, cfg))
        written.append(p)

    if "gitlab" in providers:
        p = os.path.join(proj_dir, ".gitlab-ci.yml")
        with codec.open_text("build_script", p, "w") as fp:
            fp.write(gitlab_ci_text(rel, cfg))
        written.append(p)

    if "gitea" in providers:
        p = os.path.join(proj_dir, "ci-build.sh")
        with codec.open_text("build_script", p, "w", newline="\n") as fp:
            fp.write(gitea_actions_text(rel, cfg))
        written.append(p)

    return {"ok": True, "dir": proj_dir, "files": written, "rel": rel}
