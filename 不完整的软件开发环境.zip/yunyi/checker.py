# -*- coding: utf-8 -*-
"""云易 语义检查：变量/函数/内置函数/保留字等，输出中文错误。"""
from __future__ import annotations
from typing import List, Set

from . import ast
from .lexer import YyError

TYPE_SET = {"逻辑型", "字节型", "短整数型", "整数型", "长整数型", "小数型", "文本型", "字节集",
            "日期时间型", "双精度小数型", "子程序指针"}

# 内置函数：名称 -> (最少参数, 最多参数)；-1 表示不限
# 数据源来自 yunyi/corelib.py（核心库命令表），IDE 侧栏与运行时共用同一份定义
from .corelib import builtin_arity as _builtin_arity  # noqa: E402
from .corelib import const_names as _const_names  # noqa: E402
BUILTINS = _builtin_arity()
# 核心库常量（文件_读入 / 时间_年 / 按钮_是否 / 颜色_红 …）：
# 编译期由 codegen 换成字面量，这里认它们为「已知名称」且不许被重新定义为变量/函数
CORE_CONSTS = set(_const_names())

KEYWORDS = {
    "asm", "结束asm", "结束汇编",
    "变量", "常量", "全局变量", "如果", "否则", "否则如果", "结束如果", "判断", "结束判断",
    "如果真", "结束如果真", "计次循环", "变量循环首", "结束循环", "当循环", "判断循环首",
    "循环判断首", "循环判断尾", "返回", "跳出循环", "到循环尾",
    "子程序", "测试函数", "导出子程序", "导出名", "结束子程序", "参考", "传址", "且", "或", "非", "真", "假",
    "程序入口", "_启动子程序", "API", "在库", "空",
    "数据类型", "结束数据类型", "类函数", "结束类函数",
}


def _reserved_set() -> Set[str]:
    return set(KEYWORDS) | TYPE_SET | set(BUILTINS.keys()) | CORE_CONSTS


class Checker:
    def __init__(self, prog: ast.Program):
        self.prog = prog
        self.errors: List[YyError] = []
        self.reserved = _reserved_set()
        self.globals: dict = {}          # 名称 -> (类型, 行, 文件)
        self.const_names: Set[str] = set()   # 本工程定义的常量名（使用时须写 #名称）
        self.funcs: dict = {}            # 名称 -> Func
        self.structs: dict = {}          # 数据类型名 -> StructDecl
        self.methods: dict = {}          # 数据类型名 -> {方法名: MethodDecl}
        # 子程序名集合：子程序名可以当作「函数指针」值使用（如 Win32 回调 WndProc）
        self.func_names: Set[str] = {f.name for f in prog.funcs}
        self._build_tables()

    def _err(self, msg: str, line: int, col: int, file: str = ""):
        self.errors.append(YyError(msg, line, col, file))

    def _build_tables(self):
        # 自定义数据类型
        for s in getattr(self.prog, "structs", []):
            if s.name in self.reserved or s.name in TYPE_SET:
                self._err(f"数据类型名 {s.name!r} 是保留字/基本类型名，不能使用", s.line, s.col, s.file)
                continue
            if s.name in self.structs:
                self._err(f"数据类型 {s.name!r} 重复定义", s.line, s.col, s.file)
                continue
            self.structs[s.name] = s
        # 类函数（数据类型的成员函数）
        for m in getattr(self.prog, "methods", []):
            s = self.structs.get(m.owner)
            if s is None:
                self._err(f"类函数 {m.owner}.{m.name} 的数据类型 {m.owner!r} 未定义",
                          m.line, m.col, m.file)
                continue
            if m.name in self.reserved:
                self._err(f"类函数名 {m.name!r} 是保留字/内置函数名，不能使用", m.line, m.col, m.file)
                continue
            if m.name in {fld.name for fld in s.fields}:
                self._err(f"类函数名 {m.name!r} 与数据类型 {m.owner!r} 的成员重名", m.line, m.col, m.file)
                continue
            self.methods.setdefault(m.owner, {})[m.name] = m
        # 常量/全局变量
        for g in self.prog.consts:
            self._decl_global(g.name, g.type, g.line, g.col, "常量")
            self.const_names.add(g.name)
        for g in self.prog.globals_:
            self._decl_global(g.name, g.type, g.line, g.col, "全局变量")
        # 子程序
        for f in self.prog.funcs:
            if f.name in self.funcs:
                self._err(f"子程序 {f.name!r} 重复定义", f.line, f.col, f.file)
                continue
            if f.name in BUILTINS:
                self._err(f"子程序名 {f.name!r} 与内置函数同名", f.line, f.col, f.file)
                continue
            if f.name in self.globals:
                self._err(f"子程序名 {f.name!r} 与全局变量/常量重名", f.line, f.col, f.file)
                continue
            self.funcs[f.name] = f
        # 导出名（DLL 导出函数名）：不能重复，也不能与子程序名冲突
        used_export = {}
        for f in self.prog.funcs:
            en = getattr(f, "export_name", "")
            if not en:
                continue
            if en in used_export:
                self._err(f"导出名 {en!r} 重复（已被子程序 {used_export[en]!r} 使用）",
                          f.line, f.col, f.file)
                continue
            if en in self.funcs:
                self._err(f"导出名 {en!r} 与子程序名冲突，请换一个导出名", f.line, f.col, f.file)
                continue
            used_export[en] = f.name
        # Windows API 声明
        for a in self.prog.apis:
            if a.name in self.funcs or a.name in self.globals or a.name in BUILTINS:
                self._err(f"API 名称 {a.name!r} 与子程序/变量/内置函数重名", a.line, a.col, a.file)
                continue
            self.funcs[a.name] = a

    def _decl_global(self, name, typ, line, col, kind):
        if name in self.reserved:
            self._err(f"{kind}名 {name!r} 是保留字/内置函数名，不能使用", line, col)
            return
        if name in self.globals:
            self._err(f"{kind} {name!r} 重复定义", line, col)
            return
        if name in self.structs:
            self._err(f"{kind} {name!r} 与数据类型重名", line, col)
            return
        self.globals[name] = (typ, line)

    def run(self):
        for f in self.prog.funcs:
            self._check_func(f)
        for ms in self.methods.values():
            for m in ms.values():
                self._check_method(m)
        return self.errors

    # ---------- 函数体 ----------
    def _check_func(self, f: ast.Func):
        locals_map: dict = {}      # 名称 -> (类型, is_array, line)
        for p in f.params:
            if p.name in self.reserved:
                self._err(f"参数名 {p.name!r} 是保留字/内置函数名", p.line, p.col, f.file)
                continue
            if p.name in locals_map:
                self._err(f"参数 {p.name!r} 重复", p.line, p.col, f.file)
            else:
                locals_map[p.name] = (p.type, p.array_size is not None or p.array_dynamic,
                                      p.line)
        # 收集本函数所有 变量 声明（含嵌套块，全部提升到函数顶部）
        self._collect_decls(f.body, locals_map, f)
        for st in f.body:
            self._check_stmt(st, locals_map, f, False)

    def _check_method(self, m: ast.MethodDecl):
        """类函数检查：成员可当局部变量直接使用（隐式 self）。"""
        s = self.structs[m.owner]
        locals_map: dict = {}
        for fld in s.fields:
            locals_map[fld.name] = (fld.type, False, fld.line)
        for p in m.params:
            if p.name in self.reserved:
                self._err(f"参数名 {p.name!r} 是保留字/内置函数名", p.line, p.col, m.file)
                continue
            if p.name in locals_map:
                self._err(f"参数 {p.name!r} 与数据类型 {m.owner!r} 的成员重名", p.line, p.col, m.file)
                continue
            locals_map[p.name] = (p.type, p.array_size is not None or p.array_dynamic,
                                  p.line)
        self._collect_decls(m.body, locals_map, m)
        for st in m.body:
            self._check_stmt(st, locals_map, m, False)
        # 返回值检查（复用子程序逻辑：f.ret_type / f.name 被引用）
        for st in m.body:
            if isinstance(st, ast.ReturnStmt):
                if st.expr is not None and m.ret_type is None:
                    self._err(f"类函数 {m.owner}.{m.name} 没有返回类型，不能 返回(值)",
                              st.line, st.col, m.file)
                if st.expr is None and m.ret_type is not None:
                    self._err(f"类函数 {m.owner}.{m.name} 声明了返回类型 {m.ret_type}，返回时必须带值",
                              st.line, st.col, m.file)

    def _collect_decls(self, body, locals_map, f):
        for st in body:
            if isinstance(st, ast.VarDecl):
                if st.name in self.reserved:
                    self._err(f"变量名 {st.name!r} 是保留字/内置函数名", st.line, st.col, f.file)
                elif st.name in locals_map:
                    self._err(f"变量 {st.name!r} 重复声明（位置见第 {locals_map[st.name][2]} 行）",
                              st.line, st.col, f.file)
                else:
                    是数组 = st.array_size is not None or getattr(st, "array_dynamic", False)
                    locals_map[st.name] = (st.type, 是数组, st.line)
            elif isinstance(st, ast.IfStmt):
                for c, b in st.branches:
                    self._collect_decls(b, locals_map, f)
                self._collect_decls(st.else_body, locals_map, f)
            elif isinstance(st, (ast.ForRange, ast.WhileStmt, ast.DoWhileStmt)):
                self._collect_decls(st.body, locals_map, f)

    # ---------- 语句 ----------
    def _check_stmt(self, st, loc, f, in_loop):
        t = type(st)
        if t is ast.AsmBlock:
            return      # 裸写汇编块：指令原文直接交给 codegen，不做语义检查
        if t is ast.VarDecl:
            if st.array_size is not None:
                self._check_expr(st.array_size, loc, f)
            if st.init is not None:
                self._check_expr(st.init, loc, f)
        elif t is ast.Assign:
            self._check_lvalue(st.target, loc, f)
            self._check_expr(st.value, loc, f)
        elif t is ast.ExprStmt:
            self._check_expr(st.expr, loc, f)
        elif t is ast.IfStmt:
            for c, b in st.branches:
                if c is not None:
                    self._check_expr(c, loc, f)
                for s in b:
                    self._check_stmt(s, loc, f, in_loop)
            for s in st.else_body:
                self._check_stmt(s, loc, f, in_loop)
        elif t is ast.ForRange:
            if st.var in loc and loc[st.var][1]:
                self._err(f"计次循环变量 {st.var!r} 不能是数组", st.line, st.col, f.file)
            self._check_expr(st.start, loc, f)
            self._check_expr(st.end, loc, f)
            if getattr(st, "step", None) is not None:
                self._check_expr(st.step, loc, f)
            pre = loc.get(st.var)
            if pre is None:
                loc[st.var] = ("整数型", False, st.line)
            try:
                for s in st.body:
                    self._check_stmt(s, loc, f, True)
            finally:
                if pre is None:
                    loc.pop(st.var, None)
                else:
                    loc[st.var] = pre
        elif t is ast.WhileStmt:
            self._check_expr(st.cond, loc, f)
            for s in st.body:
                self._check_stmt(s, loc, f, True)
        elif t is ast.DoWhileStmt:
            self._check_expr(st.cond, loc, f)
            for s in st.body:
                self._check_stmt(s, loc, f, True)
        elif t is ast.BreakStmt:
            if not in_loop:
                self._err("跳出循环 只能用在循环内部", st.line, st.col, f.file)
        elif t is ast.ContinueStmt:
            if not in_loop:
                self._err("到循环尾 只能用在循环内部", st.line, st.col, f.file)
        elif t is ast.ReturnStmt:
            if st.expr is not None and f.ret_type is None:
                self._err(f"子程序 {f.name!r} 没有返回类型，不能 返回(值)", st.line, st.col, f.file)
            if st.expr is None and f.ret_type is not None:
                self._err(f"子程序 {f.name!r} 声明了返回类型 {f.ret_type}，返回时必须带值", st.line, st.col, f.file)
            if st.expr is not None:
                self._check_expr(st.expr, loc, f)

    def _check_lvalue(self, e, loc, f):
        if isinstance(e, ast.Name):
            if getattr(e, "is_const", False) or e.id in self.const_names or e.id in CORE_CONSTS:
                self._err(f"常量 {e.id} 不能被赋值", e.line, e.col, f.file)
                return
            if e.id not in loc and e.id not in self.globals:
                self._err(f"变量 {e.id!r} 未声明（赋值前需先写：变量 {e.id} 类型）", e.line, e.col, f.file)
        elif isinstance(e, ast.Index):
            self._check_lvalue(e.base, loc, f)
            self._check_expr(e.index, loc, f)
        elif isinstance(e, ast.Member):
            self._check_expr(e, loc, f)      # 校验 数据类型/字段 是否存在
        else:
            self._err("赋值号左边必须是变量、数组元素或数据类型成员", e.line, e.col, f.file)

    def _check_expr(self, e, loc, f):
        if e is None:
            return
        t = type(e)
        if t is ast.Name:
            # 常量引用（#名称）：核心库常量或本工程定义的常量
            if getattr(e, "is_const", False):
                if e.id not in CORE_CONSTS and e.id not in self.const_names:
                    self._err(f"未定义的常量 #{e.id}", e.line, e.col, f.file)
                return
            # 裸写的常量名必须加 # 前缀（核心库常量 / 本工程常量）
            if e.id in CORE_CONSTS:
                self._err(f"核心库常量 {e.id} 使用时需写成 #{e.id}", e.line, e.col, f.file)
                return
            if e.id in self.const_names:
                self._err(f"常量 {e.id} 使用时需写成 #{e.id}", e.line, e.col, f.file)
                return
            # 子程序名也是合法「值」（取函数地址，用于 Win32 回调等）
            if (e.id not in loc and e.id not in self.globals
                    and e.id not in self.func_names):
                self._err(f"未声明名称 {e.id!r}", e.line, e.col, f.file)
        elif t is ast.Index:
            self._check_expr(e.base, loc, f)
            # 数组可以是：普通变量、数据类型成员（成员名[长度]）、或嵌套成员链
            if not isinstance(e.base, (ast.Name, ast.Member)):
                self._err("只有数组（变量或数据类型成员）才能使用 [下标]", e.line, e.col, f.file)
            self._check_expr(e.index, loc, f)
        elif t is ast.Member:
            self._check_expr(e.base, loc, f)
            btype = self._expr_type(e.base, loc)
            s = self.structs.get(btype)
            if s is None:
                self._err(f"类型 {btype or '?'} 不是自定义数据类型，不能使用「.成员」", e.line, e.col, f.file)
            elif e.name not in {fld.name for fld in s.fields}:
                names = "、".join(fld.name for fld in s.fields)
                self._err(f"数据类型 {btype} 没有成员 {e.name!r}（可用成员：{names}）",
                          e.line, e.col, f.file)
        elif t is ast.Call:
            self._check_call(e, loc, f)
        elif t is ast.Unary:
            self._check_expr(e.operand, loc, f)
        elif t is ast.Binary:
            self._check_expr(e.left, loc, f)
            self._check_expr(e.right, loc, f)
        # 字面量无需检查

    def _expr_type(self, e, loc):
        """推导表达式的类型名（用于成员访问校验）。未知返回 ''。"""
        if isinstance(e, ast.Name):
            info = loc.get(e.id) or self.globals.get(e.id)
            return info[0] if info else ""
        if isinstance(e, ast.Member):
            btype = self._expr_type(e.base, loc)
            s = self.structs.get(btype)
            for fld in (s.fields if s else []):
                if fld.name == e.name:
                    return fld.type
            return ""
        if isinstance(e, ast.Index):
            return self._expr_type(e.base, loc)
        if isinstance(e, ast.StrLit):
            return "文本型"
        if isinstance(e, ast.NumLit):
            return "小数型" if isinstance(e.value, float) else "整数型"
        if isinstance(e, ast.BoolLit):
            return "逻辑型"
        return ""

    def _check_call(self, c: ast.Call, loc, f):
        name = c.func
        obj = getattr(c, "obj", None)
        if obj is not None:
            # 类函数调用：对象.方法(参数)
            # 也支持「类型名.方法(参数)」：类型名不是变量（未在 loc/globals 里），
            # 但它是已声明的数据类型 → 视为静态调用（在临时实例上执行），
            # 因此不做「未声明名称」检查；codegen 会生成 类型().方法(参数)。
            if (isinstance(obj, ast.Name) and obj.id not in loc
                    and obj.id not in self.globals and obj.id in self.structs):
                c.static_owner = obj.id
                otype = obj.id
            else:
                self._check_expr(obj, loc, f)
                otype = self._expr_type(obj, loc)
            ms = self.methods.get(otype)
            m = ms.get(name) if ms else None
            if m is None:
                hint = "、".join(ms.keys()) if ms else "（无）"
                self._err(f"数据类型 {otype or '?'} 没有类函数 {name}()（可用：{hint}）",
                          c.line, c.col, f.file)
            elif len(c.args) != len(m.params):
                self._err(f"类函数 {otype}.{name}() 需要 {len(m.params)} 个参数，实际给了 {len(c.args)} 个",
                          c.line, c.col, f.file)
            for a in c.args:
                self._check_expr(a, loc, f)
            return
        if name in BUILTINS:
            lo, hi = BUILTINS[name]
            if len(c.args) < lo or (hi >= 0 and len(c.args) > hi):
                expect = f"{lo}" if lo == hi else (f"{lo}~{hi}" if hi > 0 else f"至少 {lo}")
                self._err(f"内置函数 {name}() 需要 {expect} 个参数，实际给了 {len(c.args)} 个",
                          c.line, c.col, f.file)
            for a in c.args:
                self._check_expr(a, loc, f)
            return
        if name in self.funcs:
            fn = self.funcs[name]
            label = "API" if isinstance(fn, ast.ApiDecl) else "子程序"
            if len(c.args) != len(fn.params):
                self._err(f"{label} {name}() 需要 {len(fn.params)} 个参数，实际给了 {len(c.args)} 个",
                          c.line, c.col, f.file)
            for a in c.args:
                self._check_expr(a, loc, f)
            return
        # 子程序指针间接调用：变量名指向一个子程序时允许 p(...)
        vinfo = loc.get(name) or self.globals.get(name)
        if vinfo and vinfo[0] == "子程序指针":
            for a in c.args:
                self._check_expr(a, loc, f)
            return
        # 可能把变量当函数调用，或未定义函数
        self._err(f"未找到子程序或内置函数 {name}()", c.line, c.col, f.file)


def check_program(prog: ast.Program) -> List[YyError]:
    return Checker(prog).run()
