# -*- coding: utf-8 -*-
"""云易 代码生成器（Python 后端）：AST -> Python 3 源码。

供「导出Python」使用：把云易源码翻译成自包含的标准 Python 3 程序 ——
不依赖任何中文运行库；中文内置函数换成等价的 Python 写法（标准库 +
按需注入的 yy_ 前缀辅助函数），中文变量名/常量名/类型名/子程序名原样保留
（Python 3 合法标识符）。

暂不支持：Windows API 声明（API ... 在库 "xxx.dll"）与「参考」参数 ——
生成时直接报错并说明原因。
"""
from __future__ import annotations
from typing import Dict, List, Optional, Set, Tuple

from . import ast
from . import native_rt
from .corelib import const_values as _core_const_values
from .lexer import YyError

# 核心库常量（#名称 引用时在生成处换成 Python 字面量）
_CORE_CONSTS = _core_const_values()

# 云易二元运算符 → Python 运算符（其余 + - * / % < > <= >= == != 同名）
_OP_PY = {"且": "and", "或": "or"}

# 二元运算符优先级（数值越大越紧密），按需加括号
_BIN_PREC = {"or": 1, "and": 2, "==": 3, "!=": 3, "<": 4, ">": 4, "<=": 4, ">=": 4,
             "+": 5, "-": 5, "*": 6, "/": 6, "%": 6,
             "&": 6, "|": 6, "^": 6, "<<": 7, ">>": 7}

# 位运算内置函数 → 中缀运算符
_BIT_OPS = {"位与": "&", "位或": "|", "位异或": "^", "左移": "<<", "右移": ">>"}

# 基本类型 → Python 默认值（变量声明 / 函数缺省返回值）
_DEFAULT_VALUE = {"整数型": "0", "长整数型": "0", "短整数型": "0", "字节型": "0",
                  "小数型": "0.0", "逻辑型": "False", "文本型": '""', "字节集": "bytearray()",
                  "日期时间型": "0", "双精度小数型": "0.0", "子程序指针": "0"}

# 直接映射到 Python（标准库）函数/表达式的内置函数
#   ("name", "模块.函数")   → 原样调用
#   ("expr", "模板{0}{1}")  → 内联表达式
#   ("helper", "yy_名字")   → 调用辅助函数（实现见 _HELPERS，按需注入）
_PY_CALLS: Dict[str, Tuple[str, str]] = {
    # 转换
    "到文本": ("name", "str"),
    "到整数": ("helper", "yy_to_int"),
    "到长整数": ("helper", "yy_to_int"),
    "到小数": ("helper", "yy_to_float"),
    "到逻辑": ("helper", "yy_to_bool"),
    "到字节": ("expr", "(int({0}) & 0xFF)"),
    "数值到文本": ("helper", "yy_num_to_text"),
    # 控制台
    "输入文本": ("name", "input"),
    "输入整数": ("helper", "yy_input_int"),
    "输入小数": ("helper", "yy_input_float"),
    "等待按键": ("name", "input"),
    "提示等待输入": ("helper", "yy_prompt_wait"),
    "清屏": ("helper", "yy_clear_screen"),
    "信息框": ("helper", "yy_message_box"),
    # 文本型（位置一律 1 起始，与 C++ 运行库语义一致）
    "取文本长度": ("name", "len"),
    "取文本左边": ("helper", "yy_text_left"),
    "取文本右边": ("helper", "yy_text_right"),
    "取文本中间": ("helper", "yy_text_mid"),
    "寻找文本": ("helper", "yy_find_text"),
    "倒找文本": ("helper", "yy_rfind_text"),
    "替换文本": ("expr", "({0}.replace({1}, {2}) if {1} else {0})"),
    "文本替换": ("expr", "({0}.replace({1}, {2}, 1) if {1} else {0})"),
    "子文本替换": ("helper", "yy_replace_sub"),
    "分割文本": ("helper", "yy_split_text"),
    "取文本段数": ("expr", "({0}.count({1}) + 1 if {1} else 1)"),
    "到大写": ("helper", "yy_upper"),
    "到小写": ("helper", "yy_lower"),
    "删首尾空": ("helper", "yy_trim"),
    "删首空": ("helper", "yy_ltrim"),
    "删尾空": ("helper", "yy_rtrim"),
    "删全部空": ("expr", "({0}.replace(' ', ''))"),
    "取空白文本": ("expr", "(' ' * {0})"),
    "取重复文本": ("expr", "({1} * {0})"),
    "文本比较": ("helper", "yy_compare"),
    "文本开头为": ("expr", "({0}.startswith({1}))"),
    "文本结尾为": ("expr", "({0}.endswith({1}))"),
    "取字符": ("helper", "yy_char_at"),
    "取字符代码": ("helper", "yy_ord_at"),
    "字符代码到文本": ("name", "chr"),
    "文本倒序": ("expr", "({0}[::-1])"),
    "是否为空文本": ("expr", "({0} == '')"),
    "到全角": ("helper", "yy_fullwidth"),
    "到半角": ("helper", "yy_halfwidth"),
    # 数值
    "取绝对值": ("name", "abs"),
    "取整": ("name", "int"),
    "四舍五入": ("helper", "yy_round"),
    "求平方根": ("name", "math.sqrt"),
    "整除": ("helper", "yy_div"),
    "取符号": ("helper", "yy_sign"),
    "向上取整": ("name", "math.ceil"),
    "向下取整": ("name", "math.floor"),
    "求次方": ("name", "math.pow"),
    "取自然对数": ("name", "math.log"),
    "取常用对数": ("name", "math.log10"),
    "求正弦": ("name", "math.sin"),
    "求余弦": ("name", "math.cos"),
    "求正切": ("name", "math.tan"),
    "求反正切": ("name", "math.atan"),
    "取余数": ("helper", "yy_fmod"),
    "取最大值": ("name", "max"),
    "取最小值": ("name", "min"),
    "取圆周率": ("expr", "math.pi"),
    # 随机
    "取随机数": ("name", "random.randint"),
    "取随机小数": ("name", "random.random"),
    "置随机数种子": ("name", "random.seed"),
    # 字节集
    "文本到字节集": ("helper", "yy_str_to_bytes"),
    "字节集到文本": ("helper", "yy_bytes_to_str"),
    "取字节集长度": ("name", "len"),
    "取字节集字节": ("helper", "yy_byte_at"),
    "取字节集左边": ("helper", "yy_bytes_left"),
    # 数组
    "取数组成员数": ("name", "len"),
    "加入成员": ("helper", "yy_array_push"),
    "插入成员": ("helper", "yy_array_insert"),
    "删除成员": ("helper", "yy_array_remove"),
    "重定义数组": ("helper", "yy_array_resize"),
    "数组排序": ("helper", "yy_array_sort"),
    "数组反转": ("helper", "yy_array_reverse"),
    "清除数组": ("helper", "yy_array_clear"),
    # 时间
    "取当前时间": ("helper", "yy_now_text"),
    "取日期": ("helper", "yy_today_text"),
    "取年份": ("expr", "datetime.datetime.now().year"),
    "取月份": ("expr", "datetime.datetime.now().month"),
    "取日": ("expr", "datetime.datetime.now().day"),
    "取小时": ("expr", "datetime.datetime.now().hour"),
    "取分钟": ("expr", "datetime.datetime.now().minute"),
    "取秒": ("expr", "datetime.datetime.now().second"),
    "取星期": ("helper", "yy_weekday"),
    "取现行时间": ("expr", "int(time.time())"),
    "取启动毫秒": ("helper", "yy_uptime_ms"),
    "延时": ("helper", "yy_sleep"),
    # 文件与目录
    "文件是否存在": ("name", "os.path.isfile"),
    "目录是否存在": ("name", "os.path.isdir"),
    "取文件长度": ("helper", "yy_file_size"),
    "读入文件": ("helper", "yy_read_file"),
    "写到文件": ("helper", "yy_write_file"),
    "删除文件": ("helper", "yy_delete_file"),
    "复制文件": ("helper", "yy_copy_file"),
    "移动文件": ("helper", "yy_move_file"),
    "创建目录": ("helper", "yy_make_dir"),
    "删除目录": ("helper", "yy_remove_dir"),
    "取文件列表": ("helper", "yy_list_files"),
    "取当前目录": ("name", "os.getcwd"),
    "置当前目录": ("helper", "yy_chdir"),
    "取运行目录": ("expr", "os.path.dirname(os.path.abspath(sys.argv[0]))"),
    "取临时目录": ("name", "tempfile.gettempdir"),
    "执行程序": ("helper", "yy_run_program"),
    "取命令行": ("expr", "' '.join(sys.argv)"),
    "取环境变量": ("expr", "os.environ.get({0}, '')"),
    "结束程序": ("helper", "yy_exit"),
    # 系统
    "取屏幕宽度": ("helper", "yy_screen_w"),
    "取屏幕高度": ("helper", "yy_screen_h"),
    "置控制台标题": ("helper", "yy_console_title"),
    # 测试框架
    "断言": ("helper", "yy_assert"),
    "_yy断言重置": ("helper", "yy_assert_reset"),
    "_yy取总数": ("helper", "yy_assert_total"),
    "_yy取失败": ("helper", "yy_assert_failed"),
}

# 位取反（一元）映射到 ~ 运算符
_BIT_NOT_OP = "~"

# "name" 映射里带模块前缀的 → 需要的 import
_NAME_IMPORTS = {"math": "math", "random": "random", "os": "os", "os.path": "os",
                 "sys": "sys", "time": "time", "datetime": "datetime",
                 "tempfile": "tempfile"}

# 辅助函数实现（只有真正被用到的才会注入生成文件）
_HELPERS: Dict[str, Tuple[str, Set[str]]] = {
    "yy_to_int": ('''def yy_to_int(v):
    """到整数：宽容解析（失败返回 0）"""
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v)
    m = re.match(r"[+-]?\\d+", str(v).strip())
    return int(m.group()) if m else 0''', {"re"}),

    "yy_to_float": ('''def yy_to_float(v):
    """到小数：宽容解析（失败返回 0.0）"""
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip()
    try:
        return float(t)
    except ValueError:
        m = re.match(r"[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?", t)
        return float(m.group()) if m else 0.0''', {"re"}),

    "yy_to_bool": ('''def yy_to_bool(v):
    """到逻辑"""
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    s = str(v).strip().lower()
    if s in ("真", "true", "1"):
        return True
    if s in ("", "假", "false", "0"):
        return False
    try:
        return float(s) != 0
    except ValueError:
        return bool(s)''', set()),

    "yy_num_to_text": ('''def yy_num_to_text(v, digits=0):
    """数值到文本：digits>0 时保留指定位小数，否则整数值不带小数点"""
    digits = int(digits)
    if digits > 0:
        return f"{float(v):.{digits}f}"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)''', set()),

    "yy_input_int": ('''def yy_input_int():
    return yy_to_int(input())''', set()),

    "yy_input_float": ('''def yy_input_float():
    return yy_to_float(input())''', set()),

    "yy_prompt_wait": ('''def yy_prompt_wait():
    """提示等待输入"""
    try:
        input("按回车键继续...")
    except EOFError:
        pass''', set()),

    "yy_clear_screen": ('''def yy_clear_screen():
    os.system("cls" if os.name == "nt" else "clear")''', set()),

    "yy_message_box": ('''def yy_message_box(text):
    """信息框（Windows 消息框；其他平台退化为控制台输出）"""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(text), "提示", 0)
    except Exception:
        print(text)''', set()),

    "yy_text_left": ('''def yy_text_left(s, n):
    s = str(s)
    n = int(n)
    return s[:n] if n > 0 else ""''', set()),

    "yy_text_right": ('''def yy_text_right(s, n):
    s = str(s)
    n = int(n)
    if n <= 0:
        return ""
    return s[-n:] if n < len(s) else s''', set()),

    "yy_text_mid": ('''def yy_text_mid(s, start, n):
    """取文本中间：start 从 1 起"""
    s = str(s)
    start = int(start)
    n = int(n)
    if start < 1 or n <= 0:
        return ""
    return s[start - 1:start - 1 + n]''', set()),

    "yy_find_text": ('''def yy_find_text(s, sub, start=1):
    """寻找文本：返回 1 起始位置，找不到返回 0"""
    s = str(s)
    sub = str(sub)
    start = int(start)
    if not sub:
        return start if 1 <= start <= len(s) else 0
    if start < 1:
        start = 1
    pos = s.find(sub, start - 1)
    return pos + 1 if pos >= 0 else 0''', set()),

    "yy_rfind_text": ('''def yy_rfind_text(s, sub, start=-1):
    """倒找文本：start 为允许的最右匹配起始位置（0 起），-1 表示不限"""
    s = str(s)
    sub = str(sub)
    start = int(start)
    if not sub:
        return 0
    if 0 <= start <= len(s):
        pos = s.rfind(sub, 0, start + len(sub))
    else:
        pos = s.rfind(sub)
    return pos + 1 if pos >= 0 else 0''', set()),

    "yy_replace_sub": ('''def yy_replace_sub(src, find, rep, start=1, count=-1):
    """子文本替换：从 start（1 起）开始替换 count 次（-1 全部）"""
    src = str(src)
    find = str(find)
    rep = str(rep)
    start = int(start)
    count = int(count)
    if not find or start < 1:
        return src
    head, tail = src[:start - 1], src[start - 1:]
    mid = tail.replace(find, rep) if count < 0 else tail.replace(find, rep, count)
    return head + mid''', set()),

    "yy_split_text": ('''def yy_split_text(s, sep, index):
    """分割文本：index 从 1 起，越界返回空文本"""
    parts = str(s).split(str(sep)) if sep else [str(s)]
    index = int(index)
    return parts[index - 1] if 1 <= index <= len(parts) else ""''', set()),

    "yy_upper": ('''def yy_upper(s):
    return str(s).upper()''', set()),

    "yy_lower": ('''def yy_lower(s):
    return str(s).lower()''', set()),

    "yy_trim": ('''def yy_trim(s):
    return str(s).strip()''', set()),

    "yy_ltrim": ('''def yy_ltrim(s):
    return str(s).lstrip()''', set()),

    "yy_rtrim": ('''def yy_rtrim(s):
    return str(s).rstrip()''', set()),

    "yy_compare": ('''def yy_compare(a, b, case_sensitive=False):
    """文本比较：返回 -1 / 0 / 1"""
    a, b = str(a), str(b)
    if not case_sensitive:
        a, b = a.lower(), b.lower()
    return -1 if a < b else (1 if a > b else 0)''', set()),

    "yy_char_at": ('''def yy_char_at(s, pos):
    """取字符：pos 从 1 起"""
    s = str(s)
    pos = int(pos)
    return s[pos - 1] if 1 <= pos <= len(s) else ""''', set()),

    "yy_ord_at": ('''def yy_ord_at(s, pos):
    """取字符代码：pos 从 1 起"""
    s = str(s)
    pos = int(pos)
    return ord(s[pos - 1]) if 1 <= pos <= len(s) else 0''', set()),
}

# 全角/半角单独定义（含全角空格 U+3000 的处理）
_HELPERS["yy_fullwidth"] = ('''def yy_fullwidth(s):
    """到全角：ASCII 字母/数字/符号 → 全角"""
    out = []
    for ch in str(s):
        o = ord(ch)
        if ch == " ":
            out.append("\\u3000")
        elif 0x20 < o < 0x7F:
            out.append(chr(o + 0xFEE0))
        else:
            out.append(ch)
    return "".join(out)''', set())

_HELPERS["yy_halfwidth"] = ('''def yy_halfwidth(s):
    """到半角：全角字母/数字/符号 → 半角"""
    out = []
    for ch in str(s):
        o = ord(ch)
        if ch == "\\u3000":
            out.append(" ")
        elif 0xFF01 <= o <= 0xFF5E:
            out.append(chr(o - 0xFEE0))
        else:
            out.append(ch)
    return "".join(out)''', set())

_HELPERS["yy_round"] = ('''def yy_round(x, digits=0):
    """四舍五入（.5 远离零，与 C++ 运行库一致）"""
    x = float(x)
    digits = int(digits)
    if digits > 0:
        m = 10 ** digits
        return yy_round(x * m) / m
    return math.floor(x + 0.5) if x >= 0 else math.ceil(x - 0.5)''', {"math"})

_HELPERS["yy_div"] = ('''def yy_div(a, b):
    """整除：向下取整，除数为 0 返回 0"""
    a = int(a)
    b = int(b)
    return a // b if b else 0''', set())

_HELPERS["yy_sign"] = ('''def yy_sign(v):
    """取符号：-1 / 0 / 1"""
    v = float(v)
    return 1 if v > 0 else (-1 if v < 0 else 0)''', set())

_HELPERS["yy_fmod"] = ('''def yy_fmod(a, b):
    """取余数（浮点），除数为 0 返回 0"""
    if float(b) == 0:
        return 0.0
    return math.fmod(float(a), float(b))''', {"math"})

_HELPERS["yy_str_to_bytes"] = ('''def yy_str_to_bytes(s):
    return bytearray(str(s).encode("utf-8"))''', set())

_HELPERS["yy_bytes_to_str"] = ('''def yy_bytes_to_str(b):
    return bytes(b).decode("utf-8", "replace")''', set())

_HELPERS["yy_byte_at"] = ('''def yy_byte_at(b, pos):
    """取字节集字节：pos 从 1 起"""
    pos = int(pos)
    return b[pos - 1] if 1 <= pos <= len(b) else 0''', set())

_HELPERS["yy_bytes_left"] = ('''def yy_bytes_left(b, n):
    n = int(n)
    return bytearray(b[:n]) if n > 0 else bytearray()''', set())

_HELPERS["yy_array_push"] = ('''def yy_array_push(v, item):
    v.append(item)''', set())

_HELPERS["yy_array_insert"] = ('''def yy_array_insert(v, index, item):
    """插入成员：index 从 1 起；item 也可以是数组，此时依次插入其所有成员"""
    i = int(index)
    if i < 1:
        i = 1
    if i > len(v) + 1:
        i = len(v) + 1
    if isinstance(item, (list, tuple)):
        j = i - 1
        for x in item:
            v.insert(j, x)
            j += 1
    else:
        v.insert(i - 1, item)''', set())

_HELPERS["yy_array_resize"] = ('''def yy_array_resize(v, n):
    """重定义数组：n<0 按 0 处理；扩大的部分用已有成员推断出的默认值填充
    （与 C++ 运行库的默认构造一致：数值 0、文本型 ""；空数组时按 0 填充）"""
    n = int(n)
    if n < 0:
        n = 0
    if len(v) > n:
        del v[n:]
    elif len(v) < n:
        default = 0
        for x in v:
            if isinstance(x, str):
                default = ""
            elif isinstance(x, bool):
                default = False
            elif isinstance(x, float):
                default = 0.0
            elif isinstance(x, bytearray):
                default = 0
            break
        v.extend([default] * (n - len(v)))''', set())

_HELPERS["yy_array_remove"] = ('''def yy_array_remove(v, index):
    """删除成员：index 从 1 起"""
    index = int(index)
    if 1 <= index <= len(v):
        del v[index - 1]''', set())

_HELPERS["yy_array_sort"] = ('''def yy_array_sort(v):
    v.sort()''', set())

_HELPERS["yy_array_reverse"] = ('''def yy_array_reverse(v):
    v.reverse()''', set())

_HELPERS["yy_array_clear"] = ('''def yy_array_clear(v):
    v.clear()''', set())

_HELPERS["yy_now_text"] = ('''def yy_now_text():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")''', {"datetime"})

_HELPERS["yy_today_text"] = ('''def yy_today_text():
    return datetime.date.today().strftime("%Y-%m-%d")''', {"datetime"})

_HELPERS["yy_weekday"] = ('''def yy_weekday():
    """取星期：周日=1 … 周六=7（与 C++ 运行库一致）"""
    return (datetime.date.today().weekday() + 1) % 7 + 1''', {"datetime"})

_HELPERS["yy_uptime_ms"] = ('''_YY_UPTIME_START = time.perf_counter()

def yy_uptime_ms():
    """取启动毫秒：自程序启动以来的毫秒数"""
    return int((time.perf_counter() - _YY_UPTIME_START) * 1000)''', {"time"})

_HELPERS["yy_sleep"] = ('''def yy_sleep(ms):
    """延时（毫秒）"""
    if ms > 0:
        time.sleep(ms / 1000.0)''', {"time"})

_HELPERS["yy_file_size"] = ('''def yy_file_size(path):
    try:
        if os.path.isdir(path):
            return -1
        return os.path.getsize(path)
    except OSError:
        return -1''', set())

_HELPERS["yy_read_file"] = ('''def yy_read_file(path):
    """读入文件（UTF-8，失败返回空文本）"""
    try:
        with open(path, "rb") as f:
            return f.read().decode("utf-8", "replace")
    except OSError:
        return ""''', set())

_HELPERS["yy_write_file"] = ('''def yy_write_file(path, content, append=False):
    """写到文件（UTF-8，append=True 追加）"""
    try:
        with open(path, "ab" if append else "wb") as f:
            f.write(str(content).encode("utf-8"))
        return True
    except OSError:
        return False''', set())

_HELPERS["yy_delete_file"] = ('''def yy_delete_file(path):
    try:
        os.remove(path)
        return True
    except OSError:
        return False''', set())

_HELPERS["yy_copy_file"] = ('''def yy_copy_file(src, dst):
    try:
        shutil.copyfile(src, dst)
        return True
    except OSError:
        return False''', {"shutil"})

_HELPERS["yy_move_file"] = ('''def yy_move_file(src, dst):
    try:
        shutil.move(src, dst)
        return True
    except OSError:
        return False''', {"shutil"})

_HELPERS["yy_make_dir"] = ('''def yy_make_dir(path):
    """创建目录（含多级；已存在也算成功）"""
    if not path:
        return False
    try:
        os.makedirs(path, exist_ok=True)
        return True
    except OSError:
        return False''', set())

_HELPERS["yy_remove_dir"] = ('''def yy_remove_dir(path):
    try:
        os.rmdir(path)
        return True
    except OSError:
        return False''', set())

_HELPERS["yy_list_files"] = ('''def yy_list_files(directory, pattern="*"):
    """取文件列表：返回以换行分隔的文件名（不含 . 与 ..）"""
    import glob
    names = [os.path.basename(p)
             for p in glob.glob(os.path.join(directory, pattern))]
    return "\\n".join(n for n in names if n not in (".", ".."))''', set())

_HELPERS["yy_chdir"] = ('''def yy_chdir(path):
    try:
        os.chdir(path)
        return True
    except OSError:
        return False''', set())

_HELPERS["yy_run_program"] = ('''def yy_run_program(cmdline, wait=True):
    """执行程序：返回退出码（-1 表示启动失败）；wait=False 不等待"""
    try:
        if not wait:
            subprocess.Popen(cmdline, shell=True)
            return 0
        return subprocess.call(cmdline, shell=True)
    except OSError:
        return -1''', {"subprocess"})

_HELPERS["yy_exit"] = ('''def yy_exit(code=0):
    """结束程序"""
    sys.exit(code)''', set())

_HELPERS["yy_screen_w"] = ('''def yy_screen_w():
    """取屏幕宽度（非 Windows 返回 0）"""
    try:
        import ctypes
        return int(ctypes.windll.user32.GetSystemMetrics(0))
    except Exception:
        return 0''', set())

_HELPERS["yy_screen_h"] = ('''def yy_screen_h():
    """取屏幕高度（非 Windows 返回 0）"""
    try:
        import ctypes
        return int(ctypes.windll.user32.GetSystemMetrics(1))
    except Exception:
        return 0''', set())

_HELPERS["yy_console_title"] = ('''def yy_console_title(title):
    """置控制台标题（非 Windows 忽略）"""
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleTitleW(str(title))
    except Exception:
        pass''', set())

_HELPERS["yy_assert"] = ('''_YY_ASSERT_TOTAL = 0
_YY_ASSERT_FAILED = 0

def yy_assert(cond, note=""):
    """断言：失败时打印并计数"""
    global _YY_ASSERT_TOTAL, _YY_ASSERT_FAILED
    _YY_ASSERT_TOTAL += 1
    if not cond:
        _YY_ASSERT_FAILED += 1
        print("[assert failed] " + str(note))''', set())

_HELPERS["yy_assert_reset"] = ('''def yy_assert_reset():
    global _YY_ASSERT_TOTAL, _YY_ASSERT_FAILED
    _YY_ASSERT_TOTAL = 0
    _YY_ASSERT_FAILED = 0''', set())

_HELPERS["yy_assert_total"] = ('''def yy_assert_total():
    return _YY_ASSERT_TOTAL''', set())

_HELPERS["yy_assert_failed"] = ('''def yy_assert_failed():
    return _YY_ASSERT_FAILED''', set())


def _py_str(s: str) -> str:
    """Python 字符串字面量（含转义）"""
    out = '"'
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out += '\\"'
        elif ch == "\\":
            out += "\\\\"
        elif ch == "\n":
            out += "\\n"
        elif ch == "\t":
            out += "\\t"
        elif ch == "\r":
            out += "\\r"
        elif o < 0x20:
            out += "\\x%02x" % o
        else:
            out += ch
    return out + '"'


class PyGen:
    def __init__(self, prog: ast.Program):
        self.prog = prog
        self.out: List[str] = []
        self.indent = 0
        self.entry_names = {"程序入口", "_启动子程序"}
        self.func_names = {f.name for f in prog.funcs}
        self._mfields: Set[str] = set()   # 当前类函数的成员字段（body 里映射为 self.）
        self._mlocals: Set[str] = set()   # 当前类函数的局部变量与参数
        self._used_helpers: List[str] = []  # 按首次使用顺序注入
        self._imports: Set[str] = set()

    # ---------- 输出工具 ----------
    def w(self, text: str):
        if text:
            self.out.append("    " * self.indent + text)
        else:
            self.out.append("")

    def raw(self, text: str = ""):
        self.out.append(text)

    # ---------- 支持性检查 ----------
    def check_supported(self):
        apis = getattr(self.prog, "apis", None) or []
        if apis:
            a = apis[0]
            raise YyError("导出Python 暂不支持 Windows API 声明（" + a.name
                          + " 在库 \"" + a.dll + "\"）；导出Python 仅支持不调用"
                          " Windows API 的控制台程序", a.line, a.col, a.file or "")
        for f in list(self.prog.funcs) + list(getattr(self.prog, "methods", []) or []):
            for p in f.params:
                if getattr(p, "byref", False):
                    raise YyError("导出Python 暂不支持「参考/传址」参数（子程序 "
                                  + f.name + " 的参数 " + p.name + "）；"
                                  "Python 参数没有指针语义，请改用返回值传递结果",
                                  f.line, f.col, getattr(f, "file", "") or "")

    # ---------- 内置函数映射 ----------
    def _register_name_import(self, target: str):
        mod = target.split(".")[0]
        if mod in _NAME_IMPORTS:
            self._imports.add(_NAME_IMPORTS[mod])

    def builtin_call(self, name: str, arg_exprs: List[str]) -> Optional[str]:
        """中文内置函数 → Python 写法；不支持返回 None。"""
        if name in _BIT_OPS and len(arg_exprs) == 2:
            return "(" + arg_exprs[0] + " " + _BIT_OPS[name] + " " + arg_exprs[1] + ")"
        if name == "位取反" and len(arg_exprs) == 1:
            return "(~" + arg_exprs[0] + ")"
        kind, val = _PY_CALLS[name]
        if kind == "name":
            self._register_name_import(val)
            return val + "(" + ", ".join(arg_exprs) + ")"
        if kind == "expr":
            # 模板里可能内嵌标准库调用（math.pi / datetime... / sys.argv ...）
            for mod in ("math", "datetime", "time", "random", "os", "sys"):
                if mod + "." in val:
                    self._imports.add(mod)
            return val.format(*arg_exprs)
        if val not in self._used_helpers:
            self._used_helpers.append(val)
            self._imports |= _HELPERS[val][1]
        return val + "(" + ", ".join(arg_exprs) + ")"

    def call(self, e: ast.Call, arg_exprs: List[str]) -> str:
        name = e.func
        # 内置函数映射（用户自己的子程序优先）
        if name not in self.func_names:
            if name in ("输出", "调试输出"):
                return ("print(" + ", ".join(arg_exprs) + ", sep='')"
                        if arg_exprs else "print()")
            if name in _PY_CALLS:
                r = self.builtin_call(name, arg_exprs)
                if r is not None:
                    return r
            if name in native_rt.NATIVE_NAME and name not in self.func_names:
                raise YyError("导出Python 暂不支持内置函数 " + name
                              + "（可改写为已支持的内置函数或自己的子程序）",
                              e.line, e.col, "")
        return name + "(" + ", ".join(arg_exprs) + ")"

    # ---------- 表达式 ----------
    def expr(self, e: ast.Expr) -> str:
        t = type(e)
        if t is ast.NumLit:
            return str(e.value) if isinstance(e.value, int) else repr(e.value)
        if t is ast.StrLit:
            return _py_str(e.value)
        if t is ast.BoolLit:
            return "True" if e.value else "False"
        if t is ast.Name:
            # #核心库常量：就地换成字面量；用户常量/变量原样
            if getattr(e, "is_const", False) and e.id in _CORE_CONSTS:
                return _CORE_CONSTS[e.id]
            # 类函数体内：数据类型成员 -> self.成员（被局部变量/参数遮蔽的除外）
            if self._mfields and e.id in self._mfields and e.id not in self._mlocals:
                return "self." + e.id
            return e.id
        if t is ast.Index:
            return self.expr(e.base) + "[" + self.expr(e.index) + "]"
        if t is ast.Member:
            return self.expr(e.base) + "." + e.name
        if t is ast.Call:
            arg_exprs = [self.expr(a) for a in e.args]
            obj = getattr(e, "obj", None)
            if obj is not None:
                # 「类型名.方法(参数)」静态调用：在临时实例上调用，如 运算.加法(x) → 运算().加法(x)
                owner = getattr(e, "static_owner", None)
                recv = owner + "()" if owner else self.expr(obj)
                return recv + "." + e.func + "(" + ", ".join(arg_exprs) + ")"
            return self.call(e, arg_exprs)
        if t is ast.Unary:
            inner = self.expr(e.operand)
            if isinstance(e.operand, (ast.Binary, ast.Unary)):
                inner = "(" + inner + ")"
            if e.op in ("!", "非"):
                return "not " + inner
            return e.op + inner
        if t is ast.Binary:
            if e.op == "整除":
                args = [self.expr(e.left), self.expr(e.right)]
                self.builtin_call("整除", args)
                return ("yy_div(" + args[0] + ", " + args[1] + ")")
            op = _OP_PY.get(e.op, e.op)
            p = _BIN_PREC.get(op, 7)
            l = self._child_text(e.left, p, False)
            r = self._child_text(e.right, p, True)
            return l + " " + op + " " + r
        raise YyError("内部错误：不认识的表达式节点 " + str(t),
                      getattr(e, "line", 0), 0, "")

    def _child_text(self, node: ast.Expr, parent_prec: int, right: bool) -> str:
        """按优先级给子表达式加括号（与 C++ 生成器同样的按需括号策略）"""
        text = self.expr(node)
        if isinstance(node, ast.Binary):
            op = _OP_PY.get(node.op, node.op)
            if node.op == "整除":
                return text
            cp = _BIN_PREC.get(op, 7)
            if cp < parent_prec or (cp == parent_prec and right):
                return "(" + text + ")"
        return text

    # ---------- 语句 ----------
    def emit_block(self, body: List[ast.Stmt]):
        if not body:
            self.w("pass")
            return
        for st in body:
            self.emit(st)

    def emit(self, st):
        t = type(st)
        if t is ast.VarDecl:
            # 声明本体已在函数头部统一提升（与 C++ 生成器一致）；这里只处理带初值的赋值
            if st.init is not None and st.array_size is None:
                self.w(st.name + " = " + self.expr(st.init))
            return
        if t is ast.AsmBlock:
            # 汇编没有 Python 对应写法：整块当注释保留，避免破坏语法
            for ln in (st.code or "").split("\n"):
                if ln.strip():
                    self.w("# [asm] " + ln.strip())
            return
        if t is ast.Assign:
            lhs = self.expr(st.target)
            self.w(lhs + " " + st.op + " " + self.expr(st.value))
        elif t is ast.ExprStmt:
            e = st.expr
            if isinstance(e, ast.Call) and e.func == "置入代码":
                # 把参数里的源码原样插入（导出 Python 时把 C/C++ 片段当作注释保留，避免破坏语法）
                if e.args and isinstance(e.args[0], ast.StrLit):
                    for ln in e.args[0].value.split("\n"):
                        self.w("# [置入代码] " + ln)
                return
            if isinstance(e, ast.Call):
                self.w(self.expr(e))
        elif t is ast.IfStmt:
            first_cond, first_body = st.branches[0]
            self.w("if " + self.expr(first_cond) + ":")
            self.indent += 1
            self.emit_block(first_body)
            self.indent -= 1
            for cond, body in st.branches[1:]:
                self.w("elif " + self.expr(cond) + ":")
                self.indent += 1
                self.emit_block(body)
                self.indent -= 1
            if st.else_body:
                self.w("else:")
                self.indent += 1
                self.emit_block(st.else_body)
                self.indent -= 1
        elif t is ast.ForRange:
            self.w("for " + st.var + " in range("
                   + self.expr(st.start) + ", " + self.expr(st.end) + " + 1):")
            self.indent += 1
            self.emit_block(st.body)
            self.indent -= 1
        elif t is ast.WhileStmt:
            self.w("while " + self.expr(st.cond) + ":")
            self.indent += 1
            self.emit_block(st.body)
            self.indent -= 1
        elif t is ast.DoWhileStmt:
            self.w("while True:")
            self.indent += 1
            self.emit_block(st.body)
            self.w("if not (" + self.expr(st.cond) + "):")
            self.indent += 1
            self.w("break")
            self.indent -= 1
            self.indent -= 1
        elif t is ast.BreakStmt:
            self.w("break")
        elif t is ast.ContinueStmt:
            self.w("continue")
        elif t is ast.ReturnStmt:
            if st.expr is not None:
                self.w("return " + self.expr(st.expr))
            else:
                self.w("return")
        else:
            raise YyError("内部错误：不认识的语句节点 " + str(t), st.line, 0, "")

    # ---------- 局部变量 ----------
    def collect_locals(self, body) -> List[ast.VarDecl]:
        found: List[ast.VarDecl] = []
        seen = set()

        def walk(sts):
            for s in sts:
                if isinstance(s, ast.VarDecl):
                    if s.name not in seen:
                        seen.add(s.name)
                        found.append(s)
                elif isinstance(s, ast.IfStmt):
                    for _c, b in s.branches:
                        walk(b)
                    walk(s.else_body)
                elif isinstance(s, (ast.ForRange, ast.WhileStmt)):
                    walk(s.body)
                elif isinstance(s, ast.DoWhileStmt):
                    walk(s.body)

        walk(body)
        return found

    def _default_of(self, typ: str) -> str:
        return _DEFAULT_VALUE.get(typ, typ + "()")

    def _emit_locals(self, body, file: str):
        """把函数里声明的变量提升到函数开头（与 C++ 生成器语义一致：循环里声明只初始化一次）"""
        params = set()
        for v in self.collect_locals(body):
            if v.name in params:
                continue
            if v.array_size is not None:
                size = self.expr(v.array_size)
                self.w(v.name + " = [" + self._default_of(v.type)
                       + " for _ in range(" + size + ")]")
            elif getattr(v, "array_dynamic", False):
                # 动态数组（名字[]）：生成为空列表，配合 加入成员/插入成员/重定义数组 使用
                self.w(v.name + " = []")
            else:
                self.w(v.name + " = " + self._default_of(v.type))

    # ---------- 结构体 / 类函数 ----------
    def methods_of(self, owner: str):
        return [m for m in getattr(self.prog, "methods", []) if m.owner == owner]

    def gen_structs(self):
        structs = getattr(self.prog, "structs", [])
        if not structs:
            return
        for s in structs:
            self.w("class " + s.name + ":")
            self.indent += 1
            self.w("def __init__(self):")
            self.indent += 1
            if s.fields:
                for fld in s.fields:
                    if fld.array_size is not None:
                        # 固定数组：按长度初始化为默认值列表
                        self.w("self." + fld.name + " = [" + self._default_of(fld.type)
                               + " for _ in range(" + self.expr(fld.array_size) + ")]")
                    elif getattr(fld, "array_dynamic", False):
                        # 动态数组：空列表，配合 加入成员 / 重定义数组 等命令
                        self.w("self." + fld.name + " = []")
                    else:
                        self.w("self." + fld.name + " = " + self._default_of(fld.type))
            else:
                self.w("pass")
            self.indent -= 1
            for m in self.methods_of(s.name):
                self.gen_method(m)
            self.indent -= 1
        self.raw()

    def gen_method(self, m: ast.MethodDecl):
        self._mfields = set()
        owner = next((s for s in getattr(self.prog, "structs", [])
                      if s.name == m.owner), None)
        if owner:
            self._mfields = {fld.name for fld in owner.fields}
        self._mlocals = {v.name for v in self.collect_locals(m.body)} \
            | {p.name for p in m.params}
        params = ", ".join(p.name for p in m.params)
        self.w("def " + m.name + "(self" + (", " + params if params else "") + "):")
        self.indent += 1
        self._emit_locals(m.body, m.file)
        self.emit_block(m.body)
        if m.ret_type is not None and not self._ends_with_return(m.body):
            self.w("return " + self._default_of(m.ret_type))
        self.indent -= 1
        self._mfields = set()
        self._mlocals = set()

    # ---------- 全局变量 / 常量 ----------
    def gen_globals(self):
        for c in self.prog.consts:
            self.w(c.name + " = " + self.expr(c.value))
        for g in self.prog.globals_:
            if g.array_size is not None:
                size = self.expr(g.array_size)
                self.w(g.name + " = [" + self._default_of(g.type)
                       + " for _ in range(" + size + ")]")
            elif getattr(g, "array_dynamic", False):
                self.w(g.name + " = []")
            else:
                self.w(g.name + " = " + self._default_of(g.type))
        if self.prog.consts or self.prog.globals_:
            self.raw()

    # ---------- 子程序 ----------
    def gen_func(self, f: ast.Func):
        params = ", ".join(p.name for p in f.params)
        self.w("def " + f.name + "(" + params + "):")
        self.indent += 1
        decl = {v.name for v in self.collect_locals(f.body)}
        self._mlocals = decl | {p.name for p in f.params}
        self._emit_locals(f.body, f.file)
        self.emit_block(f.body)
        if f.ret_type is not None and not self._ends_with_return(f.body):
            self.w("return " + self._default_of(f.ret_type))
        self.indent -= 1
        self._mlocals = set()
        self.raw()

    @staticmethod
    def _ends_with_return(body: List[ast.Stmt]) -> bool:
        return bool(body) and isinstance(body[-1], ast.ReturnStmt)

    def find_entry(self) -> Optional[ast.Func]:
        for f in self.prog.funcs:
            if f.name in self.entry_names and f.kind == "子程序":
                return f
        return None

    def gen_main(self, mode: str):
        self.raw()
        self.w("if __name__ == '__main__':")
        self.indent += 1
        if mode == "test":
            tests = [f for f in self.prog.funcs if f.kind == "测试函数"]
            if not tests:
                raise YyError("工程中没有测试函数。把某子程序的开头关键字改为"
                              "「测试函数」即可。", 1, 1, "")
            self.builtin_call("_yy断言重置", [])
            self.w("yy_assert_reset()")
            for t in tests:
                self.w(t.name + "()")
            self.w("print('[测试] 共', yy_assert_total(), '项断言，失败', "
                   "yy_assert_failed(), '项')")
            self.w("sys.exit(1 if yy_assert_failed() > 0 else 0)")
            self._imports.add("sys")
            self.indent -= 1
            return
        entry = self.find_entry()
        if entry is None:
            tests = [f for f in self.prog.funcs if f.kind == "测试函数"]
            if tests:
                raise YyError("工程中没有子程序「程序入口」，只有测试函数。"
                              "请点击工具栏的『测试』按钮执行测试。",
                              tests[0].line, tests[0].col, tests[0].file)
            raise YyError("缺少子程序 程序入口()。程序从 子程序 程序入口() 开始执行。",
                          1, 1, "")
        if entry.ret_type is not None:
            self.builtin_call("到整数", [])
            self.w("sys.exit(yy_to_int(" + entry.name + "()))")
            self._imports.add("sys")
        else:
            self.w(entry.name + "()")
        self.indent -= 1

    # ---------- 汇总 ----------
    def gen(self, mode: str = "run") -> str:
        self.check_supported()
        # 先生成主体（同时收集用到的辅助函数与 import），再拼文件头
        saved, self.out = self.out, []
        self.gen_structs()
        self.gen_globals()
        for f in self.prog.funcs:
            self.gen_func(f)
        self.gen_main(mode)
        body = "\n".join(self.out)
        self.out = saved

        self.raw("# 由「云易IDE」导出：纯正的 Python 3 程序，不依赖任何中文运行库")
        for f in self.prog.files:
            self.raw("# 源文件：" + f)
        self.raw()
        if self._imports:
            order = ["os", "sys", "re", "math", "time", "datetime", "random",
                     "tempfile", "shutil", "subprocess"]
            mods = [m for m in order if m in self._imports]
            mods += sorted(self._imports - set(order))
            self.raw("import " + ", ".join(mods))
            self.raw()
        for h in self._used_helpers:
            self.out.append(_HELPERS[h][0])
            self.raw()
        self.out.append(body)
        return "\n".join(self.out)


def generate_python(prog: ast.Program, mode: str = "run") -> str:
    """Python 后端翻译入口（供「导出Python」使用）。"""
    return PyGen(prog).gen(mode)
