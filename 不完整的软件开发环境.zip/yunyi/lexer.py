# -*- coding: utf-8 -*-
"""云易 词法分析器：把 .yy 源码切成 Token 流。"""
from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from typing import List


class YyError(Exception):
    """带行列位置的编译错误。"""

    def __init__(self, message: str, line: int = 0, col: int = 0, file: str = ""):
        super().__init__(message)
        self.message = message
        self.line = line
        self.col = col
        self.file = file

    def __str__(self) -> str:
        head = (f"文件：{self.file}，" if self.file else "") + f"第 {self.line} 行，第 {self.col} 列"
        return f"{head}：{self.message}"


@dataclass
class Token:
    kind: str          # ident / num / str / sym / newline / eof
    value: object
    line: int
    col: int
    text: str = ""     # 原始文本（如数字、标识符）

    def is_sym(self, *vals) -> bool:
        return self.kind == "sym" and (not vals or self.value in vals)

    def is_kw(self, *vals) -> bool:
        return self.kind == "ident" and (not vals or self.text in vals)

    def __repr__(self):  # pragma: no cover
        return f"Token({self.kind},{self.text!r},{self.line}:{self.col})"


# 会被解释为符号的多字符与单字符
_MULTI_SYMS = ["<<=", ">>=", "...", "->", "==", "!=", "<=", ">=", "&&", "||",
               "+=", "-=", "*=", "/=", "%=", "<<", ">>"]
_SINGLE_SYMS = set("()[]{},+-*/%\\=<>!;:?.")


def _is_cn_letter(ch: str) -> bool:
    if not ch:
        return False
    if ch == "_" or ch.isalpha():
        return True
    if unicodedata.category(ch).startswith(("L", "Nl")):
        return True
    return False


# 全角标点归一化：代码区自动兼容中文输入法标点（字符串内部按原文读取，不受影响）
_FULLWIDTH_MAP = {"，": ",", "、": ",", "（": "(", "）": ")", "：": ":", "；": ";",
                  "！": "!", "？": "?", "。": ".", "“": '"', "”": '"',
                  "‘": "'", "’": "'", "　": " "}


# 扫 asm 块时遇到这些收尾关键字说明本块没写 结束asm（避免把后面的子程序/循环一起吞掉）
_ASM_STOP_KW = {"结束子程序", "结束测试函数", "结束类函数", "结束如果", "结束如果真",
                "结束循环", "结束判断", "结束数据类型", "否则", "否则如果",
                "判断循环尾", "循环判断尾"}


def _read_asm_block(source: str, i: int, line: int, col: int, filename: str):
    """读「asm」块：i 指向行首关键字 asm 之后，line/col 是 asm 的位置。

    块体（直到 结束asm）按**原文**保留 —— 汇编里的 $ / & / @ 等不是云易符号，
    走常规分词会直接报「无法识别的字符」。
    asm 后面可写 Intel 或 AT&T 指定本块的语法，省略则用工程设置里的汇编语法。
    返回 (汇编代码, 方言, 结束后的下标, 结束后的行号, 结束后的列号)。"""
    n = len(source)
    j = i
    while j < n and source[j] in " \t":
        j += 1
    k = j
    while k < n and source[k] not in "\r\n":
        k += 1
    rest = source[j:k].strip()
    dialect = ""
    if rest and not rest.startswith("'") and not rest.startswith("//"):
        r = rest.upper().replace(" ", "")
        if r == "INTEL":
            dialect = "intel"
        elif r in ("AT&T", "ATT"):
            dialect = "att"
        else:
            raise YyError("asm 后面只能写 Intel 或 AT&T（省略则用工程设置的汇编语法）",
                          line, col, filename)
    body = []
    p, cur, end_i, end_line, end_col = k, line, -1, line, 1
    while p < n:
        if source[p] == "\r":
            p += 1
            if p < n and source[p] == "\n":
                p += 1
        elif source[p] == "\n":
            p += 1
        cur += 1
        q = p
        while q < n and source[q] not in "\r\n":
            q += 1
        raw = source[p:q].strip()
        if raw == "结束asm" or raw.lower() == "结束asm" or raw == "结束汇编":
            end_i, end_line, end_col = q, cur, (q - p) + 1
            break
        if raw in _ASM_STOP_KW:      # 已经跑出子程序 / 循环等外层块：块没写 结束asm
            raise YyError(f"asm 块缺少 结束asm（遇到 {raw}）", cur, 1, filename)
        body.append(raw)
        p = q
    if end_i < 0:
        raise YyError("asm 块缺少 结束asm", line, col, filename)
    return "\n".join(body), dialect, end_i, end_line, end_col


def tokenize(source: str, filename: str = "") -> List[Token]:
    tokens: List[Token] = []
    line = 1
    col = 1
    i = 0
    n = len(source)

    def pos() -> tuple:
        return line, col

    while i < n:
        ch = source[i]
        # 全角标点归一化（字符串/注释内部在后续分支按原文读取，不受影响）
        ch = _FULLWIDTH_MAP.get(ch, ch)

        # 换行
        if ch == "\r":
            if i + 1 < n and source[i + 1] == "\n":
                i += 1
            tokens.append(Token("newline", "\n", line, col))
            line += 1
            col = 1
            i += 1
            continue
        if ch == "\n":
            tokens.append(Token("newline", "\n", line, col))
            line += 1
            col = 1
            i += 1
            continue

        # 空白
        if ch in " \t\f\v":
            i += 1
            col += 1
            continue

        # 注释
        if ch == "/" and i + 1 < n and source[i + 1] == "/":
            while i < n and source[i] not in "\r\n":
                i += 1
                col += 1
            continue
        if ch == "'":
            while i < n and source[i] not in "\r\n":
                i += 1
                col += 1
            continue
        if ch == "/" and i + 1 < n and source[i + 1] == "*":
            start_line, start_col = pos()
            i += 2
            col += 2
            while i < n:
                if source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                    i += 2
                    col += 2
                    break
                if source[i] == "\n":
                    line += 1
                    col = 1
                else:
                    col += 1
                i += 1
            else:
                raise YyError("块注释 /* 未闭合", start_line, start_col, filename)
            continue

        # 字符串（支持转义 \n \t \\ \" \r \0）
        if ch == '"':
            sl, sc = pos()
            i += 1
            col += 1
            buf: List[str] = []
            closed = False
            while i < n:
                c = source[i]
                if c == '"' or c in "“”":        # 全角引号同样作为字符串边界
                    closed = True
                    i += 1
                    col += 1
                    break
                if c == "\r" or c == "\n":
                    break
                if c == "\\":
                    if i + 1 >= n:
                        break
                    e = source[i + 1]
                    mapping = {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "0": "\0"}
                    buf.append(mapping.get(e, e))
                    i += 2
                    col += 2
                    continue
                buf.append(c)
                i += 1
                col += 1
            if not closed:
                raise YyError("字符串未闭合（缺少右引号 \"）", sl, sc, filename)
            tokens.append(Token("str", "".join(buf), sl, sc))
            continue

        # 数字
        if ch.isdigit() or (ch == "." and i + 1 < n and source[i + 1].isdigit()):
            sl, sc = pos()
            start = i
            is_float = False
            if ch == "0" and i + 1 < n and source[i + 1] in "xX":
                i += 2
                col += 2
                while i < n and (source[i] in "0123456789abcdefABCDEF_"):
                    i += 1
                    col += 1
                raw = source[start:i]
                try:
                    val = int(raw, 16)
                except ValueError:
                    raise YyError(f"十六进制数格式错误：{raw}", sl, sc, filename)
                tokens.append(Token("num", val, sl, sc, raw))
                continue
            while i < n and (source[i].isdigit() or source[i] == "_"):
                i += 1
                col += 1
            if i < n and source[i] == ".":
                is_float = True
                i += 1
                col += 1
                while i < n and (source[i].isdigit() or source[i] == "_"):
                    i += 1
                    col += 1
            if i < n and source[i] in "eE":
                is_float = True
                i += 1
                col += 1
                if i < n and source[i] in "+-":
                    i += 1
                    col += 1
                while i < n and source[i].isdigit():
                    i += 1
                    col += 1
            raw = source[start:i].replace("_", "")
            try:
                val = float(raw) if is_float else int(raw)
            except ValueError:
                raise YyError(f"数字格式错误：{raw}", sl, sc, filename)
            tokens.append(Token("num", val, sl, sc, raw))
            continue

        # 标识符 / 关键字
        if _is_cn_letter(ch):
            sl, sc = pos()
            start = i
            while i < n and (_is_cn_letter(source[i]) or source[i].isdigit()):
                i += 1
                col += 1
            text = source[start:i]
            # 行首的 asm：整块读到 结束asm，块体按原文保留（见 _read_asm_block）
            if text == "asm" and ((not tokens) or tokens[-1].kind == "newline"):
                code, dialect, i, line, col = _read_asm_block(source, i, sl, sc, filename)
                tokens.append(Token("asm", {"code": code, "dialect": dialect},
                                    sl, sc, "asm"))
                continue
            tokens.append(Token("ident", text, sl, sc, text))
            continue

        # 常量引用：#名称（核心库/用户常量在使用时必须加 # 前缀）
        if ch == "#":
            sl, sc = pos()
            if i + 1 >= n or not _is_cn_letter(source[i + 1]):
                raise YyError("「#」后应跟常量名（如 #颜色_红）", line, col, filename)
            i += 1
            col += 1
            start = i
            while i < n and (_is_cn_letter(source[i]) or source[i].isdigit()):
                i += 1
                col += 1
            name = source[start:i]
            tokens.append(Token("hashconst", name, sl, sc, "#" + name))
            continue

        # 多字符符号
        matched = False
        for ms in _MULTI_SYMS:
            if source.startswith(ms, i):
                tokens.append(Token("sym", ms, line, col, ms))
                i += len(ms)
                col += len(ms)
                matched = True
                break
        if matched:
            continue

        # 单字符符号
        if ch in _SINGLE_SYMS:
            tokens.append(Token("sym", ch, line, col, ch))
            i += 1
            col += 1
            continue

        # 未知字符（常见的全角标点给出友好提示）
        _全角提示 = {"（": ")", "）": ")", "，": ",", "。": ".", "：": ":",
                     "；": ";", "“": '"', "”": '"', "‘": "'", "’": "'"}
        if ch in _全角提示:
            raise YyError(f"不能使用全角符号 {ch!r}，请改用半角 {_全角提示[ch]!r}",
                          line, col, filename)
        raise YyError(f"无法识别的字符：{ch!r}", line, col, filename)

    tokens.append(Token("eof", None, line, col, "<eof>"))
    return tokens
