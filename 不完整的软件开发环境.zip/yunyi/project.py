# -*- coding: utf-8 -*-
"""云易工程管理：.yyproj 工程文件、源码发现与新建工程。"""
from __future__ import annotations
import json
import os
import re
from typing import List, Optional

from . import codec
from .lexer import YyError

PROJ_EXT = ".yyproj"
SRC_EXT = ".yy"

TEMPLATE_MAIN = '''\' 云易 示例工程 —— 控制台程序
\' 在 IDE 中点击「运行」，本文件会被翻译成 C++ 并由 MinGW 编译执行。
\'

\' 程序入口：从这里开始执行
子程序 程序入口() 整数型
    变量 整数型 总和
    计次循环 (i, 1, 5)
        总和 = 总和 + i
    结束循环

    输出("1 到 5 的和 =", 到文本(总和))
    输出("当前时间 =", 取当前时间())

    变量 文本型 猜
    输出("请输入您的名字：")
    猜 = 输入文本()
    输出("你好，", 猜, "！")

    返回 (0)
结束子程序
'''


TEMPLATE_WINDOW = '''\' 云易 示例工程 —— 窗口程序
\' 窗口程序：编译时链接 -mwindows，不弹出命令行窗口；
\' 因此「输出 / 输入文本」不可用，提示信息请用 信息框，或写文件 / 写到控件。
\'
\' 需要完整的 Win32 窗口（按钮 + 编辑框 + 消息循环），
\' 请参考工作区中的示例工程「Windows窗口示例」（用 API 声明创建窗口）。

子程序 程序入口() 整数型
    信息框("你好", "这是一个窗口程序（不弹出命令行窗口）")
    返回 (0)
结束子程序
'''

TEMPLATE_DLL = '''\' 云易 示例工程 —— DLL 程序（动态链接库）
\' DLL 程序：编译生成 .dll；只有「导出子程序」才会导出给其它程序调用。
\' 编译后会生成「导出函数清单」：build\\<模式>\\<工程名>.导出函数.txt
\'   （含每个导出函数的两个导出名与调用示例）
\'
\' 调用方写法（云易）：
\'     API 整数型 算加法(整数型 a, 整数型 b) 在库 "工程名.dll"
\' 调用方写法（C/C++）：每个导出函数有两个名字 ——
\'     WINAPI 名：x86 为 "算加法@8"（__stdcall，保留 @参数字节数 装饰）；x64 为 "算加法"
\'     cdecl 名 ："算加法_cdecl"（C/C++ 默认调用约定用它）
\'     前者给 Win32 / VB6 / 易语言 / Delphi / 云易 用，后者给 C/C++ 默认约定用
\' 说明：本工程没有「程序入口」——纯 DLL 模块；点「编译」生成 DLL，点「测试」自测。

\' ===== 导出函数（会自动导出；可加「导出名 "Add"」指定英文导出名） =====
导出子程序 算加法(整数型 a, 整数型 b) 整数型
    返回(a + b)
结束子程序

导出子程序 算乘法(整数型 a, 整数型 b) 整数型
    返回(a * b)
结束子程序


\' ===== 内部子程序：不导出，只在 DLL 内部使用 =====
子程序 辅助计算(整数型 a) 整数型
    返回(a * 2)
结束子程序


\' ===== 自测：点「测试」（F7）执行 =====
测试函数 自测导出函数()
    断言(算加法(2, 3) = 5, "算加法(2, 3) 应为 5")
    断言(算乘法(6, 7) = 42, "算乘法(6, 7) 应为 42")
结束子程序
'''

# 程序类型 → 新建工程时的示例模板
TEMPLATES = {"console": TEMPLATE_MAIN, "window": TEMPLATE_WINDOW, "dll": TEMPLATE_DLL}

SUBSYS_LABEL = {"console": "控制台程序", "window": "窗口程序", "dll": "DLL程序"}

ARCH_LABEL = {"x64": "x64（64 位）", "x86": "x86（32 位）"}
MODE_LABEL = {"debug": "调试版", "release": "发布版"}

KEYS = ("name", "version", "target", "extraArgs", "linkArgs",
        "includeDirs", "libDirs", "libs", "defines", "subsystem", "icon",
        "arch", "mode", "asmSyntax")

# 内联汇编语法（asm 裸写汇编块用）：AT&T（GCC 默认）或 Intel
ASM_SYNTAX_LABEL = {"AT&T": "AT&T", "Intel": "Intel"}


def default_project_json(name: str, subsystem: str = "") -> dict:
    """工程默认配置。subsystem / arch / mode 为空表示「尚未标记」——打开时按内容自动识别再写回。"""
    return {"type": "yunyi-project", "name": name, "version": "1.0",
            "target": name, "extraArgs": "", "linkArgs": "",
            # 链接器 / 库 / SDK：头文件目录、库目录、要链接的库名
            "includeDirs": "", "libDirs": "", "libs": "", "defines": "",
            # 程序类型：console 控制台程序 / window 窗口程序 / dll DLL程序
            "subsystem": subsystem,
            # 目标架构 / 编译模式：空表示尚未标记，打开工程时自动识别写回
            "arch": "", "mode": "",
            # 内联汇编语法：AT&T（GCC 默认，寄存器 %eax、立即数 $1）/ Intel
            "asmSyntax": "AT&T"}


def list_projects(workspace: str) -> List[dict]:
    """列出工作区内所有工程（含 .yyproj 的目录），并带上工程标记
    （程序类型 / 目标架构 / 编译模式：已标记的用标记，未标记的自动识别）。"""
    out = []
    if not os.path.isdir(workspace):
        return out
    for name in sorted(os.listdir(workspace)):
        d = os.path.join(workspace, name)
        pj = os.path.join(d, name + PROJ_EXT)
        if os.path.isdir(d) and os.path.isfile(pj):
            try:
                sub = detect_subsystem(d)
            except Exception:
                sub = "console"
            try:
                arch = detect_arch(d)
            except Exception:
                arch = "x64"
            try:
                mode = detect_mode(d)
            except Exception:
                mode = "debug"
            out.append({"name": name, "path": d,
                        "subsystem": sub, "subsystemLabel": SUBSYS_LABEL.get(sub, sub),
                        "arch": arch, "archLabel": ARCH_LABEL.get(arch, arch),
                        "mode": mode, "modeLabel": MODE_LABEL.get(mode, mode)})
    return out


def find_project_dir(path: str) -> Optional[str]:
    """给定任意文件/目录，找到所属工程目录。"""
    p = path
    while True:
        if os.path.isdir(p):
            for f in os.listdir(p):
                if f.endswith(PROJ_EXT):
                    return p
            parent = os.path.dirname(p)
            if parent == p:
                return None
            p = parent
            continue
        parent = os.path.dirname(p)
        if parent == p:
            return None
        p = parent


def load_project(proj_dir: str) -> dict:
    """读取工程配置（目录不存在同名 .yyproj 则自动创建默认配置）。"""
    name = os.path.basename(proj_dir.rstrip("/\\"))
    pj = os.path.join(proj_dir, name + PROJ_EXT)
    if os.path.isfile(pj):
        try:
            with codec.open_text("project", pj, "r") as fp:
                data = json.load(fp)
        except Exception:
            data = {}
    else:
        data = {}
    cfg = default_project_json(name)
    if isinstance(data, dict):
        for k in KEYS:
            if k in data and isinstance(data[k], str):
                cfg[k] = data[k]
    cfg["dir"] = proj_dir
    cfg["projFile"] = pj
    return cfg


def list_sources(proj_dir: str) -> List[str]:
    """工程内所有 .yy 源码（相对路径，排序）。"""
    out = []
    if os.path.isdir(proj_dir):
        for f in sorted(os.listdir(proj_dir)):
            if f.endswith(SRC_EXT):
                out.append(f)
    return out


def create_project(workspace: str, name: str, subsystem: str = "console",
                   arch: str = "", mode: str = "") -> dict:
    """新建工程：subsystem = console / window / dll，决定 .yyproj 标记与 main.yy 示例模板。
    arch（x64/x86）与 mode（debug/release）可一并指定；留空表示「尚未标记」，
    打开工程时按编译产物自动识别再写回。"""
    if not re_safe_name(name):
        raise YyError("工程名只能使用中英文、数字与下划线", 0, 0)
    sub = (subsystem or "console").strip().lower()
    if sub not in TEMPLATES:
        sub = "console"
    arch = (arch or "").strip().lower()
    if arch not in ARCH_LABEL:
        arch = ""
    mode = (mode or "").strip().lower()
    if mode not in MODE_LABEL:
        mode = ""
    d = os.path.join(workspace, name)
    if os.path.exists(d):
        raise YyError(f"已存在同名目录：{d}", 0, 0)
    os.makedirs(d)
    cfg = default_project_json(name, sub)
    cfg["arch"], cfg["mode"] = arch, mode
    with codec.open_text("project", os.path.join(d, name + PROJ_EXT), "w") as fp:
        json.dump(cfg, fp, ensure_ascii=False, indent=2)
    with codec.open_text("source", os.path.join(d, "main.yy"), "w") as fp:
        fp.write(TEMPLATES[sub])
    return {"name": name, "path": d,
            "subsystem": sub, "subsystemLabel": SUBSYS_LABEL.get(sub, sub),
            "arch": arch, "archLabel": ARCH_LABEL.get(arch, arch),
            "mode": mode, "modeLabel": MODE_LABEL.get(mode, mode)}


# 自动识别程序类型的源码线索
_WINDOW_HINTS = ("RegisterClassExW", "RegisterClassW", "CreateWindowExW", "CreateWindowW",
                 "DefWindowProcW", "GetMessageW", "TranslateMessage", "DispatchMessageW",
                 "WndProc")


def _read_all_sources(proj_dir: str) -> str:
    parts = []
    for f in list_sources(proj_dir):
        try:
            with codec.open_text("source", os.path.join(proj_dir, f), "r",
                                 errors="replace") as fp:
                parts.append(fp.read())
        except Exception:
            pass
    return "\n".join(parts)


def detect_subsystem(proj_dir: str, cfg: dict = None) -> str:
    """判断工程程序类型：工程里已标记则用它，否则按链接参数与源码线索自动识别。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    sub = (cfg.get("subsystem") or "").strip().lower()
    if sub in SUBSYS_LABEL:
        return sub
    link = (cfg.get("linkArgs") or "").lower()
    if "-shared" in link:
        return "dll"
    if "-mwindows" in link or "subsystem,windows" in link:
        return "window"
    text = _read_all_sources(proj_dir)
    if "导出子程序" in text:
        return "dll"
    if any(k in text for k in _WINDOW_HINTS):
        return "window"
    return "console"


def _find_build_binaries(proj_dir: str):
    """扫描 build/<mode>/ 目录下的编译产物（.exe / .dll），返回 [(mode, arch, mtime)] 列表。"""
    out = []
    build_dir = os.path.join(proj_dir, "build")
    if not os.path.isdir(build_dir):
        return out
    for mode in ("debug", "release"):
        md = os.path.join(build_dir, mode)
        if not os.path.isdir(md):
            continue
        for f in os.listdir(md):
            if f.endswith(".exe") or f.endswith(".dll"):
                arch = "x86" if "_x86" in f else "x64"
                try:
                    mt = os.path.getmtime(os.path.join(md, f))
                except Exception:
                    mt = 0
                out.append((mode, arch, mt))
    return out


def detect_arch(proj_dir: str, cfg: dict = None) -> str:
    """判断工程目标架构：工程配置已标记则用它；否则按编译产物判断；最后回退到全局设置。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    arch = (cfg.get("arch") or "").strip().lower()
    if arch in ARCH_LABEL:
        return arch
    # 按编译产物判断：取最近修改的 exe/dll，看文件名是否含 _x86
    bins = _find_build_binaries(proj_dir)
    if bins:
        bins.sort(key=lambda t: t[2], reverse=True)
        return bins[0][1]
    # 回退到全局设置
    try:
        from . import toolchain
        return toolchain.get_arch()
    except Exception:
        return "x64"


def detect_mode(proj_dir: str, cfg: dict = None) -> str:
    """判断工程编译模式：工程配置已标记则用它；否则按编译产物判断
    （哪个 build 目录有更新产物）；最后回退到全局设置（上次使用的模式）。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    mode = (cfg.get("mode") or "").strip().lower()
    if mode in MODE_LABEL:
        return mode
    bins = _find_build_binaries(proj_dir)
    if bins:
        bins.sort(key=lambda t: t[2], reverse=True)
        return bins[0][0]
    # 回退到全局设置
    try:
        from . import toolchain
        return toolchain.get_mode()
    except Exception:
        return "debug"


def ensure_subsystem(proj_dir: str, cfg: dict = None):
    """打开工程时调用：已标记则沿用；未标记则自动识别并写回 .yyproj（打上标记）。
    返回 (程序类型, 是否本次自动识别)。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    sub = (cfg.get("subsystem") or "").strip().lower()
    if sub in SUBSYS_LABEL:
        return sub, False
    sub = detect_subsystem(proj_dir, cfg)
    try:
        merged = dict(cfg)
        merged["subsystem"] = sub
        save_project_config(proj_dir, merged)
    except Exception:
        pass
    cfg["subsystem"] = sub
    return sub, True


def ensure_arch(proj_dir: str, cfg: dict = None):
    """打开工程时调用：已标记则沿用；未标记则自动识别并写回 .yyproj（打上标记）。
    返回 (架构, 是否本次自动识别)。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    arch = (cfg.get("arch") or "").strip().lower()
    if arch in ARCH_LABEL:
        return arch, False
    arch = detect_arch(proj_dir, cfg)
    try:
        merged = dict(cfg)
        merged["arch"] = arch
        save_project_config(proj_dir, merged)
    except Exception:
        pass
    cfg["arch"] = arch
    return arch, True


def ensure_mode(proj_dir: str, cfg: dict = None):
    """打开工程时调用：已标记则沿用；未标记则自动识别并写回 .yyproj（打上标记）。
    返回 (模式, 是否本次自动识别)。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    mode = (cfg.get("mode") or "").strip().lower()
    if mode in MODE_LABEL:
        return mode, False
    mode = detect_mode(proj_dir, cfg)
    try:
        merged = dict(cfg)
        merged["mode"] = mode
        save_project_config(proj_dir, merged)
    except Exception:
        pass
    cfg["mode"] = mode
    return mode, True


def resolve_arch(proj_dir: str, cfg: dict = None) -> str:
    """编译时使用的目标架构：工程标记优先 → 编译产物/全局自动识别 → 全局设置。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    arch = (cfg.get("arch") or "").strip().lower()
    if arch in ARCH_LABEL:
        return arch
    if os.path.isdir(proj_dir):
        return detect_arch(proj_dir, cfg)
    try:
        from . import toolchain
        return toolchain.get_arch()
    except Exception:
        return "x64"


def resolve_mode(proj_dir: str, cfg: dict = None) -> str:
    """编译时使用的编译模式：工程标记优先 → 编译产物/全局自动识别 → 全局设置。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    mode = (cfg.get("mode") or "").strip().lower()
    if mode in MODE_LABEL:
        return mode
    if os.path.isdir(proj_dir):
        return detect_mode(proj_dir, cfg)
    try:
        from . import toolchain
        return toolchain.get_mode()
    except Exception:
        return "debug"


def apply_project_env(proj_dir: str, cfg: dict = None) -> dict:
    """编译 / 翻译前调用：确保工程标记（程序类型 / 架构 / 模式）已打上（未标记则自动识别并写回），
    并把工程架构同步到全局设置。

    为什么要同步全局：编译器（g++ 选 mingw32/mingw64）、Qt / Sciter 运行库部署、代码生成（导出名装饰）
    与类库过滤（qt / qt_x86、sciter / sciter_x86）都读 toolchain.get_arch()；同步后整条流水线才按「本工程的架构」工作，
    命令行 / 构建脚本 / CI 等没有走 IDE「载入工程」的入口也能拿到正确架构。
    返回 {"subsystem", "arch", "mode"}。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    sub, _ = ensure_subsystem(proj_dir, cfg)
    arch, _ = ensure_arch(proj_dir, cfg)
    mode, _ = ensure_mode(proj_dir, cfg)
    try:
        from . import toolchain
        if toolchain.get_arch() != arch:
            toolchain.save_settings({"arch": arch})
    except Exception:
        pass
    cfg["subsystem"], cfg["arch"], cfg["mode"] = sub, arch, mode
    return {"subsystem": sub, "arch": arch, "mode": mode}


def resolve_subsystem(proj_dir: str, cfg: dict = None) -> str:
    """编译时使用的程序类型：工程配置优先 → 自动识别 → 全局设置（环境设置里的默认值）。"""
    cfg = cfg if cfg is not None else load_project(proj_dir)
    sub = (cfg.get("subsystem") or "").strip().lower()
    if sub in SUBSYS_LABEL:
        return sub
    if os.path.isdir(proj_dir):
        return detect_subsystem(proj_dir, cfg)
    try:
        from . import toolchain
        return toolchain.get_subsystem()
    except Exception:
        return "console"


def save_project_config(proj_dir: str, cfg: dict) -> dict:
    name = os.path.basename(proj_dir.rstrip("/\\"))
    base = default_project_json(name)
    for k in KEYS:
        if k in cfg and isinstance(cfg[k], str):
            base[k] = cfg[k]
    pj = os.path.join(proj_dir, name + PROJ_EXT)
    with codec.open_text("project", pj, "w") as fp:
        json.dump(base, fp, ensure_ascii=False, indent=2)
    base["dir"] = proj_dir
    base["projFile"] = pj
    return base


def re_safe_name(name: str) -> bool:
    return bool(re.match(r"^[\w\u4e00-\u9fff]+$", name, re.UNICODE)) and not name.startswith(".")
