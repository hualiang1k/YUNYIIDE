# -*- coding: utf-8 -*-
"""构建系统：翻译 → g++ 编译 → EXE；导出 C++；一键发布。"""
from __future__ import annotations
import sys
import datetime
import json
import os
import re
import shutil
import zipfile

from . import codec
from . import codegen as codegen_mod
from . import codegen_py as codegen_py_mod
from . import libauto
from . import native_rt
from . import project as project_mod
from . import toolchain
from .checker import check_program
from .lexer import YyError
from .parser import parse_files

RUNTIME_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runtime")
RUNTIME_HEADER = os.path.join(RUNTIME_DIR, "yunyi_rt.hpp")

# IDE 根目录（yunyi/ 的上一级）与程序「默认图标」：config/ico.ico
# 编译 / 运行(调试) / 测试 / 发布 / 导出C++ 生成的 exe 都会嵌入它；
# 单个工程可在「工程设置 → 程序图标」里换成自己的 .ico。
IDE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    IDE_ROOT = os.path.dirname(os.path.abspath(sys.executable))
ICON_DEFAULT = os.path.join(IDE_ROOT, "config", "ico.ico")

# -- Qt runtime auto-deploy -----------------------------------------------
# Projects using lib/qt.class + lib/qt.api (Qt widget library) need Qt runtime
# DLLs alongside the exe.  Three call sites auto-detect and copy:
#   (1) compile_yunyi()   -- build/run/test  (exe dir: build/<mode>/)
#   (2) release_project() -- publish         (dist dir + zip)
#   (3) export_cpp()      -- export C++      (export dir)
# Detection: generated C++ contains "云易Qt.dll" (all qt.api APIs declare
# their library as "云易Qt.dll").
QT_YYQT_DIR = os.path.join(IDE_ROOT, "tools", "yyqt")
QT_BIN_DIR = os.path.join(IDE_ROOT, "tools", "Qt", "ucrt64", "bin")
QT_PLUGIN_DIR = os.path.join(IDE_ROOT, "tools", "Qt", "ucrt64",
                             "share", "qt6", "plugins", "platforms")
# 32-bit Qt runtime (built from Qt6 source, installed to tools/Qtx86/ucrt32)
QTX86_YYQT_DLL = os.path.join(QT_YYQT_DIR, "\u4e91\u6613Qt_x86.dll")
QTX86_BIN_DIR = os.path.join(IDE_ROOT, "tools", "Qtx86", "ucrt32", "bin")
QTX86_PLUGIN_DIR = os.path.join(IDE_ROOT, "tools", "Qtx86", "ucrt32",
                               "plugins", "platforms")
# MinGW32 runtime DLLs (32-bit Qt DLLs dynamically link to them)
MGW32_BIN_DIR = os.path.join(IDE_ROOT, "tools", "mingw32", "bin")
MGW32_RUNTIME_DLLS = ("libgcc_s_dw2-1.dll", "libstdc++-6.dll", "libwinpthread-1.dll")


def _uses_qt(cpp: str) -> bool:
    """True if the generated C++ references 云易Qt.dll or 云易Qt_x86.dll."""
    return ("\u4e91\u6613Qt.dll" in (cpp or "")
            or "\u4e91\u6613Qt_x86.dll" in (cpp or ""))


def _find_wrapper_dll(dir_path: str, name: str) -> str:
    """在 *dir_path* 里找 *name*（云易Qt.dll / 云易Qt_x86.dll / yysciter*.dll）。

    找不到时再兜一层：这些封装 DLL 是批处理（cmd）编译出来的，批处理本身是
    GBK / UTF-8 而控制台代码页不匹配时，产物名可能被写成**乱码名**
    （例：ÔÆÒ×Qt_x86.dll —— GBK 字节被当成 UTF-8）。把目录里每个名字按
    latin-1 → gbk 还原一次再比对，命中就用它的真实路径 —— 这样即使
    tools 里已经躺着乱码名的 DLL，也照样能正确部署到 exe 旁边
    （拷过去用的是正确的中文名，程序 LoadLibrary 才找得到）。
    """
    p = os.path.join(dir_path, name)
    if os.path.isfile(p):
        return p
    try:
        names = os.listdir(dir_path)
    except OSError:
        return p
    for n in names:
        # 走 file_name 通道（原先写死 gbk；换语言环境的 Windows 上应该用它的 ANSI 代码页）
        fixed = codec.fix_mojibake(n)
        if fixed.lower() == name.lower():
            return os.path.join(dir_path, n)
    return p


def _deploy_qt_runtime(dest_dir: str, arch: str = "x64") -> int:
    """Copy Qt runtime DLLs to *dest_dir*, return number of files copied.

    Copies (same as tools/yyqt/复制运行库.bat):
      - 云易Qt.dll  (Qt widget C-interface wrapper)
      - Qt6Core/Qt6Gui/Qt6Widgets etc.  (tools/Qt/ucrt64/bin/*.dll)
      - platforms/qwindows.dll  (Qt platform plugin)
    Skips files that already exist with the same size (avoids redundant I/O).
    arch: "x64" uses 64-bit Qt (tools/Qt/ucrt64); "x86" uses 32-bit (tools/Qtx86/ucrt32).
    """
    count = 0

    def _copy(src, dst):
        nonlocal count
        if not os.path.isfile(src):
            return
        if os.path.isfile(dst) and os.path.getsize(src) == os.path.getsize(dst):
            return
        d = os.path.dirname(dst)
        if d:
            os.makedirs(d, exist_ok=True)
        shutil.copy2(src, dst)
        count += 1

    # Select source by architecture.
    # 32-bit wrapper is 云易Qt_x86.dll and stays that name (generated C++ loads
    # "云易Qt_x86.dll" because qt_x86.api declares 在库 "云易Qt_x86.dll").
    # 64-bit wrapper is 云易Qt.dll.
    if arch == "x86":
        # 源文件按名字找，找不到时自动认「乱码名」（见 _find_wrapper_dll）
        yyqt_src = _find_wrapper_dll(QT_YYQT_DIR, os.path.basename(QTX86_YYQT_DLL))
        yyqt_dst_name = "\u4e91\u6613Qt_x86.dll"
        bin_dir = QTX86_BIN_DIR
        plugin_dir = QTX86_PLUGIN_DIR
    else:
        yyqt_src = _find_wrapper_dll(QT_YYQT_DIR, "\u4e91\u6613Qt.dll")
        yyqt_dst_name = "\u4e91\u6613Qt.dll"
        bin_dir = QT_BIN_DIR
        plugin_dir = QT_PLUGIN_DIR
    _copy(yyqt_src, os.path.join(dest_dir, yyqt_dst_name))
    if os.path.isdir(bin_dir):
        for f in os.listdir(bin_dir):
            if f.lower().endswith(".dll"):
                _copy(os.path.join(bin_dir, f), os.path.join(dest_dir, f))
    _copy(os.path.join(plugin_dir, "qwindows.dll"),
          os.path.join(dest_dir, "platforms", "qwindows.dll"))
    # 32-bit: also deploy MinGW32 runtime DLLs (Qt6 DLLs dynamically link to them)
    if arch == "x86":
        for rt in MGW32_RUNTIME_DLLS:
            _copy(os.path.join(MGW32_BIN_DIR, rt), os.path.join(dest_dir, rt))
    return count


# -- Sciter runtime auto-deploy --------------------------------------------
# 用了 Sciter 界面库（lib/sciter.class + lib/sciter.api / sciter_x86.*）的工程，
# exe 同目录需要两个 DLL：
#   yysciter.dll / yysciter_x86.dll  —— 我们的 C 接口封装（tools/yysciter、tools/sciterx86）
#   sciter.dll                        —— Sciter 引擎（**32 位与 64 位是两个不同的文件**）
# 与 Qt 一样在这三处自动侦测并拷贝：
#   (1) compile_yunyi()   —— 运行 / 编译 / 测试（exe 在 build/<模式>/）
#   (2) release_project() —— 发布（dist 目录 + zip）
#   (3) export_cpp()      —— 导出 C++（导出目录）
# 侦测方式：生成的 C++ 里出现 "yysciter.dll" 或 "yysciter_x86.dll"
# （sciter.api / sciter_x86.api 的「在库」声明的库名）。
SCITER_DIR = os.path.join(IDE_ROOT, "tools", "yysciter")
SCITERX86_DIR = os.path.join(IDE_ROOT, "tools", "sciterx86")
# Sciter 引擎：SDK 自带的 x64 / x32 两份 sciter.dll（x86 工程必须用 x32 那份）
SCITER_ENGINE = {
    "x64": os.path.join(IDE_ROOT, "tools", "sciter", "bin", "windows", "x64", "sciter.dll"),
    "x86": os.path.join(IDE_ROOT, "tools", "sciter", "bin", "windows", "x32", "sciter.dll"),
}


def _uses_sciter(cpp: str) -> bool:
    """生成的 C++ 是否用到 Sciter 界面库（看 sciter.api / sciter_x86.api 的库名）。"""
    t = cpp or ""
    return ("yysciter.dll" in t) or ("yysciter_x86.dll" in t)


def _deploy_sciter_runtime(dest_dir: str, arch: str = "x64") -> int:
    """把 Sciter 运行库拷到 *dest_dir*（exe 同目录），返回拷贝的文件数。

    拷两样（与 tools/yysciter|sciterx86/复制运行库.bat 一致）：
      · 封装 DLL：x64 → yysciter.dll；x86 → yysciter_x86.dll
        （名字必须与 lib/sciter(.|_x86.)api 里「在库」写的一致，否则 LoadLibrary 失败）
      · 引擎：    tools\\sciter\\bin\\windows\\x64|x32\\sciter.dll

    架构必须严格匹配：把 64 位的 sciter.dll 拷给 32 位 exe 会加载失败。
    已存在且大小相同的文件跳过（避免重复 I/O）。
    """
    count = 0

    def _copy(src, dst):
        nonlocal count
        if not os.path.isfile(src):
            return
        if os.path.isfile(dst) and os.path.getsize(src) == os.path.getsize(dst):
            return
        d = os.path.dirname(dst)
        if d:
            os.makedirs(d, exist_ok=True)
        shutil.copy2(src, dst)
        count += 1

    wrap_dir = SCITERX86_DIR if arch == "x86" else SCITER_DIR
    wrap_name = "yysciter_x86.dll" if arch == "x86" else "yysciter.dll"
    wrap_src = _find_wrapper_dll(wrap_dir, wrap_name)   # 找不到时也认「乱码名」
    _copy(wrap_src, os.path.join(dest_dir, wrap_name))  # 目标名固定为正确的中文/英文名
    _copy(SCITER_ENGINE.get(arch, SCITER_ENGINE["x64"]),
          os.path.join(dest_dir, "sciter.dll"))
    return count


def find_windres(gxx: str = "") -> str:
    """定位资源编译器 windres：优先与 g++ 同目录（同一套 MinGW）→ 系统 PATH。"""
    if gxx:
        p = os.path.join(os.path.dirname(gxx), "windres.exe")
        if os.path.isfile(p):
            return p
    return shutil.which("windres") or ""


def resolve_icon(proj_dir: str, cfg: dict) -> str:
    """该工程要嵌入的程序图标：
    工程设置 icon（绝对路径 / 以工程目录为基准的相对路径）→ 默认 config/ico.ico → 无。"""
    cfg = cfg or {}
    p = (cfg.get("icon") or "").strip().strip('"')
    if p:
        cand = p if os.path.isabs(p) else os.path.join(proj_dir, p)
        if os.path.isfile(cand):
            return cand
    return ICON_DEFAULT if os.path.isfile(ICON_DEFAULT) else ""


def build_icon_object(icon: str, build_root: str, gxx: str, result: dict) -> str:
    """把 .ico 编成资源目标文件（windres），返回 .o 路径（失败返回 ""）。

    生成物都放在编译输出目录（build/<模式>）里，随「清理构建」一并删除：
        app_icon.ico  图标副本（源路径可能带中文 / 空格，副本用固定英文名最稳）
        app.rc        资源脚本：1 ICON "app_icon.ico"
        app_icon.o    编好的资源目标文件（g++ 链接时带上它即可嵌入图标）

    图标只是锦上添花：找不到 windres、.ico 不合法等任何失败都只记一条提示，
    绝不阻断正常编译。"""
    if not icon:
        return ""
    windres = find_windres(gxx)
    if not windres:
        result["messages"].append({
            "kind": "warning",
            "text": "未找到 windres（图标资源编译器），本次编译未嵌入程序图标。",
            "file": "", "line": 0, "col": 0})
        return ""
    try:
        os.makedirs(build_root, exist_ok=True)
        shutil.copyfile(icon, os.path.join(build_root, "app_icon.ico"))
        # 资源脚本用 ASCII 写（注释也用英文）：windres 对本地代码页/UTF-8 混排不敏感，
        # 路径写成相对名（app_icon.ico），避免中文与空格路径带来的解析问题
        codec.write("resource", os.path.join(build_root, "app.rc"),
                    '/* auto-generated by Yunyi IDE: program icon */\n'
                    '1 ICON "app_icon.ico"\n')
        obj = os.path.join(build_root, "app_icon.o")
        if os.path.isfile(obj):
            os.remove(obj)
        code, so, se = toolchain.run([windres, "-i", "app.rc", "-o", "app_icon.o"],
                                     cwd=build_root)
        if code == 0 and os.path.isfile(obj):
            return obj
        detail = codec.decode("windres", (so or b"") + (se or b""))
        detail = " ".join(x for x in detail.splitlines() if x.strip())[:200]
        result["messages"].append({
            "kind": "warning",
            "text": "图标资源编译失败，本次未嵌入程序图标：" + detail,
            "file": "", "line": 0, "col": 0})
        return ""
    except Exception as e:                       # 图标出问题也不能影响正常编译
        result["messages"].append({
            "kind": "warning", "text": "处理程序图标失败，本次未嵌入：" + str(e),
            "file": "", "line": 0, "col": 0})
        return ""

_GCC_MSG = re.compile(
    r"^(?P<file>.+?\.yy):(?P<line>\d+):(?P<col>\d+):\s*(?P<kind>fatal error|error|warning):\s*(?P<msg>.*)$")


def split_args(text: str) -> list:
    """把配置里的目录/库列表拆成参数数组（支持空格、逗号、分号、换行分隔）。"""
    out = []
    for part in re.split(r"[,;\s]+", (text or "").strip()):
        if part:
            out.append(part)
    return out


def lib_flags(cfg: dict, proj_dir: str) -> tuple:
    """根据工程配置的 头文件目录 / 库目录 / 库名 生成 (include 参数, 链接参数)。"""
    inc, link = [], []
    for d in split_args(cfg.get("includeDirs")):
        inc += ["-I", d if os.path.isabs(d) else os.path.join(proj_dir, d)]
    for d in split_args(cfg.get("libDirs")):
        link += ["-L", d if os.path.isabs(d) else os.path.join(proj_dir, d)]
    for name in split_args(cfg.get("libs")):
        link += [name if name.startswith("-") else "-l" + name]
    for d in split_args(cfg.get("defines")):
        inc += ["-D", d]
    return inc, link


def _write_dll_manifest(exe_path: str, cfg: dict, mode: str, exports: list, result: dict,
                        arch: str = ""):
    """DLL 程序：生成「导出函数清单」文件（列出导出名/签名/调用示例），
    并把导出函数信息写入编译消息（界面「输出」与命令行都会显示）。"""
    dll_name = os.path.basename(exe_path)
    man = os.path.join(os.path.dirname(exe_path),
                       os.path.splitext(dll_name)[0] + ".导出函数.txt")
    lines = [
        "# 云易 DLL 导出函数清单",
        "# 程序：" + dll_name,
        "# 工程：" + str(cfg.get("name") or ""),
        "# 架构：" + (arch or toolchain.get_arch()) + "    模式：" + mode
        + "    生成：" + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "# 导出函数：" + str(len(exports)) + " 个（每个函数导出两个名字）",
        "# 调用约定：",
        "#   · WINAPI 名（__stdcall）= Win32 / VB6 / 易语言 / Delphi / 云易 用它",
        "#       i386 保留规范的 @参数字节数 装饰（如 Add@8）；x64 只有一种调用约定、没有装饰（Add）",
        "#   · <名字>_cdecl（Add_cdecl）= cdecl 约定，C/C++ 默认调用约定用它（两个架构都是平名）",
        "",
    ]
    if exports:
        lines.append("序号\tWINAPI 名(__stdcall)\tcdecl 别名\t云易子程序\t签名")
        for i, e in enumerate(exports, 1):
            lines.append("%d\t%s\t%s\t%s\t%s" % (
                i, e.get("winapi") or e["name"], e.get("cdecl") or "—",
                e["cn"], e["signature"]))
        lines += ["", "# 调用示例（云易）：把下面几行抄进调用方的 .yy 文件即可",
                  "#   （云易的「API」声明按 WINAPI 调用：i386 命中带 @参数字节数 装饰的那一列）"]
        for e in exports:
            lines.append('API %s %s(%s) 在库 "%s,%s"'
                         % (e["ret"], e["name"], ", ".join(e["apiParams"]),
                            dll_name, e["name"]))
            if e["byref"]:
                lines.append("#   注意：" + e["name"] + " 含「传址」参数（指针传递）")
        e0 = exports[0]
        c_ret = "void" if e0["ret"] == "空" else codegen_mod._API_TYPE.get(e0["ret"], "void *")
        c_ps = ", ".join(e0.get("cParams") or []) or "void"
        wa0 = e0.get("winapi") or e0["name"]
        lines += ["", "# 调用示例（C / C++ 按名调用）：",
                  '#   HMODULE h = LoadLibraryW(L"%s");' % dll_name,
                  "#   · WINAPI 约定（VB6 / 易语言 / Delphi / 声明 __stdcall 的 C/C++）：",
                  "#     typedef %s (__stdcall *FN)(%s);" % (c_ret, c_ps),
                  '#     FN f = (FN)GetProcAddress(h, "%s");' % wa0,
                  "#   · cdecl 别名（C/C++ 默认调用约定，不加 __stdcall）：",
                  "#     typedef %s (*FN2)(%s);" % (c_ret, c_ps),
                  '#     FN2 g = (FN2)GetProcAddress(h, "%s");' % (e0.get("cdecl") or e0["name"])]
    else:
        lines.append("（本 DLL 没有导出函数：请在源码里用「导出子程序」声明导出函数）")
    try:
        with codec.open_text("artifact", man, "w", newline="") as fp:
            fp.write("\n".join(lines) + "\n")
    except Exception:
        return
    wa_names = "、".join((e.get("winapi") or e["name"]) for e in exports)
    result["messages"].append({
        "kind": "info", "file": "", "line": 0, "col": 0,
        "text": "DLL 导出函数（%d 个）WINAPI 名（__stdcall）：%s" % (len(exports), wa_names or "无")})
    cd_names = "、".join(e["cdecl"] for e in exports if e.get("cdecl"))
    if cd_names:
        result["messages"].append({
            "kind": "info", "file": "", "line": 0, "col": 0,
            "text": "同一批函数的 cdecl 别名（C/C++ 默认约定）：%s" % cd_names})
    result["messages"].append({
        "kind": "info", "file": "", "line": 0, "col": 0,
        "text": "导出函数清单：" + man})
    result["exportFile"] = man


def translate(proj_dir: str, cfg: dict = None, target: str = "run",
              mode: str = "debug", native: bool = False,
              clean: bool = False) -> dict:
    """只做翻译：语法 → 语义 → 生成 C++，并写入 build/<mode>/main_gen.cpp。

    native=True 时生成「原生 C++」：类型/内置函数为英文标准写法、Windows API 静态调用，
    不再依赖中文运行库 yunyi_rt.hpp —— 供「导出纯正 C++」使用。
    clean=True 去掉 #line 与机器注释（纯正 C++ 风格）。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    # 工程标记（程序类型 / 架构 / 模式）：未标记的工程按内容与编译产物自动识别并写回 .yyproj，
    # 并把工程架构同步到全局设置 —— 代码生成（导出名装饰）、编译器选择、Qt 运行库部署都读全局架构
    try:
        project_mod.apply_project_env(proj_dir, cfg)
    except Exception:
        pass
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    sources = project_mod.list_sources(proj_dir)
    result = {"ok": False, "messages": [], "phase": "翻译", "cpp": "",
              "genPath": "", "mode": mode, "target": target, "artifacts": {}}

    if not sources:
        result["messages"].append({"kind": "error", "text": "工程中没有 .yy 源码文件",
                                   "file": "", "line": 0, "col": 0})
        return result

    files = []
    for f in sources:
        p = os.path.join(proj_dir, f)
        try:
            with codec.open_text("source", p, "r") as fp:
                text = fp.read()
        except Exception as e:
            result["messages"].append({"kind": "error", "text": f"读取 {f} 失败：{e}",
                                       "file": f, "line": 0, "col": 0})
            return result
        files.append((p, text))

    # 类库自动引入：「类」选项卡（lib/*.class）里的数据类型与类函数允许工程直接使用——
    # ① 解析前把类库类型名传给语法分析器（变量/参数/返回类型可直接写类库类型）；
    # ② 解析后把工程用到、但没定义的「数据类型 + 类函数」合并进翻译输入。
    # （AST 级合并，不改动 .yy 文件；运行/编译/测试/发布/导出C++ 共用本入口）
    lib = libauto.load_lib_defs()

    try:
        prog = parse_files(files, extra_types=lib.type_names())
    except YyError as e:
        result["phase"] = "语法检查"
        result["messages"].append({"kind": "error", "text": str(e),
                                   "file": e.file, "line": e.line, "col": e.col})
        return result

    libauto.inject_lib_refs(prog, result["messages"], lib=lib)

    # 工程实际用到的 API 所在 DLL（含「类」选项卡自动注入的声明，
    # 如 云易Qt.dll / yysciter.dll）——「导出C++」据此判断能否走「纯正 C++」模式：
    # 第三方 DLL 的 API 在 windows.h 里没有声明，静态调用无法生成。
    api_dlls = []
    for a in getattr(prog, "apis", None) or []:
        d = getattr(a, "dll", "")
        if d and d not in api_dlls:
            api_dlls.append(d)
    result["apiDlls"] = api_dlls

    errs = check_program(prog)
    if errs:
        result["phase"] = "语义检查"
        for e in errs:
            result["messages"].append({"kind": "error", "text": str(e),
                                       "file": e.file, "line": e.line, "col": e.col})
        return result

    # DLL 程序：收集导出函数（导出名 / 云易子程序名 / 签名），供清单文件与界面显示
    if project_mod.resolve_subsystem(proj_dir, cfg) == "dll":
        exps = []
        for f in prog.funcs:
            if not getattr(f, "export", False):
                continue
            parts, api_args = [], []

            def _arr_suffix(p):
                return "[]" if (p.array_dynamic or p.array_size is not None) else ""

            for p in f.params:
                parts.append(p.type + " " + p.name + _arr_suffix(p)
                             + (" 传址" if p.byref else ""))
                api_args.append(p.type + " " + p.name + _arr_suffix(p)
                                + (" 传址" if p.byref else ""))
            ret = f.ret_type or "空"
            en = getattr(f, "export_name", "") or f.name
            exps.append({
                "name": en, "cn": f.name, "ret": ret,
                "params": parts, "apiParams": api_args,
                "byref": any(p.byref or p.array_dynamic or p.array_size is not None
                             for p in f.params),
                "line": f.line,
                "winapi": codegen_mod.winapi_export_name(f),
                "cdecl": codegen_mod.cdecl_alias_name(f),
                "cParams": ["void *" if (p.byref or p.array_dynamic or p.array_size is not None)
                            else codegen_mod._API_TYPE.get(p.type, "void *")
                            for p in f.params],
                "signature": ret + " " + en + "(" + ", ".join(parts) + ")",
            })
        result["exports"] = exps
        if not exps:
            result["messages"].append({
                "kind": "warning", "file": "", "line": 0, "col": 0,
                "text": "当前是「DLL程序」，但源码里没有「导出子程序」；生成的 DLL 不含导出函数"})

    try:
        gen_mode = ("dll" if (project_mod.resolve_subsystem(proj_dir, cfg) == "dll"
                              and target != "test")
                    else target)
        cpp = codegen_mod.generate_cpp(prog, mode=gen_mode, native=native, clean=clean,
                                       asm_syntax=cfg.get("asmSyntax") or "AT&T")
    except YyError as e:
        result["phase"] = "代码生成"
        result["messages"].append({"kind": "error", "text": str(e),
                                   "file": e.file, "line": e.line, "col": e.col})
        return result

    build_root = os.path.join(proj_dir, "build", mode)
    os.makedirs(build_root, exist_ok=True)
    gen_path = os.path.join(build_root, "main_gen.cpp")
    with codec.open_text("artifact", gen_path, "w") as fp:
        fp.write(cpp)

    result["ok"] = True
    result["cpp"] = cpp
    result["genPath"] = gen_path
    result["artifacts"] = {"genCpp": gen_path, "cpp": cpp}
    result["messages"].append({"kind": "ok", "text": "翻译成功：" + gen_path,
                               "file": "", "line": 0, "col": 0})
    return result


def compile_yunyi(proj_dir: str, cfg: dict, mode: str = "debug",
                  target: str = "run", keep_going: bool = False,
                  native: bool = False, clean: bool = False) -> dict:
    """编译云易工程。
    mode: debug / release
    target: run / test
    native: True 时翻译为「原生 C++」（无中文运行库依赖，供导出用）
    clean: 传给翻译器（导出纯正 C++ 时启用，见 translate）
    返回 dict：ok / messages / log / artifacts
    """
    cfg = cfg or project_mod.load_project(proj_dir)
    # 工程标记：确保程序类型 / 架构 / 模式已打上，并把架构同步到全局（编译器 + Qt 部署 + 代码生成用）
    try:
        project_mod.apply_project_env(proj_dir, cfg)
    except Exception:
        pass
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    sources = project_mod.list_sources(proj_dir)
    result = {"ok": False, "messages": [], "log": "", "phase": "编译",
              "artifacts": {}, "mode": mode, "target": target}

    if not sources:
        result["messages"].append({"kind": "error", "text": "工程中没有 .yy 源码文件",
                                   "file": "", "line": 0, "col": 0})
        return result

    # 1~3) 翻译（语法 → 语义 → 生成 C++）
    # 说明：translate 里的 DLL 导出函数明细（exports）要带出来，
    #       供生成的清单文件与界面「输出」面板列示。
    tr = translate(proj_dir, cfg, target, mode, native=native, clean=clean)
    result["messages"].extend(tr["messages"])
    result["exports"] = tr.get("exports") or []      # DLL 导出函数明细（供界面「输出」列示）
    result["apiDlls"] = tr.get("apiDlls") or []      # 工程 API 所在 DLL（导出纯正模式判定用）
    if not tr["ok"]:
        result["phase"] = tr["phase"]
        result["artifacts"] = tr.get("artifacts") or {}
        return result
    cpp = tr["cpp"]
    gen_path = tr["genPath"]
    build_root = os.path.dirname(gen_path)

    subsys = project_mod.resolve_subsystem(proj_dir, cfg)
    # 「测试」始终编译成 exe（测试要能运行）；「DLL程序」只作用于 运行/编译
    is_dll = (subsys == "dll" and target != "test")
    exe_name = re.sub(r'[^\w\u4e00-\u9fff.-]', "_", cfg.get("target") or "程序")
    # 目标架构取「本工程的标记」（已在上面同步到全局）；x86 产物带 _x86 后缀便于区分
    arch = project_mod.resolve_arch(proj_dir, cfg)
    is_x86 = (arch == "x86")
    if is_x86:
        exe_name = exe_name + "_x86"
    exe_path = os.path.join(build_root, exe_name + (".dll" if is_dll else ".exe"))

    # 4) g++ 编译
    gxx = toolchain.find_gxx()
    if not gxx:
        result["messages"].append({
            "kind": "error",
            "text": "找不到 MinGW g++ 编译器。请在「设置」中填写 g++ 路径，或点击「工具 → 下载/自检工具链」。",
            "file": "", "line": 0, "col": 0})
        return result

    cmd = [gxx, "-std=c++17", "-finput-charset=UTF-8", "-fexec-charset=UTF-8"]
    # 静态链接运行库，让生成的 EXE 无需附带 DLL、可直接分发
    cmd += ["-static", "-static-libgcc", "-static-libstdc++"]
    if mode == "debug":
        cmd += ["-O0", "-g"]
    else:
        # -DNDEBUG：release 版下「是否为调试版()」返回假（运行库据此判断）
        cmd += ["-O2", "-DNDEBUG"]
    cmd += ["-Wall", "-Wextra", "-Wno-unused-parameter"]
    extra = (cfg.get("extraArgs") or "").strip()
    if extra:
        cmd += extra.split()
    # 链接器 / 库 / SDK：用户配置的头文件目录、宏定义、库目录与库名
    inc_flags, lib_flags_ = lib_flags(cfg, proj_dir)
    cmd += inc_flags
    cmd += ["-I", RUNTIME_DIR, gen_path]
    cmd += ["-luser32"]
    if native:
        # 原生模式：按源码里 API「在库」声明自动追加链接库（StrCpyW→shlwapi 等）
        for l in _api_dll_libs(proj_dir, cfg):
            if l not in ("user32", "kernel32"):
                cmd += ["-l" + l]
    cmd += lib_flags_
    link = (cfg.get("linkArgs") or "").strip()
    if link:
        cmd += link.split()
    # 程序类型（工程级）：窗口程序 → GUI 子系统（不弹命令行窗口）；DLL程序 → 生成动态库
    if is_dll:
        # 不传 -Wl,--kill-at：i386 的 __stdcall 导出名保留 @参数字节数 装饰（Add@8）；
        # x64 本就没有装饰。两个架构同一套参数。
        cmd += ["-shared"]
    elif subsys == "window":
        cmd += ["-mwindows"]
    # 4.4) 程序图标：config/ico.ico（工程设置里可换）→ windres 编成资源目标文件一起链接，
    #      生成的 EXE 在资源管理器 / 任务栏里就是这个图标（失败只提示，不影响编译）
    icon = resolve_icon(proj_dir, cfg)
    icon_obj = build_icon_object(icon, build_root, gxx, result)
    if icon_obj:
        cmd += [icon_obj]
    cmd += ["-o", exe_path]

    # 4.5) 编译前清理：输出文件若被上次「运行/测试」的残留进程占用，
    #      链接器会报 Permission denied —— 先自动结束残留进程再编译
    kill_note = toolchain.kill_locked_process(exe_path)
    if kill_note:
        kind = "warning" if kill_note.startswith("已") else "error"
        result["messages"].append({"kind": kind, "text": kill_note,
                                   "file": "", "line": 0, "col": 0})
        result["log"] = (result["log"] or "") + kill_note + "\n"

    code, so, se = toolchain.run(cmd, cwd=proj_dir)
    log_bytes = (se if se else b"") if code != 0 else ((so or b"") + (se or b""))
    # compiler 通道 = 逐行智能解码：gcc 输出里中文路径按 ANSI 代码页、源码标识符回显是
    # UTF-8，混排时整块 decode 一定会坏一半（规则见 yunyi/codec.py 的通道表）
    log = codec.decode("compiler", log_bytes)
    result["log"] = log
    result["messages"].extend(_parse_gcc_log(log, proj_dir))

    artifacts = {"genCpp": gen_path, "cpp": cpp}
    if code == 0 and os.path.isfile(exe_path):
        result["ok"] = True
        result["messages"].append({"kind": "ok", "text": "编译成功：已生成 " + os.path.basename(exe_path),
                                   "file": "", "line": 0, "col": 0})
        if icon_obj:
            result["messages"].append({"kind": "ok",
                                       "text": "已嵌入程序图标：" + os.path.basename(icon),
                                       "file": "", "line": 0, "col": 0})
            artifacts["icon"] = icon
        artifacts["exe"] = exe_path
        if is_dll:
            _write_dll_manifest(exe_path, cfg, mode, tr.get("exports") or [], result, arch)
        # Qt runtime: auto-deploy when the project uses the Qt widget library
        if _uses_qt(cpp):
            n = _deploy_qt_runtime(build_root, arch)
            if n:
                result["messages"].append({"kind": "info",
                    "text": "已自动复制 Qt 运行库（%d 个文件）到编译输出目录。" % n,
                    "file": "", "line": 0, "col": 0})
            else:
                result["messages"].append({"kind": "warning",
                    "text": "工程使用了 Qt 控件库，但未找到 Qt 运行库文件"
                            "（tools/Qt/ 或 tools/yyqt/）。程序可能无法运行。",
                    "file": "", "line": 0, "col": 0})
        # Sciter runtime：用了 Sciter 界面库就把「封装 DLL + 对应架构的引擎」拷过去。
        # 注意：目标文件已存在且大小相同时 _deploy 返回 0（只是没重复拷），
        # 不能据此判定缺失 —— 按目标文件是否真的就位来提示。
        if _uses_sciter(cpp):
            n = _deploy_sciter_runtime(build_root, arch)
            need = ("yysciter_x86.dll" if arch == "x86" else "yysciter.dll", "sciter.dll")
            got = [f for f in need if os.path.isfile(os.path.join(build_root, f))]
            if len(got) == len(need):
                result["messages"].append({"kind": "info",
                    "text": "已自动复制 Sciter 运行库（%d 个文件）到编译输出目录。" % n,
                    "file": "", "line": 0, "col": 0})
            else:
                result["messages"].append({"kind": "warning",
                    "text": "工程使用了 Sciter 界面库，但运行库不全（缺少 "
                            + "、".join(f for f in need if f not in got) + "）。"
                            "请确认 tools/sciterx86（x86 封装）或 tools/yysciter（x64 封装）"
                            "与 tools/sciter/bin/windows/"
                            + ("x32" if arch == "x86" else "x64") + "/sciter.dll 存在。",
                    "file": "", "line": 0, "col": 0})
    else:
        result["messages"].append({"kind": "error", "text": "编译失败，请查看信息。",
                                   "file": "", "line": 0, "col": 0})
    result["artifacts"] = artifacts
    return result


def _parse_gcc_log(log: str, proj_dir: str):
    out = []
    for line in log.splitlines():
        m = _GCC_MSG.match(line.strip())
        if m:
            kind = m.group("kind")
            if kind == "fatal error":
                kind = "error"
            out.append({"kind": kind, "text": m.group("msg"),
                        "file": m.group("file"), "line": int(m.group("line")),
                        "col": int(m.group("col"))})
    return out


def _report(progress, percent: int, text: str):
    """导出进度回调（界面进度条用）；回调自身异常一律吞掉，不影响导出。"""
    if callable(progress):
        try:
            progress(int(percent), text)
        except Exception:
            pass


def _api_dlls(proj_dir: str, cfg: dict) -> list:
    """收集源码里「API … 在库 "xxx.dll"」声明用到的 DLL 名（按出现顺序去重）。
    只认未被注释的声明：单引号 ' 之后是注释（如示例文档里的 在库 "xxx.dll"）不算。"""
    dlls = []
    for name in (project_mod.list_sources(proj_dir) or []):
        path = os.path.join(proj_dir, name)     # list_sources 返回的是相对路径
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                text = fp.read()
        except OSError:
            continue
        for m in re.finditer(r'在库\s*"([^"]+)"', text):
            # 在库 "xxx.dll[,真实API名]"：链接库只看 DLL 名，剥掉逗号后的真实 API 名
            line_start = text.rfind("\n", 0, m.start()) + 1
            if "'" in text[line_start:m.start()]:
                continue                        # 匹配位置之前有注释符 → 是注释不是声明
            d = m.group(1).split(",")[0].strip()
            if d and d not in dlls:
                dlls.append(d)
    return dlls


def _api_dll_libs(proj_dir: str, cfg: dict) -> list:
    """把 _api_dlls 收集到的 DLL 换算成 g++ 的 -l 链接库名。"""
    libs = []
    for d in _api_dlls(proj_dir, cfg):
        lib = native_rt.DLL_LIBS.get(d.lower())
        if lib is None:
            lib = os.path.splitext(os.path.basename(d))[0]
        if lib and lib not in libs:
            libs.append(lib)
    return libs


def export_cpp(proj_dir: str, cfg: dict, mode: str = "debug", target: str = "run",
               native: bool = True, progress=None) -> dict:
    """把工程导出为 C++ 工程（只翻译导出代码，不调用编译器编译）。

    native=True（默认）→「纯正的 C++」：固定导出到 工程\\导出C++\\main.cpp。
                          代码为标准 C++17 / Win32 写法：类型与内置函数是英文、
                          Windows API 直接静态调用、无 #line 与机器注释，
                          中文变量名/常量名/类型名/子程序名原样保留（合法 C++ 标识符），
                          不依赖中文运行库 yunyi_rt.hpp。
    native=False        → 旧式导出（main_gen.cpp + yunyi_rt.hpp 中文运行库），
                          输出到 工程\\导出C++\\<工程名>-<时间戳>\\。

    progress: 可选回调 progress(百分比, 阶段文字)，供界面显示进度条。
    """
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    _report(progress, 8, "读取工程配置")
    # 只翻译，不编译。纯正模式只支持调用标准系统 DLL 的工程：Qt / Sciter 等
    # 第三方 DLL 的 API 在 windows.h 里没有声明，静态调用无法生成 —— 自动回退
    # 到旧式导出并说明原因。注意：Qt / Sciter 的 API 声明写在「类」选项卡的
    # lib/qt.api 里，由翻译时自动注入，工程源码里没有「在库」声明 —— 所以用
    # 翻译结果里带出的 API DLL 清单（含类库注入）来判断。
    native_note = ""
    res = translate(proj_dir, cfg, target, mode, native=native, clean=native)
    if native and res["ok"]:
        unknown = [d for d in (res.get("apiDlls") or [])
                   if d.lower() not in native_rt.DLL_LIBS]
        if unknown:
            native = False
            native_note = ("工程调用了第三方库 API（" + "、".join(unknown) + "），"
                           "已按「中文转译版」导出（纯正 C++ 仅支持标准系统 DLL 的工程）。")
            res = translate(proj_dir, cfg, target, mode, native=False)
    if not res["ok"]:
        return res
    _report(progress, 45, "源码翻译完成")
    name = cfg.get("name") or os.path.basename(proj_dir.rstrip("/\\"))
    if native:
        # 纯正 C++：固定输出到 工程\导出C++\main.cpp（同名覆盖，不堆积带时间戳的目录；
        # 旧式导出则在 导出C++\<工程名>-<时间戳>\ 子目录里，互不干扰）
        out_dir = os.path.join(proj_dir, "导出C++")
    else:
        ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        out_dir = os.path.join(proj_dir, "导出C++", f"{name}-{ts}")
    if os.path.isfile(out_dir):
        # 目标目录名被同名文件占用（手工误建等）：明确报错，不让导出崩溃
        return {"ok": False, "native": native, "dir": "", "files": [],
                "messages": [{"kind": "error", "file": "", "line": 0, "col": 0,
                              "text": "导出失败：路径被同名文件占用，请删除后重试 —— " + out_dir}]}
    os.makedirs(out_dir, exist_ok=True)
    src = res["artifacts"]["genCpp"]
    # native 版是自包含的标准 C++（main.cpp）；旧版要把中文运行库头一起带上
    dst = os.path.join(out_dir, "main.cpp" if native else os.path.basename(src))
    shutil.copy(src, dst)
    if not native:
        shutil.copy(RUNTIME_HEADER, os.path.join(out_dir, "yunyi_rt.hpp"))
    _report(progress, 58, "生成 C++ 源文件")
    # 程序图标：图标与资源脚本一起导出，编译脚本用 windres 编成 app_icon.o 参与链接
    icon = resolve_icon(proj_dir, cfg)
    windres = find_windres(toolchain.find_gxx()) if icon else ""
    icon_files = []
    if icon:
        shutil.copyfile(icon, os.path.join(out_dir, "app_icon.ico"))
        rc = os.path.join(out_dir, "app.rc")
        with codec.open_text("resource", rc, "w") as fp:
            fp.write('/* auto-generated by Yunyi IDE: program icon */\n'
                     '1 ICON "app_icon.ico"\n')
        icon_files = [rc, os.path.join(out_dir, "app_icon.ico")]
    # 生成编译脚本
    _report(progress, 75, "生成编译脚本与资源")
    gen = os.path.basename(dst)
    subsys = project_mod.resolve_subsystem(proj_dir, cfg)
    win_flag = " -mwindows" if subsys == "window" else ""
    out_name = "程序.exe"
    tmp_name = "_build.exe"          # g++ 先写 ASCII 名（中文名会被 g++ 写坏，见下）
    if subsys == "dll":
        # 不加 --kill-at：i386 保留 @参数字节数 装饰（Add@8），x64 无装饰
        win_flag = " -shared"
        out_name = "程序.dll"
        tmp_name = "_build.dll"
    # 编译脚本统一 UTF-8 + 开头 chcp 65001：中文路径与中文输出名（程序.exe）在默认 936
    # 控制台和 UTF-8 终端下都不会乱码（实测两种起始代码页均可用）
    bat = os.path.join(out_dir, "编译运行.bat")
    with codec.open_text("build_script", bat, "w", newline="") as fp:
        fp.write("@echo off\r\n")
        fp.write("chcp 65001 >nul\r\n")
        gxx = toolchain.find_gxx()
        fp.write(f"set GXX={gxx}\r\n")
        # 兜底：把 g++ 所在目录临时加进 PATH，万一链接不是全静态，运行时也能找到 libgcc_s_dw2-1.dll
        fp.write('for %%I in ("%GXX%") do set "GXXDIR=%%~dpI"\r\n')
        fp.write("set \"PATH=%GXXDIR%;%PATH%\"\r\n")
        if windres:
            fp.write(f"set WINDRES={windres}\r\n")
            fp.write("set ICONOBJ=\r\n")
            fp.write('if exist app.rc "%WINDRES%" -i app.rc -o app_icon.o\r\n')
            fp.write("if exist app_icon.o set ICONOBJ=app_icon.o\r\n")
        # -static：静态链接 GCC 运行时（libgcc / libstdc++ / libwinpthread）。
        # 不加的话，生成的 exe 在没有 MinGW 的机器上会报「找不到 libgcc_s_dw2-1.dll」。
        # 链接库：按源码里 API 声明的「在库」自动追加（user32 默认已链）
        libs = [l for l in _api_dll_libs(proj_dir, cfg) if l not in ("user32", "kernel32")]
        lib_flags = "".join(f" -l{l}" for l in libs)
        fp.write(f'"%GXX%" -std=c++17 -Wall -O2 -static "{gen}" %ICONOBJ% '
                 f'-I. -luser32{lib_flags}{win_flag} -o {tmp_name}\r\n')
        fp.write('if errorlevel 1 ( echo 编译失败 & pause & exit /b 1 )\r\n')
        # g++ 在 Windows 上写中文输出名会变成乱码（实测 程序.exe → ³ÌÐò.exe，MinGW 已知行为），
        # 所以先用 ASCII 名编译，再由 cmd 内建 ren 改成中文名（cmd 是 Unicode 安全的）
        fp.write(f'ren {tmp_name} {out_name}\r\n')
        fp.write(f'if not exist {out_name} ( echo 生成失败 & pause & exit /b 1 )\r\n')
        fp.write(out_name + '\r\n')
        fp.write('pause\r\n')
    # Qt runtime: auto-deploy to the export directory
    _report(progress, 90, "部署界面运行库")
    qt_count = 0
    if _uses_qt(res["artifacts"].get("cpp", "")):
        qt_count = _deploy_qt_runtime(out_dir, project_mod.resolve_arch(proj_dir, cfg))
    # Sciter runtime: auto-deploy to the export directory (arch-matched engine)
    sciter_count = 0
    if _uses_sciter(res["artifacts"].get("cpp", "")):
        sciter_count = _deploy_sciter_runtime(out_dir, project_mod.resolve_arch(proj_dir, cfg))
    _report(progress, 96, "写入说明文件")
    readme = os.path.join(out_dir, "\u8bf4\u660e.txt")
    with codec.open_text("artifact", readme, "w", newline="") as fp:
        if native:
            fp.write("本目录由「云易中文编程语言」导出为【纯正 C++ 工程】。\r\n"
                     "main.cpp 是标准 C++17 / Win32 源码：类型与内置函数均为英文写法，\r\n"
                     "Windows API 直接静态调用，无 #line 指令与机器注释，\r\n"
                     "不依赖任何中文运行库（无需 yunyi_rt.hpp）。\r\n"
                     "注：你在源码里自己写的中文变量名/子程序名会原样保留（C++ 合法标识符）。\r\n"
                     "双击 编译运行.bat 即可用 MinGW 编译并运行；已加 -static，\r\n"
                     "生成的 exe 不依赖 MinGW 的 DLL，可直接拷到别的 Windows 机器运行。\r\n")
        else:
            fp.write("本目录由「云易中文编程语言」导出。\r\n"
                     "main_gen.cpp 是翻译得到的 C++17 源码，yunyi_rt.hpp 是中文运行库。\r\n"
                     "双击 编译运行.bat 即可用 MinGW 编译并运行（需修改 .bat 中的 GXX 路径）。\r\n")
        if icon:
            fp.write("app.rc + app_icon.ico \u662f\u7a0b\u5e8f\u56fe\u6807"
                     "\uff08\u7f16\u8bd1\u811a\u672c\u7528 windres \u7f16\u6210 app_icon.o \u4e00\u8d77\u94fe\u63a5\uff09\uff1b\r\n"
                     "\u4e0d\u9700\u8981\u56fe\u6807\u65f6\uff0c\u5220\u6389\u8fd9\u4e24\u4e2a\u6587\u4ef6"
                     "\u5e76\u53bb\u6389 \u7f16\u8bd1\u8fd0\u884c.bat \u91cc\u7684\u4e24\u884c windres \u5373\u53ef\u3002\r\n")
        if qt_count:
            fp.write("\u672c\u7a0b\u5e8f\u4f7f\u7528\u4e86 Qt \u63a7\u4ef6\u5e93\uff0c"
                     "\u5df2\u9644\u5e26\u6240\u9700\u8fd0\u884c\u5e93 DLL"
                     "\uff08\u540c\u76ee\u5f55\u4e0b\uff0c\u542b\u4e91\u6613Qt.dll\u3001"
                     "Qt6 \u8fd0\u884c\u5e93\u4e0e\u5e73\u53f0\u63d2\u4ef6\uff09\u3002\r\n"
                     "\u7f16\u8bd1\u751f\u6210\u7684 exe \u9700\u8981\u8fd9\u4e9b DLL "
                     "\u624d\u80fd\u8fd0\u884c\uff0c\u8bf7\u4fdd\u6301\u5728\u4e00\u8d77\u3002\r\n")
        if sciter_count:
            fp.write("本程序使用了 Sciter 界面库，已附带所需运行库 DLL"
                     "（同目录下：yysciter.dll 或 yysciter_x86.dll、sciter.dll —— "
                     "后者必须与 exe 位数一致）。\r\n"
                     "编译生成的 exe 需要这些 DLL 才能运行，请保持在一起。\r\n")
        fp.write("\u7f16\u8bd1\u811a\u672c\u5148\u8ba9 g++ \u751f\u6210 ASCII \u540d"
                 "\uff08_build.exe\uff09\uff0c\u518d\u7528 ren \u6539\u6210\u4e2d\u6587\u540d\uff1a\r\n"
                 "g++ \u5728 Windows \u4e0a\u76f4\u63a5\u5199\u4e2d\u6587\u8f93\u51fa\u540d"
                 "\u4f1a\u53d8\u6210\u4e71\u7801\uff08MinGW \u7684\u5df2\u77e5\u884c\u4e3a\uff09\u3002\r\n")
    _report(progress, 100, "导出完成")
    if native_note:
        result_messages = [{"kind": "warning", "file": "", "line": 0, "col": 0,
                            "text": native_note}]
    else:
        result_messages = []
    files = [dst, bat, readme] + icon_files
    if not native:
        files.insert(1, os.path.join(out_dir, "yunyi_rt.hpp"))
    return {"ok": True, "dir": out_dir, "native": native,
            "messages": result_messages, "files": files}


# ============ 「导出Python」：把工程翻译为自包含的 Python 3 程序 ============

def translate_python(proj_dir: str, cfg: dict = None, target: str = "run",
                     mode: str = "debug") -> dict:
    """把 .yy 源码翻译为 Python 3（供「导出Python」使用）。

    语法 → 语义检查 → codegen_py 生成 Python，写入 build/<mode>/main_gen.py。
    生成的是自包含的标准 Python 3：中文内置函数换成等价 Python 写法（标准库 +
    按需注入的 yy_ 辅助函数），不依赖任何中文运行库。
    暂不支持 Windows API 声明与「参考」参数（生成时报错说明）。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    try:
        project_mod.apply_project_env(proj_dir, cfg)
    except Exception:
        pass
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    sources = project_mod.list_sources(proj_dir)
    result = {"ok": False, "messages": [], "phase": "翻译", "py": "",
              "genPath": "", "mode": mode, "target": target, "artifacts": {}}

    if not sources:
        result["messages"].append({"kind": "error", "text": "工程中没有 .yy 源码文件",
                                   "file": "", "line": 0, "col": 0})
        return result

    if project_mod.resolve_subsystem(proj_dir, cfg) == "dll":
        result["messages"].append({"kind": "error", "text":
                                   "「DLL程序」暂不支持导出 Python", "file": "",
                                   "line": 0, "col": 0})
        return result

    files = []
    for f in sources:
        p = os.path.join(proj_dir, f)
        try:
            with codec.open_text("source", p, "r") as fp:
                text = fp.read()
        except Exception as e:
            result["messages"].append({"kind": "error", "text": f"读取 {f} 失败：{e}",
                                       "file": f, "line": 0, "col": 0})
            return result
        files.append((p, text))

    lib = libauto.load_lib_defs()
    try:
        prog = parse_files(files, extra_types=lib.type_names())
    except YyError as e:
        result["phase"] = "语法检查"
        result["messages"].append({"kind": "error", "text": str(e),
                                   "file": e.file, "line": e.line, "col": e.col})
        return result

    libauto.inject_lib_refs(prog, result["messages"], lib=lib)

    errs = check_program(prog)
    if errs:
        result["phase"] = "语义检查"
        for e in errs:
            result["messages"].append({"kind": "error", "text": str(e),
                                       "file": e.file, "line": e.line, "col": e.col})
        return result

    try:
        py = codegen_py_mod.generate_python(prog, mode=target)
    except YyError as e:
        result["phase"] = "代码生成"
        result["messages"].append({"kind": "error", "text": str(e),
                                   "file": e.file, "line": e.line, "col": e.col})
        return result

    build_root = os.path.join(proj_dir, "build", mode)
    os.makedirs(build_root, exist_ok=True)
    gen_path = os.path.join(build_root, "main_gen.py")
    with codec.open_text("artifact", gen_path, "w") as fp:
        fp.write(py)

    result["ok"] = True
    result["py"] = py
    result["genPath"] = gen_path
    result["artifacts"] = {"genPy": gen_path, "py": py}
    result["messages"].append({"kind": "ok", "text": "翻译成功：" + gen_path,
                               "file": "", "line": 0, "col": 0})
    return result


def export_python(proj_dir: str, cfg: dict, mode: str = "debug", target: str = "run",
                  progress=None) -> dict:
    """把工程导出为 Python 工程（只翻译导出，不执行）。

    输出到 工程\\导出Python\\：main.py（自包含的 Python 3，无中文运行库）、
    运行.bat（双击用系统 Python 运行）、说明.txt。
    progress: 可选回调 progress(百分比, 阶段文字)，供界面显示进度条。"""
    _report(progress, 8, "读取工程配置")
    res = translate_python(proj_dir, cfg, target, mode)
    if not res["ok"]:
        return res
    _report(progress, 45, "源码翻译完成")
    out_dir = os.path.join(proj_dir, "导出Python")
    if os.path.isfile(out_dir):
        return {"ok": False, "dir": "", "files": [],
                "messages": [{"kind": "error", "file": "", "line": 0, "col": 0,
                              "text": "导出失败：路径被同名文件占用，请删除后重试 —— " + out_dir}]}
    os.makedirs(out_dir, exist_ok=True)
    dst = os.path.join(out_dir, "main.py")
    shutil.copy(res["artifacts"]["genPy"], dst)
    _report(progress, 58, "生成 Python 源文件")
    # 运行脚本：双击即用系统 Python 运行（UTF-8 控制台，避免中文乱码）
    _report(progress, 75, "生成运行脚本")
    bat = os.path.join(out_dir, "运行.bat")
    with codec.open_text("build_script", bat, "w", newline="") as fp:
        fp.write("@echo off\r\n")
        fp.write("chcp 65001 >nul\r\n")
        fp.write('cd /d "%~dp0"\r\n')
        # 管道/重定向时 Python 用系统默认编码（936）写 stdout，中文会乱码；强制 UTF-8
        fp.write("set PYTHONIOENCODING=utf-8\r\n")
        fp.write("where python >nul 2>nul\r\n")
        fp.write("if errorlevel 1 ( echo 未找到 Python，请先安装 Python 3.8+"
                 " 并勾选 Add to PATH & pause & exit /b 1 )\r\n")
        fp.write("python main.py\r\n")
        fp.write("if errorlevel 1 pause\r\n")
    _report(progress, 96, "写入说明文件")
    readme = os.path.join(out_dir, "说明.txt")
    with codec.open_text("artifact", readme, "w", newline="") as fp:
        fp.write("本目录由「云易中文编程语言」导出为【Python 工程】。\r\n"
                 "main.py 是自包含的标准 Python 3 源码：中文内置函数已换成等价的\r\n"
                 "Python 写法（标准库 + 文件内附带的 yy_ 辅助函数），\r\n"
                 "不依赖任何中文运行库；你在源码里自己写的中文变量名/子程序名原样保留。\r\n"
                 "双击 运行.bat 即可运行（需要已安装 Python 3.8+ 并加入 PATH），\r\n"
                 "或在本目录执行：python main.py\r\n"
                 "注意：暂不支持 Windows API 声明与「参考」参数的工程。\r\n"
                 "另：云易的 整数除法 / 在 C++ 里是截断取整，Python 的 / 是精确除法，\r\n"
                 "如需截断取整请用「整除」或 到整数(...) 包一下。\r\n")
    _report(progress, 100, "导出完成")
    return {"ok": True, "dir": out_dir, "native": False,
            "messages": [], "files": [dst, bat, readme]}


def release_project(proj_dir: str, cfg: dict) -> dict:
    """一键发布：release 编译 + 收集产物 + 打包 zip。"""
    res = compile_yunyi(proj_dir, cfg, mode="release", target="run")
    if not res["ok"]:
        return res
    exe = res["artifacts"]["exe"]
    name = cfg.get("name") or os.path.basename(proj_dir.rstrip("/\\"))
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dist_name = f"{name}-发布-{ts}"
    dist = os.path.join(os.path.dirname(exe), "..", "..", "发布", dist_name)
    dist = os.path.normpath(dist)
    os.makedirs(dist, exist_ok=True)
    target_exe = os.path.join(dist, os.path.basename(exe))
    shutil.copy(exe, target_exe)
    # Qt runtime: auto-deploy to the publish directory
    qt_count = 0
    if _uses_qt(res["artifacts"].get("cpp", "")):
        qt_count = _deploy_qt_runtime(dist, project_mod.resolve_arch(proj_dir, cfg))
    # Sciter runtime: auto-deploy to the publish directory (arch-matched engine)
    sciter_count = 0
    if _uses_sciter(res["artifacts"].get("cpp", "")):
        sciter_count = _deploy_sciter_runtime(dist, project_mod.resolve_arch(proj_dir, cfg))
    readme = os.path.join(dist, "\u8fd0\u884c\u8bf4\u660e.txt")
    with codec.open_text("artifact", readme, "w", newline="") as fp:
        fp.write(f"\u3010{name}\u3011\u53d1\u5e03\u7248\u672c {ts}\r\n\r\n")
        if qt_count:
            fp.write("\u672c\u7a0b\u5e8f\u4f7f\u7528\u4e86 Qt \u63a7\u4ef6\u5e93\uff0c"
                     "\u5df2\u9644\u5e26\u6240\u9700\u8fd0\u884c\u5e93 DLL"
                     "\uff08\u542b\u4e91\u6613Qt.dll\u3001Qt6 \u8fd0\u884c\u5e93\u4e0e\u5e73\u53f0\u63d2\u4ef6\uff09\u3002\r\n"
                     "\u8bf7\u4fdd\u6301 exe \u4e0e\u540c\u76ee\u5f55\u4e0b\u7684 DLL "
                     "\u53ca platforms \u5b50\u76ee\u5f55\u5728\u4e00\u8d77\u3002\r\n\r\n")
        if sciter_count:
            fp.write("本程序使用了 Sciter 界面库，已附带所需运行库 DLL"
                     "（yysciter.dll 或 yysciter_x86.dll、sciter.dll —— "
                     "后者必须与 exe 位数一致）。\r\n"
                     "请保持 exe 与同目录下的这两个 DLL 在一起。\r\n\r\n")
        fp.write("\u76f4\u63a5\u53cc\u51fb\u540c\u540d .exe \u5373\u53ef\u8fd0\u884c\u3002\r\n"
                 "\u82e5\u63d0\u793a\u7f3a\u5c11 DLL\uff0c\u8bf7\u786e\u8ba4\u7cfb\u7edf"
                 "\u5df2\u5b89\u88c5 Microsoft VC++ \u8fd0\u884c\u5e93\uff0c\r\n"
                 "\u6216\u4f7f\u7528 mingw \u63d0\u4f9b\u7684 libgcc/libstdc++ "
                 "\u52a8\u6001\u5e93\u3002\r\n")
    zip_name = dist_name + ".zip"
    zip_path = os.path.join(os.path.dirname(dist), zip_name)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(target_exe, os.path.basename(exe))
        zf.write(readme, "\u8fd0\u884c\u8bf4\u660e.txt")
        # Qt / Sciter runtime: also pack into the zip
        if qt_count or sciter_count:
            for root, _dirs, names in os.walk(dist):
                for n in names:
                    fp_ = os.path.join(root, n)
                    arc = os.path.relpath(fp_, dist).replace("\\", "/")
                    if arc in (os.path.basename(exe), "\u8fd0\u884c\u8bf4\u660e.txt"):
                        continue
                    zf.write(fp_, arc)
    return {"ok": True, "exe": target_exe, "zip": zip_path, "dir": dist,
            "files": os.listdir(dist)}


# ============ 「清理构建」：删除可重构的产物（编译/运行/测试/发布/导出生成） ============

# 可由「编译 / 运行 / 测试 / 发布 / 导出」随时重新生成的目录（都在工程目录内）
CLEAN_DIRS = ("build", "发布", "导出C++", "导出Python")


def _dir_stats(path: str):
    """统计目录内的文件数与总字节数。"""
    files = size = 0
    for root, _dirs, names in os.walk(path):
        for n in names:
            try:
                files += 1
                size += os.path.getsize(os.path.join(root, n))
            except OSError:
                pass
    return files, size


def _fmt_size(n: int) -> str:
    v = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if v < 1024 or unit == "GB":
            return ("%d B" % int(n)) if unit == "B" else ("%.1f %s" % (v, unit))
        v /= 1024.0
    return "%.1f GB" % v


def clean_build(proj_dir: str, cfg: dict = None, dry_run: bool = False) -> dict:
    """清理「可重构」的构建产物 —— 编译 / 运行 / 测试 / 发布 / 导出 生成的文件。

    清理范围（都在工程目录内，全部可以重新生成）：
        build\\      翻译产物 main_gen.cpp、exe / dll、目标文件、DLL 导出函数清单
        发布\\       一键发布收集的可执行文件、运行说明与 zip
        导出C++\\    「导出C++」的产物：纯正 C++（main.cpp）与
                     旧式导出（<工程名>-<时间戳>\\main_gen.cpp + 中文运行库）
        导出Python\\ 「导出Python」的产物：main.py + 运行.bat + 说明.txt
    用户源码（.yy）、工程配置（.yyproj）、构建脚本（Makefile / CMakeLists.txt / 构建.bat）不动。
    dry_run=True 时只统计不删除（供界面先弹确认框再执行）。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    items, removed, failed = [], [], []
    total_files = total_bytes = 0
    for name in CLEAN_DIRS:
        d = os.path.join(proj_dir, name)
        if not os.path.isdir(d):
            continue
        n, sz = _dir_stats(d)
        items.append({"name": name, "files": n, "bytes": sz})
        total_files += n
        total_bytes += sz
        if dry_run:
            continue
        # 先结束仍占用产物的残留进程（上次「运行 / 测试」留下、锁着 exe / dll 的进程）
        for root, _dirs, names in os.walk(d):
            for f in names:
                if f.lower().endswith((".exe", ".dll")):
                    toolchain.kill_locked_process(os.path.join(root, f))
        try:
            shutil.rmtree(d)
            removed.append(name)
        except Exception:
            for root, dirs, names in os.walk(d, topdown=False):
                for f in names:
                    try:
                        os.remove(os.path.join(root, f))
                    except Exception:
                        failed.append(os.path.join(root, f))
                for dd in dirs:
                    try:
                        os.rmdir(os.path.join(root, dd))
                    except Exception:
                        pass
            if not failed:
                removed.append(name)
    msgs = []
    if total_files:
        msgs.append({"kind": "info", "file": "", "line": 0, "col": 0,
                     "text": ("待清理" if dry_run else "已清理") + " %d 个文件（%s）：%s"
                             % (total_files, _fmt_size(total_bytes),
                                "、".join(i["name"] for i in items))})
    else:
        msgs.append({"kind": "info", "file": "", "line": 0, "col": 0,
                     "text": "没有可清理的构建产物（build / 发布 / 导出C++ / 导出Python 均不存在）"})
    for p in failed:
        msgs.append({"kind": "warning", "file": "", "line": 0, "col": 0,
                     "text": "未能删除（可能仍被占用，请先停止运行再试）：" + p})
    return {"dryRun": dry_run, "items": items, "files": total_files,
            "bytes": total_bytes, "removed": removed, "failed": failed,
            "messages": msgs, "ok": not failed}
