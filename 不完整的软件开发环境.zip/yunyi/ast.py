# -*- coding: utf-8 -*-
"""云易 AST 节点定义。"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# ---------- 表达式 ----------
class Expr:
    line: int = 0
    col: int = 0


@dataclass
class NumLit(Expr):
    value: object          # int / float
    raw: str = ""          # 源码原文（保留进制/小数点写法）
    line: int = 0
    col: int = 0


@dataclass
class StrLit(Expr):
    value: str = ""
    line: int = 0
    col: int = 0


@dataclass
class BoolLit(Expr):
    value: bool = True
    line: int = 0
    col: int = 0


@dataclass
class Name(Expr):
    id: str = ""
    is_const: bool = False     # True = 「#名称」常量引用（核心库/用户常量使用时必须加 #）
    line: int = 0
    col: int = 0


@dataclass
class Index(Expr):
    base: Expr = None
    index: Expr = None
    line: int = 0
    col: int = 0


@dataclass
class Member(Expr):
    """成员访问：base.name（自定义数据类型的字段）"""
    base: Expr = None
    name: str = ""
    line: int = 0
    col: int = 0


@dataclass
class Call(Expr):
    func: str = ""
    args: List[Expr] = field(default_factory=list)
    obj: Optional[Expr] = None   # 非 None 时为类函数（成员函数）调用：obj.func(args)
    line: int = 0
    col: int = 0


@dataclass
class Unary(Expr):
    op: str = ""           # '-', '+', '!', '非'
    operand: Expr = None
    line: int = 0
    col: int = 0


@dataclass
class Binary(Expr):
    op: str = ""           # 规范化后的运算符（见 parser 常量）
    left: Expr = None
    right: Expr = None
    line: int = 0
    col: int = 0


# ---------- 语句 ----------
class Stmt:
    line: int = 0


@dataclass
class VarDecl(Stmt):
    name: str = ""
    type: str = ""
    array_size: Optional[Expr] = None   # None=普通变量（见 array_dynamic）
    array_dynamic: bool = False         # True=动态数组（写作 名字[]，C++ 侧是 std::vector）
    init: Optional[Expr] = None         # 可选默认值（仅普通变量）
    line: int = 0
    col: int = 0


@dataclass
class Assign(Stmt):
    target: Expr = None     # Name / Index / Member
    op: str = "="           # '=','+=','-=','*=','/='
    value: Expr = None
    line: int = 0
    col: int = 0


@dataclass
class ExprStmt(Stmt):
    expr: Expr = None
    line: int = 0


@dataclass
class IfStmt(Stmt):
    branches: List[Tuple[Optional[Expr], List[Stmt]]] = field(default_factory=list)
    else_body: List[Stmt] = field(default_factory=list)   # 可能为空
    line: int = 0
    col: int = 0


@dataclass
class ForRange(Stmt):
    var: str = ""
    start: Expr = None
    end: Expr = None
    step: Optional[Expr] = None     # 非 None = 变量循环首（带步长）
    body: List[Stmt] = field(default_factory=list)
    line: int = 0
    col: int = 0


@dataclass
class WhileStmt(Stmt):
    cond: Expr = None
    body: List[Stmt] = field(default_factory=list)
    line: int = 0
    col: int = 0


@dataclass
class DoWhileStmt(Stmt):
    cond: Expr = None
    body: List[Stmt] = field(default_factory=list)
    line: int = 0
    col: int = 0


@dataclass
class BreakStmt(Stmt):
    line: int = 0
    col: int = 0


@dataclass
class ContinueStmt(Stmt):
    line: int = 0
    col: int = 0


@dataclass
class ReturnStmt(Stmt):
    expr: Optional[Expr] = None
    line: int = 0
    col: int = 0


@dataclass
class AsmBlock(Stmt):
    """裸写汇编块：
    asm [Intel | AT&T]
        汇编指令（原样保留，不用引号也不用逗号）
    结束asm
    dialect 为空表示沿用工程设置的汇编语法。"""
    code: str = ""
    dialect: str = ""
    line: int = 0
    col: int = 0


# ---------- 顶层 ----------
@dataclass
class GlobalVar:
    name: str = ""
    type: str = ""
    array_size: Optional[Expr] = None
    array_dynamic: bool = False         # True=动态数组（写作 名字[]）
    line: int = 0
    col: int = 0
    file: str = ""


@dataclass
class GlobalConst:
    name: str = ""
    type: str = ""
    value: Expr = None
    line: int = 0
    col: int = 0
    file: str = ""


@dataclass
class Param:
    name: str = ""
    type: str = ""
    byref: bool = False
    byval: bool = False           # 传值：显式声明按值（数据类型成员用；成员默认即按值嵌入）
    array_size: object = None     # 固定数组：长度表达式（如 整数型 a[10] 的 10）
    array_dynamic: bool = False   # 动态数组：名称[]（配合 加入成员 / 重定义数组 等命令）
    line: int = 0
    col: int = 0


@dataclass
class Func:
    kind: str = "子程序"        # '子程序' | '测试函数'
    name: str = ""
    params: List[Param] = field(default_factory=list)
    ret_type: Optional[str] = None   # None=空
    body: List[Stmt] = field(default_factory=list)
    file: str = ""
    line: int = 0
    col: int = 0
    export: bool = False        # 导出子程序：编译为 DLL 时导出为 DLL 导出函数
    export_name: str = ""       # 自定义导出名（空=用子程序名本身）


@dataclass
class ApiDecl:
    """Windows API 声明：API 返回类型 名称(参数...) 在库 "xxx.dll[,真实API名]"。
    写成 "xxx.dll,真实API名" 时，声明里的 名称 是别名（调用点用它），
    逗号后是 DLL 里的真实导出函数名（WinAPI 函数名）；real_name 为空 = 与 name 相同。"""
    ret_type: str = "整数型"      # TYPE_SET 之一或 '空'
    name: str = ""
    params: List[Param] = field(default_factory=list)
    dll: str = ""
    real_name: str = ""          # 真实 API 名（在库 "xxx.dll,真实名" 的真实名；空=用 name）
    file: str = ""
    line: int = 0
    col: int = 0


@dataclass
class StructDecl:
    """自定义数据类型：
    数据类型 名称
        成员类型 成员名 [数组长度 | []] [传址]
    结束数据类型
    成员支持：「传址」后缀（写在成员名之后，显式按值嵌入；兼容旧的前缀写法）、
    固定数组 成员名[长度]、动态数组 成员名[]、
    成员类型可为基本类型或已定义的自定义数据类型（嵌套，按值嵌入）。"""
    name: str = ""
    fields: List[Param] = field(default_factory=list)
    file: str = ""
    line: int = 0
    col: int = 0


@dataclass
class MethodDecl:
    """类函数（数据类型的成员函数）：
    类函数 类型名.函数名(参数...) 返回类型
        ...
    结束类函数
    函数体内可直接使用该类型的成员（隐式 self）。"""
    owner: str = ""
    name: str = ""
    params: List[Param] = field(default_factory=list)
    ret_type: Optional[str] = None
    body: List[Stmt] = field(default_factory=list)
    file: str = ""
    line: int = 0
    col: int = 0


@dataclass
class Program:
    globals_: List[GlobalVar] = field(default_factory=list)
    consts: List[GlobalConst] = field(default_factory=list)
    structs: List[StructDecl] = field(default_factory=list)
    methods: List[MethodDecl] = field(default_factory=list)
    funcs: List[Func] = field(default_factory=list)
    apis: List[ApiDecl] = field(default_factory=list)
    files: List[str] = field(default_factory=list)
