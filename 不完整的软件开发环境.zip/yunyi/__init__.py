# -*- coding: utf-8 -*-
"""云易编译器包。"""
__version__ = "1.0.0"
