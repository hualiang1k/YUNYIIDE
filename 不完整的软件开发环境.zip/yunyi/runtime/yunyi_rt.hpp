// 云易中文运行库 yunyi_rt.hpp
// 供「云易」翻译出的 C++17 代码包含。定义了中文类型别名与内置函数。
#ifndef YUNYI_RT_HPP
#define YUNYI_RT_HPP

#define NOMINMAX
#include <windows.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <direct.h>
#include <io.h>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <vector>

// ---------------- 中文类型别名 ----------------
using 逻辑型 = bool;
using 字节型 = unsigned char;
using 短整数型 = short;
using 整数型 = int;
using 长整数型 = long long;
using 小数型 = float;            // 单精度浮点数（约7位小数），占 4 字节
using 双精度小数型 = double;    // 双精度浮点数（约15位小数），占 8 字节
using 日期时间型 = long long;     // 记录日期和时间，占 8 字节（1970 年起的秒数时间戳）
using 子程序指针 = long long;   // 指向一个子程序的内存地址，用于间接调用
using 文本型 = std::string;
// 字节集：对应 C/C++ 里的字节流（UTF-8 字节的动态数组）
using 字节集 = std::vector<字节型>;

inline constexpr bool 真 = true;
inline constexpr bool 假 = false;
using 空 = void;

// 控制台切换到 UTF-8 代码页，保证中文正常输入/输出
// 放在匿名命名空间里：内部链接，编译 DLL 时不会被导出
namespace {
struct YY_控制台初始化 {
    YY_控制台初始化() {
        SetConsoleOutputCP(65001);
        SetConsoleCP(65001);
    }
};
inline YY_控制台初始化 _yy_控制台初始化器;
}

// ---------------- 类型转换（先声明，供输出等使用） ----------------
inline 文本型 到文本(const 文本型 &s) { return s; }
inline 文本型 到文本(const char *s) { return s ? s : ""; }
inline 文本型 到文本(bool v) { return v ? "真" : "假"; }
inline 文本型 到文本(整数型 v) { return std::to_string(v); }
inline 文本型 到文本(长整数型 v) { return std::to_string(v); }
inline 文本型 到文本(短整数型 v) { return std::to_string((整数型)v); }
inline 文本型 到文本(字节型 v) { return std::to_string((整数型)v); }
inline 文本型 到文本(double v) {
    std::ostringstream os;
    os << std::setprecision(15) << v;
    return os.str();
}
inline 文本型 到文本(float v) { return 到文本((double)v); }

inline 整数型 到整数(const 文本型 &s) {
    try {
        size_t p = 0;
        长整数型 v = std::stoll(s, &p);
        return (整数型)v;
    } catch (...) { return 0; }
}
inline 整数型 到整数(double v) { return (整数型)v; }
inline 整数型 到整数(整数型 v) { return v; }

inline 长整数型 到长整数(const 文本型 &s) {
    try { return std::stoll(s); } catch (...) { return 0; }
}
inline 长整数型 到长整数(double v) { return (长整数型)v; }
inline 长整数型 到长整数(整数型 v) { return v; }

inline 小数型 到小数(const 文本型 &s) {
    try { return std::stod(s); } catch (...) { return 0.0; }
}
inline 小数型 到小数(整数型 v) { return (double)v; }
inline 小数型 到小数(double v) { return v; }

inline 逻辑型 到逻辑(const 文本型 &s) {
    文本型 t = s;
    return t == "真" || t == "true" || t == "1";
}

// ---------------- 通用输出 ----------------
namespace yy {
// 全局随机数引擎（「置随机数种子」可重置它，便于复现随机序列）
inline std::mt19937_64 &随机数引擎() {
    static std::mt19937_64 _e{std::random_device{}()};
    return _e;
}
// 按名称动态获取 Windows API 函数地址（供「API」声明使用）
inline void *取API(const wchar_t *dll, const char *fn) {
    HMODULE h = GetModuleHandleW(dll);
    if (!h) h = LoadLibraryW(dll);
    if (!h) return nullptr;
    return reinterpret_cast<void *>(GetProcAddress(h, fn));
}
// 取函数地址：优先按 stdcall 装饰名（名字@参数字节数）查找，找不到再退回平名。
//   云易生成的 DLL（i386）：WINAPI 名就是带装饰的 名字@参数字节数 → 命中装饰名；
//   云易生成的 DLL（x64）/ Windows API：只有平名，自然退回平名。
inline void *取API装饰(const wchar_t *dll, const char *fn, int 参数字节数) {
#if defined(_WIN32) && !defined(_WIN64)
    if (参数字节数 > 0) {
        std::string deco = std::string(fn) + "@" + std::to_string(参数字节数);
        if (void *p = 取API(dll, deco.c_str())) return p;
    }
#else
    (void)参数字节数;
#endif
    return 取API(dll, fn);
}
template <typename T>
void 写一个(std::ostream &os, const T &v) { os << v; }
inline void 写一个(std::ostream &os, bool v) { os << (v ? "真" : "假"); }
inline void 写一个(std::ostream &os, const 文本型 &v) { os << v; }
inline void 写一个(std::ostream &os, const char *v) { os << (v ? v : ""); }
inline void 写一个(std::ostream &os, unsigned char v) { os << (整数型)v; }
inline void 写一个(std::ostream &os, double v) { os << 到文本(v); }
inline void 写一个(std::ostream &os, float v) { os << 到文本((double)v); }
inline void 写一个(std::ostream &os, const 字节集 &b) {
    os << "字节集(" << b.size() << "){";
    for (size_t i = 0; i < b.size(); ++i) {
        if (i) os << ", ";
        os << (int)b[i];
    }
    os << "}";
}
} // namespace yy

template <typename... 参数们>
void 输出(const 参数们 &... 参数) {
    bool 首位 = true;
    auto 打印 = [&](const auto &v) {
        if (!首位) std::cout << ' ';
        首位 = false;
        yy::写一个(std::cout, v);
    };
    (打印(参数), ...);
    std::cout << std::endl;
}

// 说明：「调试输出」已合并进 yunyi_core_rt.hpp 的「程序调试」一节
// （控制台 + OutputDebugStringW 双份输出），这里不再重复定义。

// ---------------- 输入 ----------------
// 读标准输入前给 IDE 一个「正在等待输入」的提示：输出一个隐藏标记（ESC[?yy-in]），
// 云易IDE 收到后会弹出「请输入内容」对话框（多行文本框，点「确定」把内容发给本程序），
// 标记本身不显示在控制台里。
// 仅当标准输出不是控制台时才发（由 IDE 运行时 stdout 是管道）；程序发布出去、
// 在真实命令行窗口里运行时不输出任何多余字符。
inline void 提示等待输入() {
#if defined(_WIN32)
    if (!::_isatty(::_fileno(stdout))) std::cout << "\x1b[?yy-in]" << std::endl;
#endif
}

inline 文本型 输入文本() {
    提示等待输入();
    文本型 行;
    if (!std::getline(std::cin, 行)) 行.clear();
    return 行;
}

// ---------------- 文本操作 ----------------
namespace yy {
inline size_t 取序列长度(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c >> 5) == 0b110) return 2;
    if ((c >> 4) == 0b1110) return 3;
    if ((c >> 3) == 0b11110) return 4;
    return 1;
}
inline size_t 字符数(const 文本型 &s) {
    size_t n = 0;
    for (unsigned char c : s)
        if ((c & 0xC0) != 0x80) ++n;
    return n;
}
// 第 cp 个字符(0基) 的字节偏移
inline size_t 到字节(const 文本型 &s, size_t cp) {
    size_t b = 0, c = 0, L = s.size();
    while (b < L && c < cp) { b += 取序列长度((unsigned char)s[b]); ++c; }
    if (b > L) b = L;
    return b;
}
inline 文本型 截取(const 文本型 &s, size_t start_char, size_t count) {
    size_t L = s.size();
    size_t b = 到字节(s, start_char);
    size_t e = b;
    size_t got = 0;
    while (e < L && got < count) { e += 取序列长度((unsigned char)s[e]); ++got; }
    return s.substr(b, e - b);
}
} // namespace yy

inline 整数型 取文本长度(const 文本型 &s) { return (整数型)yy::字符数(s); }

inline 文本型 取文本左边(const 文本型 &s, 长整数型 n) {
    if (n <= 0) return "";
    return yy::截取(s, 0, (size_t)n);
}
inline 文本型 取文本右边(const 文本型 &s, 长整数型 n) {
    if (n <= 0) return "";
    size_t total = yy::字符数(s);
    if ((size_t)n >= total) return s;
    return yy::截取(s, total - (size_t)n, (size_t)n);
}
inline 文本型 取文本中间(const 文本型 &s, 长整数型 起始, 长整数型 n) {
    if (n <= 0 || 起始 < 1) return "";
    return yy::截取(s, (size_t)起始 - 1, (size_t)n);
}

inline 整数型 寻找文本(const 文本型 &s, const 文本型 &子, 长整数型 起始 = 1) {
    if (子.empty()) return 起始 <= (长整数型)yy::字符数(s) ? (整数型)起始 : 0;
    if (起始 < 1) 起始 = 1;
    size_t byte_start = yy::到字节(s, (size_t)起始 - 1);
    size_t pos = s.find(子, byte_start);
    if (pos == 文本型::npos) return 0;
    return (整数型)yy::字符数(s.substr(0, pos)) + 1;
}

inline 整数型 倒找文本(const 文本型 &s, const 文本型 &子, 长整数型 起始 = -1) {
    if (子.empty()) return 0;
    size_t total = yy::字符数(s);
    size_t byte_end;
    if (起始 < 0 || 起始 > (长整数型)total) byte_end = s.size();
    else byte_end = yy::到字节(s, (size_t)起始);
    size_t pos = s.rfind(子, byte_end);
    if (pos == 文本型::npos) return 0;
    return (整数型)yy::字符数(s.substr(0, pos)) + 1;
}

inline 文本型 替换文本(const 文本型 &源, const 文本型 &找, const 文本型 &替换为) {
    if (找.empty()) return 源;
    文本型 结果;
    size_t pos = 0, last = 0;
    while ((pos = 源.find(找, pos)) != 文本型::npos) {
        结果.append(源, last, pos - last);
        结果.append(替换为);
        pos += 找.size();
        last = pos;
    }
    结果.append(源, last, 源.size() - last);
    return 结果;
}

inline 文本型 到大写(const 文本型 &s) {
    文本型 r = s;
    for (auto &c : r)
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    return r;
}
inline 文本型 到小写(const 文本型 &s) {
    文本型 r = s;
    for (auto &c : r)
        if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return r;
}
inline 文本型 删首尾空(const 文本型 &s) {
    size_t b = 0, e = s.size();
    while (b < e && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
    while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
    return s.substr(b, e - b);
}
inline 文本型 取空白文本(长整数型 n) {
    if (n <= 0) return "";
    return 文本型((size_t)n, ' ');
}

// ---------------- 数值 ----------------
inline 长整数型 取绝对值(长整数型 v) { return v < 0 ? -v : v; }
inline 长整数型 取绝对值(整数型 v) { return v < 0 ? -(长整数型)v : (长整数型)v; }
inline 小数型 取绝对值(小数型 v) { return std::fabs(v); }
inline 长整数型 取整(小数型 x) { return (长整数型)x; }
inline 小数型 四舍五入(小数型 x, 长整数型 位 = 0) {
    小数型 p = std::pow(10.0, (double)位);
    return std::round(x * p) / p;
}
inline 小数型 求平方根(小数型 x) { return std::sqrt(x); }

inline 长整数型 取随机数(长整数型 下界, 长整数型 上界) {
    if (下界 > 上界) std::swap(下界, 上界);
    std::uniform_int_distribution<长整数型> d(下界, 上界);
    return d(yy::随机数引擎());
}

inline 长整数型 整除(长整数型 a, 长整数型 b) {
    if (b == 0) return 0;
    长整数型 q = a / b;
    长整数型 r = a % b;
    if (r != 0 && ((r < 0) != (b < 0))) --q;
    return q;
}

// ---------------- 字节集（对应 C/C++ 的字节流） ----------------
inline 字节集 文本到字节集(const 文本型 &s) { return 字节集(s.begin(), s.end()); }
inline 文本型 字节集到文本(const 字节集 &b) { return 文本型(b.begin(), b.end()); }
inline 整数型 取字节集长度(const 字节集 &b) { return (整数型)b.size(); }
inline 字节型 取字节集字节(const 字节集 &b, 整数型 位置) {
    整数型 i = 位置 - 1;
    return (i >= 0 && i < (整数型)b.size()) ? b[(size_t)i] : 字节型(0);
}
inline 字节集 取字节集左边(const 字节集 &b, 整数型 个数) {
    if (个数 < 0) 个数 = 0;
    if ((size_t)个数 > b.size()) 个数 = (整数型)b.size();
    return 字节集(b.begin(), b.begin() + 个数);
}

// ---------------- 数组 ----------------
template <typename T, std::size_t N>
inline 长整数型 取数组成员数(const std::array<T, N> &) { return (长整数型)N; }

// ---------------- 时间 / 消息框 ----------------
inline 文本型 取当前时间() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    char buf[64];
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
             (int)st.wYear, (int)st.wMonth, (int)st.wDay,
             (int)st.wHour, (int)st.wMinute, (int)st.wSecond);
    return buf;
}

inline void 信息框(const 文本型 &text) {
    int wlen = MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, nullptr, 0);
    std::vector<wchar_t> w(wlen > 0 ? (size_t)wlen : 1, L'\0');
    if (wlen > 0) MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, w.data(), wlen);
    MessageBoxW(nullptr, w.data(), L"云易提示", MB_OK | MB_ICONINFORMATION);
}

// ---------------- 测试框架 ----------------
inline 长整数型 _yy断言总数 = 0;
inline 长整数型 _yy断言失败 = 0;
inline void _yy断言重置() { _yy断言总数 = 0; _yy断言失败 = 0; }
inline 长整数型 _yy取总数() { return _yy断言总数; }
inline 长整数型 _yy取失败() { return _yy断言失败; }

inline void 断言(bool 条件, const 文本型 &说明 = "") {
    ++_yy断言总数;
    if (!条件) {
        ++_yy断言失败;
        std::cout << "[断言失败] " << 说明 << std::endl;
    }
}

// ==================================================================
// 云易核心库（第二部分）：控制台补充 / 文本型 / 数学 / 时间 / 数组 /
//                        文件目录 / 系统环境 / 位运算
// ==================================================================
namespace yy {
inline std::wstring 到宽文本(const 文本型 &s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    if (n <= 0) return std::wstring();
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
inline 文本型 到窄文本(const std::wstring &w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return "";
    文本型 s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
inline 文本型 编码字符(unsigned int cp) {
    文本型 r;
    if (cp < 0x80) r += (char)cp;
    else if (cp < 0x800) {
        r += (char)(0xC0 | (cp >> 6)); r += (char)(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        r += (char)(0xE0 | (cp >> 12)); r += (char)(0x80 | ((cp >> 6) & 0x3F)); r += (char)(0x80 | (cp & 0x3F));
    } else {
        r += (char)(0xF0 | (cp >> 18)); r += (char)(0x80 | ((cp >> 12) & 0x3F));
        r += (char)(0x80 | ((cp >> 6) & 0x3F)); r += (char)(0x80 | (cp & 0x3F));
    }
    return r;
}
inline unsigned int 解码字符(const 文本型 &s, size_t &i) {
    unsigned char c = (unsigned char)s[i];
    unsigned int cp; size_t extra;
    if (c < 0x80) { cp = c; extra = 0; }
    else if ((c >> 5) == 0b110) { cp = c & 0x1Fu; extra = 1; }
    else if ((c >> 4) == 0b1110) { cp = c & 0x0Fu; extra = 2; }
    else if ((c >> 3) == 0b11110) { cp = c & 0x07u; extra = 3; }
    else { cp = c; extra = 0; }
    ++i;
    for (size_t k = 0; k < extra && i < s.size(); ++k, ++i) cp = (cp << 6) | ((unsigned char)s[i] & 0x3Fu);
    return cp;
}
inline std::vector<unsigned int> 拆成码点(const 文本型 &s) {
    std::vector<unsigned int> v;
    size_t i = 0;
    while (i < s.size()) v.push_back(解码字符(s, i));
    return v;
}
inline bool 是空白(unsigned int cp) { return cp == ' ' || cp == '\t' || cp == '\r' || cp == '\n'; }
} // namespace yy

// ---------------- 控制台补充 ----------------
inline 整数型 输入整数() { return 到整数(输入文本()); }
inline 小数型 输入小数() { return 到小数(输入文本()); }
inline void 等待按键() { std::cin.clear(); (void)std::cin.get(); }
inline void 清屏() { (void)system("cls"); }
inline void 信息框(const 文本型 &内容, const 文本型 &标题) {
    std::wstring wt = yy::到宽文本(内容), wc = yy::到宽文本(标题);
    MessageBoxW(nullptr, wt.c_str(), wc.c_str(), MB_OK | MB_ICONINFORMATION);
}

// ---------------- 类型转换补充 ----------------
inline 字节型 到字节(长整数型 v) { return (字节型)(v & 0xFF); }
inline 文本型 数值到文本(小数型 v, 长整数型 位 = 0) {
    std::ostringstream os;
    os << std::fixed << std::setprecision((int)位) << v;
    return os.str();
}
inline 文本型 数值到文本(双精度小数型 v, 长整数型 位 = 0) {
    std::ostringstream os;
    os << std::fixed << std::setprecision((int)位) << v;
    return os.str();
}

// ---------------- 文本操作补充 ----------------
inline 文本型 子文本替换(const 文本型 &源, const 文本型 &找, const 文本型 &替换为,
                       长整数型 起始 = 1, 长整数型 次数 = -1) {
    if (找.empty() || 起始 < 1) return 源;
    size_t startByte = yy::到字节(源, (size_t)起始 - 1);
    文本型 头部 = 源.substr(0, startByte);
    文本型 尾部 = 源.substr(startByte);
    文本型 中段;
    size_t pos = 0, last = 0, cnt = 0;
    while ((pos = 尾部.find(找, pos)) != 文本型::npos) {
        中段.append(尾部, last, pos - last);
        中段.append(替换为);
        pos += 找.size();
        last = pos;
        ++cnt;
        if (次数 > 0 && cnt >= (size_t)次数) break;
    }
    中段.append(尾部, last, 尾部.size() - last);
    return 头部 + 中段;
}
inline 文本型 分割文本(const 文本型 &s, const 文本型 &分隔符, 长整数型 第几段) {
    if (第几段 < 1) return "";
    std::vector<文本型> 段;
    size_t pos = 0, last = 0;
    while ((pos = s.find(分隔符, last)) != 文本型::npos) {
        段.push_back(s.substr(last, pos - last));
        pos += 分隔符.size();
        last = pos;
    }
    段.push_back(s.substr(last));
    return ((size_t)第几段 <= 段.size()) ? 段[(size_t)第几段 - 1] : "";
}
inline 整数型 取文本段数(const 文本型 &s, const 文本型 &分隔符) {
    if (分隔符.empty()) return 1;
    整数型 n = 1;
    size_t pos = 0, last = 0;
    while ((pos = s.find(分隔符, last)) != 文本型::npos) {
        ++n;
        pos += 分隔符.size();
        last = pos;
    }
    return n;
}
inline 文本型 删首空(const 文本型 &s) {
    size_t i = 0;
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) ++i;
    return s.substr(i);
}
inline 文本型 删尾空(const 文本型 &s) {
    size_t e = s.size();
    while (e > 0 && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
    return s.substr(0, e);
}
inline 文本型 删全部空(const 文本型 &s) {
    文本型 r;
    for (unsigned int cp : yy::拆成码点(s))
        if (!yy::是空白(cp)) r += yy::编码字符(cp);
    return r;
}
inline 文本型 取重复文本(长整数型 次数, const 文本型 &s) {
    if (次数 <= 0) return "";
    文本型 r;
    for (长整数型 i = 0; i < 次数; ++i) r += s;
    return r;
}
inline 整数型 文本比较(const 文本型 &a, const 文本型 &b, 逻辑型 区分大小写 = 假) {
    文本型 x = a, y = b;
    if (!区分大小写) { x = 到小写(x); y = 到小写(y); }
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}
inline 逻辑型 文本开头为(const 文本型 &s, const 文本型 &前缀) {
    return s.size() >= 前缀.size() && s.compare(0, 前缀.size(), 前缀) == 0;
}
inline 逻辑型 文本结尾为(const 文本型 &s, const 文本型 &后缀) {
    return s.size() >= 后缀.size() && s.compare(s.size() - 后缀.size(), 后缀.size(), 后缀) == 0;
}
inline 文本型 取字符(const 文本型 &s, 长整数型 位置) {
    if (位置 < 1) return "";
    return yy::截取(s, (size_t)位置 - 1, 1);
}
inline 整数型 取字符代码(const 文本型 &s, 长整数型 位置) {
    文本型 c = 取字符(s, 位置);
    if (c.empty()) return 0;
    size_t i = 0;
    return (整数型)yy::解码字符(c, i);
}
inline 文本型 字符代码到文本(长整数型 码) { return yy::编码字符((unsigned int)码); }
inline 文本型 文本倒序(const 文本型 &s) {
    auto cps = yy::拆成码点(s);
    文本型 r;
    for (size_t i = cps.size(); i-- > 0;) r += yy::编码字符(cps[i]);
    return r;
}
inline 逻辑型 是否为空文本(const 文本型 &s) { return s.empty(); }
inline 文本型 到全角(const 文本型 &s) {
    文本型 r;
    for (unsigned int cp : yy::拆成码点(s)) {
        if (cp == 0x20) cp = 0x3000;
        else if (cp >= 0x21 && cp <= 0x7E) cp += 0xFEE0;
        r += yy::编码字符(cp);
    }
    return r;
}
inline 文本型 到半角(const 文本型 &s) {
    文本型 r;
    for (unsigned int cp : yy::拆成码点(s)) {
        if (cp == 0x3000) cp = 0x20;
        else if (cp >= 0xFF01 && cp <= 0xFF5E) cp -= 0xFEE0;
        r += yy::编码字符(cp);
    }
    return r;
}

// ---------------- 数学运算补充 ----------------
inline 整数型 取符号(小数型 v) { return v > 0 ? 1 : (v < 0 ? -1 : 0); }
inline 长整数型 向上取整(小数型 x) { return (长整数型)std::ceil(x); }
inline 长整数型 向下取整(小数型 x) { return (长整数型)std::floor(x); }
inline 小数型 求次方(小数型 x, 小数型 y) { return std::pow(x, y); }
inline 小数型 取自然对数(小数型 x) { return std::log(x); }
inline 小数型 取常用对数(小数型 x) { return std::log10(x); }
inline 小数型 求正弦(小数型 x) { return std::sin(x); }
inline 小数型 求余弦(小数型 x) { return std::cos(x); }
inline 小数型 求正切(小数型 x) { return std::tan(x); }
inline 小数型 求反正切(小数型 x) { return std::atan(x); }
inline 小数型 取余数(小数型 a, 小数型 b) { return b == 0 ? 0 : std::fmod(a, b); }
template <typename T> inline T 取最大值(T a, T b) { return a > b ? a : b; }
template <typename T, typename... R> inline T 取最大值(T a, T b, R... r) { return 取最大值(a > b ? a : b, r...); }
template <typename T> inline T 取最小值(T a, T b) { return a < b ? a : b; }
template <typename T, typename... R> inline T 取最小值(T a, T b, R... r) { return 取最小值(a < b ? a : b, r...); }
inline void 置随机数种子(长整数型 s) { yy::随机数引擎().seed((unsigned long long)s); }
inline 小数型 取随机小数() {
    std::uniform_real_distribution<小数型> d(0.0, 1.0);
    return d(yy::随机数引擎());
}
inline 小数型 取圆周率() { return 3.14159265358979323846; }

// ---------------- 时间日期补充 ----------------
// 说明：取日期 / 取年份 / 取月份 / 取日 / 取小时 / 取分钟 / 取秒 / 取星期 …
// 全部移到 yunyi_core_rt.hpp 统一实现（带可选的「时间」参数），这里不再重复定义。
inline 长整数型 取现行时间() { return (长整数型)std::time(nullptr); }
inline 长整数型 取启动毫秒() {
    static const auto _起点 = std::chrono::steady_clock::now();
    auto d = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - _起点);
    return (长整数型)d.count();
}
inline void 延时(长整数型 毫秒) {
    if (毫秒 > 0) std::this_thread::sleep_for(std::chrono::milliseconds(毫秒));
}

// ---------------- 数组（动态数组 std::vector） ----------------
template <typename T> inline 长整数型 取数组成员数(const std::vector<T> &v) { return (长整数型)v.size(); }
// 成员类型单独一个模板参数：可以直接写 加入成员(文本数组, "张三")
template <typename T, typename U>
inline void 加入成员(std::vector<T> &v, const U &成员) { v.push_back((T)成员); }
template <typename T> inline void 删除成员(std::vector<T> &v, 长整数型 索引) {
    if (索引 >= 1 && (size_t)索引 <= v.size()) v.erase(v.begin() + (索引 - 1));
}
template <typename T> inline void 数组排序(std::vector<T> &v) { std::sort(v.begin(), v.end()); }
template <typename T> inline void 数组反转(std::vector<T> &v) { std::reverse(v.begin(), v.end()); }
template <typename T> inline void 清除数组(std::vector<T> &v) { v.clear(); }

// ---------------- 文件与目录 ----------------
// 使用 Win32 原生 API 判断（避免 CRT stat 在中文路径下的兼容问题）
inline 逻辑型 文件是否存在(const 文本型 &路径) {
    DWORD a = GetFileAttributesW(yy::到宽文本(路径).c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
inline 逻辑型 目录是否存在(const 文本型 &路径) {
    DWORD a = GetFileAttributesW(yy::到宽文本(路径).c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) != 0;
}
inline 长整数型 取文件长度(const 文本型 &路径) {
    WIN32_FILE_ATTRIBUTE_DATA d;
    if (!GetFileAttributesExW(yy::到宽文本(路径).c_str(), GetFileExInfoStandard, &d)) return -1;
    if (d.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) return -1;
    return ((长整数型)d.nFileSizeHigh << 32) | (长整数型)d.nFileSizeLow;
}
inline 文本型 读入文件(const 文本型 &路径) {
    FILE *f = _wfopen(yy::到宽文本(路径).c_str(), L"rb");
    if (!f) return "";
    文本型 结果;
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) 结果.append(buf, n);
    fclose(f);
    return 结果;
}
inline 逻辑型 写到文件(const 文本型 &路径, const 文本型 &内容, 逻辑型 追加 = 假) {
    FILE *f = _wfopen(yy::到宽文本(路径).c_str(), 追加 ? L"ab" : L"wb");
    if (!f) return 假;
    if (!内容.empty()) fwrite(内容.data(), 1, 内容.size(), f);
    fclose(f);
    return 真;
}
inline 逻辑型 删除文件(const 文本型 &路径) { return _wunlink(yy::到宽文本(路径).c_str()) == 0; }
inline 逻辑型 复制文件(const 文本型 &源, const 文本型 &目标) {
    return CopyFileW(yy::到宽文本(源).c_str(), yy::到宽文本(目标).c_str(), FALSE) != 0;
}
inline 逻辑型 移动文件(const 文本型 &源, const 文本型 &目标) {
    return MoveFileW(yy::到宽文本(源).c_str(), yy::到宽文本(目标).c_str()) != 0;
}
inline 逻辑型 创建目录(const 文本型 &路径) {
    std::wstring p = yy::到宽文本(路径);
    if (p.empty()) return 假;
    for (auto &c : p) if (c == L'/') c = L'\\';
    size_t pos = 0;
    if (p.size() >= 2 && p[1] == L':') pos = 3;
    else if (p[0] == L'\\') pos = 1;
    size_t 找到;
    while ((找到 = p.find(L'\\', pos)) != std::wstring::npos) {
        std::wstring 部分 = p.substr(0, 找到);
        if (!部分.empty()) CreateDirectoryW(部分.c_str(), nullptr);
        pos = 找到 + 1;
    }
    DWORD a = GetFileAttributesW(p.c_str());
    if (a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY)) return 真;
    return CreateDirectoryW(p.c_str(), nullptr) != 0;
}
inline 逻辑型 删除目录(const 文本型 &路径) { return _wrmdir(yy::到宽文本(路径).c_str()) == 0; }
inline 文本型 取文件列表(const 文本型 &目录, const 文本型 &通配符 = "*") {
    std::wstring 模式 = yy::到宽文本(目录);
    if (!模式.empty() && 模式.back() != L'\\' && 模式.back() != L'/') 模式 += L'\\';
    模式 += yy::到宽文本(通配符);
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(模式.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return "";
    文本型 结果;
    do {
        const wchar_t *n = fd.cFileName;
        if (n[0] == L'.' && (n[1] == L'\0' || (n[1] == L'.' && n[2] == L'\0'))) continue;
        if (!结果.empty()) 结果 += "\n";
        结果 += yy::到窄文本(n);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return 结果;
}
inline 文本型 取当前目录() {
    wchar_t buf[MAX_PATH];
    if (!GetCurrentDirectoryW(MAX_PATH, buf)) return "";
    return yy::到窄文本(buf);
}
inline 逻辑型 置当前目录(const 文本型 &路径) { return SetCurrentDirectoryW(yy::到宽文本(路径).c_str()) != 0; }
inline 文本型 取运行目录() {
    wchar_t buf[MAX_PATH];
    if (!GetModuleFileNameW(nullptr, buf, MAX_PATH)) return "";
    std::wstring p(buf);
    size_t pos = p.find_last_of(L"\\/");
    return yy::到窄文本(pos == std::wstring::npos ? L"" : p.substr(0, pos));
}
inline 文本型 取临时目录() {
    wchar_t buf[MAX_PATH + 1];
    if (!GetTempPathW(MAX_PATH + 1, buf)) return "";
    return yy::到窄文本(buf);
}

// ---------------- 系统与环境 ----------------
inline 整数型 执行程序(const 文本型 &命令行, 逻辑型 是否等待 = 真) {
    std::wstring w = yy::到宽文本(命令行);
    std::vector<wchar_t> buf(w.begin(), w.end());
    buf.push_back(L'\0');
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, buf.data(), nullptr, nullptr, FALSE, 0,
                        nullptr, nullptr, &si, &pi))
        return -1;
    if (!是否等待) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return 0;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD 码 = 0;
    GetExitCodeProcess(pi.hProcess, &码);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return (整数型)码;
}
inline 文本型 取命令行() { return yy::到窄文本(GetCommandLineW()); }
inline 文本型 取环境变量(const 文本型 &名) {
    const char *v = std::getenv(名.c_str());
    return v ? 文本型(v) : "";
}
inline void 结束程序(整数型 退出码 = 0) { std::cout.flush(); std::exit(退出码); }
inline 整数型 取屏幕宽度() { return (整数型)GetSystemMetrics(SM_CXSCREEN); }
inline 整数型 取屏幕高度() { return (整数型)GetSystemMetrics(SM_CYSCREEN); }
inline void 置控制台标题(const 文本型 &标题) { SetConsoleTitleW(yy::到宽文本(标题).c_str()); }

// ---------------- 位运算 ----------------
inline 长整数型 位与(长整数型 a, 长整数型 b) { return a & b; }
inline 长整数型 位或(长整数型 a, 长整数型 b) { return a | b; }
inline 长整数型 位异或(长整数型 a, 长整数型 b) { return a ^ b; }
inline 长整数型 位取反(长整数型 a) { return ~a; }
inline 长整数型 左移(长整数型 a, 长整数型 n) { return n >= 0 ? (a << (n & 63)) : (a >> ((-n) & 63)); }
inline 长整数型 右移(长整数型 a, 长整数型 n) { return n >= 0 ? (a >> (n & 63)) : (a << ((-n) & 63)); }

// 《核心支持库命令.txt》里的其余命令（文件读写 / 系统处理 / 磁盘 / 时间 / 字节集 /
// 数值转换 / 拼音 …）都在 yunyi_core_rt.hpp 里实现（与上面同一套中文类型）
#include "yunyi_core_rt.hpp"

#endif // YUNYI_RT_HPP
