// 云易核心支持库（第二部分）yunyi_core_rt.hpp
// 由 yunyi_rt.hpp 在末尾包含：这里可以直接用上面定义的中文类型与 yy:: 辅助函数。
// 内容：算术运算补充 / 位运算补充 / 数值转换 / 文本操作补充 / 时间操作 /
//       字节集操作 / 磁盘操作 / 文件读写 / 系统处理 / 媒体播放 / 程序调试 / 其他 / 拼音处理
#ifndef YUNYI_CORE_RT_HPP
#define YUNYI_CORE_RT_HPP

#include <commdlg.h>
#include <cstdarg>
#include <cstring>
#include <cwchar>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <cctype>
#include <cfenv>
#include <algorithm>
#include <functional>
#include <vector>

namespace yy {
// 动态取得只在特定 DLL 里的 Windows API（不必额外链接 comdlg32 / gdi32 / winmm / advapi32）
template <typename FN>
inline FN 取函数(const wchar_t *dll, const char *fn) {
    return reinterpret_cast<FN>(取API(dll, fn));
}
// 日期时间在云易用「长整数时间戳」（1970 年起的秒数）表示
inline tm 到日历(long long 时间戳) {
    time_t t = (time_t)时间戳;
    const tm *p = localtime(&t);
    if (p) return *p;
    tm lt;
    memset(&lt, 0, sizeof(lt));
    lt.tm_year = 70;
    lt.tm_mday = 1;
    return lt;
}
inline long long 到时间戳(tm lt) { return (long long)mktime(&lt); }
inline long long 现在() { return (long long)time(nullptr); }
} // namespace yy

// ============ 算术运算补充 ============
inline 长整数型 绝对取整(小数型 x) { return x >= 0 ? (长整数型)std::ceil(x) : (长整数型)std::floor(x); }
inline 小数型 求反对数(小数型 x) { return std::exp(x); }
inline 逻辑型 是否运算正确() {
    int f = std::fetestexcept(FE_INVALID | FE_DIVBYZERO | FE_OVERFLOW);
    std::feclearexcept(FE_ALL_EXCEPT);
    return f == 0;
}
inline 逻辑型 近似等于(小数型 a, 小数型 b, 小数型 精度 = 0.000001) { return std::fabs(a - b) <= 精度; }

// ============ 位运算补充 ============
inline 长整数型 合并整数(整数型 高32位, 整数型 低32位) {
    return (((长整数型)(unsigned int)高32位) << 32) | (长整数型)(unsigned int)低32位;
}
inline 整数型 合并短整数(短整数型 高16位, 短整数型 低16位) {
    return (((整数型)(unsigned short)高16位) << 16) | (整数型)(unsigned short)低16位;
}

// ============ 数值转换补充 ============
inline 小数型 到数值(const 文本型 &s) {
    if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X'))
        return (小数型)strtoll(s.c_str(), nullptr, 16);
    try { return std::stod(s); } catch (...) { return 0.0; }
}
inline 小数型 到数值(小数型 v) { return v; }
inline 小数型 到数值(长整数型 v) { return (小数型)v; }
inline 小数型 到数值(整数型 v) { return (小数型)v; }
inline 短整数型 到短整数(const 文本型 &s) {
    try { return (短整数型)std::stoi(s); } catch (...) { return 0; }
}
inline 短整数型 到短整数(小数型 v) { return (短整数型)v; }
inline 短整数型 到短整数(长整数型 v) { return (短整数型)v; }
inline 短整数型 到短整数(整数型 v) { return (短整数型)v; }

namespace yy {
// 四位数一段 → 中文数字；金额大写用「壹拾佰仟」
inline 文本型 段到中文(整数型 n, bool 金额大写) {
    const char *数字[] = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};
    const char *金额[] = {"零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"};
    const char *位[] = {"千", "百", "十", ""};
    const char *位金[] = {"仟", "佰", "拾", ""};
    const char **D = 金额大写 ? 金额 : 数字;
    const char **P = 金额大写 ? 位金 : 位;
    int d[4] = {(n / 1000) % 10, (n / 100) % 10, (n / 10) % 10, n % 10};
    文本型 out;
    bool 待补零 = false;
    for (int i = 0; i < 4; ++i) {
        if (d[i] == 0) { 待补零 = !out.empty(); continue; }
        if (待补零) { out += D[0]; 待补零 = false; }
        // 「十几」读作「十」而不是「一十」（仅在最高位的十位上省略）
        bool 省略一 = (!金额大写 && i == 2 && d[i] == 1 && out.empty());
        if (!省略一) out += D[d[i]];
        out += P[i];
    }
    return out;
}
inline 文本型 整数到中文(long long v, bool 金额大写) {
    if (v == 0) return "零";
    unsigned long long n = (v < 0) ? (unsigned long long)(-v) : (unsigned long long)v;
    const char *段名[] = {"", "万", "亿", "万亿", "亿亿"};
    std::vector<整数型> 段;
    while (n > 0) { 段.push_back((整数型)(n % 10000)); n /= 10000; }
    文本型 out;
    bool 已输出 = false;      // 是否已经写出过内容（用于决定是否补「零」）
    bool 待补零 = false;
    for (size_t i = 段.size(); i-- > 0;) {
        if (段[i] == 0) { 待补零 = 已输出; continue; }
        if (待补零) { out += "零"; 待补零 = false; }
        out += 段到中文(段[i], 金额大写) + 段名[i];
        已输出 = true;
    }
    return (v < 0 ? "负" : "") + out;
}
} // namespace yy

inline 文本型 数值到大写(小数型 v, 逻辑型 金额大写 = 假) {
    if (金额大写) {
        long long 分 = (long long)llround(std::fabs(v) * 100.0);
        文本型 out = (v < 0 ? "负" : "");
        if (分 == 0) return out + "零元整";
        long long 元 = 分 / 100, 角 = (分 / 10) % 10, 分位 = 分 % 10;
        if (元 > 0) out += yy::整数到中文(元, true) + "元";
        if (角 > 0) out += yy::整数到中文(角, true) + "角";
        else if (元 > 0 && 分位 > 0) out += "零";
        if (分位 > 0) out += yy::整数到中文(分位, true) + "分";
        return out + "整";
    }
    long long 整数部分 = (long long)std::trunc(v);
    小数型 余 = std::fabs(v - (小数型)整数部分);
    文本型 out = yy::整数到中文(整数部分, false);
    if (余 > 1e-9) {
        out += "点";
        char buf[32];
        snprintf(buf, sizeof(buf), "%.6f", 余);
        文本型 s = buf;
        size_t pos = s.find('.');
        if (pos != 文本型::npos) {
            s = s.substr(pos + 1);
            while (!s.empty() && s[s.size() - 1] == '0') s.erase(s.size() - 1);
            for (char c : s) out += yy::整数到中文(c - '0', false);
        }
    }
    return out;
}

namespace yy {
// 给整数文本加千分位（从左往右每三位一组）
inline 文本型 加千分位(文本型 整) {
    文本型 r;
    int cnt = 0;
    for (size_t i = 0; i < 整.size(); ++i) {
        if (cnt > 0 && cnt % 3 == 0) r = "," + r;
        r = 整.substr(整.size() - 1 - i, 1) + r;
        ++cnt;
    }
    return r;
}
} // namespace yy

inline 文本型 数值到金额(小数型 v, 逻辑型 大写金额 = 假) {
    if (大写金额) return 数值到大写(v, 真);
    char buf[64];
    snprintf(buf, sizeof(buf), "%.2f", v);
    文本型 s = buf;
    size_t pos = s.find('.');
    文本型 整 = (pos == 文本型::npos) ? s : s.substr(0, pos);
    文本型 小 = (pos == 文本型::npos) ? "00" : s.substr(pos + 1);
    bool 负 = !整.empty() && 整[0] == '-';
    if (负) 整.erase(0, 1);
    return (负 ? "-￥" : "￥") + yy::加千分位(整) + "." + 小;
}

inline 文本型 数值到格式文本(小数型 v, 长整数型 小数位 = 0, 逻辑型 千分位 = 真) {
    char fmt[16], buf[128];
    snprintf(fmt, sizeof(fmt), "%%.%df", (int)小数位);
    snprintf(buf, sizeof(buf), fmt, v);
    文本型 s = buf;
    if (!千分位) return s;
    size_t pos = s.find('.');
    文本型 整 = (pos == 文本型::npos) ? s : s.substr(0, pos);
    文本型 小 = (pos == 文本型::npos) ? "" : s.substr(pos);
    bool 负 = !整.empty() && 整[0] == '-';
    if (负) 整.erase(0, 1);
    return (负 ? "-" : "") + yy::加千分位(整) + 小;
}

inline 文本型 取十六进制文本(长整数型 v, 长整数型 位数 = 0) {
    std::ostringstream os;
    os << std::hex << std::uppercase << (unsigned long long)v;
    文本型 s = os.str();
    if (位数 > 0 && (长整数型)s.size() < 位数) s = 文本型((size_t)(位数 - (长整数型)s.size()), '0') + s;
    return s;
}
inline 文本型 取八进制文本(长整数型 v, 长整数型 位数 = 0) {
    std::ostringstream os;
    os << std::oct << (unsigned long long)v;
    文本型 s = os.str();
    if (位数 > 0 && (长整数型)s.size() < 位数) s = 文本型((size_t)(位数 - (长整数型)s.size()), '0') + s;
    return s;
}

// ============ 兼容别名（云易早期命令名 → 标准名） ============
inline 小数型 求自然对数(小数型 x) { return 取自然对数(x); }   // 「求自然对数」= yunyi_rt.hpp 里的取自然对数

// ============ 文本操作补充 ============
inline 文本型 字符(长整数型 字符代码) { return yy::编码字符((unsigned int)字符代码); }
inline 整数型 取代码(const 文本型 &s, 长整数型 位置 = 1) {
    文本型 c = 取字符(s, 位置);
    if (c.empty()) return 0;
    size_t i = 0;
    return (整数型)yy::解码字符(c, i);
}
inline 文本型 文本替换(const 文本型 &源, const 文本型 &找, const 文本型 &替换为) {
    if (找.empty()) return 源;
    size_t pos = 源.find(找);
    if (pos == 文本型::npos) return 源;
    文本型 结果 = 源;
    结果.replace(pos, 找.size(), 替换为);
    return 结果;
}
inline 文本型 指针到文本(长整数型 内存地址, 长整数型 最大长度 = -1) {
    if (内存地址 == 0) return "";
    const char *p = reinterpret_cast<const char *>((uintptr_t)内存地址);
    size_t n = 0;
    while (p[n] != '\0' && (最大长度 < 0 || (长整数型)n < 最大长度)) ++n;
    return 文本型(p, n);
}

// ============ 时间操作 ============
// 时间部分：1年 2月 3日 4时 5分 6秒 7星期
inline long long 到时间(const 文本型 &s) {
    if (s.empty()) return 0;
    int Y = 0, M = 1, D = 1, h = 0, m = 0, sec = 0;
    int got = sscanf(s.c_str(), "%d-%d-%d %d:%d:%d", &Y, &M, &D, &h, &m, &sec);
    if (got < 3) got = sscanf(s.c_str(), "%d/%d/%d %d:%d:%d", &Y, &M, &D, &h, &m, &sec);
    if (got < 3) {
        got = sscanf(s.c_str(), "%d-%d-%d", &Y, &M, &D);
        if (got < 3) got = sscanf(s.c_str(), "%d/%d/%d", &Y, &M, &D);
    }
    if (got < 1 || Y < 1970) return 0;
    tm lt;
    memset(&lt, 0, sizeof(lt));
    lt.tm_year = Y - 1900;
    lt.tm_mon = M - 1;
    lt.tm_mday = D;
    lt.tm_hour = h;
    lt.tm_min = m;
    lt.tm_sec = sec;
    lt.tm_isdst = -1;
    return yy::到时间戳(lt);
}
inline long long 到时间(长整数型 v) { return v; }
inline long long 到时间(整数型 v) { return (long long)v; }
inline long long 到时间(小数型 v) { return (long long)v; }

inline long long 增减时间(长整数型 时间, 整数型 部分, 长整数型 增量) {
    tm lt = yy::到日历(时间);
    switch (部分) {
    case 1: lt.tm_year += (int)增量; break;
    case 2: lt.tm_mon += (int)增量; break;
    case 3: lt.tm_mday += (int)增量; break;
    case 4: lt.tm_hour += (int)增量; break;
    case 5: lt.tm_min += (int)增量; break;
    case 6: lt.tm_sec += (int)增量; break;
    case 7: lt.tm_mday += (int)增量 * 7; break;
    default: break;
    }
    return yy::到时间戳(lt);
}

inline long long 取时间间隔(长整数型 时间1, 长整数型 时间2, 整数型 部分) {
    long long d = 时间1 - 时间2;
    switch (部分) {
    case 1: return (long long)((小数型)d / 31557600.0);
    case 2: return (long long)((小数型)d / 2629800.0);
    case 3: return d / 86400;
    case 4: return d / 3600;
    case 5: return d / 60;
    case 7: return d / 604800;
    default: return d;
    }
}

inline 整数型 取某月天数(整数型 年, 整数型 月) {
    static const int 天[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (月 < 1 || 月 > 12) return 0;
    if (月 == 2 && ((年 % 4 == 0 && 年 % 100 != 0) || 年 % 400 == 0)) return 29;
    return 天[月 - 1];
}

inline 长整数型 指定时间(长整数型 年 = 0, 长整数型 月 = 0, 长整数型 日 = 0,
                       长整数型 时 = 0, 长整数型 分 = 0, 长整数型 秒 = 0) {
    tm lt = yy::到日历(yy::现在());
    if (年 > 0) lt.tm_year = (int)年 - 1900;
    if (月 > 0) lt.tm_mon = (int)月 - 1;
    if (日 > 0) lt.tm_mday = (int)日;
    lt.tm_hour = (int)时;
    lt.tm_min = (int)分;
    lt.tm_sec = (int)秒;
    return yy::到时间戳(lt);
}

inline 整数型 取时间部分(长整数型 时间, 整数型 部分) {
    tm lt = yy::到日历(时间);
    switch (部分) {
    case 1: return lt.tm_year + 1900;
    case 2: return lt.tm_mon + 1;
    case 3: return lt.tm_mday;
    case 4: return lt.tm_hour;
    case 5: return lt.tm_min;
    case 6: return lt.tm_sec;
    case 7: return lt.tm_wday + 1;
    default: return 0;
    }
}

inline 文本型 时间到文本(长整数型 时间, 整数型 方式 = 0) {
    tm lt = yy::到日历(时间);
    char buf[64];
    if (方式 == 1) snprintf(buf, sizeof(buf), "%04d-%02d-%02d", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday);
    else if (方式 == 2) snprintf(buf, sizeof(buf), "%02d:%02d:%02d", lt.tm_hour, lt.tm_min, lt.tm_sec);
    else snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
                  lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday, lt.tm_hour, lt.tm_min, lt.tm_sec);
    return buf;
}

inline 整数型 取年份(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 1); }
inline 整数型 取月份(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 2); }
inline 整数型 取日(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 3); }
inline 整数型 取小时(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 4); }
inline 整数型 取分钟(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 5); }
inline 整数型 取秒(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 6); }
inline 整数型 取星期几(长整数型 时间 = -1) { return 取时间部分(时间 < 0 ? yy::现在() : 时间, 7); }
inline 整数型 取星期(长整数型 时间 = -1) { return 取星期几(时间); }
inline 文本型 取日期(长整数型 时间 = -1) { return 时间到文本(时间 < 0 ? yy::现在() : 时间, 1); }
inline 文本型 取时间(长整数型 时间 = -1) { return 时间到文本(时间 < 0 ? yy::现在() : 时间, 2); }

inline 逻辑型 置现行时间(长整数型 时间) {
    tm lt = yy::到日历(时间);
    SYSTEMTIME st;
    st.wYear = (WORD)(lt.tm_year + 1900);
    st.wMonth = (WORD)(lt.tm_mon + 1);
    st.wDayOfWeek = (WORD)lt.tm_wday;
    st.wDay = (WORD)lt.tm_mday;
    st.wHour = (WORD)lt.tm_hour;
    st.wMinute = (WORD)lt.tm_min;
    st.wSecond = (WORD)lt.tm_sec;
    st.wMilliseconds = 0;
    return SetLocalTime(&st) != 0;
}

// ============ 字节集操作 ============
namespace yy {
// 数值 → 字节集（低字节在前，即 little endian）
template <typename T>
inline 字节集 打到字节集(T v, size_t 宽) {
    字节集 r(宽);
    unsigned long long u = (unsigned long long)v;
    for (size_t i = 0; i < 宽; ++i) r[i] = (字节型)((u >> (8 * i)) & 0xFF);
    return r;
}
} // namespace yy
inline 字节集 到字节集(const 文本型 &s) { return 字节集(s.begin(), s.end()); }
inline 字节集 到字节集(const char *s) { return 到字节集(文本型(s ? s : "")); }
inline 字节集 到字节集(字节型 v) { return yy::打到字节集((unsigned long long)v, 1); }
inline 字节集 到字节集(短整数型 v) { return yy::打到字节集((unsigned short)v, 2); }
inline 字节集 到字节集(整数型 v) { return yy::打到字节集((unsigned int)v, 4); }
inline 字节集 到字节集(长整数型 v) { return yy::打到字节集((unsigned long long)v, 8); }
inline 字节集 到字节集(小数型 v) {
    unsigned int u = 0;
    memcpy(&u, &v, 4);
    return yy::打到字节集((unsigned long long)u, 4);
}
inline 字节集 到字节集(逻辑型 v) { return 字节集{ (字节型)(v ? 1 : 0) }; }

inline 字节集 取字节集右边(const 字节集 &b, 整数型 个数) {
    if (个数 <= 0) return 字节集();
    if ((size_t)个数 >= b.size()) return b;
    return 字节集(b.end() - 个数, b.end());
}
inline 字节集 取字节集中间(const 字节集 &b, 整数型 起始, 整数型 个数) {
    if (起始 < 1 || 个数 <= 0) return 字节集();
    size_t s = (size_t)(起始 - 1);
    if (s >= b.size()) return 字节集();
    size_t n = std::min((size_t)个数, b.size() - s);
    return 字节集(b.begin() + s, b.begin() + s + n);
}
inline 整数型 寻找字节集(const 字节集 &源, const 字节集 &子, 整数型 起始 = 1) {
    if (子.empty()) return 0;
    size_t s = (起始 < 1) ? 0 : (size_t)(起始 - 1);
    if (s >= 源.size()) return 0;
    auto it = std::search(源.begin() + s, 源.end(), 子.begin(), 子.end());
    if (it == 源.end()) return 0;
    return (整数型)(it - 源.begin()) + 1;
}
inline 整数型 倒找字节集(const 字节集 &源, const 字节集 &子, 整数型 起始 = -1) {
    if (子.empty()) return 0;
    long long e = (起始 < 0 || (size_t)起始 > 源.size()) ? (long long)源.size() : (long long)起始;
    for (long long i = e - 1; i >= 0; --i) {
        if ((size_t)i + 子.size() > 源.size()) continue;
        bool ok = true;
        for (size_t k = 0; k < 子.size(); ++k)
            if (源[(size_t)i + k] != 子[k]) { ok = false; break; }
        if (ok) return (整数型)i + 1;
    }
    return 0;
}
inline 字节集 字节集替换(const 字节集 &源, const 字节集 &找, const 字节集 &替换为) {
    if (找.empty()) return 源;
    字节集 r;
    size_t last = 0;
    for (size_t i = 0; i + 找.size() <= 源.size();) {
        bool hit = true;
        for (size_t k = 0; k < 找.size(); ++k)
            if (源[i + k] != 找[k]) { hit = false; break; }
        if (hit) {
            for (size_t k = last; k < i; ++k) r.push_back(源[k]);
            for (size_t k = 0; k < 替换为.size(); ++k) r.push_back(替换为[k]);
            i += 找.size();
            last = i;
        } else ++i;
    }
    for (size_t k = last; k < 源.size(); ++k) r.push_back(源[k]);
    return r;
}
inline 字节集 子字节集替换(const 字节集 &源, const 字节集 &找, const 字节集 &替换为,
                           整数型 起始 = 1, 整数型 次数 = -1) {
    if (找.empty() || 起始 < 1) return 源;
    size_t s = (size_t)(起始 - 1);
    字节集 r(源.begin(), 源.begin() + std::min(s, 源.size()));
    整数型 计数 = 0;
    for (size_t i = std::min(s, 源.size()); i + 找.size() <= 源.size();) {
        bool hit = true;
        for (size_t k = 0; k < 找.size(); ++k)
            if (源[i + k] != 找[k]) { hit = false; break; }
        if (hit && (次数 < 0 || 计数 < 次数)) {
            for (size_t k = 0; k < 替换为.size(); ++k) r.push_back(替换为[k]);
            i += 找.size();
            ++计数;
        } else {
            r.push_back(源[i]);
            ++i;
        }
    }
    for (size_t i = r.size(); i < 源.size(); ++i) r.push_back(源[i]);
    return r;
}
inline 字节集 取空白字节集(整数型 个数) { return (个数 <= 0) ? 字节集() : 字节集((size_t)个数, 字节型(0)); }
inline 字节集 取重复字节集(整数型 次数, const 字节集 &b) {
    字节集 r;
    for (整数型 i = 0; i < 次数; ++i) r.insert(r.end(), b.begin(), b.end());
    return r;
}
inline 字节集 分割字节集(const 字节集 &源, const 字节集 &分隔, 整数型 第几份) {
    if (第几份 < 1) return 字节集();
    std::vector<字节集> 份;
    size_t last = 0;
    for (size_t i = 0; i + 分隔.size() <= 源.size();) {
        bool hit = !分隔.empty();
        for (size_t k = 0; k < 分隔.size() && hit; ++k)
            if (源[i + k] != 分隔[k]) hit = false;
        if (hit) {
            份.push_back(字节集(源.begin() + last, 源.begin() + i));
            i += 分隔.size();
            last = i;
        } else ++i;
    }
    份.push_back(字节集(源.begin() + last, 源.end()));
    return ((size_t)第几份 <= 份.size()) ? 份[(size_t)第几份 - 1] : 字节集();
}
inline 字节集 指针到字节集(长整数型 地址, 长整数型 字节数) {
    if (地址 == 0 || 字节数 <= 0) return 字节集();
    const 字节型 *p = reinterpret_cast<const 字节型 *>((uintptr_t)地址);
    return 字节集(p, p + (size_t)字节数);
}

inline 长整数型 取字节集数据(const 字节集 &b, const 文本型 &类型名, 整数型 起始 = 1) {
    size_t s = (起始 < 1) ? 0 : (size_t)(起始 - 1);
    if (s >= b.size()) return 0;
    unsigned long long v = 0;
    size_t 宽 = (类型名 == "字节型" || 类型名 == "逻辑型") ? 1
              : (类型名 == "短整数型") ? 2
              : (类型名 == "整数型" || 类型名 == "小数型") ? 4 : 8;
    for (size_t i = 0; i < 宽 && s + i < b.size(); ++i)
        v |= ((unsigned long long)b[s + i]) << (8 * i);
    if (宽 == 1) return (长整数型)(unsigned char)v;
    if (宽 == 2) return (长整数型)(short)(unsigned short)v;
    if (宽 == 4) return (长整数型)(int)(unsigned int)v;
    return (长整数型)v;
}

// ============ 磁盘操作 ============
inline 长整数型 取磁盘剩余空间(const 文本型 &路径) {
    std::wstring p = yy::到宽文本(路径);
    ULARGE_INTEGER 总, 余;
    if (!GetDiskFreeSpaceExW(p.c_str(), &余, &总, nullptr)) return -1;
    return (长整数型)余.QuadPart;
}
inline 长整数型 取磁盘总空间(const 文本型 &路径) {
    std::wstring p = yy::到宽文本(路径);
    ULARGE_INTEGER 总, 余;
    if (!GetDiskFreeSpaceExW(p.c_str(), &余, &总, nullptr)) return -1;
    return (长整数型)总.QuadPart;
}
inline 文本型 取磁盘卷标(const 文本型 &盘符) {
    std::wstring root = yy::到宽文本(盘符);
    if (root.size() == 1) root += L":\\";
    wchar_t 卷标[MAX_PATH + 1] = {0};
    DWORD 序号 = 0, 长度 = 0, 标志 = 0;
    if (!GetVolumeInformationW(root.c_str(), 卷标, MAX_PATH, &序号, &长度, &标志, nullptr, 0)) return "";
    return yy::到窄文本(卷标);
}
inline 逻辑型 置磁盘卷标(const 文本型 &盘符, const 文本型 &卷标) {
    std::wstring root = yy::到宽文本(盘符);
    if (root.size() == 1) root += L":\\";
    return SetVolumeLabelW(root.c_str(), yy::到宽文本(卷标).c_str()) != 0;
}
inline 长整数型 取硬盘特征字(const 文本型 &盘符 = "") {
    std::wstring root = yy::到宽文本(盘符);
    if (root.empty()) root = L"\\\\.\\PhysicalDrive0";
    else if (root.size() == 1) root += L":\\";
    DWORD 序号 = 0;
    if (!GetVolumeInformationW(root.c_str(), nullptr, 0, &序号, nullptr, nullptr, nullptr, 0)) {
        std::wstring s = root.substr(0, 1) + L":\\";
        if (!GetVolumeInformationW(s.c_str(), nullptr, 0, &序号, nullptr, nullptr, nullptr, 0)) return 0;
    }
    return (长整数型)(unsigned long)序号;
}
inline 逻辑型 改变驱动器(const 文本型 &盘符) {
    std::wstring s = yy::到宽文本(盘符);
    int 号 = -1;
    if (!s.empty()) {
        wchar_t c = (wchar_t)towlower(s[0]);
        if (c >= L'a' && c <= L'z') 号 = c - L'a' + 1;
    }
    return 号 > 0 && _chdrive(号) == 0;
}
inline 逻辑型 改变目录(const 文本型 &路径) { return 置当前目录(路径); }
inline 逻辑型 文件更名(const 文本型 &原名, const 文本型 &新名) { return 移动文件(原名, 新名); }

// 「寻找文件」：同一个通配模式每次调用返回下一个匹配到的文件名，没有则返回空文本
inline 文本型 寻找文件(const 文本型 &通配名, 整数型 属性 = -1) {
    struct 状态 { HANDLE h = INVALID_HANDLE_VALUE; 文本型 模式; };
    static std::vector<状态> 表;
    for (auto &s : 表)
        if (s.模式 == 通配名) {
            if (s.h == INVALID_HANDLE_VALUE) return "";
            WIN32_FIND_DATAW fd;
            if (FindNextFileW(s.h, &fd)) return yy::到窄文本(fd.cFileName);
            FindClose(s.h);
            s.h = INVALID_HANDLE_VALUE;
            return "";
        }
    状态 s;
    s.模式 = 通配名;
    WIN32_FIND_DATAW fd;
    s.h = FindFirstFileW(yy::到宽文本(通配名).c_str(), &fd);
    表.push_back(s);
    if (s.h == INVALID_HANDLE_VALUE) {
        表.back() = s;
        return "";
    }
    // 属性：-1 或 0 表示不过滤；否则按位测试 dwFileAttributes
    auto 命中 = [&](DWORD a) {
        if (属性 <= 0) return true;
        if (属性 & 16) return (a & FILE_ATTRIBUTE_DIRECTORY) != 0;
        DWORD mask = 0;
        if (属性 & 1) mask |= FILE_ATTRIBUTE_READONLY;
        if (属性 & 2) mask |= FILE_ATTRIBUTE_HIDDEN;
        if (属性 & 4) mask |= FILE_ATTRIBUTE_SYSTEM;
        if (属性 & 32) mask |= FILE_ATTRIBUTE_ARCHIVE;
        return mask == 0 || (a & mask) != 0;
    };
    while (!命中(fd.dwFileAttributes)) {
        if (!FindNextFileW(s.h, &fd)) { FindClose(s.h); 表.back().h = INVALID_HANDLE_VALUE; return ""; }
    }
    表.back() = s;
    return yy::到窄文本(fd.cFileName);
}

inline 长整数型 取文件时间(const 文本型 &文件名, 整数型 类型 = 3) {
    std::wstring p = yy::到宽文本(文件名);
    WIN32_FILE_ATTRIBUTE_DATA d;
    HANDLE h = CreateFileW(p.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    FILETIME ft{};
    bool ok = false;
    if (h != INVALID_HANDLE_VALUE) {
        FILETIME c, a, m;
        if (GetFileTime(h, &c, &a, &m)) {
            ft = (类型 == 1) ? c : (类型 == 2) ? a : m;
            ok = true;
        }
        CloseHandle(h);
    } else if (GetFileAttributesExW(p.c_str(), GetFileExInfoStandard, &d)) {
        ft = (类型 == 1) ? d.ftCreationTime : (类型 == 2) ? d.ftLastAccessTime : d.ftLastWriteTime;
        ok = true;
    }
    if (!ok) return 0;
    ULARGE_INTEGER u;
    u.LowPart = ft.dwLowDateTime;
    u.HighPart = ft.dwHighDateTime;
    long long v = (long long)u.QuadPart;
    if (v == 0) return 0;
    return (long long)(v / 10000000ULL - 11644473600ULL);      // FILETIME → Unix 时间戳
}
inline 长整数型 取文件尺寸(const 文本型 &文件名) { return 取文件长度(文件名); }
inline 整数型 取文件属性(const 文本型 &文件名) {
    DWORD a = GetFileAttributesW(yy::到宽文本(文件名).c_str());
    if (a == INVALID_FILE_ATTRIBUTES) return -1;
    整数型 r = 0;
    if (a & FILE_ATTRIBUTE_READONLY) r |= 1;
    if (a & FILE_ATTRIBUTE_HIDDEN) r |= 2;
    if (a & FILE_ATTRIBUTE_SYSTEM) r |= 4;
    if (a & FILE_ATTRIBUTE_DIRECTORY) r |= 16;
    if (a & FILE_ATTRIBUTE_ARCHIVE) r |= 32;
    return r;
}
inline 逻辑型 置文件属性(const 文本型 &文件名, 整数型 属性) {
    DWORD old = GetFileAttributesW(yy::到宽文本(文件名).c_str());
    if (old == INVALID_FILE_ATTRIBUTES) return 假;
    DWORD a = old & ~(DWORD)(FILE_ATTRIBUTE_READONLY | FILE_ATTRIBUTE_HIDDEN |
                             FILE_ATTRIBUTE_SYSTEM | FILE_ATTRIBUTE_ARCHIVE);
    if (属性 & 1) a |= FILE_ATTRIBUTE_READONLY;
    if (属性 & 2) a |= FILE_ATTRIBUTE_HIDDEN;
    if (属性 & 4) a |= FILE_ATTRIBUTE_SYSTEM;
    if (属性 & 32) a |= FILE_ATTRIBUTE_ARCHIVE;
    return SetFileAttributesW(yy::到宽文本(文件名).c_str(), a) != 0;
}
inline 文本型 取临时文件名(const 文本型 &目录 = "") {
    std::wstring dir = yy::到宽文本(目录);
    if (dir.empty()) {
        wchar_t buf[MAX_PATH + 1];
        DWORD n = GetTempPathW(MAX_PATH + 1, buf);
        dir = n ? std::wstring(buf, n) : std::wstring(L".");
    }
    wchar_t 文件[MAX_PATH + 1] = {0};
    if (!GetTempFileNameW(dir.c_str(), L"yy", 0, 文件)) return "";
    return yy::到窄文本(文件);
}

// ============ 文件读写（文件号） ============
// 打开方式：1=读入 2=重写 3=改写（追加）4=随机读写
// 文件号从 1 开始；同一套机制也支持「打开内存文件」与「打开加密文件」。
namespace yyfile {
struct 句柄 {
    FILE *文件 = nullptr;        // 普通文件
    文本型 缓冲;                   // 内存文件的数据
    size_t 位置 = 0;             // 内存文件的读写位置
    bool 内存 = false;
    bool 使用中 = false;
    字节型 密钥 = 0;               // 0=不加密（打开加密文件时非 0）
};
inline std::vector<句柄> &表() {
    static std::vector<句柄> t;
    return t;
}
inline 长整数型 分配(句柄 h) {
    h.使用中 = true;
    for (size_t i = 0; i < 表().size(); ++i)
        if (!表()[i].使用中) { 表()[i] = h; return (长整数型)i + 1; }
    表().push_back(h);
    return (长整数型)表().size();
}
inline 句柄 *取(长整数型 号) {
    if (号 < 1 || (size_t)号 > 表().size()) return nullptr;
    句柄 *h = &表()[(size_t)号 - 1];
    if (!h->使用中 || (!h->文件 && !h->内存)) return nullptr;
    return h;
}
inline 字节型 密码字节(字节型 密钥, long long 偏移) { return (字节型)(密钥 + (字节型)(偏移 % 251)); }
// 原始读写（不含解密）
inline size_t 读原始(句柄 *h, void *buf, size_t n) {
    if (h->内存) {
        size_t 可用 = (h->位置 < h->缓冲.size()) ? (h->缓冲.size() - h->位置) : 0;
        size_t got = std::min(n, 可用);
        if (got) memcpy(buf, h->缓冲.data() + h->位置, got);
        h->位置 += got;
        return got;
    }
    return fread(buf, 1, n, h->文件);
}
inline size_t 写原始(句柄 *h, const void *buf, size_t n) {
    if (h->内存) {
        if (h->位置 + n > h->缓冲.size()) h->缓冲.resize(h->位置 + n, '\0');
        if (n) memcpy(&h->缓冲[h->位置], buf, n);
        h->位置 += n;
        return n;
    }
    return fwrite(buf, 1, n, h->文件);
}
inline long long 位置(句柄 *h) { return h->内存 ? (long long)h->位置 : (long long)ftell(h->文件); }
inline long long 长度(句柄 *h) {
    if (h->内存) return (long long)h->缓冲.size();
    long long 老 = ftell(h->文件);
    fseek(h->文件, 0, SEEK_END);
    long long 尾 = (long long)ftell(h->文件);
    fseek(h->文件, (long)老, SEEK_SET);
    return 尾;
}
inline bool 定位(句柄 *h, long long p) {
    if (h->内存) {
        if (p < 0) p = 0;
        if ((size_t)p > h->缓冲.size()) h->缓冲.resize((size_t)p, '\0');
        h->位置 = (size_t)p;
        return true;
    }
    return fseek(h->文件, (long)p, SEEK_SET) == 0;
}
// 读写 + 自动加解密（密钥为 0 时原样）
inline size_t 读(句柄 *h, void *buf, size_t n) {
    long long 起点 = 位置(h);
    size_t got = 读原始(h, buf, n);
    if (h->密钥)
        for (size_t i = 0; i < got; ++i)
            ((字节型 *)buf)[i] ^= 密码字节(h->密钥, 起点 + (long long)i);
    return got;
}
inline size_t 写(句柄 *h, const void *buf, size_t n) {
    long long 起点 = 位置(h);
    if (h->密钥) {
        std::vector<字节型> tmp(n);
        memcpy(tmp.data(), buf, n);
        for (size_t i = 0; i < n; ++i) tmp[i] ^= 密码字节(h->密钥, 起点 + (long long)i);
        return 写原始(h, tmp.data(), n);
    }
    return 写原始(h, buf, n);
}
inline bool 关闭(长整数型 号) {
    句柄 *h = 取(号);
    if (!h) return false;
    if (h->文件) fclose(h->文件);
    *h = 句柄();
    return true;
}
inline 文本型 模式串(整数型 方式) {
    switch (方式) {
    case 1: return "rb";
    case 2: return "w+b";
    case 3: return "a+b";
    default: return "r+b";
    }
}
} // namespace yyfile

inline 整数型 打开文件(const 文本型 &文件名, 整数型 打开方式 = 1, 整数型 共享方式 = -1, 整数型 保存方式 = 3) {
    (void)保存方式;
    std::wstring p = yy::到宽文本(文件名);
    文本型 m = yyfile::模式串(打开方式);
    if (打开方式 == 4 || 打开方式 == 1) {
        DWORD a = ::GetFileAttributesW(p.c_str());
        if (a == INVALID_FILE_ATTRIBUTES && (打开方式 == 1 || 打开方式 == 4)) {
            if (打开方式 == 1) return -1;      // 读入方式要求文件已存在
            FILE *试 = _wfopen(p.c_str(), L"wb");
            if (试) fclose(试);
        }
    }
    // 共享方式由成员记住（读写层面上不影响），实际打开统一不带拒绝共享
    (void)共享方式;
    FILE *f = _wfopen(p.c_str(), yy::到宽文本(m).c_str());
    if (!f) return -1;
    yyfile::句柄 h;
    h.文件 = f;
    long long 号 = yyfile::分配(h);
    if (打开方式 == 3) yyfile::定位(yyfile::取(号), (long long)0);
    return (整数型)号;
}
inline 整数型 打开加密文件(const 文本型 &文件名, const 文本型 &密码, 整数型 打开方式 = 4, 整数型 共享方式 = -1) {
    整数型 号 = 打开文件(文件名, 打开方式, 共享方式, 3);
    if (号 < 0) return -1;
    yyfile::句柄 *h = yyfile::取((长整数型)号);
    unsigned char k = 0;
    for (char c : 密码) k = (unsigned char)(k * 31 + (unsigned char)c);
    h->密钥 = k ? k : (字节型)1;
    return 号;
}

inline 整数型 打开内存文件(const 字节集 &数据, const 文本型 &文件名 = "") {
    (void)文件名;
    yyfile::句柄 h;
    h.内存 = true;
    h.缓冲.assign(数据.begin(), 数据.end());
    return (整数型)yyfile::分配(h);
}
inline 整数型 打开内存文件(const 文本型 &文本数据, const 文本型 &文件名 = "") {
    return 打开内存文件(到字节集(文本数据), 文件名);
}
inline 逻辑型 关闭文件(整数型 文件号) { return yyfile::关闭((长整数型)文件号); }
inline void 关闭所有文件() {
    for (size_t i = 0; i < yyfile::表().size(); ++i) yyfile::关闭((长整数型)i + 1);
}

inline 长整数型 取读写位置(整数型 文件号) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    return h ? yyfile::位置(h) : -1;
}
inline 逻辑型 移到文件首(整数型 文件号) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    return h && yyfile::定位(h, 0);
}
inline 逻辑型 移到文件尾(整数型 文件号) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 假;
    if (h->内存) { h->位置 = h->缓冲.size(); return 真; }
    return fseek(h->文件, 0, SEEK_END) == 0;
}
inline 逻辑型 移动读写位置(整数型 文件号, 整数型 移动方式 = 1, 长整数型 字节数 = 0) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 假;
    long long 目标;
    if (移动方式 == 1) 目标 = 字节数;                        // 相对文件首
    else if (移动方式 == 2) 目标 = yyfile::位置(h) + 字节数;  // 相对当前位置
    else 目标 = yyfile::长度(h) + 字节数;                     // 相对文件尾
    if (目标 < 0) 目标 = 0;
    return yyfile::定位(h, 目标);
}
inline 长整数型 取文件长度(长整数型 文件号) {
    yyfile::句柄 *h = yyfile::取(文件号);
    return h ? yyfile::长度(h) : -1;
}
inline 逻辑型 是否在文件尾(整数型 文件号) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 真;
    return yyfile::位置(h) >= (long long)取文件长度((长整数型)文件号);
}

inline 字节集 读入字节集(整数型 文件号, 长整数型 字节数 = -1) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 字节集();
    size_t 要读;
    if (字节数 < 0) {
        long long 余 = (long long)取文件长度((长整数型)文件号) - yyfile::位置(h);
        要读 = (余 > 0) ? (size_t)余 : 0;
    } else 要读 = (size_t)字节数;
    字节集 r(要读);
    size_t got = yyfile::读(h, r.data(), 要读);
    r.resize(got);
    return r;
}
inline 字节集 读入数据(整数型 文件号, 长整数型 字节数) { return 读入字节集(文件号, 字节数); }
inline 文本型 读入文本(整数型 文件号, 长整数型 字符数 = -1) {
    字节集 b = 读入字节集(文件号, 字符数 < 0 ? -1 : 字符数);
    return 文本型(b.begin(), b.end());
}
inline 文本型 读入一行(整数型 文件号) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return "";
    文本型 r;
    char c;
    long long 起点 = yyfile::位置(h);
    while (yyfile::读(h, &c, 1) == 1) {
        if (c == '\n') {
            // 兼容 \r\n：回退删除行尾多余的 \r
            (void)起点;
            if (!r.empty() && r[r.size() - 1] == '\r') r.erase(r.size() - 1);
            break;
        }
        r += c;
    }
    return r;
}

inline 逻辑型 写出字节集(整数型 文件号, const 字节集 &欲写出的字节集, 长整数型 字节数 = -1) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 假;
    size_t n = (字节数 < 0 || (size_t)字节数 > 欲写出的字节集.size())
                   ? 欲写出的字节集.size() : (size_t)字节数;
    return n == 0 || yyfile::写(h, 欲写出的字节集.data(), n) == n;
}
inline 逻辑型 写出文本(整数型 文件号, const 文本型 &欲写出的文本, 长整数型 字符数 = -1) {
    文本型 s = (字符数 < 0 || (size_t)字符数 > 欲写出的文本.size())
                 ? 欲写出的文本 : 欲写出的文本.substr(0, (size_t)字符数);
    return 写出字节集(文件号, 到字节集(s));
}
inline 逻辑型 写出数据(整数型 文件号, const 文本型 &数据, 长整数型 字节数 = -1) { return 写出字节集(文件号, 到字节集(数据), 字节数); }
inline 逻辑型 写出数据(整数型 文件号, const 字节集 &数据, 长整数型 字节数 = -1) { return 写出字节集(文件号, 数据, 字节数); }
inline 逻辑型 写出数据(整数型 文件号, 长整数型 数据, 长整数型 字节数 = -1) { return 写出字节集(文件号, 到字节集(数据), 字节数); }
inline 逻辑型 写出数据(整数型 文件号, 小数型 数据, 长整数型 字节数 = -1) { return 写出字节集(文件号, 到字节集(数据), 字节数); }
inline 逻辑型 写文本行(整数型 文件号, const 文本型 &欲写入的文本) { return 写出文本(文件号, 欲写入的文本 + "\n"); }

inline 逻辑型 插入字节集(整数型 文件号, const 字节集 &欲插入的字节集, 长整数型 字节数 = -1) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h) return 假;
    long long 老位置 = yyfile::位置(h);
    字节集 后半 = 读入字节集(文件号, -1);
    size_t n = (字节数 < 0 || (size_t)字节数 > 欲插入的字节集.size())
                   ? 欲插入的字节集.size() : (size_t)字节数;
    yyfile::定位(h, 老位置);
    if (n && yyfile::写(h, 欲插入的字节集.data(), n) != n) return 假;
    if (!后半.empty()) yyfile::写(h, 后半.data(), 后半.size());
    yyfile::定位(h, 老位置 + (long long)n);
    return 真;
}
inline 逻辑型 插入文本(整数型 文件号, const 文本型 &欲插入的文本, 长整数型 字符数 = -1) {
    文本型 s = (字符数 < 0) ? 欲插入的文本 : 欲插入的文本.substr(0, (size_t)字符数);
    return 插入字节集(文件号, 到字节集(s));
}
inline 逻辑型 插入文本行(整数型 文件号, const 文本型 &欲插入的文本) { return 插入文本(文件号, 欲插入的文本 + "\n"); }

inline 逻辑型 删除数据(整数型 文件号, 长整数型 字节数) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h || 字节数 <= 0) return 假;
    long long 起点 = yyfile::位置(h);
    yyfile::定位(h, 起点 + 字节数);
    字节集 后半 = 读入字节集(文件号, -1);
    yyfile::定位(h, 起点);
    if (!后半.empty()) yyfile::写(h, 后半.data(), 后半.size());
    if (h->内存) { h->缓冲.resize((size_t)yyfile::位置(h)); return 真; }
    // 截断：把长度收缩到 起点 + 后半.size()
    fflush(h->文件);
    int fd = _fileno(h->文件);
    return fd >= 0 && _chsize(fd, (long)(起点 + (long long)后半.size())) == 0;
}

inline 逻辑型 锁住文件(整数型 文件号, 长整数型 起始位置 = 0, 长整数型 字节数 = -1) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h || h->内存) return 假;
    fflush(h->文件);
    int fd = _fileno(h->文件);
    if (fd < 0) return 假;
    HANDLE os = (HANDLE)_get_osfhandle(fd);
    // 省略字节数时锁住整段文件（至少 1 字节）
    long long len = (字节数 < 0) ? yyfile::长度(h) : 字节数;
    if (len <= 0) len = 1;
    return LockFile(os, (DWORD)起始位置, (DWORD)((起始位置 >> 32) & 0xFFFFFFFF),
                    (DWORD)len, (DWORD)((len >> 32) & 0xFFFFFFFF)) != 0;
}
inline 逻辑型 解锁文件(整数型 文件号, 长整数型 起始位置 = 0, 长整数型 字节数 = -1) {
    yyfile::句柄 *h = yyfile::取((长整数型)文件号);
    if (!h || h->内存) return 假;
    fflush(h->文件);
    int fd = _fileno(h->文件);
    if (fd < 0) return 假;
    HANDLE os = (HANDLE)_get_osfhandle(fd);
    long long len = (字节数 < 0) ? yyfile::长度(h) : 字节数;
    if (len <= 0) len = 1;
    if (UnlockFile(os, (DWORD)起始位置, (DWORD)((起始位置 >> 32) & 0xFFFFFFFF),
                   (DWORD)len, (DWORD)((len >> 32) & 0xFFFFFFFF)) != 0)
        return 真;
    // 这段已经不在锁定状态（ERROR_NOT_LOCKED = 158）时也视为解锁成功
    return GetLastError() == 158;
}

// ============ 系统处理 ============
inline 整数型 运行(const 文本型 &命令行, 逻辑型 是否等待 = 真) { return 执行程序(命令行, 是否等待); }
inline 逻辑型 剪辑板中可有文本() { return IsClipboardFormatAvailable(CF_UNICODETEXT) != 0; }
inline 文本型 取剪辑板文本() {
    if (!OpenClipboard(nullptr)) return "";
    HGLOBAL g = GetClipboardData(CF_UNICODETEXT);
    文本型 r;
    if (g) {
        const wchar_t *w = (const wchar_t *)GlobalLock(g);
        if (w) {
            r = yy::到窄文本(w);
            GlobalUnlock(g);
        }
    }
    CloseClipboard();
    return r;
}
inline 逻辑型 置剪辑板文本(const 文本型 &文本_) {
    if (!OpenClipboard(nullptr)) return 假;
    std::wstring w = yy::到宽文本(文本_);
    size_t n = (w.size() + 1) * sizeof(wchar_t);
    HGLOBAL g = GlobalAlloc(GMEM_MOVEABLE, n);
    if (!g) { CloseClipboard(); return 假; }
    void *p = GlobalLock(g);
    if (!p) { GlobalFree(g); CloseClipboard(); return 假; }
    memcpy(p, w.c_str(), n);
    GlobalUnlock(g);
    EmptyClipboard();
    bool ok = SetClipboardData(CF_UNICODETEXT, g) != nullptr;
    CloseClipboard();
    return ok;
}
inline 逻辑型 清除剪辑板() {
    if (!OpenClipboard(nullptr)) return 假;
    EmptyClipboard();
    CloseClipboard();
    return 真;
}
inline 整数型 取鼠标水平位置() { POINT p{0, 0}; GetCursorPos(&p); return (整数型)p.x; }
inline 整数型 取鼠标垂直位置() { POINT p{0, 0}; GetCursorPos(&p); return (整数型)p.y; }
inline 长整数型 取颜色数() {
    using FN = int (WINAPI *)(void *, int);
    static FN _GetDeviceCaps = yy::取函数<FN>(L"gdi32.dll", "GetDeviceCaps");
    if (!_GetDeviceCaps) return 0;
    HDC dc = ::GetDC(nullptr);
    if (!dc) return 0;
    int bits = _GetDeviceCaps(dc, 12);          // BITSPIXEL = 12
    ::ReleaseDC(nullptr, dc);
    return bits <= 0 ? 0 : (((长整数型)1) << bits);
}
inline 长整数型 取默认底色() {
    DWORD c = GetSysColor(15);                  // COLOR_BTNFACE = 15
    return (长整数型)c;
}
inline void 鸣叫(整数型 类型 = 0) {
    UINT u = MB_OK;
    switch (类型) {
    case 1: u = MB_ICONEXCLAMATION; break;
    case 2: u = MB_ICONHAND; break;
    case 3: u = MB_ICONQUESTION; break;
    default: u = MB_ICONASTERISK; break;
    }
    MessageBeep(u);
}
inline long long 取启动时间() { return (long long)GetTickCount64(); }
inline void 置等待鼠标() { SetCursor(LoadCursor(nullptr, IDC_WAIT)); }
inline void 恢复鼠标() { SetCursor(LoadCursor(nullptr, IDC_ARROW)); }

// 信息框：返回所按按钮编号（结果_确定=1 / 结果_取消=2 / 结果_终止=3 / 结果_重试=4 /
//                          结果_忽略=5 / 结果_是=6 / 结果_否=7）
inline 整数型 信息框(const 文本型 &内容, 整数型 按钮类型, const 文本型 &标题 = "云易提示") {
    UINT u = MB_OK | MB_ICONINFORMATION;
    switch (按钮类型) {
    case 1: u = MB_OKCANCEL | MB_ICONINFORMATION; break;
    case 2: u = MB_YESNO | MB_ICONQUESTION; break;
    case 3: u = MB_YESNOCANCEL | MB_ICONQUESTION; break;
    case 4: u = MB_RETRYCANCEL | MB_ICONWARNING; break;
    case 5: u = MB_ABORTRETRYIGNORE | MB_ICONWARNING; break;
    default: break;
    }
    std::wstring w = yy::到宽文本(内容), t = yy::到宽文本(标题);
    int r = MessageBoxW(nullptr, w.c_str(), t.c_str(), u);
    switch (r) {
    case IDOK: return 1;
    case IDCANCEL: return 2;
    case IDABORT: return 3;
    case IDRETRY: return 4;
    case IDIGNORE: return 5;
    case IDYES: return 6;
    case IDNO: return 7;
    default: return 0;
    }
}

// ---------- 注册表（动态加载 advapi32） ----------
namespace yyreg {
using FN_Open = long (WINAPI *)(void *, const wchar_t *, unsigned long, unsigned long, void **);
using FN_Create = long (WINAPI *)(void *, const wchar_t *, unsigned long, wchar_t *,
                                  unsigned long, unsigned long, void *, void **, unsigned long *);
using FN_Close = long (WINAPI *)(void *);
using FN_Get = long (WINAPI *)(void *, const wchar_t *, const wchar_t *, unsigned long,
                               unsigned long *, void *, unsigned long *, unsigned long *);
using FN_Set = long (WINAPI *)(void *, const wchar_t *, unsigned long, unsigned long,
                               const void *, unsigned long);
using FN_DelValue = long (WINAPI *)(void *, const wchar_t *);
using FN_DelTree = long (WINAPI *)(void *, const wchar_t *);
inline void *根键(const 文本型 &名) {
    if (名 == "HKEY_CLASSES_ROOT" || 名 == "HKCR") return HKEY_CLASSES_ROOT;
    if (名 == "HKEY_CURRENT_USER" || 名 == "HKCU") return HKEY_CURRENT_USER;
    if (名 == "HKEY_LOCAL_MACHINE" || 名 == "HKLM") return HKEY_LOCAL_MACHINE;
    if (名 == "HKEY_USERS" || 名 == "HKU") return HKEY_USERS;
    if (名 == "HKEY_CURRENT_CONFIG" || 名 == "HKCC") return HKEY_CURRENT_CONFIG;
    return nullptr;
}
// 把「HKEY_LOCAL_MACHINE\Software\x」拆成根键 + 子键
inline bool 拆分(const 文本型 &路径, void *&root, std::wstring &子键) {
    size_t pos = 路径.find('\\');
    文本型 根名 = (pos == 文本型::npos) ? 路径 : 路径.substr(0, pos);
    // 支持「注册_本地机器」这类常量拼出来的完整路径：形如 HKEY_LOCAL_MACHINE + 反斜杠
    for (const char *别名 : {"HKEY_CLASSES_ROOT", "HKEY_CURRENT_USER", "HKEY_LOCAL_MACHINE",
                             "HKEY_USERS", "HKEY_CURRENT_CONFIG"}) {
        if (根名 == 别名) { root = 根键(别名); break; }
    }
    if (!root) {
        root = 根键(到大写(根名));
        if (!root) return false;
    }
    子键 = yy::到宽文本((pos == 文本型::npos) ? "" : 路径.substr(pos + 1));
    return true;
}
inline void *打开项(const 文本型 &路径, bool 可写, void **要关闭) {
    void *root = nullptr;
    std::wstring 子键;
    if (!拆分(路径, root, 子键)) return nullptr;
    static FN_Open _Open = yy::取函数<FN_Open>(L"advapi32.dll", "RegOpenKeyExW");
    if (!_Open) return nullptr;
    void *h = nullptr;
    long r;
    if (可写) {
        FN_Create _C = yy::取函数<FN_Create>(L"advapi32.dll", "RegCreateKeyExW");
        if (!_C) return nullptr;
        unsigned long disp = 0;
        r = _C(root, 子键.c_str(), 0, nullptr, 0, 0x00020006L /*KEY_READ|KEY_WRITE*/,
               nullptr, &h, &disp);
    } else {
        r = _Open(root, 子键.c_str(), 0, 0x00020019L /*KEY_READ*/, &h);
    }
    if (r != 0) return nullptr;
    if (要关闭) *要关闭 = h;
    return h;
}
} // namespace yyreg

inline 文本型 取文本注册项(const 文本型 &注册表项路径, const 文本型 &值名 = "") {
    void *h = yyreg::打开项(注册表项路径, false, nullptr);
    if (!h) return "";
    yyreg::FN_Get _Get = yy::取函数<yyreg::FN_Get>(L"advapi32.dll", "RegGetValueW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    std::vector<wchar_t> buf(1024);
    unsigned long size = (unsigned long)(buf.size() * sizeof(wchar_t));
    const unsigned long 任意类型 = 0x0000FFFFL;             // RRF_RT_ANY
    long r = _Get ? _Get(h, nullptr, yy::到宽文本(值名).c_str(), 任意类型,
                         nullptr, buf.data(), &size, nullptr)
                  : -1;
    if (r != 0 && size > buf.size() * sizeof(wchar_t)) {
        buf.resize(size / sizeof(wchar_t) + 2);
        size = (unsigned long)(buf.size() * sizeof(wchar_t));
        r = _Get(h, nullptr, yy::到宽文本(值名).c_str(), 任意类型, nullptr,
                 buf.data(), &size, nullptr);
    }
    if (_Close) _Close(h);
    return (r == 0) ? yy::到窄文本(buf.data()) : "";
}
inline 长整数型 取数值注册项(const 文本型 &注册表项路径, const 文本型 &值名 = "") {
    void *h = yyreg::打开项(注册表项路径, false, nullptr);
    if (!h) return 0;
    yyreg::FN_Get _Get = yy::取函数<yyreg::FN_Get>(L"advapi32.dll", "RegGetValueW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    unsigned long v = 0, size = sizeof(v);
    long r = _Get ? _Get(h, nullptr, yy::到宽文本(值名).c_str(), 0x0000FFFFL /*RT_ALL*/,
                         nullptr, &v, &size, nullptr)
                  : -1;
    if (_Close) _Close(h);
    return (r == 0) ? (长整数型)v : 0;
}
inline 字节集 取字节集注册项(const 文本型 &注册表项路径, const 文本型 &值名 = "") {
    void *h = yyreg::打开项(注册表项路径, false, nullptr);
    if (!h) return 字节集();
    yyreg::FN_Get _Get = yy::取函数<yyreg::FN_Get>(L"advapi32.dll", "RegGetValueW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    std::vector<字节型> buf(1024);
    unsigned long size = (unsigned long)buf.size();
    long r = _Get ? _Get(h, nullptr, yy::到宽文本(值名).c_str(), 0x0000FFFFL,
                         nullptr, buf.data(), &size, nullptr)
                  : -1;
    if (_Close) _Close(h);
    return (r == 0) ? 字节集(buf.begin(), buf.begin() + size) : 字节集();
}
inline 逻辑型 写注册项(const 文本型 &注册表项路径, const 文本型 &值名, const 文本型 &值) {
    void *要关闭 = nullptr;
    void *h = yyreg::打开项(注册表项路径, true, &要关闭);
    if (!h) return 假;
    yyreg::FN_Set _Set = yy::取函数<yyreg::FN_Set>(L"advapi32.dll", "RegSetValueExW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    std::wstring w = yy::到宽文本(值);
    long r = _Set ? _Set(h, yy::到宽文本(值名).c_str(), 0, 1 /*REG_SZ*/,
                         w.c_str(), (unsigned long)((w.size() + 1) * sizeof(wchar_t)))
                  : -1;
    if (_Close) _Close(h);
    return r == 0;
}
inline 逻辑型 写注册项(const 文本型 &注册表项路径, const 文本型 &值名, 长整数型 值) {
    void *要关闭 = nullptr;
    void *h = yyreg::打开项(注册表项路径, true, &要关闭);
    if (!h) return 假;
    yyreg::FN_Set _Set = yy::取函数<yyreg::FN_Set>(L"advapi32.dll", "RegSetValueExW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    unsigned long v = (unsigned long)值;
    long r = _Set ? _Set(h, yy::到宽文本(值名).c_str(), 0, 4 /*REG_DWORD*/, &v, sizeof(v)) : -1;
    if (_Close) _Close(h);
    return r == 0;
}
inline 逻辑型 写注册项(const 文本型 &注册表项路径, const 文本型 &值名, const 字节集 &值) {
    void *要关闭 = nullptr;
    void *h = yyreg::打开项(注册表项路径, true, &要关闭);
    if (!h) return 假;
    yyreg::FN_Set _Set = yy::取函数<yyreg::FN_Set>(L"advapi32.dll", "RegSetValueExW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    long r = _Set ? _Set(h, yy::到宽文本(值名).c_str(), 0, 3 /*REG_BINARY*/,
                         值.data(), (unsigned long)值.size())
                  : -1;
    if (_Close) _Close(h);
    return r == 0;
}
inline 逻辑型 删除注册项(const 文本型 &注册表项路径, const 文本型 &值名 = "") {
    void *root = nullptr;
    std::wstring 子键;
    if (!yyreg::拆分(注册表项路径, root, 子键)) return 假;
    if (值名.empty()) {
        yyreg::FN_DelTree _Tree = yy::取函数<yyreg::FN_DelTree>(L"advapi32.dll", "RegDeleteTreeW");
        return _Tree && _Tree(root, 子键.c_str()) == 0;
    }
    void *要关闭 = nullptr;
    void *h = yyreg::打开项(注册表项路径, true, &要关闭);
    if (!h) return 假;
    yyreg::FN_DelValue _Del = yy::取函数<yyreg::FN_DelValue>(L"advapi32.dll", "RegDeleteValueW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    long r = _Del ? _Del(h, yy::到宽文本(值名).c_str()) : -1;
    if (_Close) _Close(h);
    return r == 0;
}
inline 逻辑型 注册项是否存在(const 文本型 &注册表项路径, const 文本型 &值名 = "") {
    void *要关闭 = nullptr;
    void *h = yyreg::打开项(注册表项路径, false, &要关闭);
    if (!h) return 假;
    if (值名.empty()) {
        yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
        if (_Close) _Close(h);
        return 真;
    }
    yyreg::FN_Get _Get = yy::取函数<yyreg::FN_Get>(L"advapi32.dll", "RegGetValueW");
    yyreg::FN_Close _Close = yy::取函数<yyreg::FN_Close>(L"advapi32.dll", "RegCloseKey");
    unsigned long size = 0;
    long r = _Get ? _Get(h, nullptr, yy::到宽文本(值名).c_str(), 0x0000FFFFL,
                         nullptr, nullptr, &size, nullptr)
                  : -1;
    if (_Close) _Close(h);
    return r == 0;
}

// ---------- ini 配置文件 ----------
inline 文本型 读配置项(const 文本型 &文件名, const 文本型 &节名, const 文本型 &项名, const 文本型 &默认文本 = "") {
    std::wstring f = yy::到宽文本(文件名);
    std::vector<wchar_t> buf(1024);
    DWORD n = GetPrivateProfileStringW(yy::到宽文本(节名).c_str(), yy::到宽文本(项名).c_str(),
                                       yy::到宽文本(默认文本).c_str(), buf.data(),
                                       (DWORD)buf.size(), f.c_str());
    if (n + 2 >= buf.size()) {
        buf.resize((size_t)n + 4);
        GetPrivateProfileStringW(yy::到宽文本(节名).c_str(), yy::到宽文本(项名).c_str(),
                                 yy::到宽文本(默认文本).c_str(), buf.data(),
                                 (DWORD)buf.size(), f.c_str());
    }
    return yy::到窄文本(buf.data());
}
inline 逻辑型 写配置项(const 文本型 &文件名, const 文本型 &节名, const 文本型 &项名, const 文本型 &值) {
    return WritePrivateProfileStringW(yy::到宽文本(节名).c_str(), yy::到宽文本(项名).c_str(),
                                      yy::到宽文本(值).c_str(),
                                      yy::到宽文本(文件名).c_str()) != 0;
}
inline 文本型 取配置节名(const 文本型 &文件名) {
    std::vector<wchar_t> buf(8192);
    DWORD n = GetPrivateProfileSectionNamesW(buf.data(), (DWORD)buf.size(),
                                             yy::到宽文本(文件名).c_str());
    文本型 r;
    size_t i = 0;
    while (i < (size_t)n && buf[i] != L'\0') {
        std::wstring one(&buf[i]);
        if (!r.empty()) r += "\n";
        r += yy::到窄文本(one);
        i += one.size() + 1;
    }
    return r;
}
inline 整数型 取操作系统类别() {
    typedef long (WINAPI *FN_RtlGetVersion)(void *);
    FN_RtlGetVersion _Ver = yy::取函数<FN_RtlGetVersion>(L"ntdll.dll", "RtlGetVersion");
    struct { unsigned long 长度, 主版本, 次版本, 内部版本, 平台; wchar_t 描述[128]; } vi;
    memset(&vi, 0, sizeof(vi));
    if (_Ver && _Ver(&vi) == 0) return (整数型)(vi.主版本 * 100 + vi.次版本);
    OSVERSIONINFOW osvi;
    memset(&osvi, 0, sizeof(osvi));
    osvi.dwOSVersionInfoSize = sizeof(osvi);
    if (GetVersionExW(&osvi)) return (整数型)(osvi.dwMajorVersion * 100 + osvi.dwMinorVersion);
    return 0;
}
inline 整数型 取系统语言() { return (整数型)(unsigned short)GetUserDefaultLangID(); }
inline 逻辑型 置DLL装载目录(const 文本型 &目录) { return SetDllDirectoryW(yy::到宽文本(目录).c_str()) != 0; }

// ---------- 多文件对话框（动态加载 comdlg32） ----------
// 过滤器写法：「图片文件|*.bmp;*.png|所有文件|*.*」→ 内部转成 Windows 需要的格式
inline 文本型 多文件对话框(const 文本型 &标题 = "打开文件", const 文本型 &过滤器 = "所有文件|*.*",
                          const 文本型 &初始目录 = "") {
    using FN_Get = int (WINAPI *)(void *);
    FN_Get _Get = yy::取函数<FN_Get>(L"comdlg32.dll", "GetOpenFileNameW");
    if (!_Get) return "";
    std::vector<wchar_t> filter;
    {
        std::wstring fl = yy::到宽文本(过滤器);
        for (wchar_t &c : fl) filter.push_back(c == L'|' ? L'\0' : c);
        filter.push_back(L'\0');
        filter.push_back(L'\0');
    }
    std::vector<wchar_t> buf(65536, L'\0');
    OPENFILENAMEW ofn;
    memset(&ofn, 0, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = nullptr;
    ofn.lpstrFilter = filter.data();
    ofn.lpstrFile = buf.data();
    ofn.nMaxFile = (DWORD)buf.size();
    ofn.Flags = 0x00080000 | 0x00000200 | 0x00001000 | 0x00000008; // EXPLORER|ALLOWMULTISELECT|HIDEREADONLY|FILEMUSTEXIST
    std::wstring t = yy::到宽文本(标题), d = yy::到宽文本(初始目录);
    ofn.lpstrTitle = t.c_str();
    ofn.lpstrInitialDir = d.empty() ? nullptr : d.c_str();
    if (!_Get(&ofn)) return "";
    // 多选结果：目录\0名字1\0名字2\0\0
    std::wstring first(&buf[0]);
    size_t pos = first.size() + 1;
    if (pos < (size_t)65536 && buf[pos] == L'\0') return yy::到窄文本(first);   // 只选了一个
    文本型 r;
    size_t i = pos;
    while (i < buf.size() && buf[i] != L'\0') {
        std::wstring one(&buf[i]);
        if (!r.empty()) r += "\n";
        r += yy::到窄文本(first) + "\\" + yy::到窄文本(one);
        i += one.size() + 1;
    }
    return r.empty() ? yy::到窄文本(first) : r;
}

// ---------- 快照：抓屏保存 BMP ----------
inline 逻辑型 快照(const 文本型 &文件名, 整数型 左边 = 0, 整数型 顶边 = 0, 整数型 宽度 = 0, 整数型 高度 = 0) {
    using FN_GetDC = void *(WINAPI *)(void *);
    using FN_ReleaseDC = int (WINAPI *)(void *, void *);
    using FN_CreateDC = void *(WINAPI *)(void *);
    using FN_Delete = int (WINAPI *)(void *);
    using FN_Select = void *(WINAPI *)(void *, void *);
    using FN_CreateBmp = void *(WINAPI *)(void *, int, int);
    using FN_BitBlt = int (WINAPI *)(void *, int, int, int, int, void *, int, int, unsigned long);
    using FN_GetDIBits = int (WINAPI *)(void *, void *, unsigned int, unsigned int,
                                        void *, void *, unsigned int);
    using FN_GetCaps = int (WINAPI *)(void *, int);
    FN_GetDC _GetDC = yy::取函数<FN_GetDC>(L"user32.dll", "GetDC");
    FN_ReleaseDC _ReleaseDC = yy::取函数<FN_ReleaseDC>(L"user32.dll", "ReleaseDC");
    FN_CreateDC _CreateDC = yy::取函数<FN_CreateDC>(L"gdi32.dll", "CreateCompatibleDC");
    FN_Delete _DeleteDC = yy::取函数<FN_Delete>(L"gdi32.dll", "DeleteDC");
    FN_Delete _DeleteObj = yy::取函数<FN_Delete>(L"gdi32.dll", "DeleteObject");
    FN_Select _Select = yy::取函数<FN_Select>(L"gdi32.dll", "SelectObject");
    FN_CreateBmp _CreateBmp = yy::取函数<FN_CreateBmp>(L"gdi32.dll", "CreateCompatibleBitmap");
    FN_BitBlt _BitBlt = yy::取函数<FN_BitBlt>(L"gdi32.dll", "BitBlt");
    FN_GetDIBits _GetDIBits = yy::取函数<FN_GetDIBits>(L"gdi32.dll", "GetDIBits");
    FN_GetCaps _GetCaps = yy::取函数<FN_GetCaps>(L"gdi32.dll", "GetDeviceCaps");
    if (!_GetDC || !_CreateDC || !_CreateBmp || !_BitBlt || !_GetDIBits) return 假;
    int w = (宽度 > 0) ? 宽度 : GetSystemMetrics(0);
    int h = (高度 > 0) ? 高度 : GetSystemMetrics(1);
    void *屏幕 = _GetDC(nullptr);
    if (!屏幕) return 假;
    void *内存 = _CreateDC(屏幕);
    void *图 = _CreateBmp(屏幕, w, h);
    if (!内存 || !图) {
        if (内存) _DeleteDC(内存);
        _ReleaseDC(nullptr, 屏幕);
        return 假;
    }
    _Select(内存, 图);
    bool ok = _BitBlt(内存, 0, 0, w, h, 屏幕, 左边, 顶边, 0x00CC0020) != 0;   // SRCCOPY
    BITMAPINFOHEADER bi;
    memset(&bi, 0, sizeof(bi));
    bi.biSize = sizeof(bi);
    bi.biWidth = w;
    bi.biHeight = h;
    bi.biPlanes = 1;
    bi.biBitCount = 24;
    bi.biCompression = 0;
    size_t 行长 = ((size_t)w * 3 + 3) & ~(size_t)3;
    std::vector<字节型> 数据(行长 * (size_t)h);
    if (ok) ok = _GetDIBits(内存, 图, 0, (unsigned int)h, 数据.data(),
                            (BITMAPINFO *)&bi, 0) != 0;
    _DeleteObj(图);
    _DeleteDC(内存);
    _ReleaseDC(nullptr, 屏幕);
    (void)_GetCaps;
    if (!ok) return 假;
    FILE *f = _wfopen(yy::到宽文本(文件名).c_str(), L"wb");
    if (!f) return 假;
    BITMAPFILEHEADER bf;
    memset(&bf, 0, sizeof(bf));
    bf.bfType = 0x4D42;
    bf.bfOffBits = sizeof(bf) + sizeof(bi);
    bf.bfSize = (DWORD)(bf.bfOffBits + 数据.size());
    fwrite(&bf, 1, sizeof(bf), f);
    fwrite(&bi, 1, sizeof(bi), f);
    fwrite(数据.data(), 1, 数据.size(), f);
    fclose(f);
    return 真;
}

// ---------- 输入框（用 Win32 窗口现做一个输入对话框） ----------
namespace yybox {
struct 数据 { HWND 编辑 = nullptr; 文本型 结果; bool 完成 = false; };
inline LRESULT CALLBACK 过程(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_CREATE) {
        CREATESTRUCTW *cs = (CREATESTRUCTW *)l;
        SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)cs->lpCreateParams);
        return 0;
    }
    数据 *d = (数据 *)GetWindowLongPtrW(h, GWLP_USERDATA);
    if (d && (m == WM_COMMAND) && HIWORD(w) == BN_CLICKED) {
        WORD id = LOWORD(w);
        if (id == 1 || id == 2) {
            if (id == 1 && d->编辑) {
                int len = GetWindowTextLengthW(d->编辑);
                std::vector<wchar_t> buf((size_t)len + 2, L'\0');
                GetWindowTextW(d->编辑, buf.data(), (int)buf.size());
                d->结果 = yy::到窄文本(buf.data());
            }
            d->完成 = true;
            DestroyWindow(h);
        }
        return 0;
    }
    if (m == WM_CLOSE) { if (d) d->完成 = true; DestroyWindow(h); return 0; }
    if (m == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(h, m, w, l);
}
inline bool 注册(HINSTANCE hinst) {
    static bool 已注册 = false;
    if (已注册) return true;
    WNDCLASSW wc;
    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc = 过程;
    wc.hInstance = hinst;
    wc.lpszClassName = L"YunYiInputBox";
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    已注册 = RegisterClassW(&wc) != 0;
    return 已注册;
}
inline std::wstring 静态类名() { return L"Static"; }
} // namespace yybox

inline 文本型 输入框(const 文本型 &提示信息, const 文本型 &标题 = "请输入",
                    const 文本型 &初始文本 = "", 逻辑型 密码输入 = 假) {
    HINSTANCE hinst = GetModuleHandleW(nullptr);
    if (!yybox::注册(hinst)) return "";
    yybox::数据 d;
    std::wstring t = yy::到宽文本(标题), p = yy::到宽文本(提示信息), s = yy::到宽文本(初始文本);
    // 屏幕居中：按主屏尺寸与窗口大小（400×150）算出左上角坐标
    int x = (GetSystemMetrics(SM_CXSCREEN) - 400) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - 150) / 2;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    HWND h = CreateWindowExW(WS_EX_DLGMODALFRAME, L"YunYiInputBox", t.c_str(),
                             WS_POPUPWINDOW | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                             x, y, 400, 150, nullptr, nullptr, hinst, &d);
    if (!h) return "";
    CreateWindowExW(0, L"Static", p.c_str(), WS_CHILD | WS_VISIBLE,
                    14, 16, 356, 20, h, nullptr, hinst, nullptr);
    d.编辑 = CreateWindowExW(WS_EX_CLIENTEDGE, L"Edit", s.c_str(),
                             WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | WS_TABSTOP
                                 | (密码输入 ? ES_PASSWORD : 0),
                             14, 44, 356, 24, h, nullptr, hinst, nullptr);
    CreateWindowExW(0, L"Button", L"确定", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON | WS_TABSTOP,
                    190, 84, 88, 28, h, (HMENU)(uintptr_t)1, hinst, nullptr);
    CreateWindowExW(0, L"Button", L"取消", WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                    286, 84, 84, 28, h, (HMENU)(uintptr_t)2, hinst, nullptr);
    SetFocus(d.编辑);
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        if (!IsWindow(h)) break;
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
        if (d.完成) break;
    }
    return d.结果;
}

// ============ 媒体播放（MCI，动态加载 winmm） ============
namespace yymp {
using FN_Send = unsigned long (WINAPI *)(const wchar_t *, wchar_t *, unsigned int, void *);
inline FN_Send 发送() { return yy::取函数<FN_Send>(L"winmm.dll", "mciSendStringW"); }
// 文件名 → 别名（避免文件路径里的空格等字符破坏 MCI 命令）
inline std::wstring 别名(const 文本型 &文件) {
    std::wstring s = yy::到宽文本(文件);
    unsigned long h = 2166136261UL;
    for (wchar_t c : s) { h ^= (unsigned long)c; h = h * 16777619UL; }
    return L"yy" + std::to_wstring(h % 1000000UL);
}
inline bool 执行(const std::wstring &命令) {
    FN_Send f = 发送();
    return f && f(命令.c_str(), nullptr, 0, nullptr) == 0;
}
inline bool 打开(const 文本型 &文件, const wchar_t *类型) {
    std::wstring a = 别名(文件);
    return 执行(L"open \"" + yy::到宽文本(文件) + L"\" type " + 类型 + L" alias " + a);
}
inline bool 播放(const 文本型 &文件, bool 重复, bool 等待) {
    std::wstring a = 别名(文件);
    std::wstring cmd = L"play " + a;
    if (重复) cmd += L" repeat";
    if (等待) cmd += L" wait";
    return 执行(cmd);
}
} // namespace yymp
inline 逻辑型 播放MP(const 文本型 &文件名, 逻辑型 重复 = 假) {
    return yymp::打开(文件名, L"mpegvideo") && yymp::播放(文件名, 重复, false);
}
inline 逻辑型 同步播放MP(const 文本型 &文件名, 逻辑型 重复 = 假) {
    return yymp::打开(文件名, L"mpegvideo") && yymp::播放(文件名, 重复, true);
}
inline 逻辑型 播放MID(const 文本型 &文件名, 逻辑型 重复 = 假) {
    return yymp::打开(文件名, L"sequencer") && yymp::播放(文件名, 重复, false);
}
inline 逻辑型 停止播放() { return yymp::执行(L"stop yyall"); }
inline 逻辑型 播放音乐(const 文本型 &文件名, 逻辑型 重复 = 假) { return 播放MP(文件名, 重复); }
inline 逻辑型 暂停播放MP(const 文本型 &文件名) { return yymp::执行(L"pause " + yymp::别名(文件名)); }
inline 逻辑型 继续播放MP(const 文本型 &文件名) { return yymp::执行(L"resume " + yymp::别名(文件名)); }
inline 整数型 取MP播放状态(const 文本型 &文件名 = "") {
    yymp::FN_Send f = yymp::发送();
    if (!f) return 0;
    std::wstring a = 文件名.empty() ? L"all" : yymp::别名(文件名);
    wchar_t buf[64] = {0};
    if (f((L"status " + a + L" mode").c_str(), buf, 64, nullptr) != 0) return 0;
    std::wstring s = buf;
    if (s == L"playing" || s == L"seeking") return 1;
    if (s == L"paused") return 2;
    return 0;
}

// ============ 程序调试 ============
// 调试输出：与「输出」写法一致（多项自动加空格、结尾换行），
// 同时写进控制台和调试器（OutputDebugStringW，可用 DebugView / IDE 输出窗口查看）
template <typename... 参数们>
void 调试输出(const 参数们 &... 参数) {
    std::ostringstream os;
    bool 首位 = true;
    auto 打印 = [&](const auto &v) {
        if (!首位) os << ' ';
        首位 = false;
        yy::写一个(os, v);
    };
    (打印(参数), ...);
    文本型 行 = os.str();
    std::cout << 行 << std::endl;
    std::wstring w = yy::到宽文本(行) + L"\n";
    OutputDebugStringW(w.c_str());
}

// 「输出调试文本」= 易语言核心支持库的标准命令名，与「调试输出」完全一致
template <typename... 参数们>
void 输出调试文本(const 参数们 &... 参数) { 调试输出(参数...); }
inline void 暂停() {
    int r = MessageBoxW(nullptr, L"程序已暂停，要继续执行吗？", L"云易·暂停",
                        MB_YESNO | MB_ICONINFORMATION | MB_TASKMODAL);
    if (r == IDNO) { std::cout.flush(); std::exit(0); }
}
inline 逻辑型 检查(逻辑型 条件, const 文本型 &提示 = "") {
    if (条件) return 真;
    std::wstring w = yy::到宽文本(提示.empty() ? 文本型("检查失败") : 提示);
    int r = MessageBoxW(nullptr, w.c_str(), L"云易·检查失败",
                        MB_ABORTRETRYIGNORE | MB_ICONERROR | MB_TASKMODAL);
    if (r == IDABORT) { std::cout.flush(); std::exit(3); }
    return 假;
}
#ifdef NDEBUG
inline 逻辑型 是否为调试版() { return 假; }
#else
inline 逻辑型 是否为调试版() { return 真; }
#endif

// ============ 其他 ============
// 两个分支的类型允许不同（如 选择(条件, 文本变量, "字面量")），取它们的公共类型
template <typename A, typename B>
inline typename std::common_type<typename std::decay<A>::type,
                                 typename std::decay<B>::type>::type
选择(逻辑型 条件, const A &真时的值, const B &假时的值) {
    typedef typename std::common_type<typename std::decay<A>::type,
                                      typename std::decay<B>::type>::type R;
    return 条件 ? (R)真时的值 : (R)假时的值;
}

// 多项选择：下标从 1 开始；越界返回最后一个值
template <typename T>
inline typename std::decay<T>::type 多项选择(长整数型 下标, const T &值1) {
    (void)下标;
    return 值1;
}
template <typename T, typename... R>
inline typename std::common_type<typename std::decay<T>::type,
                                 typename std::decay<R>::type...>::type
多项选择(长整数型 下标, const T &值1, R... 其余) {
    typedef typename std::common_type<typename std::decay<T>::type,
                                      typename std::decay<R>::type...>::type 公共;
    return (下标 <= 1) ? (公共)值1 : (公共)多项选择(下标 - 1, 其余...);
}
inline 逻辑型 是否为空(const 文本型 &s) { return s.empty(); }
inline 逻辑型 是否为空(const 字节集 &b) { return b.empty(); }
inline 长整数型 取颜色值(整数型 红, 整数型 绿, 整数型 蓝) {
    return ((长整数型)(字节型)蓝 << 16) | ((长整数型)(字节型)绿 << 8) | (长整数型)(字节型)红;
}
inline 整数型 取数据类型尺寸(const 文本型 &类型名) {
    if (类型名 == "逻辑型") return (整数型)sizeof(bool);
    if (类型名 == "字节型") return 1;
    if (类型名 == "短整数型") return 2;
    if (类型名 == "整数型") return 4;
    if (类型名 == "长整数型" || 类型名 == "双精度小数型"
        || 类型名 == "日期时间型" || 类型名 == "子程序指针") return 8;
    if (类型名 == "小数型") return 4;
    if (类型名 == "文本型") return (整数型)sizeof(文本型);
    if (类型名 == "字节集") return (整数型)sizeof(字节集);
    return -1;
}
// 取数据类型长度：等价于 C/C++ 的 sizeof —— 接受任意类型的变量 / 表达式，
// 返回其在内存中本身占用的字节数（编译期确定，对所有数据类型通用）。
template <typename T>
inline 整数型 取数据类型长度(const T &v) {
    return (整数型)sizeof(v);
}
inline 逻辑型 写到内存(长整数型 地址, const 字节集 &数据, 长整数型 字节数 = -1) {
    if (地址 == 0) return 假;
    size_t n = (字节数 < 0 || (size_t)字节数 > 数据.size()) ? 数据.size() : (size_t)字节数;
    void *p = reinterpret_cast<void *>((uintptr_t)地址);
    memcpy(p, 数据.data(), n);
    return 真;
}
inline 逻辑型 写到内存(长整数型 地址, const 文本型 &数据, 长整数型 字节数 = -1) {
    return 写到内存(地址, 到字节集(数据), 字节数);
}
// 调用子程序：按地址动态调用一个子程序（等同 C/C++ 的函数指针调用）
// · 第一个参数：子程序地址（子程序指针的值）；后面依次是被调用子程序的参数
// · 返回值按「长整数型」取回 —— 被调用的子程序应当返回整数 / 地址这类结果
//   （编译器能看出目标签名时会直接按真实签名转型调用，见 codegen 的 调用子程序 处理，
//    那种情况下返回 文本型 / 小数型 等类型也正确；走这里的运行时模板时请自行保证签名一致）
// · 地址为 0 时不调用，直接返回 0
template <typename... A>
inline 长整数型 调用子程序(长整数型 地址, A... 参数) {
    if (地址 == 0) return 0;
    typedef 长整数型 (*函数类型)(A...);
    return reinterpret_cast<函数类型>(static_cast<uintptr_t>(地址))(参数...);
}

// ============ 变量与数组操作（动态数组 std::vector / 定长数组 std::array） ============
template <typename T>
inline void 重定义数组(std::vector<T> &数组, 长整数型 成员数) {
    if (成员数 < 0) 成员数 = 0;
    数组.resize((size_t)成员数);
}
template <typename T>
inline void 复制数组(std::vector<T> &目标, const std::vector<T> &源) { 目标 = 源; }
template <typename T, std::size_t N>
inline void 复制数组(std::array<T, N> &目标, const std::array<T, N> &源) { 目标 = 源; }
// 成员类型单独用一个模板参数：这样「加入成员(文本数组, "张三")」也能直接写
template <typename T, typename U>
inline void 插入成员(std::vector<T> &数组, 长整数型 位置, const U &成员) {
    size_t i = (位置 < 1) ? 0 : (size_t)(位置 - 1);
    if (i > 数组.size()) i = 数组.size();
    数组.insert(数组.begin() + i, (T)成员);
}
// 欲插入的成员数据为数组：把该数组的所有成员依次插入
template <typename T, typename U, typename A>
inline void 插入成员(std::vector<T> &数组, 长整数型 位置, const std::vector<U, A> &成员们) {
    size_t i = (位置 < 1) ? 0 : (size_t)(位置 - 1);
    if (i > 数组.size()) i = 数组.size();
    for (const auto &m : 成员们) {
        数组.insert(数组.begin() + i, (T)m);
        ++i;
    }
}
template <typename T, typename U>
inline 长整数型 取数组下标(const std::vector<T> &数组, const U &成员) {
    for (size_t i = 0; i < 数组.size(); ++i)
        if (数组[i] == 成员) return (长整数型)i + 1;
    return 0;
}
template <typename T, std::size_t N>
inline 长整数型 取数组下标(const std::array<T, N> &数组, const T &成员) {
    for (size_t i = 0; i < N; ++i)
        if (数组[i] == 成员) return (长整数型)i + 1;
    return 0;
}
template <typename T>
inline void 数组清零(std::vector<T> &数组) { std::fill(数组.begin(), 数组.end(), T()); }
template <typename T, std::size_t N>
inline void 数组清零(std::array<T, N> &数组) { 数组.fill(T()); }
template <typename T, std::size_t N>
inline void 数组排序(std::array<T, N> &数组) { std::sort(数组.begin(), 数组.end()); }
template <typename T, std::size_t N>
inline void 数组反转(std::array<T, N> &数组) { std::reverse(数组.begin(), 数组.end()); }

// ============ 环境存取 ============
inline 文本型 取执行文件名() {
    wchar_t buf[MAX_PATH];
    DWORD n = GetModuleFileNameW(nullptr, buf, MAX_PATH);
    if (!n) return "";
    return yy::到窄文本(std::wstring(buf, n));
}
inline 文本型 读环境变量(const 文本型 &名) {
    // 先问 Windows（能读到本进程用 写环境变量 设进去的值），再退回 CRT 的 getenv
    std::wstring w = yy::到宽文本(名);
    DWORD n = GetEnvironmentVariableW(w.c_str(), nullptr, 0);
    if (n > 0) {
        std::vector<wchar_t> buf((size_t)n + 1, L'\0');
        if (GetEnvironmentVariableW(w.c_str(), buf.data(), (DWORD)buf.size()) > 0)
            return yy::到窄文本(buf.data());
    }
    return 取环境变量(名);
}
inline 逻辑型 写环境变量(const 文本型 &名, const 文本型 &值) {
    _wputenv_s(yy::到宽文本(名).c_str(), yy::到宽文本(值).c_str());
    return SetEnvironmentVariableW(yy::到宽文本(名).c_str(), yy::到宽文本(值).c_str()) != 0;
}

// ============ 拼音处理 ============
// 数据由 yunyi_pinyin.hpp 提供；只有源码里用到拼音命令时 codegen 才会包含它
//（数据表较大，普通程序不必带上），这里的代码也随之生效。
#ifdef YY_PINYIN
namespace yypy {
inline void 拆多项(const char *s, std::vector<文本型> &out) {
    文本型 cur;
    for (const char *p = s; *p; ++p) {
        if (*p == ' ') { if (!cur.empty()) out.push_back(cur); cur.clear(); }
        else cur += *p;
    }
    if (!cur.empty()) out.push_back(cur);
}
inline char 声调(const 文本型 &p) {
    if (!p.empty() && p[p.size() - 1] >= '1' && p[p.size() - 1] <= '5') return p[p.size() - 1];
    return 0;
}
inline 文本型 去声调(const 文本型 &p) {
    return (!p.empty() && 声调(p)) ? p.substr(0, p.size() - 1) : p;
}
// 按《汉语拼音的声调标法》给字母加声调符号
inline 文本型 加声调符号(文本型 p) {
    char t = 声调(p);
    if (!t) return p;
    p = 去声调(p);
    static const char *调[][5] = {
        {"a", "ā", "á", "ǎ", "à"}, {"o", "ō", "ó", "ǒ", "ò"},
        {"e", "ē", "é", "ě", "è"}, {"i", "ī", "í", "ǐ", "ì"},
        {"u", "ū", "ú", "ǔ", "ù"}, {"v", "ǖ", "ǘ", "ǚ", "ǜ"},
    };
    int idx = -1;                     // 标在哪个韵母字母上
    size_t at = 文本型::npos;
    auto 找 = [&](char c) { return p.find(c); };
    if (找('a') != 文本型::npos) { idx = 0; at = 找('a'); }
    else if (找('o') != 文本型::npos) { idx = 1; at = 找('o'); }
    else if (找('e') != 文本型::npos) { idx = 2; at = 找('e'); }
    else if (找('i') != 文本型::npos && 找('u') != 文本型::npos) {
        // iu 标在 u，ui 标在 i
        bool iu = 找('i') < 找('u');
        idx = iu ? 4 : 3;
        at = iu ? 找('u') : 找('i');
    } else if (找('i') != 文本型::npos) { idx = 3; at = 找('i'); }
    else if (找('u') != 文本型::npos) { idx = 4; at = 找('u'); }
    else if (找('v') != 文本型::npos) { idx = 5; at = 找('v'); }
    if (idx < 0) return p;
    int tone = t - '0';
    if (tone < 1 || tone > 4) tone = 4;
    return p.substr(0, at) + 调[idx][tone] + p.substr(at + 1);
}
inline 文本型 格式化(const 文本型 &拼音, 整数型 方式) {
    if (方式 == 0) return 拼音;                     // 带数字声调（原始数据就是）
    if (方式 == 1) {
        文本型 r = 加声调符号(拼音);
        size_t pos = r.find('v');
        while (pos != 文本型::npos) { r.replace(pos, 1, "ü"); pos = r.find('v'); }
        return r;
    }
    文本型 r = 去声调(拼音);
    size_t pos = r.find('v');
    while (pos != 文本型::npos) { r.replace(pos, 1, "ü"); pos = r.find('v'); }
    return r;
}
// 拆分出音节与本字的全部读音
inline void 读音集(const 文本型 &s, std::vector<std::vector<文本型>> &out) {
    size_t i = 0;
    while (i < s.size()) {
        size_t next = i;
        unsigned int cp = yy::解码字符(s, next);
        std::vector<文本型> 一组;
        const char *v = yy_pinyin::查(cp);
        if (v) 拆多项(v, 一组);
        out.push_back(一组);
        i = next;
    }
}
} // namespace yypy

inline 文本型 取声母(const 文本型 &拼音) {
    文本型 p = 到小写(yypy::去声调(拼音));
    const char *双[] = {"zh", "ch", "sh"};
    const char *单 = "bpmfdtnlgkhjqxrzcsyw";
    文本型 r;
    for (const char *c : 双)
        if (p.compare(0, 2, c) == 0) { r = c; break; }
    if (r.empty() && !p.empty())
        for (const char *c = 单; *c; ++c)
            if (p[0] == *c) { r = 文本型(1, p[0]); break; }
    return 到大写(r);
}
inline 文本型 取韵母(const 文本型 &拼音) {
    文本型 p = 到小写(yypy::去声调(拼音));
    const char *双[] = {"zh", "ch", "sh"};
    size_t start = 0;
    for (const char *c : 双)
        if (p.compare(0, 2, c) == 0) { start = 2; break; }
    if (start == 0) {
        const char *单 = "bpmfdtnlgkhjqxrzcsyw";
        for (const char *c = 单; *c; ++c)
            if (!p.empty() && p[0] == *c) { start = 1; break; }
    }
    return p.substr(start);
}

inline 整数型 取发音数目(const 文本型 &汉字) {
    std::vector<std::vector<文本型>> s;
    yypy::读音集(汉字, s);
    return s.empty() ? 0 : (整数型)s[0].size();
}
inline 文本型 取所有发音(const 文本型 &汉字, 整数型 方式 = 0) {
    std::vector<std::vector<文本型>> s;
    yypy::读音集(汉字, s);
    文本型 r;
    for (auto &组 : s) {
        if (!r.empty()) r += " ";
        for (size_t i = 0; i < 组.size(); ++i) {
            if (i) r += " ";
            r += yypy::格式化(组[i], 方式);
        }
    }
    return r;
}
inline 文本型 取拼音(const 文本型 &汉字文本, 整数型 方式 = 0, 整数型 第几个发音 = 1) {
    std::vector<std::vector<文本型>> s;
    yypy::读音集(汉字文本, s);
    文本型 r;
    for (auto &组 : s) {
        if (!r.empty()) r += " ";
        if (组.empty()) continue;
        size_t i = ((size_t)第几个发音 > 组.size()) ? 组.size() - 1
                                                    : (size_t)(第几个发音 - 1);
        r += yypy::格式化(组[i], 方式);
    }
    return r;
}
inline 逻辑型 发音比较(const 文本型 &发音1, const 文本型 &发音2, 逻辑型 忽略声调 = 假) {
    if (忽略声调) return 到小写(yypy::去声调(发音1)) == 到小写(yypy::去声调(发音2));
    return 到小写(发音1) == 到小写(发音2);
}
inline 逻辑型 输入字比较(const 文本型 &汉字文本, const 文本型 &输入码, 逻辑型 模糊比较 = 假) {
    std::vector<std::vector<文本型>> s;
    yypy::读音集(汉字文本, s);
    文本型 全拼, 简拼;
    for (auto &组 : s) {
        if (!组.empty()) {
            全拼 += yypy::去声调(组[0]);
            简拼 += 到小写(取声母(组[0]));
        }
    }
    文本型 码 = 到小写(输入码);
    if (码.empty()) return 假;
    if (模糊比较)
        return 简拼 == 码 || 简拼.compare(0, 码.size(), 码) == 0 || 码.size() <= 简拼.size();
    return 全拼 == 码 || (全拼.size() >= 码.size() && 全拼.compare(0, 码.size(), 码) == 0);
}
#endif // YY_PINYIN

#endif // YUNYI_CORE_RT_HPP
