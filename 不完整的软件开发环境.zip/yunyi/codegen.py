# -*- coding: utf-8 -*-
"""云易 代码生成器：AST -> C++17 源码。"""
from __future__ import annotations
import os
from typing import List, Optional

from . import ast
from . import native_rt
from .lexer import YyError

# 核心库常量（文件打开方式 / 时间部分 / 信息框按钮 / 颜色 …）：
# 在调用点直接替换成字面量，运行时不需要额外的表 —— 数据源 yunyi/corelib.py
from .corelib import const_values as _core_const_values
_CORE_CONSTS = _core_const_values()

# 拼音数据表较大：只有源码里真的用到拼音命令时才包含它
from .corelib import PINYIN_NAMES as _PINYIN_NAMES

_OP_CPP = {"且": "&&", "或": "||"}

# 「API」声明中 云易类型 → C++ 类型
_API_TYPE = {"逻辑型": "bool", "字节型": "unsigned char", "短整数型": "short",
             "整数型": "int", "长整数型": "long long", "小数型": "float",
             "日期时间型": "long long", "双精度小数型": "double", "子程序指针": "long long"}

# DLL 导出命名约定：
#   · WINAPI 名（__stdcall）：i386 保留规范的 @参数字节数 装饰（如 Add@8，不加 -Wl,--kill-at）；
#                             x64 只有一种调用约定，没有装饰（Add）
#   · <名字>_cdecl（Add_cdecl）：cdecl 约定（C/C++ 默认调用约定用它），两个架构都是平名
# 云易自身的「API」声明按 WINAPI 调用，i386 会优先按 Add@8 找到（见运行库 取API装饰）。
_CDECL_SUFFIX = "_cdecl"

# i386 下 __stdcall 每个参数占用的字节数（推算导出名的 @参数字节数 装饰）
_STDCALL_SIZE = {"逻辑型": 4, "字节型": 4, "短整数型": 4, "整数型": 4, "长整数型": 8, "小数型": 4,
                 "日期时间型": 8, "双精度小数型": 8, "子程序指针": 8}

# 二元运算符的 C++ 优先级（数值越大越紧密）；用于按需加括号，避免 ((a + b) + c) 这种转译腔
_BIN_PREC = {"||": 1, "&&": 2, "==": 3, "!=": 3, "<": 4, ">": 4, "<=": 4, ">=": 4,
             "+": 5, "-": 5, "*": 6, "/": 6, "%": 6}

# 云易标量类型 → C++ 类型（与 Win32 签名表比对，同宽则不加 cast）
_YY_CPP_TYPE = {"整数型": "int", "长整数型": "long long", "逻辑型": "bool",
                "短整数型": "short", "字节型": "unsigned char", "小数型": "float",
                "日期时间型": "long long", "双精度小数型": "double", "子程序指针": "long long"}


def _is_x86() -> bool:
    """目标架构是否 i386（只有 i386 的 __stdcall 才带 @参数字节数 装饰）。"""
    try:
        from . import toolchain
        return toolchain.get_arch() == "x86"
    except Exception:
        return True


def _stdcall_bytes(f: ast.Func):
    """i386 下 __stdcall 导出名的 @N；含宽度无法确定的参数（文本型/字节集/自定义类型）时返回 None。"""
    total = 0
    for p in f.params:
        if p.byref or p.array_dynamic or p.array_size is not None:
            total += 4                   # 参考/传址/数组 → 传指针（4 字节）
            continue
        sz = _STDCALL_SIZE.get(p.type)
        if sz is None:
            return None
        total += sz
    return total


def winapi_export_name(f: ast.Func) -> str:
    """WINAPI（__stdcall）导出名：i386 为 <导出名>@<参数字节数>，x64 为平名。"""
    name = (getattr(f, "export_name", "") or f.name)
    if not _is_x86():
        return name
    n = _stdcall_bytes(f)
    return (name + "@" + str(n)) if n is not None else name + "@?"


def cdecl_alias_name(f: ast.Func) -> str:
    """导出函数的 cdecl 别名（C/C++ 默认调用约定使用）：<导出名>_cdecl。"""
    return (getattr(f, "export_name", "") or f.name) + _CDECL_SUFFIX


def _cpp_str(s: str, prefix: str = '"') -> str:
    out = prefix
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out += '\\"'
        elif ch == "\\":
            out += "\\\\"
        elif ch == "\n":
            out += "\\n"
        elif ch == "\t":
            out += "\\t"
        elif ch == "\r":
            out += "\\r"
        elif o < 0x20:
            out += "\\%03o" % o
        else:
            out += ch
    return out + '"'


def _num_lit(e: ast.NumLit) -> str:
    if isinstance(e.value, int):
        return str(e.value)
    # 编译仅 -Wall（无 -Wconversion/-Werror），double 字面量赋给 float 变量属隐式转换，安全；
    # 故浮点字面量不加 f 后缀，以免双精度小数型丢失精度。
    return repr(e.value)


def _decl_text(typ: str, name: str, array_size, dynamic: bool = False) -> str:
    if dynamic:
        return f"std::vector<{typ}> {name};"
    if array_size is not None:
        return f"std::array<{typ}, {array_size}> {name}{{}}"
    return f"{typ} {name}{{}}"


class CodeGen:
    def __init__(self, prog: ast.Program):
        self.prog = prog
        self.out: List[str] = []
        self.indent = 0
        self.entry_names = {"程序入口", "_启动子程序"}
        # 子程序名集合：子程序名被当作「值」使用时，取它的函数地址（如 Win32 回调）
        self.func_names = {f.name for f in prog.funcs}
        self.mode = "run"          # run / test / dll（generate_cpp 里设置）
        # Windows API 名称集合：调用点映射到内部包装函数 yy_api_*
        self.api_names = {a.name for a in getattr(prog, "apis", [])}
        # 类函数体生成时：需转为 this-> 的成员名 / 已被局部变量遮蔽的名字
        self._mfields = set()
        self._mlocals = set()
        # 原生模式：产物里不出现中文类型/中文内置函数名，也不 include 中文运行库
        self.native = False
        self.api_defs = {a.name: a for a in getattr(prog, "apis", [])}
        # native 模式下收集用到的 DLL，供导出侧计算 -l 链接库
        self.api_dlls: List[str] = []
        # native 模式下用到的中文内置函数名（决定注入哪些英文实现）
        self._used_funcs = set()
        # native 模式：是否回退到通用翻译层（出现签名表/KNOWN_API_SIGS 都覆盖不到的 API）
        self._used_fallback = False
        # native 导出选项（「导出C++」用）：clean → 去掉 #line 指令与机器注释（纯正 C++ 风格）；
        # 用户写的中文变量名/常量名/类型名/子程序名一律原样保留（中文字符是合法 C++ 标识符）
        self.clean = False
        # 内联汇编语法：att（默认，GCC 原生）/ intel（生成时包一层 .intel_syntax）
        self.asm_syntax = "att"

    # ---------- 输出工具 ----------
    def raw(self, text: str = ""):
        self.out.append(text)

    def w(self, text: str):
        self.out.append("    " * self.indent + text)

    def wline_directive(self, line: int, file: str):
        if self.clean:
            return                          # 导出模式：不写 #line（纯正 C++ 风格）
        f = file.replace("\\", "/").replace('"', '\\"')
        self.raw(f'#line {line} "{f}"')

    @staticmethod
    def _ends_with_return(body) -> bool:
        """函数体最后一条顶层语句是否已确定是 return（是则不再补 return {} 兜底）。"""
        return bool(body) and isinstance(body[-1], ast.ReturnStmt)

    def _child_text(self, node, parent_prec: int, right_side: bool) -> str:
        txt = self.expr(node)
        cp = (_BIN_PREC.get(node.op) if isinstance(node, ast.Binary) else None)
        if cp is None:
            return txt
        if cp < parent_prec or (cp == parent_prec and right_side):
            return f"({txt})"
        return txt

    @staticmethod
    def _strip_discard_wrap(text: str) -> str:
        """语句级调用（返回值被丢弃）：剥掉生成器为「整数收口」包的无副作用 cast，
        static_cast<int>(::GetMessageW(...)) → ::GetMessageW(...)、
        to_narrow(::StrCpyW(...)) → ::StrCpyW(...)、
        reinterpret_cast<uintptr_t>(::Xxx(...)) → ::Xxx(...)。"""
        wraps = ("static_cast<int>(", "static_cast<BOOL>(", "to_narrow(",
                 "reinterpret_cast<uintptr_t>(", "static_cast<uintptr_t>(")
        while True:
            for wrap in wraps:
                if not text.startswith(wrap) or not text.endswith(")"):
                    continue
                depth, ok = 0, False
                for i in range(len(wrap) - 1, len(text)):
                    if text[i] == "(":
                        depth += 1
                    elif text[i] == ")":
                        depth -= 1
                        if depth == 0:
                            ok = (i == len(text) - 1)
                            break
                if ok:
                    text = text[len(wrap):-1]
                    break
            else:
                return text

    # ---------- 拼音数据表的按需引入 ----------
    def _用到拼音(self) -> bool:
        """源码里是否用到了拼音处理类命令（用到才在产物里带上拼音数据表）。"""
        def 走(node) -> bool:
            if isinstance(node, ast.Call):
                if getattr(node, "func", "") in _PINYIN_NAMES:
                    return True
            if isinstance(node, list):
                return any(走(x) for x in node)
            fields = getattr(node, "__dataclass_fields__", None)
            if fields:
                for name in fields:
                    if name in ("file", "line", "col"):
                        continue
                    if 走(getattr(node, name, None)):
                        return True
            return False
        return 走(self.prog)

    # ---------- 原生模式（native）：类型 / 内置函数换成英文标准写法 ----------
    def T(self, typ: str) -> str:
        """类型名：native 下 整数型→int、文本型→std::string …（自定义类型名原样保留）。"""
        if not self.native:
            return typ
        return native_rt.NATIVE_TYPE.get(typ, typ)

    def call_name(self, name: str) -> str:
        """内置函数名：native 下 信息框→message_box（用户自己的子程序名原样保留）。"""
        if not self.native or name in self.func_names:
            return name
        if name in native_rt.NATIVE_NAME:
            self._used_funcs.add(name)
            return native_rt.NATIVE_NAME[name]
        return name

    def lit(self, value: bool) -> str:
        return ("true" if value else "false") if self.native else ("真" if value else "假")

    @staticmethod
    def _cast_arg(real: str, yy: str, arg: str) -> str:
        """把云易实参表达式按真实 Win32 形参类型写出 cast：
           · 文本形参 + 宽串输入 → to_wide(x).c_str()；窄串输入 → 直接传（云易文本即 UTF-8 窄串）
           · 文本形参 + 指针/整数形参（如 SendMessageW 的 LPARAM 收字符串）→ 传宽串地址
           · 指针/句柄形参 → reinterpret_cast<真实类型>(static_cast<uintptr_t>(x))（x86/x64 都安全）；
             实参为 0 时直接写 nullptr
           · 实参类型与形参类型完全一致时不加 cast；其余 → static_cast<真实类型>(x)"""
        if yy == "文本型":
            if real in ("LPCWSTR", "const wchar_t*", "PCWSTR"):
                return f"to_wide({arg}).c_str()"
            if real in ("LPCSTR", "const char*", "PCSTR"):
                return f"({arg})"
            return f"reinterpret_cast<{real}>(to_wide({arg}).c_str())"
        if "*" in real or real in native_rt.WIN32_PTR_TYPEDEFS:
            if arg == "0":
                return "nullptr"
            return f"reinterpret_cast<{real}>(static_cast<uintptr_t>({arg}))"
        if _YY_CPP_TYPE.get(yy) == real:
            return arg
        return f"static_cast<{real}>({arg})"

    @staticmethod
    def _wrap_direct(ret_cpp: str, call: str) -> str:
        """按真实返回类型收口（云易侧一律以 整数型/文本型 接收）：void 直接丢弃；
           字符串返回 → to_narrow；指针/句柄返回 → 经 uintptr_t 转 int（x86/x64 都安全）；
           其余整数/布尔返回 → 直接 static_cast<int>。"""
        if ret_cpp == "void":
            return call
        if ret_cpp in ("LPCWSTR", "LPCSTR", "LPWSTR", "LPSTR",
                       "const wchar_t*", "const char*"):
            return f"to_narrow({call})"
        if "*" in ret_cpp or ret_cpp in native_rt.WIN32_PTR_TYPEDEFS:
            return f"static_cast<int>(reinterpret_cast<uintptr_t>({call}))"
        if ret_cpp in ("int", "BOOL"):
            return call                        # 返回类型与云易整数同宽，无需收口
        return f"static_cast<int>({call})"

    def _wrap_by_yy_rt(self, rt: str, call: str) -> str:
        """按云易声明的返回类型收口（兜底 / KNOWN_API_SIGS 路径共用）。"""
        if rt == "文本型":
            return f"to_narrow({call})"
        if rt in ("整数型", "短整数型", "字节型"):
            return f"static_cast<int>({call})"
        if rt == "逻辑型":
            return f"({call} != 0)"
        if rt == "小数型":
            return f"static_cast<float>({call})"
        return call

    def _api_arg(self, real: str, yy: str, arg: str, node) -> str:
        """API 实参生成：字符串字面量直接写成 C++ 宽/窄字符串字面量
        （L"标题" 比 to_wide("标题").c_str() 纯正），其余走 _cast_arg。"""
        if yy == "文本型" and isinstance(node, ast.StrLit):
            if real in ("LPCWSTR", "const wchar_t*", "PCWSTR"):
                return _cpp_str(node.value, "L\"")
            if real in ("LPCSTR", "const char*", "PCSTR"):
                return _cpp_str(node.value)
            if "*" in real or real in native_rt.WIN32_PTR_TYPEDEFS:
                # SendMessageW 的 LPARAM/WPARAM 收字符串等场景
                return f"reinterpret_cast<{real}>({_cpp_str(node.value, 'L\"')})"
        return self._cast_arg(real, yy, arg)

    @staticmethod
    def _has_ptr_param(a) -> bool:
        """声明里是否含 传址/数组 参数。"""
        if not a:
            return False
        return any(p.byref or p.array_dynamic or p.array_size is not None
                   for p in a.params)

    def _api_arg_wrap(self, a, arg_exprs: list) -> list:
        """按声明对实参做 数组 包裹（原列表不被修改）：
        · 数组 → (实参).data()（vector/std::array 都有 data()），包装形参是 元素指针
        · 传址不包裹：包装形参是 T&（引用），实参直接按引用绑定，包装内部再取地址"""
        if not a:
            return arg_exprs
        out = list(arg_exprs)
        for j, p in enumerate(a.params):
            if j >= len(out):
                break
            is_arr = bool(p.array_dynamic) or p.array_size is not None
            if is_arr and p.type != "文本型":
                out[j] = f"({out[j]}).data()"
        return out

    def api_call(self, name: str, call: ast.Call, arg_exprs: list) -> str:
        """Windows API 调用的生成方式：
           非 native → yy_api_<名字>（运行时 GetProcAddress 动态包装）
           native    → 优先按真实签名直接静态调用（最「纯正」），分三档：
                       ① WIN32_SIGS 命中 → 调用点直接 ::API(真实签名) 并按需 cast
                       ② KNOWN_API_SIGS（intrinsic / cdecl 平名）→ 按既定逐参 cast 直接调用
                       ③ 其余（签名表与 KNOWN 都覆盖不到）→ 回退 yynative 通用翻译层
           传址/数组参数在调用点包成指针：传址 → &(实参)；数组 → (实参).data()"""
        a = self.api_defs.get(name)
        # 别名支持：在库 "xxx.dll,真实API名" —— 声明名是别名，按真实名查签名表并生成调用
        real = (getattr(a, "real_name", "") or name) if a else name
        if not self.native:
            if self._has_ptr_param(a):
                arg_exprs = self._api_arg_wrap(a, arg_exprs)
            return f"yy_api_{name}({', '.join(arg_exprs)})"
        rt = getattr(a, "ret_type", "") if a else ""
        param_types = [p.type for p in (getattr(a, "params", []) or [])] if a else []
        wrapped = self._api_arg_wrap(a, arg_exprs) \
            if self._has_ptr_param(a) else arg_exprs

        # ① 真实签名表：直接按 Win32 签名写出调用（最「纯正」）
        sig = native_rt.WIN32_SIGS.get(real)
        if sig and len(sig[1]) == len(arg_exprs):
            ret_cpp, real_params = sig[0], sig[1]
            args = ", ".join(self._api_arg(rp, yt, ae, node)
                             for rp, yt, ae, node in zip(real_params, param_types,
                                                         wrapped, call.args))
            return self._wrap_direct(ret_cpp, f"::{real}({args})")

        # ② KNOWN_API_SIGS（intrinsic / cdecl 平名 / 文本指针）：按既定逐参 cast 直接调用
        casts = native_rt.KNOWN_API_SIGS.get(real)
        if casts and len(casts) == len(arg_exprs):
            call = "::" + real + "(" + ", ".join(
                c.format(a=x) for c, x in zip(casts, wrapped)) + ")"
            return self._wrap_by_yy_rt(rt, call)

        # ③ 兜底：用 yynative 通用翻译层（保持旧工程兼容）
        self._used_fallback = True
        int_like = rt in ("整数型", "短整数型", "字节型", "长整数型", "逻辑型")
        conv = []
        for i, (t, x) in enumerate(zip(param_types, arg_exprs)):
            wv = wrapped[i] if i < len(wrapped) else x
            if t == "文本型":
                conv.append(f"yynative::wc({x})")
            elif wv != x:
                # 传址/数组实参（指针）：按地址整数传给通用翻译层
                conv.append(f"static_cast<long long>(reinterpret_cast<uintptr_t>({wv}))")
            else:
                conv.append(x)
        inner = f"::{real}{', ' if conv else ''}{', '.join(conv)}"
        call = (f"yynative::api_call_int({inner})" if int_like
                else f"yynative::api_call({inner})")
        return self._wrap_by_yy_rt(rt, call)

    # ---------- 调用子程序 ----------
    def call_sub(self, e: ast.Call) -> str:
        """调用子程序(地址, 参数…)：按地址动态调用一个子程序（等同 C/C++ 的函数指针调用）。
        · 第一个参数直接写了子程序名，或能看出「变量 子程序指针 p = 某子程序」的目标：
          按目标的**真实签名**转型后调用 —— 返回值可以是文本 / 小数等任意类型
        · 其余情况（地址要到运行期才知道）：走运行库模板 调用子程序()，返回值按长整数取回
          （此时被调用的子程序最好返回整数 / 地址这类结果）"""
        if not e.args:
            return f"{self.call_name('调用子程序')}()"
        a0 = e.args[0]
        rest = ", ".join(self.expr(a) for a in e.args[1:])
        if isinstance(a0, ast.Name):
            nm = a0.id
            mlocals = getattr(self, "_mlocals", ())
            if nm in self.func_names and nm not in mlocals:
                return f"{self.call_name(nm)}({rest})"
            tgt = getattr(self, "_subptr", {}).get(nm)
            if tgt:
                return f"reinterpret_cast<decltype({tgt})*>({nm})({rest})"
        return f"{self.call_name('调用子程序')}({', '.join(self.expr(a) for a in e.args)})"

    # ---------- 内联汇编 ----------
    @staticmethod
    def _asm_dialect(v) -> str:
        """汇编语法归一：Intel → intel，其余（AT&T / 空 / 未知）→ att。"""
        s = str(v or "").strip().lower()
        return "intel" if s.startswith("intel") else "att"

    def asm_block(self, code: str, dialect: str = "") -> str:
        """一段汇编指令 → GCC 内联汇编语句（等同 C/C++ 的 __asm__）。

        Intel 语法（块头写了 Intel 或工程设置选了 Intel）时整段包在
        .intel_syntax noprefix … .att_syntax noprefix 之间 —— 这样不必改编译参数，
        且不会影响编译器自己生成的（AT&T）代码。指令为空时返回空串。"""
        raw = str(code or "").replace("\r\n", "\n").replace("\r", "\n")
        insns = [ln.strip() for ln in raw.split("\n") if ln.strip()]
        if not insns:
            return ""
        body = "\n\t".join(insns)
        if self._asm_dialect(dialect or self.asm_syntax) == "intel":
            body = ".intel_syntax noprefix\n\t" + body + "\n\t.att_syntax noprefix"
        return "__asm__ __volatile__(" + _cpp_str(body) + ");"

    # ---------- 表达式 ----------
    def expr(self, e: ast.Expr) -> str:
        t = type(e)
        if t is ast.NumLit:
            return _num_lit(e)
        if t is ast.StrLit:
            return _cpp_str(e.value)
        if t is ast.BoolLit:
            return self.lit(e.value)
        if t is ast.Name:
            # #常量引用：核心库常量就地换成字面量；用户常量即 C++ const 名（原样）
            if getattr(e, "is_const", False):
                if e.id in _CORE_CONSTS:
                    return _CORE_CONSTS[e.id]
                return e.id
            # 类函数体内：数据类型成员 -> this->成员（被局部变量/参数遮蔽的除外）
            if self._mfields and e.id in self._mfields and e.id not in self._mlocals:
                return "this->" + e.id
            # 子程序名当值使用 → 取函数地址（Win32 回调等需要函数指针的场景）
            if e.id in self.func_names and e.id not in self._mlocals:
                return f"reinterpret_cast<long long>(&{e.id})"
            return self.call_name(e.id)
        if t is ast.Index:
            return f"{self.expr(e.base)}[{self.expr(e.index)}]"
        if t is ast.Member:
            return f"{self.expr(e.base)}.{e.name}"
        if t is ast.Call:
            arg_exprs = [self.expr(a) for a in e.args]
            obj = getattr(e, "obj", None)
            if obj is not None:                   # 类函数调用：对象.方法(参数)
                # 「类型名.方法(参数)」静态调用（checker 标注 static_owner）：
                # 在临时实例上调用，例如 运算.加法(x) → 运算().加法(x)
                owner = getattr(e, "static_owner", None)
                recv = (owner + "()") if owner else self.expr(obj)
                return f"{recv}.{e.func}({', '.join(arg_exprs)})"
            if e.func in self.api_names:
                return self.api_call(e.func, e, arg_exprs)
            # 调用子程序(地址, 参数…)：按地址动态调用（等同 C/C++ 的函数指针调用）
            if e.func == "调用子程序" and not obj:
                return self.call_sub(e)
            # 子程序指针间接调用：变量名指向一个子程序，按其目标签名转型后调用
            if getattr(self, "_func_vtypes", {}).get(e.func) == "子程序指针":
                tgt = self._subptr.get(e.func)
                if tgt:
                    return f"reinterpret_cast<decltype({tgt})*>({e.func})({', '.join(arg_exprs)})"
                # 退化情况：用调用点实参类型兜底（用户需自行保证签名一致）
                ats = [self._arg_cpp_type(a) for a in e.args]
                return f"reinterpret_cast<void(*)({', '.join(ats)})>({e.func})({', '.join(arg_exprs)})"
            # 非 native 时 API 调用映射到内部包装函数（避与 windows.h 的同名声明冲突）
            return f"{self.call_name(e.func)}({', '.join(arg_exprs)})"
        if t is ast.Unary:
            inner = self.expr(e.operand)
            if isinstance(e.operand, ast.Binary):
                inner = f"({inner})"        # 一元运算作用于复合表达式才需要括号
            if e.op == "!":
                return f"!{inner}"
            return f"{e.op}{inner}"
        if t is ast.Binary:
            if e.op == "整除":
                return f"{self.call_name('整除')}({self.expr(e.left)}, {self.expr(e.right)})"
            # 两个字符串字面量直接 + 在 C++ 里是 const char* + const char*，非法
            # （"云易" + "，"）。语言规范承诺「两个文本用 + 拼接」，所以这里把左边
            # 包成 std::string；链式拼接（"a"+"b"+变量）递归自愈。
            if e.op == "+" and isinstance(e.left, ast.StrLit) and isinstance(e.right, ast.StrLit):
                return f"(std::string({self.expr(e.left)}) + {self.expr(e.right)})"
            op = _OP_CPP.get(e.op, e.op)
            # 按 C++ 优先级按需加括号：a + b + c 不再写成 ((a + b) + c)，
            # 消息 == 1 || 消息 == 2 不再写成 ((消息 == 1) || (消息 == 2))。
            p = _BIN_PREC.get(op, 7)
            l = self._child_text(e.left, p, False)
            r = self._child_text(e.right, p, True)
            return f"{l} {op} {r}"
        raise YyError(f"内部错误：不认识的表达式节点 {t}", getattr(e, "line", 0), 0, "")

    # ---------- 语句 ----------
    def _arg_cpp_type(self, a) -> str:
        """退化路径下，推测一个实参的 C++ 类型（仅 子程序指针 目标不可知时使用）。"""
        t = type(a)
        if t is ast.NumLit:
            return "long long" if isinstance(a.value, int) else "double"
        if t is ast.StrLit:
            return "std::string"
        if t is ast.Name:
            return self.T(getattr(self, "_func_vtypes", {}).get(a.id, "长整数型"))
        return "long long"

    def emit_block(self, body: List[ast.Stmt], file: str):
        for st in body:
            self.wline_directive(st.line, file)
            self.emit(st, file)

    def emit(self, st, file: str):
        t = type(st)
        if t is ast.AsmBlock:
            # 裸写汇编块：指令原文 → __asm__ __volatile__("…")
            txt = self.asm_block(st.code, st.dialect)
            if txt:
                self.w(txt)
            return
        if t is ast.VarDecl:
            if (st.init is not None and st.array_size is None
                    and not getattr(st, "array_dynamic", False)):
                self.w(f"{st.name} = {self.expr(st.init)};")
            return  # 变量声明本体已在函数头部统一提升
        if t is ast.Assign:
            lhs = self.expr(st.target)
            self.w(f"{lhs} {st.op} {self.expr(st.value)};")
        elif t is ast.ExprStmt:
            e = st.expr
            if isinstance(e, ast.Call) and e.func == "置入代码":
                # 把参数里的 C/C++（或内联汇编）源码原样插入到当前作用域
                if e.args and isinstance(e.args[0], ast.StrLit):
                    for ln in e.args[0].value.split("\n"):
                        self.w(ln)
                return
            if isinstance(e, ast.Call):
                # 返回值被丢弃的调用语句：去掉收口用的无副作用 cast / 转换包装
                self.w(self._strip_discard_wrap(self.expr(e)) + ";")
        elif t is ast.IfStmt:
            first_cond, first_body = st.branches[0]
            self.w(f"if ({self.expr(first_cond)}) {{")
            self.indent += 1
            self.emit_block(first_body, file)
            self.indent -= 1
            for cond, body in st.branches[1:]:
                self.w(f"}} else if ({self.expr(cond)}) {{")
                self.indent += 1
                self.emit_block(body, file)
                self.indent -= 1
            if st.else_body:
                self.w("} else {")
                self.indent += 1
                self.emit_block(st.else_body, file)
                self.indent -= 1
            self.w("}")
        elif t is ast.ForRange:
            s, e = self.expr(st.start), self.expr(st.end)
            v = st.var
            声明 = v if st.var in self._func_locals else f"{self.T('整数型')} {v}"
            if getattr(st, "step", None) is not None:
                # 变量循环首：步长可正可负，越界即结束
                k = self.expr(st.step)
                self.w(f"for ({声明} = {s}; {k} >= 0 ? {v} <= {e} : {v} >= {e}; {v} += {k}) {{")
            elif st.var in self._func_locals:
                self.w(f"for ({v} = {s}; {v} <= {e}; {v}++) {{")
            else:
                self.w(f"for ({self.T('整数型')} {v} = {s}; {v} <= {e}; {v}++) {{")
            self.indent += 1
            self.emit_block(st.body, file)
            self.indent -= 1
            self.w("}")
        elif t is ast.WhileStmt:
            self.w(f"while ({self.expr(st.cond)}) {{")
            self.indent += 1
            self.emit_block(st.body, file)
            self.indent -= 1
            self.w("}")
        elif t is ast.DoWhileStmt:
            self.w("do {")
            self.indent += 1
            self.emit_block(st.body, file)
            self.indent -= 1
            self.w(f"}} while ({self.expr(st.cond)});")
        elif t is ast.BreakStmt:
            self.w("break;")
        elif t is ast.ContinueStmt:
            self.w("continue;")
        elif t is ast.ReturnStmt:
            if st.expr is not None:
                self.w(f"return {self.expr(st.expr)};")
            else:
                self.w("return;")
        else:
            raise YyError(f"内部错误：不认识的语句节点 {t}", st.line, 0, file)

    # ---------- 收集函数局部变量 ----------
    def collect_locals(self, body, file: str) -> List[ast.VarDecl]:
        found: List[ast.VarDecl] = []
        seen = set()

        def walk(sts):
            for s in sts:
                if isinstance(s, ast.VarDecl):
                    if s.name not in seen:
                        seen.add(s.name)
                        found.append(s)
                elif isinstance(s, ast.IfStmt):
                    for _, b in s.branches:
                        walk(b)
                    walk(s.else_body)
                elif isinstance(s, (ast.ForRange, ast.WhileStmt, ast.DoWhileStmt)):
                    walk(s.body)
        walk(body)
        return found

    # ---------- 顶层 ----------
    def find_entry(self) -> Optional[ast.Func]:
        for f in self.prog.funcs:
            if f.name in self.entry_names and f.kind == "子程序":
                return f
        return None

    def test_funcs(self) -> List[ast.Func]:
        return [f for f in self.prog.funcs if f.kind == "测试函数"]

    def gen(self, mode: str = "run") -> str:
        if self.native:
            # native：主体先生成到临时缓冲 → 扫描用到的内置函数 → 再拼上英文运行时前缀
            saved, self.out = self.out, []
            self._used_funcs = set()
            self._used_fallback = False
            self.gen_body(mode)
            body = "\n".join(self.out)
            impls = native_rt.impls_for(self._used_funcs)
            self.out = saved
            if self.clean:
                # 导出模式：一行英文头注，不写机器翻译痕迹与源文件绝对路径
                self.raw("// Generated by Yunyi IDE ("
                         + ", ".join(os.path.basename(f) for f in self.prog.files) + ")")
            else:
                self.raw("// 本文件由「云易IDE」自动翻译生成（云易语法 → 原生 C++17）")
                for f in self.prog.files:
                    self.raw(f"// 源文件：{f}")
                self.raw("// 纯正的 C++17 / Win32 程序：不依赖任何中文运行库")
            self.raw()
            # 所有 API 都有真实签名时，用不含翻译脚手架的精简前缀；
            # 否则用完整前缀（保留 yynative 通用翻译层兜底）。
            prologue = (native_rt.PROLOGUE_FULL if self._used_fallback
                        else native_rt.PROLOGUE_MIN)
            prologue_lines = prologue.splitlines()
            if self.clean:
                # 导出模式：前缀里的纯注释行也去掉（纯正 C++ 风格）
                prologue_lines = [ln for ln in prologue_lines
                                  if not ln.lstrip().startswith("//")]
            self.out.extend(prologue_lines)
            if impls:
                self.raw()
                self.raw("namespace yynative {")
                self.out.extend(impls.splitlines())
                self.raw("}  // namespace yynative")
            self.raw()
            self.out.append(body)
            return "\n".join(self.out)
        self.raw("// 本文件由「云易IDE」自动翻译生成（云易语法 → C++17）")
        for f in self.prog.files:
            self.raw(f"// 源文件：{f}")
        # 用到拼音命令时才带上汉字拼音表（yunyi_pinyin.hpp 里定义 YY_PINYIN）
        if self._用到拼音():
            self.raw('#include "yunyi_pinyin.hpp"')
        if mode == "dll":
            self.raw('// 使用方法：g++ -std=c++17 -shared '
                     '-I<运行库目录> 本文件 -luser32 -o 程序.dll')
            # 运行库符号设为隐藏可见性：确保导出表里只有「导出子程序」的包装函数，
            # 运行库内部符号（控制台初始化、辅助函数等）不会被导出
            self.raw("#pragma GCC visibility push(hidden)")
            self.raw('#include "yunyi_rt.hpp"')
            self.raw("#pragma GCC visibility pop")
        else:
            self.raw('// 使用方法：g++ -std=c++17 -I<运行库目录> 本文件 -luser32 -o 程序.exe')
            self.raw('#include "yunyi_rt.hpp"')
        self.raw()
        return self.gen_body(mode)

    def gen_body(self, mode: str) -> str:
        """生成结构体 / 全局变量 / 子程序 / main 部分（不含文件头注释与 #include，
        便于 native 模式先扫一遍内容再拼前缀）。"""
        self.gen_structs()
        self.gen_globals()
        self.gen_prototypes()
        self.gen_apis()
        self.gen_methods()
        for f in self.prog.funcs:
            self.gen_func(f)
        if mode == "dll":
            # DLL 程序：不生成 main()，导出函数由「导出子程序」声明
            self.raw("// DLL 程序：本文件编译为动态库（-shared），导出「导出子程序」定义的函数")
            self.gen_dll_aliases()
        elif mode == "run":
            self.gen_main_run()
        else:
            self.gen_main_test()
        return "\n".join(self.out)

    def gen_structs(self):
        """把「数据类型」定义翻译为 C++ struct（含类函数声明）。
        成员支持：「传址」后缀（按值嵌入，C++ 值成员即为按值）、固定数组 std::array、
        动态数组 std::vector、自定义类型成员（嵌套按值嵌入）。"""
        structs = list(getattr(self.prog, "structs", []))
        if not structs:
            return
        if not self.clean:
            self.raw("// ===== 自定义数据类型 =====")
        # 拓扑排序：按值嵌入的自定义类型成员要求被嵌套类型先完整定义
        # （前置声明不够 —— 值成员需要完整类型才知道大小）。
        # 循环引用无法按值嵌入，保持原顺序交给 C++ 编译器报错。
        names = {s.name for s in structs}
        order, done, visiting = [], set(), set()

        def visit(s):
            if s.name in done or s.name in visiting:
                return
            visiting.add(s.name)
            for fld in s.fields:
                dep = next((x for x in structs if x.name == fld.type), None)
                if dep is not None:
                    visit(dep)
            visiting.discard(s.name)
            done.add(s.name)
            order.append(s)

        for s in structs:
            visit(s)
        structs = order
        # 先给所有类型发「前置声明」：类函数签名里可能引用尚未定义的类型
        # （例如 lib/core.class 里「类函数 运算.加法(数据列 ab)」写在「数据类型 数据列」之前），
        # 没有前置声明时 C++ 会报 '数据列' has not been declared
        for s in structs:
            self.wline_directive(s.line, s.file if s.file else self._file_of(s))
            self.w(f"struct {s.name};")
        for s in structs:
            self.wline_directive(s.line, s.file if s.file else self._file_of(s))
            self.w(f"struct {s.name} {{")
            self.indent += 1
            for fld in s.fields:
                size = self.expr(fld.array_size) if fld.array_size is not None else None
                decl = _decl_text(self.T(fld.type), fld.name, size,
                                  getattr(fld, "array_dynamic", False))
                self.w(decl if decl.endswith(";") else decl + ";")
            for m in self.methods_of(s.name):
                params = ", ".join(self._param_decl(p) for p in m.params)
                self.w(f"{self.T(m.ret_type or '空')} {m.name}({params});")
            self.indent -= 1
            self.w("};")
        self.raw()

    def methods_of(self, owner: str):
        return [m for m in getattr(self.prog, "methods", []) if m.owner == owner]

    def gen_methods(self):
        """类函数定义（struct 外定义，成员用 this-> 访问）。"""
        methods = getattr(self.prog, "methods", [])
        if not methods:
            return
        if not self.clean:
            self.raw("// ===== 类函数（数据类型的成员函数） =====")
        for m in methods:
            owner = next((s for s in getattr(self.prog, "structs", []) if s.name == m.owner), None)
            self._mfields = {fld.name for fld in owner.fields} if owner else set()
            locals_decls = self.collect_locals(m.body, m.file)
            self._mlocals = {v.name for v in locals_decls} | {p.name for p in m.params}
            # 计次循环变量判断也依赖 _func_locals（类函数体内与子程序一致的局部名集合）
            self._func_locals = self._mlocals
            self.wline_directive(m.line, m.file if m.file else self._file_of(m))
            params = ", ".join(self._param_decl(p) for p in m.params)
            self.w(f"{self.T(m.ret_type or '空')} {m.owner}::{m.name}({params}) {{")
            self.indent += 1
            for v in locals_decls:
                self.wline_directive(v.line, m.file)
                size = self.expr(v.array_size) if v.array_size is not None else None
                self.w(_decl_text(self.T(v.type), v.name, size,
                                  getattr(v, "array_dynamic", False)) + ";")
            self.emit_block(m.body, m.file)
            if m.ret_type is not None and not self._ends_with_return(m.body):
                self.w("return {};")
            self.indent -= 1
            self.w("}")
        self._mfields = set()
        self._mlocals = set()
        self._func_locals = set()
        self.raw()

    def gen_globals(self):
        for c in self.prog.consts:
            self.wline_directive(c.line, c.file if c.file else self._file_of(c))
            self.w(f"const {self.T(c.type)} {c.name} = {self.expr(c.value)};")
        for g in self.prog.globals_:
            self.wline_directive(g.line, g.file if g.file else self._file_of(g))
            size = self.expr(g.array_size) if g.array_size is not None else None
            self.w(_decl_text(self.T(g.type), g.name, size,
                              getattr(g, "array_dynamic", False)) + ";")
        if self.prog.consts or self.prog.globals_:
            self.raw()

    def gen_apis(self):
        """把「API」声明翻译为调用桩：
           非 native → 运行时 LoadLibrary + GetProcAddress 动态包装（yy_api_*）
           native    → 不生成包装：调用点直接静态调用真实 API（见 CodeGen.api_call）"""
        apis = getattr(self.prog, "apis", [])
        if not apis:
            return
        if self.native:
            for a in apis:
                if a.dll and a.dll not in self.api_dlls:
                    self.api_dlls.append(a.dll)
            # native：不生成包装桩 —— 调用点直接静态调用真实 API
            #（见 CodeGen.api_call；intrinsic/重载函数走 KNOWN_API_SIGS）
            if self.clean:
                return
            self.raw("// ===== Windows API 声明（直接静态调用，无动态加载） =====")
            for a in apis:
                real = getattr(a, "real_name", "") or a.name
                alias = f"（别名，真实名 {real}）" if real != a.name else ""
                self.raw(f"//   {a.name}{alias} —— {a.dll}")
            self.raw()
            return
        self.raw("// ===== Windows API 声明（运行时 LoadLibrary + GetProcAddress 动态调用） =====")
        for a in apis:
            self.wline_directive(a.line, a.file if a.file else self._file_of(a))
            is_text_ret = a.ret_type == "文本型"
            is_void = a.ret_type == "空"
            cpp_ret = ("文本型" if is_text_ret else
                       "void" if is_void else
                       _API_TYPE.get(a.ret_type, "long long"))
            fn_ret = ("const wchar_t *" if is_text_ret else
                      "void" if is_void else
                      _API_TYPE.get(a.ret_type, "long long"))
            sig_params, fn_params, call_args, convs, backs = [], [], [], [], []
            for i, p in enumerate(a.params):
                is_arr = bool(p.array_dynamic) or p.array_size is not None
                if p.type == "文本型" and (p.byref or is_arr):
                    # 传址/数组文本（如 GetWindowTextW 的缓冲）：包装内开可写宽字符缓冲，
                    # 调用后把内容写回云易文本（缓冲 1024 宽字符，超出截断）
                    sig_params.append(f"文本型& {p.name}")
                    fn_params.append("wchar_t *")
                    convs.append(f"    std::wstring _t{i} = yy::到宽文本({p.name});")
                    convs.append(f"    std::vector<wchar_t> _p{i}(_t{i}.begin(), _t{i}.end());")
                    convs.append(f"    _p{i}.resize(1024, L'\\0');")
                    call_args.append(f"_p{i}.data()")
                    backs.append(f"{p.name} = yy::到窄文本(_p{i}.data());")
                elif p.byref or is_arr:
                    cpp = _API_TYPE.get(p.type)
                    if cpp is None:
                        # 字节集 / 自定义数据类型：直接传对象地址（数组传数据区首址）
                        tn = self.T(p.type)
                        sig_params.append(f"{tn}{'*' if is_arr else '&'} {p.name}")
                        fn_params.append("void *")
                        call_args.append(p.name if is_arr else f"&({p.name})")
                    elif is_arr:
                        # 数组参数 = 元素首址（调用点传 数组变量.data()）
                        sig_params.append(f"{cpp}* {p.name}")
                        fn_params.append(f"{cpp} *")
                        call_args.append(p.name)
                    elif p.type == "逻辑型":
                        # BOOL* 是 4 字节 int，bool 只有 1 字节：用 int 中转，调用后写回
                        sig_params.append(f"逻辑型& {p.name}")
                        fn_params.append("int *")
                        convs.append(f"    int _p{i} = {p.name} ? 1 : 0;")
                        call_args.append(f"&_p{i}")
                        backs.append(f"{p.name} = (_p{i} != 0);")
                    else:
                        # 传址标量：直接把变量地址交给 API，写回自动生效
                        sig_params.append(f"{cpp}& {p.name}")
                        fn_params.append(f"{cpp} *")
                        call_args.append(f"&({p.name})")
                elif p.type == "文本型":
                    sig_params.append(f"文本型 {p.name}")
                    fn_params.append("const wchar_t *")
                    convs.append(f"    std::wstring _p{i} = yy::到宽文本({p.name});")
                    call_args.append(f"_p{i}.c_str()")
                else:
                    cpp = _API_TYPE.get(p.type, "long long")
                    sig_params.append(f"{cpp} {p.name}")
                    fn_params.append(cpp)
                    call_args.append(p.name)
            real = getattr(a, "real_name", "") or a.name
            alias = "" if real == a.name else f"（别名 = {real}）"
            self.raw(f"// ---- {a.name} @ {a.dll} {alias}----")
            # DLL 模式：包装函数用 static inline，避免被导出去
            pre = "static " if self.mode == "dll" else ""
            self.w(f"{pre}inline {cpp_ret} yy_api_{a.name}({', '.join(sig_params)}) {{")
            self.indent += 1
            self.w(f"using FN = {fn_ret}(__stdcall *)({', '.join(fn_params)});")
            # 取函数地址：先按 stdcall 装饰名（名字@参数字节数）查，再退回平名。
            #   云易生成的 DLL（i386）：WINAPI 名就是带装饰的 名字@参数字节数 → 命中装饰名；
            #   云易生成的 DLL（x64）/ Windows API：只有平名，自然退回平名。
            # 注意：GetProcAddress 用的是真实 API 名（在库 "xxx.dll,真实名" 的真实名）
            nbytes = sum(8 if t in ("long long", "double") else 4 for t in fn_params)
            self.w(f'static FN _fn = reinterpret_cast<FN>('
                   f'yy::取API装饰(L"{a.dll}", "{real}", {nbytes}));')
            if is_void:
                self.w("if (!_fn) return;")
            elif is_text_ret:
                self.w('if (!_fn) return "";')
            elif a.ret_type == "逻辑型":
                self.w("if (!_fn) return false;")
            else:
                self.w("if (!_fn) return 0;")
            for c in convs:
                self.w(c)
            call = f"_fn({', '.join(call_args)})"
            if backs:
                # 有「传址文本/逻辑型」写回：先把返回值暂存，写回后再返回
                if is_void:
                    self.w(f"{call};")
                    for b in backs:
                        self.w(b)
                else:
                    tmp = "const wchar_t *_r" if is_text_ret else "auto _r"
                    self.w(f"{tmp} = {call};")
                    for b in backs:
                        self.w(b)
                    if is_text_ret:
                        self.w('return yy::到窄文本(_r ? _r : L"");')
                    else:
                        self.w("return _r;")
            elif is_void:
                self.w(f"{call};")
            elif is_text_ret:
                self.w(f"const wchar_t *_r = {call};")
                self.w('return yy::到窄文本(_r ? _r : L"");')
            else:
                self.w(f"return {call};")
            self.indent -= 1
            self.w("}")
        self.raw()

    def _file_of(self, node) -> str:
        return node.file if getattr(node, "file", "") else ""

    def gen_prototypes(self):
        for f in self.prog.funcs:
            sig = self.signature(f)
            self.wline_directive(f.line, f.file)
            self.w(f"{self._export_prefix(f)}{sig};")
        if self.prog.funcs:
            self.raw()

    def _export_prefix(self, f: ast.Func) -> str:
        """DLL 模式下的链接属性：
           · 「导出子程序」（未指定「导出名」）→ 子程序本身即 WINAPI 导出：
             extern "C" __stdcall __declspec(dllexport)
             （i386 的导出名带 @参数字节数 装饰，如 算加法@8；x64 无装饰）
           · 其余子程序 → static inline：不进导出表（内部子程序与辅助函数不导出）
           非 DLL 模式一律不加前缀。x64 上 __stdcall 被编译器忽略（只有一种调用约定）。"""
        if self.mode != "dll":
            return ""
        if getattr(f, "export", False) and not getattr(f, "export_name", ""):
            return 'extern "C" __stdcall __declspec(dllexport) '
        return "static inline "

    def _param_decl(self, p) -> str:
        """参数的 C++ 声明：
        · 数组参数（固定/动态）一律按引用传递：std::array<T,N>& / std::vector<T>&
        · 传址（参考）参数 → T&
        · 其余 → T"""
        t = self.T(p.type)
        if p.array_dynamic:
            return f"std::vector<{t}>& {p.name}"
        if p.array_size is not None:
            return f"std::array<{t}, {self.expr(p.array_size)}>& {p.name}"
        if p.byref:
            return f"{t}& {p.name}"
        return f"{t} {p.name}"

    def signature(self, f: ast.Func) -> str:
        ret = self.T(f.ret_type or "空")
        params = [self._param_decl(p) for p in f.params]
        return f"{ret} {f.name}({', '.join(params)})"

    def gen_func(self, f: ast.Func):
        self._func_locals = {v.name for v in self.collect_locals(f.body, f.file)}
        # 本函数可见的「变量名 → 类型」表，用于识别 子程序指针 间接调用
        self._func_vtypes = {}
        for p in f.params:
            self._func_vtypes[p.name] = p.type
        for v in self.collect_locals(f.body, f.file):
            self._func_vtypes[v.name] = v.type
        for g in self.prog.globals_:
            self._func_vtypes.setdefault(g.name, g.type)
        for c in self.prog.consts:
            self._func_vtypes.setdefault(c.name, c.type)
        # 子程序指针间接调用：记录「变量 = 子程序名」的指向，调用时按目标签名转型
        self._subptr = {}

        def _children(s):
            ch = []
            if isinstance(s, ast.IfStmt):
                for _, b in s.branches:
                    ch.extend(b)
                if s.else_body:
                    ch.extend(s.else_body)
            body = getattr(s, "body", None)
            if isinstance(body, list):
                ch.extend(body)
            return ch

        def scan(sts):
            for s in sts:
                if isinstance(s, ast.VarDecl) and isinstance(s.init, ast.Name) and s.init.id in self.func_names:
                    self._subptr[s.name] = s.init.id
                elif (isinstance(s, ast.Assign) and isinstance(s.target, ast.Name)
                      and isinstance(s.value, ast.Name) and s.value.id in self.func_names):
                    self._subptr[s.target.id] = s.value.id
                for c in _children(s):
                    scan([c])

        scan(f.body)
        # 子程序开头不允许与参数重名（参数已经在符号表）
        params = {p.name for p in f.params}
        local_decls = [v for v in self.collect_locals(f.body, f.file) if v.name not in params]
        self.wline_directive(f.line, f.file)
        sig = self.signature(f)
        self.w(f"{self._export_prefix(f)}{sig} {{")
        self.indent += 1
        for v in local_decls:
            self.wline_directive(v.line, f.file)
            size = self.expr(v.array_size) if v.array_size is not None else None
            self.w(_decl_text(self.T(v.type), v.name, size,
                              getattr(v, "array_dynamic", False)) + ";")
        self.emit_block(f.body, f.file)
        if f.ret_type is not None and not self._ends_with_return(f.body):
            self.w("return {};")
        self.indent -= 1
        self.w("}")

    def gen_dll_aliases(self):
        """DLL 导出包装：每个「导出子程序」导出两个名字。

          · WINAPI 名（__stdcall）：i386 保留 @参数字节数 装饰（Add@8；不加 -Wl,--kill-at），
            x64 为平名（Add）—— Win32 / VB6 / 易语言 / Delphi / 云易 用它
            （未指定「导出名」时，由 _export_prefix 直接把子程序本身导出去）
          · <名字>_cdecl（Add_cdecl）：cdecl 约定 —— C/C++ 默认调用约定用它
          两者都转发到同一个云易子程序。"""
        rows = [f for f in self.prog.funcs if getattr(f, "export", False)]
        if not rows:
            return
        self.raw("// ===== DLL 导出包装（WINAPI 名 = __stdcall；<名字>_cdecl = cdecl） =====")
        for f in rows:
            e = getattr(f, "export_name", "") or f.name       # 导出基名
            params = ", ".join(self._param_decl(p) for p in f.params)
            args = ", ".join(p.name for p in f.params)
            ret = self.T(f.ret_type or "空")
            body = (f"{f.name}({args});" if f.ret_type is None
                    else f"return {f.name}({args});")
            # ① WINAPI 名（__stdcall）：未指定「导出名」时它就是这个子程序本身
            #    （已在 gen_func 里 __stdcall + dllexport），这里只为指定了「导出名」的另生成包装
            if getattr(f, "export_name", ""):
                self.wline_directive(f.line, f.file)
                self.w(f'extern "C" __stdcall __declspec(dllexport) {ret} {e}({params}) {{')
                self.indent += 1
                self.w(body)
                self.indent -= 1
                self.w("}")
            # ② cdecl 别名导出：<名字>_cdecl
            self.wline_directive(f.line, f.file)
            self.w(f'extern "C" __declspec(dllexport) {ret} {e}{_CDECL_SUFFIX}({params}) {{')
            self.indent += 1
            self.w(body)
            self.indent -= 1
            self.w("}")
        self.raw()

    def gen_main_run(self):
        entry = self.find_entry()
        if entry is None:
            tests = self.test_funcs()
            if tests:
                raise YyError(
                    "工程中没有子程序「程序入口」，只有测试函数。请点击工具栏的『测试』按钮执行测试。",
                    tests[0].line, tests[0].col, tests[0].file)
            raise YyError("缺少子程序 程序入口()。程序从 子程序 程序入口() 开始执行。", 1, 1, "")
        self.raw()
        self.wline_directive(entry.line, entry.file)
        self.w("int main() {")
        self.indent += 1
        if entry.ret_type is not None:
            self.w(f"return {entry.name}();")
        else:
            self.w(f"{entry.name}();")
            self.w("return 0;")
        self.indent -= 1
        self.w("}")

    def gen_main_test(self):
        tests = self.test_funcs()
        if not tests:
            raise YyError("工程中没有测试函数。把某子程序的开头关键字改为「测试函数」即可。", 1, 1, "")
        self.raw()
        self.w("int main() {")
        self.indent += 1
        self.w(f"{self.call_name('_yy断言重置')}();")
        for t in tests:
            self.wline_directive(t.line, t.file)
            self.w(f"{t.name}();")
        self.w(f'{self.call_name("输出")}("[测试] 共", '
               f'{self.call_name("_yy取总数")}(), "项断言，失败", '
               f'{self.call_name("_yy取失败")}(), "项");')
        self.w(f"return {self.call_name('_yy取失败')}() > 0 ? 1 : 0;")
        self.indent -= 1
        self.w("}")


def generate_cpp(prog: ast.Program, mode: str = "run", native: bool = False,
                 clean: bool = False, asm_syntax: str = "att") -> str:
    """翻译入口。
    native=True 生成不依赖中文运行库的「原生 C++」（供导出功能使用）；
    clean=True  去掉 #line 指令与机器注释（纯正 C++ 风格）；
    asm_syntax  内联汇编语法：att（默认）/ intel（工程设置「汇编语法」）。
    用户源码里的中文变量名/常量名/类型名/子程序名一律原样保留（合法 C++ 标识符）。"""
    gen = CodeGen(prog)
    gen.mode = mode
    gen.native = native
    gen.clean = clean
    gen.asm_syntax = CodeGen._asm_dialect(asm_syntax)
    return gen.gen(mode)
