# -*- coding: utf-8 -*-
"""文本与编码工具（全工程以 UTF-8 为基准；本机代码页只作兜底）。

统一策略
--------
本 IDE 自己产出的**一切文本都是 UTF-8**：源码（.yy / .py / .js / .css / .html）、
配置（.json / .yyproj）、文档（.md）、生成物（main_gen.cpp / CMakeLists.txt /
构建.bat / 导出脚本 / app.rc）。这是「统一 UTF-8」的基准。

只有两处**客观上**不能是 UTF-8，都有实测依据，不能盲目改：

1. **生成的 Makefile 必须是本机代码页（中文 Windows = GBK）**：
   mingw32-make 在 Windows 上把 Makefile 里的字节按 ANSI 代码页（GetACP）转成命令行
   参数，UTF-8 内容会被转坏 —— 实测：UTF-8 的 Makefile 报
   `工程目录不存在：F:\\…\\宸ヤ綔鍖?zzUTF8`（GBK 版正常）。
   （CMakeLists.txt 不受此限：CMake 走 Unicode，已经是 UTF-8。）
2. **用户 / 第三方产生的文件**可能是 GBK（记事本存的 .txt/.bat、老 .class 等）：
   只做**兜底解码**读取，绝不改其编码（回写时按原编码）。

本模块提供
----------
· 统一读写：read_text / write_text（默认 UTF-8 + LF）、sniff_encoding（供「按原编码回写」）
· 兜底解码：decode_bytes（UTF-8 优先 → 本机代码页 → replace，**永不抛异常**）
· 混合解码：decode_mixed（逐行判断）—— 子进程输出常是混排（mingw 诊断里路径是 ANSI、
  标识符回显是 UTF-8），逐行处理最稳
"""
from __future__ import annotations
import os

UTF8 = "utf-8"
UTF8_SIG = "utf-8-sig"


def code_page_name(cp) -> str:
    """代码页号 → Python 编码名（936 报作 "gbk"：更好读，且是同一个编解码器）。"""
    if not cp:
        return ""
    return "gbk" if cp == 936 else "cp%d" % cp


def ansi_encoding() -> str:
    """本机 **ANSI** 代码页（GetACP）。

    这是 Windows 上「非 Unicode 程序」读写文件、把字节转命令行参数时用的代码页，
    也就是 `mingw32-make` 读 Makefile、cmd 内建命令报错信息所用的那一种。
    中文 Windows → "gbk"。取不到时给 "gbk"（本项目主力环境）。
    """
    if os.name == "nt":
        try:
            import ctypes
            name = code_page_name(ctypes.windll.kernel32.GetACP())
            if name:
                return name
        except Exception:
            pass
    return "gbk"


def oem_encoding() -> str:
    """本机 **OEM**（控制台）代码页（GetOEMCP）。

    控制台老程序（`cmd` 内建命令、`chcp` 未改时的原生命令行工具）往管道里吐的是
    这个代码页的字节。取不到时回退 ANSI。
    """
    if os.name == "nt":
        try:
            import ctypes
            name = code_page_name(ctypes.windll.kernel32.GetOEMCP())
            if name:
                return name
        except Exception:
            pass
    return ansi_encoding()


def local_encodings() -> list:
    """本机 ANSI / OEM 代码页的**候选编码列表**（去重 + 兜底），供 decode_bytes 依次尝试。"""
    out = []
    for name in (ansi_encoding(), oem_encoding()):
        if name and name not in out:
            out.append(name)
    for name in ("gbk", "cp1252"):               # 非 Windows / 取不到代码页时的兜底
        if name not in out:
            out.append(name)
    return out


def decode_bytes(b: bytes, prefer: str = UTF8) -> tuple:
    """bytes → (文本, 实际编码)；永不抛异常。

    顺序：BOM（UTF-8 / UTF-16）→ prefer → UTF-8 → 本机 ANSI / OEM 代码页 →
    `utf-8 + replace`。最后一种兜底时编码名带 `*`（如 `utf-8*`），表示有字节被替换、
    内容可能不完整（调用方可据此判定「像二进制」）。
    """
    if not b:
        return "", prefer or UTF8
    if b[:3] == b"\xef\xbb\xbf":
        try:
            return b.decode(UTF8_SIG), UTF8
        except UnicodeDecodeError:
            pass
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        enc = "utf-16-le" if b[:2] == b"\xff\xfe" else "utf-16-be"
        try:
            return b.decode(enc), enc
        except UnicodeDecodeError:
            pass
    tried = []
    for enc in (prefer or UTF8, UTF8):
        if enc in tried:
            continue
        tried.append(enc)
        try:
            # 不带 BOM 的 UTF-8 统一报 "utf-8"（"utf-8-sig" 只在确实有 BOM 时有区别）
            return b.decode(enc), (UTF8 if enc in (UTF8, UTF8_SIG) else enc)
        except (LookupError, UnicodeDecodeError):
            continue
    for enc in local_encodings():
        if enc in tried:
            continue
        tried.append(enc)
        try:
            return b.decode(enc), enc
        except (LookupError, UnicodeDecodeError):
            continue
    return b.decode(UTF8, "replace"), UTF8 + "*"


def decode_text(b: bytes, prefer: str = UTF8) -> str:
    """只要文本、不要编码名时的简写。"""
    return decode_bytes(b, prefer)[0]


def decode_mixed(raw: bytes) -> str:
    """逐行智能解码（用于子进程输出）。

    能按 UTF-8 严格解码的行用 UTF-8，否则按本机代码页 —— 因为 mingw 的编译器 / make 输出
    常是混排：路径按 ANSI 代码页、源码标识符回显是 UTF-8。整块 decode 一定有一边会坏，
    逐行则两边都对。
    """
    if not raw:
        return ""
    out = []
    for line in raw.split(b"\n"):
        try:
            out.append(line.decode(UTF8))
        except UnicodeDecodeError:
            out.append(decode_bytes(line, UTF8)[0])
    return "\n".join(out)


def read_text(path: str, prefer: str = UTF8_SIG) -> tuple:
    """读文本文件 → (文本, 实际编码)。文件不存在的 OSError 由调用方处理。"""
    with open(path, "rb") as fp:
        return decode_bytes(fp.read(), prefer)


def sniff_encoding(path: str) -> str:
    """探测文件当前编码（'utf-8' / 'gbk' …）；不存在、空文件或读不了返回 ""。"""
    try:
        with open(path, "rb") as fp:
            b = fp.read(512 * 1024)
    except OSError:
        return ""
    if not b:
        return ""
    return decode_bytes(b)[1]


def write_text(path: str, text: str, enc: str = UTF8, newline: str = "") -> dict:
    """写文本文件（默认 UTF-8 + LF，与工程约定一致），返回 {bytes, encoding}。"""
    enc = (enc or UTF8).replace("*", "") or UTF8
    with open(path, "w", encoding=enc, errors="replace", newline=newline) as fp:
        fp.write(text)
    return {"bytes": len(text.encode(enc, "replace")), "encoding": enc}


def can_encode(text: str, enc: str) -> bool:
    """text 能否无损用 enc 表示（用于提示「按原编码回写会不会掉字符」）。"""
    try:
        text.encode((enc or UTF8).replace("*", "") or UTF8)
        return True
    except (LookupError, UnicodeEncodeError):
        return False
