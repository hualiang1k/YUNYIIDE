# -*- coding: utf-8 -*-
"""编码通道表与统一转换接口（编译 / 调试 / 子进程 / 文件读写共用的那一套规则）。

为什么要有这个模块
------------------
本项目「字节 → 文本」的转换原先散落在十几处，各自假设的编码并不相同：

    编译器诊断      mingw 输出是**混排**的：中文路径按 ANSI 代码页、源码标识符回显是 UTF-8
    cmd 内建命令    dir / echo 输出是 OEM 代码页；可 `type <UTF-8 文件>` 又是原样 UTF-8 字节
    自带 bash/git   全程 UTF-8
    生成的 Makefile **必须**是本机代码页（mingw32-make 按 GetACP 把字节转成命令行参数）
    编译出的程序    运行库启动即 SetConsoleOutputCP(65001) → UTF-8
    自产的一切文件  源码 / 配置 / 日志 / HTTP 全是 UTF-8

由此带来两个问题：
  1. 同一件事（比如「解码子进程输出」）在不同文件里各写一遍，行为不一致；
  2. 不少地方直接 `.decode("utf-8", "replace")` —— **没有本机代码页兜底**，
     中文 Windows 上 GBK 的诊断、GBK 的 taskkill 提示会整片变成乱码，
     而且因为用了 replace 还看不出是乱码（实测问题）。

本模块把「哪个通道用什么编码」集中成一张**声明式表**（CHANNELS），调用方只说通道名，
不再各自记编码：

    from yunyi import codec

    codec.decode("compiler", raw)          # 编译诊断（逐行混排解码）
    codec.decode("shell_cmd", raw)         # cmd 内建命令输出
    codec.decode("shell_bash", raw)        # 自带 bash / git 输出
    codec.read("source", "工作区/示例程序/main.yy")
    codec.write("makefile", path, text)    # 自动按本机代码页写
    codec.convert(raw, "gbk", "utf-8")     # 跨编码转换

编码可以用 `config/encoding.json` 覆盖（不用改代码），例如把编译器输出钉死成 GBK：

    { "compiler": "gbk", "shell_pwsh": "oem" }

命令行（编译 / 调试时直接调用，不必进 Python）
--------------------------------------------
    python -m yunyi.codec list                        # 看全部通道的编码配置
    python -m yunyi.codec list --json                 # 同上，机器可读
    python -m yunyi.codec enc compiler                # 查某个通道实际用什么编码
    python -m yunyi.codec decode compiler err.bin     # 解码一段字节（省略文件=读 stdin）
    python -m yunyi.codec encode makefile out.txt     # 按通道编码（输出到 stdout）
    python -m yunyi.codec convert gbk utf-8 a.txt     # src 通道/编码 → dst 通道/编码
    python -m yunyi.codec read source 工作区/.../main.yy
    python -m yunyi.codec write makefile Makefile     # 从 stdin 读文本写入

分层：`yunyi/textio.py` 是**低层原语**（decode_bytes / decode_mixed / read_text …），
本模块只做「通道登记 + 策略解析 + 分发」，不重复实现解码。
"""
from __future__ import annotations
import json
import os
import sys
from dataclasses import dataclass

from yunyi import textio as T

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe：config 在 exe 旁边（与 yunyi/toolchain.py 同一规则）
    ROOT = os.path.dirname(os.path.abspath(sys.executable))
OVERRIDE_FILE = os.path.join(ROOT, "config", "encoding.json")

# ---------------- 编码策略代号 ----------------
# 这些不是真实的 Python 编码名，而是「怎么解」的说明，运行时再解析成具体编码。
AUTO = "auto"          # 探测：UTF-8 优先 → 本机 ANSI / OEM 代码页 → utf-8+replace（永不抛）
MIXED = "mixed"        # 逐行判断（子进程混排输出专用）
LOCAL = "local"        # 本机 ANSI 代码页（中文 Windows = gbk）
OEM = "oem"            # 本机 OEM（控制台）代码页
ASCII = "ascii"        # 纯 ASCII
LATIN_LOCAL = "latin-local"   # 乱码名还原：latin-1 编回字节 → 按本机代码页解码

_POLICIES = (AUTO, MIXED, LOCAL, OEM, ASCII, LATIN_LOCAL)


@dataclass(frozen=True)
class Channel:
    """一条编码通道：某个接口 / 环节「用什么编码」的声明。"""
    key: str
    label: str        # 中文名（给人看）
    codec: str        # 策略代号或具体编码名
    mode: str         # "r" 只读 / "w" 只写 / "rw" 读写
    note: str         # 为什么是这个编码（带实测依据，排查时看这里）

    @property
    def writable(self) -> bool:
        return "w" in self.mode

    @property
    def readable(self) -> bool:
        return "r" in self.mode


# ---------------- 通道表（唯一的「配置列表」） ----------------
_SPEC = [
    # ---- 编译 / 构建 ----
    ("compiler", "编译器 / 构建诊断", MIXED, "r",
     "mingw 输出是混排的：中文路径按 ANSI 代码页、源码标识符回显是 UTF-8；"
     "整块 decode 必坏一半，只能逐行判断"),
    ("make", "mingw32-make 输出", MIXED, "r",
     "同上：make 自身消息按 ANSI，它拉起的编译子进程输出是 UTF-8"),
    ("windres", "windres 资源编译诊断", AUTO, "r",
     "只在图标资源编译失败时用；信息量小且可能混排，走带兜底的探测解码"),
    ("taskkill", "taskkill 等系统工具提示", LOCAL, "r",
     "系统消息按 ANSI 代码页（实测中文 Windows = gbk）。原先硬编码 gbk，"
     "非中文系统上会乱码"),
    # ---- 子进程 / 运行 ----
    ("shell_cmd", "cmd.exe 内建命令输出", AUTO, "r",
     "dir / echo 等按 OEM 代码页，但 `type <UTF-8 文件>` 是原样 UTF-8 字节 —— "
     "两种情况并存，不能钉死某一种，必须探测"),
    ("shell_bash", "自带 bash / git / coreutils", T.UTF8, "r",
     "Git Bash 与 GNU 工具全程 UTF-8（已由 bash_env 保证）"),
    ("shell_pwsh", "PowerShell 输出", AUTO, "r",
     "随控制台输出代码页变化（Windows PowerShell 5 默认 OEM），探测更稳"),
    ("runner", "程序 / 脚本运行输出", T.UTF8, "r",
     "云易运行库启动即 SetConsoleOutputCP(65001)（yunyi/runtime/yunyi_rt.hpp）；"
     "脚本进程另有 PYTHONIOENCODING=utf-8 保证"),
    ("debugger", "调试器输出（预留通道）", T.UTF8, "r",
     "本项目目前**没有**调试器；将来接 gdb/MI 或 DAP 时，输出从这条通道走"),
    # ---- 工程文件（写入侧编码最要紧） ----
    ("source", "云易源码 .yy", T.UTF8, "rw",
     "自产 UTF-8 **不写 BOM**（写 utf-8-sig 会带上 BOM，与工程约定不符）；"
     "读的时候 decode_bytes 会先认 BOM，所以照样能读别人的带 BOM 文件"),
    ("project", "工程配置 .yyproj", T.UTF8, "rw", "同上：写不带 BOM，读容 BOM"),
    ("makefile", "生成的 Makefile", LOCAL, "rw",
     "**唯一强制本机代码页的产物**：mingw32-make 按 GetACP 把 Makefile 字节转成命令行"
     "参数，UTF-8 会被转坏（实测报「工程目录不存在：F:\\…\\宸ヤ綔鍖?」）"),
    ("cmake", "CMakeLists.txt", T.UTF8, "rw", "CMake 内部走 Unicode，UTF-8 即可"),
    ("build_script", "构建.bat / CI 脚本", T.UTF8, "rw",
     "脚本自己带 chcp 65001，UTF-8 安全"),
    ("repo", "仓库元文件（.gitignore 等）", T.UTF8, "rw", "git 按 UTF-8 读；内容自产"),
    ("artifact", "构建产物 / 生成物", T.UTF8, "rw",
     "翻译产物 main_gen.cpp、DLL 导出清单、导出目录里的 README：全自产 UTF-8，"
     "且都能重新生成（compile / 导出）"),
    ("resource", "app.rc（windres 资源脚本）", ASCII, "rw",
     "刻意纯 ASCII：windres 对代码页混排敏感，内容只有图标引用"),
    ("classlib", "类库 .class / 语言文档", T.UTF8, "r",
     "自产 UTF-8；BOM 由 decode_bytes 统一识别（原先是 utf-8-sig，读侧等价）"),
    # ---- 智能体侧 / 与外部文件的边界 ----
    ("skill", "SKILL.md（可能被手工编辑）", AUTO, "r",
     "UTF-8 优先、本机代码页兜底：记事本存成 GBK 的 SKILL.md 也要能加载"),
    ("config", "settings / agent / MCP 配置", T.UTF8, "rw",
     "UTF-8 不写 BOM；读取容 BOM（与 yunyi/toolchain.py 既有做法一致）"),
    ("state", "会话 / 记忆 / 日志 / trace", T.UTF8, "rw", "全部自产，UTF-8"),
    ("text", "任意文本文件（编辑器/智能体）", AUTO, "rw",
     "用户文件可能是 GBK：读时兜底；**回写必须显式给 enc**（先 codec.sniff(path)）"),
    ("http", "HTTP JSON / SSE", T.UTF8, "rw", "响应头都声明 charset=utf-8"),
    ("ipc", "子进程 IPC（PTC / 会话管道）", T.UTF8, "rw",
     "自家进程之间的 JSON 帧（PTC 父子进程、MCP stdio 传输）：两端都是本项目控制，"
     "协议固定 UTF-8"),
    ("frontend", "编辑器 ↔ 后端（.yy 内容）", T.UTF8, "rw",
     "前端 TextDecoder('utf-8') 固定 UTF-8；非 UTF-8 走 base64 + binary 标记"),
    # ---- 特殊转换 ----
    ("file_name", "乱码文件名还原", LATIN_LOCAL, "r",
     "批处理产物名乱码（ÔÆÒ×Qt_x86.dll = GBK 字节被当成 latin-1）："
     "先按 latin-1 编回字节，再按本机代码页解码"),
]

CHANNELS = {k: Channel(k, label, codec, mode, note)
            for (k, label, codec, mode, note) in _SPEC}

# 好记的别名（编译 / 调试时手敲更省事）；别名不参与 list 输出
ALIASES = {
    "gcc": "compiler", "gxx": "compiler", "diagnostic": "compiler", "build_log": "compiler",
    "make_output": "make", "mingw_make": "make",
    "cmd": "shell_cmd", "console": "shell_cmd",
    "bash": "shell_bash", "git": "shell_bash", "sh": "shell_bash", "coreutils": "shell_bash",
    "powershell": "shell_pwsh", "ps": "shell_pwsh", "pwsh": "shell_pwsh",
    "run": "runner", "program": "runner", "stdout": "runner",
    "debug": "debugger", "gdb": "debugger", "dap": "debugger", "mi": "debugger",
    "yy": "source", "code": "source",
    "yyproj": "project",
    "made_file": "makefile",
    "bat": "build_script", "ci": "build_script", "gitignore": "repo",
    "rc": "resource",
    "class": "classlib", "langdoc": "classlib",
    "skills": "skill", "skill_md": "skill",
    "settings": "config",
    "session": "state", "log": "state", "trace": "state", "memory": "state",
    "file": "text", "editor": "text", "user_file": "text",
    "json": "http", "sse": "http",
    "dll_name": "file_name", "filename": "file_name",
}


# ---------------- 覆盖配置（config/encoding.json） ----------------
_OV = {"mtime": None, "data": {}}


def overrides() -> dict:
    """读取覆盖配置 {通道: 策略或编码名}；文件不存在 / 坏了都返回 {}（不影响默认行为）。"""
    try:
        mtime = os.path.getmtime(OVERRIDE_FILE)
    except OSError:
        if _OV["mtime"] is not None:
            _OV.update(mtime=None, data={})
        return {}
    if _OV["mtime"] == mtime:
        return _OV["data"]
    data = {}
    try:
        with open(OVERRIDE_FILE, "r", encoding="utf-8-sig") as fp:
            raw = json.load(fp)
        if isinstance(raw, dict):
            for k, v in raw.items():
                k, v = str(k or "").strip(), str(v or "").strip()
                if k and v and k in CHANNELS:
                    data[k] = v
    except Exception:
        data = {}
    _OV.update(mtime=mtime, data=data)
    return data


def reload_overrides() -> dict:
    """丢掉缓存，重新读覆盖配置。"""
    _OV.update(mtime=None, data={})
    return overrides()


# ---------------- 查询 ----------------

def get(key: str) -> Channel:
    """取通道。

    key 可以是通道名、别名，也可以是**裸编码名**（"gbk" / "utf-8" / "cp1252"）——
    后者会被包成一条临时通道（不会登记进 CHANNELS），供 convert / 命令行直接按编码读写。
    都不是才报 KeyError，并把可用通道列在错误信息里。
    """
    k = str(key or "").strip()
    if k in CHANNELS:
        return CHANNELS[k]
    low = k.lower()
    if low in ALIASES:
        return CHANNELS[ALIASES[low]]
    if k:
        try:
            "".encode(k)                      # 合法编码名 → 临时通道
            return Channel(k, "直接指定编码 " + k, k, "rw",
                           "由调用方直接指定的编码，未登记在通道表里")
        except LookupError:
            pass
    raise KeyError("未知编码通道 / 编码名：%s（通道可用：%s）"
                   % (key, "、".join(sorted(CHANNELS))))


def codec_of(key: str) -> str:
    """该通道生效的编码策略（覆盖配置优先）。"""
    ch = get(key)
    return overrides().get(ch.key, ch.codec)


def is_policy(c: str) -> bool:
    return (c or "").strip().lower() in _POLICIES


def encoding_of(key: str) -> str:
    """该通道落到哪个**具体** Python 编码名。

    探测类通道（auto / mixed）给的是「首选编码」：读的时候还会按本机代码页兜底，
    所以别把它当成「唯一可能」。写回时这些通道必须显式给 enc（见 write）。
    """
    c = (codec_of(key) or T.UTF8).strip()
    low = c.lower()
    if low == LOCAL:
        return T.ansi_encoding()
    if low == OEM:
        return T.oem_encoding()
    if low == LATIN_LOCAL:
        return T.ansi_encoding()
    if low in (AUTO, MIXED):
        return T.UTF8
    return c


def codec_label(key: str) -> str:
    """编码列的**人类可读**写法：探测类通道不能只写 "utf-8"，那会误导。"""
    c = (codec_of(key) or T.UTF8).strip()
    low = c.lower()
    if low == MIXED:
        return "mixed 逐行"
    if low == AUTO:
        return "auto 探测"
    if low == LOCAL:
        return "local(%s)" % T.ansi_encoding()
    if low == OEM:
        return "oem(%s)" % T.oem_encoding()
    if low == LATIN_LOCAL:
        return "latin1→%s" % T.ansi_encoding()
    if low == ASCII:
        return "ascii"
    return c


def decode_chain(key: str) -> str:
    """人类可读的「解码顺序」（排查乱码时看这个）。"""
    c = (codec_of(key) or T.UTF8).strip()
    low = c.lower()
    if low == MIXED:
        return "逐行：能严格 UTF-8 的行按 UTF-8，否则 " + T.ansi_encoding()
    if low == AUTO:
        return "UTF-8 → BOM → %s → replace" % " / ".join(T.local_encodings())
    if low == LATIN_LOCAL:
        return "latin-1 → " + T.ansi_encoding()
    if low == LOCAL:
        return "%s → UTF-8 → 兜底（首选 %s）" % (T.ansi_encoding(), T.ansi_encoding())
    if low == OEM:
        return "%s → UTF-8 → 兜底（首选 %s）" % (T.oem_encoding(), T.oem_encoding())
    if low == ASCII:
        return "ascii → replace"
    return "BOM → %s → 本机代码页 → replace" % c


def channel_info(key: str) -> dict:
    """单条通道的完整信息（给界面 / CLI / JSON 用）。"""
    ch = get(key)
    eff = codec_of(key)
    return {"key": ch.key, "label": ch.label, "mode": ch.mode,
            "codec": eff, "codecLabel": codec_label(key), "default": ch.codec,
            "encoding": encoding_of(key),
            "overridden": ch.key in overrides(),
            "chain": decode_chain(key), "note": ch.note}


def channels() -> list:
    """**配置列表**：全部通道及其编码（按表内顺序）。"""
    return [channel_info(k) for k in CHANNELS]


def encodings() -> list:
    """本机与全表涉及到的具体编码名（排查环境用，已去重）。"""
    out = []
    for name in (T.UTF8, T.UTF8_SIG, T.ansi_encoding(), T.oem_encoding()):
        if name and name not in out:
            out.append(name)
    for k in CHANNELS:
        e = encoding_of(k)
        if e and e not in out:
            out.append(e)
    return out


# ---------------- 转换 ----------------

def decode_ex(key: str, raw: bytes) -> tuple:
    """bytes → (文本, 实际编码/策略名)。永不抛异常。"""
    c = (codec_of(key) or T.UTF8).strip()
    low = c.lower()
    if not raw:
        return "", encoding_of(key)
    if low == MIXED:
        return T.decode_mixed(raw), MIXED
    if low == AUTO:
        return T.decode_bytes(raw, T.UTF8)
    if low == LATIN_LOCAL:
        return fix_mojibake(raw.decode("latin-1", "replace")), "latin1+%s" % T.ansi_encoding()
    if low == LOCAL:
        return T.decode_bytes(raw, T.ansi_encoding())
    if low == OEM:
        return T.decode_bytes(raw, T.oem_encoding())
    if low == ASCII:
        return raw.decode(ASCII, "replace"), ASCII
    return T.decode_bytes(raw, c)


def decode(key: str, raw: bytes) -> str:
    """bytes → 文本（主入口）。"""
    return decode_ex(key, raw)[0]


def encode(key: str, text: str) -> bytes:
    """文本 → bytes（按该通道**应写**的编码）。

    探测类通道（auto / mixed）没有确定答案，必须显式走 write(..., enc=...) —— 
    在这里直接抛错，免得写出一份自己都读不准的文件。
    """
    c = (codec_of(key) or T.UTF8).strip()
    low = c.lower()
    if low in (AUTO, MIXED):
        ch = get(key)
        raise ValueError(
            "通道 %s（%s）是探测式读取通道，编码不唯一，写回必须显式指定编码："
            "先 codec.sniff(path) 取原编码，或用 write(..., enc=\"utf-8\")"
            % (ch.key, ch.label))
    if low == LATIN_LOCAL:
        enc = T.ansi_encoding()
        return text.encode(enc, "replace").decode("latin-1").encode("latin-1", "replace")
    enc = ASCII if low == ASCII else encoding_of(key)
    return text.encode(enc, "replace")


def read(key: str, path: str) -> tuple:
    """按通道读文本文件 → (文本, 实际编码)。"""
    ch = get(key)
    if not ch.readable:
        raise ValueError("通道 %s（%s）是只写通道，不能用于读取" % (ch.key, ch.label))
    with open(path, "rb") as fp:
        return decode_ex(key, fp.read())


def write(key: str, path: str, text: str, enc: str = "") -> dict:
    """按通道写文本文件。

    enc 为空时用通道自己的写入编码；若该通道是探测式（auto / mixed），**必须**显式给
    enc（典型做法：先 sniff 原编码再原样回写，避免把用户的 GBK 文件改成 UTF-8）。
    """
    ch = get(key)
    if not ch.writable:
        raise ValueError("通道 %s（%s）是只读通道，不能用于写入" % (ch.key, ch.label))
    if enc:
        use = str(enc).replace("*", "") or T.UTF8
    else:
        if (codec_of(key) or "").lower() in (AUTO, MIXED):
            raise ValueError(
                "通道 %s（%s）是探测式通道，写入必须显式给 enc"
                "（先用 codec.sniff(path) 取原编码）" % (ch.key, ch.label))
        use = encoding_of(key)
    out = T.write_text(path, text, use)
    out["channel"] = ch.key
    return out


def _read_encoding(enc: str) -> str:
    """读取用的编码：UTF-8 一律用 utf-8-sig。

    有 BOM 就剥掉、没有则与 utf-8 **完全等价** —— 这样「别人用记事本存了个带 BOM 的
    json」也不会让 json.load 报错，同时与 read()/decode_bytes 的 BOM 处理保持一致。
    """
    e = (enc or "").replace("*", "") or T.UTF8
    return T.UTF8_SIG if e.lower() in ("utf-8", "utf8", "u8") else e


def open_text(key: str, path: str, mode: str = "r", enc: str = "",
              newline=None, errors=None):
    """按通道打开文本文件（需要**追加**、**原子写**、**自定义换行**时用它）。

    比 read / write 更通用，编码照样由通道决定，调用方不必再写 encoding=：
      · 写模式（w / a / x / +）默认 errors="replace"（与 write 一致），
        且探测式通道（auto / mixed）**必须**显式给 enc；
      · 读模式默认 errors="strict"（保持「坏文件要报错」的既有语义）；
      · newline 默认走 Python 默认（写时把 \\n 转成平台换行）；生成 Makefile /
        构建.bat 这类「模板里已是 \\r\\n」的场景要传 newline="" 原样直写。
    """
    ch = get(key)
    writing = any(m in mode for m in ("w", "a", "x", "+"))
    if writing and not ch.writable:
        raise ValueError("通道 %s（%s）是只读通道，不能用于写入" % (ch.key, ch.label))
    if not writing and not ch.readable:
        raise ValueError("通道 %s（%s）是只写通道，不能用于读取" % (ch.key, ch.label))
    if enc:
        use = str(enc).replace("*", "") or T.UTF8
    elif writing and (codec_of(key) or "").lower() in (AUTO, MIXED):
        raise ValueError("通道 %s（%s）是探测式通道，写入必须显式给 enc"
                         % (ch.key, ch.label))
    else:
        use = encoding_of(key)
    if errors is None:
        errors = "replace" if writing else "strict"
    if not writing:
        use = _read_encoding(use)
    return open(path, mode, encoding=use, errors=errors, newline=newline)


def sniff(path: str) -> str:
    """探测文件当前编码（供「按原编码回写」）。"""
    return T.sniff_encoding(path)


def can_encode(text: str, enc: str) -> bool:
    return T.can_encode(text, enc)


def fix_mojibake(text: str, to: str = "") -> str:
    """还原「某代码页的字节被当成 latin-1 读进来」的乱码（文件名 / 控制台输出）。"""
    to = (to or T.ansi_encoding()).replace("*", "")
    try:
        return text.encode("latin-1").decode(to)
    except (LookupError, UnicodeEncodeError, UnicodeDecodeError):
        return text


def convert(data, src: str, dst: str) -> bytes:
    """跨通道 / 跨编码转换：把按 src 解释的 data 转成 dst 的字节。

    src / dst 既可以是通道名（"compiler" / "makefile" / 别名），也可以是编码名（"gbk"）。
    """
    text = data if isinstance(data, str) else decode(src, data)
    return encode(dst, text)


# ---------------- 命令行 ----------------

def _fix_stdio():
    for name in ("stdout", "stderr"):
        fp = getattr(sys, name, None)
        try:
            fp.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _read_input(path: str) -> bytes:
    if path:
        with open(path, "rb") as fp:
            return fp.read()
    return sys.stdin.buffer.read()


def _out(data: bytes, path: str):
    if path:
        with open(path, "wb") as fp:
            fp.write(data)
        sys.stderr.write("已写入 %s（%d 字节）\n" % (path, len(data)))
    else:
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


def _dw(s: str) -> int:
    """显示宽度（CJK 算 2 列）—— 命令行表格对齐用。"""
    return sum(2 if ord(ch) > 0x2E7F else 1 for ch in str(s))


def _pad(s: str, width: int) -> str:
    s = str(s)
    return s + " " * max(0, width - _dw(s))


def _cut(s: str, width: int) -> str:
    """按显示宽度截断（不切出半个汉字）。"""
    out, w = "", 0
    for ch in str(s):
        cw = 2 if ord(ch) > 0x2E7F else 1
        if w + cw > width:
            break
        out += ch
        w += cw
    return out


_MODE_CN = {"r": "读", "w": "写", "rw": "读写"}


def _cmd_list(a) -> int:
    items = channels()
    if a.json:
        sys.stdout.write(json.dumps(
            {"root": ROOT, "overrideFile": OVERRIDE_FILE,
             "overrides": overrides(), "channels": items},
            ensure_ascii=False, indent=2) + "\n")
        return 0
    w = (16, 32, 15, 6, 44)
    line = "-" * (sum(w) + 4)
    print("编码通道表（%d 条）    覆盖文件：%s" % (len(items), OVERRIDE_FILE))
    print(line)
    print(_pad(" 通道", w[0]) + _pad("用途", w[1]) + _pad("编码", w[2])
          + _pad("方向", w[3]) + "解码顺序")
    print(line)
    for c in items:
        print((" *" if c["overridden"] else "  ") + _pad(c["key"], w[0] - 2)
              + _pad(_cut(c["label"], w[1] - 2), w[1])
              + _pad(c["codecLabel"], w[2])
              + _pad(_MODE_CN.get(c["mode"], c["mode"]), w[3])
              + _cut(c["chain"], w[4]))
    print(line)
    print("* = 已被 config/encoding.json 覆盖（改这个文件即可覆盖，不必改代码）。")
    print("别名：" + "、".join("%s→%s" % (k, v) for k, v in sorted(ALIASES.items())[:14]) + " …")
    return 0


def _cmd_enc(a) -> int:
    c = channel_info(a.channel)
    print("%s（%s）" % (c["key"], c["label"]))
    print("  生效编码 ：%s%s" % (c["codecLabel"], "   ← 被 config/encoding.json 覆盖"
                                if c["overridden"] else ""))
    print("  策略代号 ：%s" % c["codec"])
    print("  具体编码 ：%s" % c["encoding"])
    print("  方向     ：%s" % _MODE_CN.get(c["mode"], c["mode"]))
    print("  解码顺序 ：%s" % c["chain"])
    print("  依据     ：%s" % c["note"])
    return 0


def _cmd_decode(a) -> int:
    raw = _read_input(a.path)
    text, enc = decode_ex(a.channel, raw)
    data = text.encode("utf-8", "replace")
    if a.out:
        _out(data, a.out)
    else:
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()
    sys.stderr.write("[%s] %d 字节 → %s，实际编码 %s\n"
                     % (a.channel, len(raw), len(text), enc))
    return 0


def _cmd_encode(a) -> int:
    raw = _read_input(a.path)
    text = T.decode_text(raw, T.UTF8)
    try:
        data = encode(a.channel, text)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 2
    _out(data, a.out)
    return 0


def _cmd_convert(a) -> int:
    raw = _read_input(a.path)
    text = decode(a.src, raw) if not a.as_text else raw.decode("utf-8", "replace")
    try:
        data = encode(a.dst, text)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 2
    _out(data, a.out)
    sys.stderr.write("[%s → %s] %d 字节 → %d 字节\n"
                     % (a.src, a.dst, len(raw), len(data)))
    return 0


def _cmd_read(a) -> int:
    text, enc = read(a.channel, a.path)
    sys.stdout.buffer.write(text.encode("utf-8", "replace"))
    sys.stdout.buffer.flush()
    sys.stderr.write("[%s] %s → %d 字符，实际编码 %s\n"
                     % (a.channel, a.path, len(text), enc))
    return 0


def _cmd_write(a) -> int:
    text = T.decode_text(sys.stdin.buffer.read(), T.UTF8)
    try:
        out = write(a.channel, a.path, text, a.enc)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 2
    sys.stderr.write("已写入 %s：%d 字符 / %d 字节（编码 %s）\n"
                     % (a.path, len(text), out["bytes"], out["encoding"]))
    return 0


def main(argv=None) -> int:
    import argparse
    _fix_stdio()
    p = argparse.ArgumentParser(
        prog="python -m yunyi.codec",
        description="编码通道表与统一转换接口（编译 / 调试 / 子进程 / 文件读写共用）")
    sub = p.add_subparsers(dest="cmd")

    s = sub.add_parser("list", help="列出全部编码通道（配置列表）")
    s.add_argument("--json", action="store_true", help="输出 JSON")
    s.set_defaults(fn=_cmd_list)

    s = sub.add_parser("enc", help="查某个通道实际用什么编码")
    s.add_argument("channel")
    s.set_defaults(fn=_cmd_enc)

    s = sub.add_parser("decode", help="按通道解码一段字节（省略文件=读 stdin）")
    s.add_argument("channel")
    s.add_argument("path", nargs="?", default="")
    s.add_argument("-o", "--out", default="", help="输出文件（省略=写 stdout）")
    s.set_defaults(fn=_cmd_decode)

    s = sub.add_parser("encode", help="按通道编码（输入按 UTF-8 读，省略文件=读 stdin）")
    s.add_argument("channel")
    s.add_argument("path", nargs="?", default="")
    s.add_argument("-o", "--out", default="")
    s.set_defaults(fn=_cmd_encode)

    s = sub.add_parser("convert", help="src → dst（通道名或编码名都行）")
    s.add_argument("src")
    s.add_argument("dst")
    s.add_argument("path", nargs="?", default="")
    s.add_argument("-o", "--out", default="")
    s.add_argument("--as-text", action="store_true", help="输入本身已是 UTF-8 文本")
    s.set_defaults(fn=_cmd_convert)

    s = sub.add_parser("read", help="按通道读文件并输出 UTF-8")
    s.add_argument("channel")
    s.add_argument("path")
    s.set_defaults(fn=_cmd_read)

    s = sub.add_parser("write", help="按通道写文件（从 stdin 读 UTF-8 文本）")
    s.add_argument("channel")
    s.add_argument("path")
    s.add_argument("--enc", default="", help="显式编码（探测式通道必给）")
    s.set_defaults(fn=_cmd_write)

    a = p.parse_args(argv)
    if not getattr(a, "fn", None):
        p.print_help()
        return 0
    try:
        return a.fn(a)
    except KeyError as e:
        sys.stderr.write(str(e).strip("'\"") + "\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
