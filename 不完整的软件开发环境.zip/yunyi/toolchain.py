# -*- coding: utf-8 -*-
"""工具链定位与环境设置：MinGW(g++/make)、git，支持在线下载 MinGW。"""
from __future__ import annotations
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

from . import codec

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    ROOT = os.path.dirname(os.path.abspath(sys.executable))
SETTINGS_FILE = os.path.join(ROOT, "config", "settings.json")

# 优先使用 IDE 目录内自带的工具链（tools/mingw64…），方便整个目录拷贝携带。
DEFAULT_CANDIDATES = [
    os.path.join(ROOT, "tools", "mingw64", "bin", "g++.exe"),
    os.path.join(ROOT, "tools", "mingw32", "bin", "g++.exe"),
    r"C:\mingw64\bin\g++.exe",
    r"C:\MinGW\bin\g++.exe",
    r"D:\mingw64\bin\g++.exe",
]

# 默认值直接指向 tools 目录（「留空=自动检测」的兜底逻辑不变，但设置项不再空着）：
# 路径不存在时各 find_* 会自动回退到探测（tools 其它位置 → 系统），不会因为写了
# 默认路径而误报；IDE 目录整体挪动后启动时的 autofill 会重写为新的实际路径。
TOOLS_GIT_GIT = os.path.join(ROOT, "tools", "git", "cmd", "git.exe")
TOOLS_PYTHON_EXE = os.path.join(ROOT, "tools", "python", "bin", "python3.14.exe")
TOOLS_PIP_EXE = os.path.join(ROOT, "tools", "python", "Scripts", "pip.exe")
TOOLS_GXX = os.path.join(ROOT, "tools", "mingw64", "bin", "g++.exe")
TOOLS_MAKE = os.path.join(ROOT, "tools", "mingw64", "bin", "mingw32-make.exe")

DEFAULT_SETTINGS = {
    "gxx": TOOLS_GXX,      # 默认 tools/mingw64（x86 架构时 find_gxx 仍优先 mingw32）
    "make": TOOLS_MAKE,    # 默认 tools/mingw64（mingw32-make 对 x86 工程同样可用）
    "git": TOOLS_GIT_GIT,  # 默认 tools/git（PortableGit，与自带 bash 同包）
    "python": TOOLS_PYTHON_EXE,  # 默认自带 tools/python
    "pip": TOOLS_PIP_EXE,  # 默认自带 tools/python/Scripts（随自带 Python 使用）
    "bash": os.path.join(ROOT, "tools", "git", "bin", "bash.exe"),  # 默认 PortableGit 里的 bash
    "node": os.path.join(ROOT, "tools", "node", "node.exe"),  # 智能体 PTC 的 TS 运行时
    "qt": os.path.join(ROOT, "tools", "Qt", "ucrt64", "bin"),
    "qtx86": os.path.join(ROOT, "tools", "Qtx86", "ucrt32", "bin"),
    "sciter": os.path.join(ROOT, "tools", "sciter", "bin"),
    "sciterx86": os.path.join(ROOT, "tools", "sciterx86", "yysciter_x86.dll"),
    "zstd": "",            # 解压目录带版本号（zstd-v*），启动 autofill 会写入实际路径；留空=自动找
    "arch": "x64",         # 目标架构：x64 / x86（工具栏或环境设置选择）
    "subsystem": "console",  # 程序类型：window（窗口程序，链接 -mwindows）/ console（控制台程序）
    "mode": "debug",       # 编译模式：debug（调试版 -O0 -g）/ release（发布版 -O2）
    "workspace": "工作区",  # 工程总目录：相对 IDE 根目录（ROOT），见下方 _PATH_KEYS；
                           # 整个 IDE 目录复制到别台机器 / 别的盘符后照样能用
    # tools 四件套（git / python / mingw32 / mingw64）的下载基地址：
    # 实际下载 <downloadUrl>/<包名>.zip，即 git.zip / python.zip / mingw32.zip / mingw64.zip
    "downloadUrl": "https://yunyi.24992499.xyz/",
    "port": 8405,          # IDE 服务端口（环境设置中可修改，保存后服务自动切换）
    # AI 智能体后端（逻辑名，模块映射见 server/server.py 的 _AI_MODULES）：
    #   hope2 = 纯 Python 智能体，代码在 server\The_future_is_promising\（只用标准库、
    #           无需 Node / node_modules）。
    #   旧值 "hope"（Node 版 dsh）对应的 hope\ 目录已删除；历史配置里残留的
    #   "hope" 认不到时会自动回落 hope2，不用手工改这里。
    # 环境变量 YUNYI_AI_BACKEND 优先于这里。
    "aiBackend": "hope2",
    # 界面语言：config 目录下语言包（*.lng）的文件主名（如 zh_cn / en_us）。
    # 语言包格式见 config\zh_cn.lng 文件头说明。
    "language": "zh_cn",
}


# 这些键是「工具链 / 目录路径」：在配置里以相对 IDE 根目录（ROOT）的形式存储，
# 读取时再解析成绝对路径（相对 ROOT），这样整个 IDE 目录挪到别的机器/路径后
# 不会因写死绝对路径而失效。
# 注意 workspace 也在其中：用户在「环境设置」里挑的工作区若落在 IDE 目录内，
# 落盘时会自动压回相对路径（落在目录外则保留绝对路径 —— 那种目录本来就不跟着搬家）。
_PATH_KEYS = ("gxx", "make", "git", "python", "pip", "bash", "node",
              "qt", "qtx86", "sciter", "sciterx86", "zstd", "workspace")


def _resolve_path(p: str) -> str:
    """把配置里相对 ROOT 的路径解析成绝对路径；已是绝对（如用户指定的系统路径）或空串则原样返回。"""
    p = (p or "").strip()
    if not p or os.path.isabs(p):
        return p
    return os.path.normpath(os.path.join(ROOT, p))


def _rel_path(p: str) -> str:
    """写回配置时，把 ROOT 下的绝对路径转回相对形式；不属于 ROOT 或空串则原样返回。"""
    p = (p or "").strip()
    if not p or not os.path.isabs(p):
        return p
    try:
        rp = os.path.relpath(p, ROOT)
    except ValueError:
        return p
    # 仅当确实落在 ROOT 之内才转相对（避免跨盘符 relpath 仍返回绝对的情况）
    if os.path.isabs(rp) or rp.startswith(".."):
        return p
    return rp.replace("\\", "/")


def _load_raw_settings() -> dict:
    try:
        # utf-8-sig：容忍手工编辑 / 其他工具写入的 BOM
        with codec.open_text("config", SETTINGS_FILE, "r") as fp:
            data = json.load(fp)
        s = dict(DEFAULT_SETTINGS)
        s.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
        return s
    except Exception:
        return dict(DEFAULT_SETTINGS)


def _load_settings() -> dict:
    s = _load_raw_settings()
    # 工具链路径：相对 ROOT 的相对路径 → 绝对路径（保证子进程调用不丢路径、isfile 判定正确）
    for k in _PATH_KEYS:
        if s.get(k):
            s[k] = _resolve_path(s[k])
    return s


def save_settings(updates: dict) -> dict:
    s = _load_raw_settings()
    s.update(updates)
    # 写回时把 ROOT 下的绝对路径转回相对，保持配置文件可移植（无写死绝对路径）
    for k in _PATH_KEYS:
        if s.get(k):
            s[k] = _rel_path(s[k])
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    with codec.open_text("config", SETTINGS_FILE, "w") as fp:
        json.dump(s, fp, ensure_ascii=False, indent=2)
    return s


def get_settings() -> dict:
    return _load_settings()


def _find(settings_key: str, candidates) -> str:
    s = _load_settings()
    p = (s.get(settings_key) or "").strip()
    if p and os.path.isfile(p):
        return p
    for c in candidates:
        if os.path.isfile(c):
            return c
    found = shutil.which(os.path.basename(candidates[0]) if candidates else None)
    if found:
        return found
    return ""


def get_arch() -> str:
    """目标体系结构：x64（默认）/ x86。由工具栏或环境设置选择，保存在 settings.json。"""
    a = (get_settings().get("arch") or "x64").strip().lower()
    return a if a in ("x86", "x64") else "x64"


def get_subsystem() -> str:
    """程序类型：window（窗口程序，-mwindows，不弹命令行窗口）/ console（控制台程序，默认）
    / dll（DLL 程序，-shared，生成动态库）。"""
    v = (get_settings().get("subsystem") or "console").strip().lower()
    return v if v in ("console", "window", "dll") else "console"


def get_mode() -> str:
    """编译模式：debug（调试版 -O0 -g，默认）/ release（发布版 -O2）。
    工程打开时会把该工程的模式同步到这里；无工程时用它作为新工程的默认模式。"""
    v = (get_settings().get("mode") or "debug").strip().lower()
    return v if v in ("debug", "release") else "debug"


def _arch_tool_dirs() -> list:
    """内置 MinGW 的 bin 目录，按所选架构排序（首选在前，回退在后）。"""
    m64 = os.path.join(ROOT, "tools", "mingw64", "bin")
    m32 = os.path.join(ROOT, "tools", "mingw32", "bin")
    return [m32, m64] if get_arch() == "x86" else [m64, m32]


def find_gxx() -> str:
    # CI / 命令行可用环境变量 YUNYI_GXX 指定编译器（交叉编译场景）
    env_gxx = os.environ.get("YUNYI_GXX", "").strip()
    if env_gxx and (os.path.isfile(env_gxx) or os.path.basename(env_gxx) == env_gxx):
        which = shutil.which(env_gxx)
        if which:
            return which
    # 架构优先：按选择（x86/x64）使用对应的内置编译器
    for d in _arch_tool_dirs():
        p = os.path.join(d, "g++.exe")
        if os.path.isfile(p):
            return p
    return _find("gxx", DEFAULT_CANDIDATES)


def find_make() -> str:
    base = os.path.dirname(find_gxx())
    return _find("make", [os.path.join(base, "mingw32-make.exe"),
                          os.path.join(base, "make.exe")])


def find_python() -> str:
    """定位 Python 解释器：设置中的路径 → IDE 自带（tools/python）→ 当前解释器 → 系统 PATH。"""
    s = _load_settings()
    p = (s.get("python") or "").strip()
    if p and os.path.isfile(p):
        return p
    bundled = os.path.join(ROOT, "tools", "python", "bin", "python3.14.exe")
    if os.path.isfile(bundled):
        return bundled
    if sys.executable and os.path.isfile(sys.executable):
        return sys.executable
    return shutil.which("python") or ""


def find_git() -> str:
    """定位 git：设置中的路径 → IDE 自带（tools/git，与自带 bash 同一个 PortableGit）→ 系统 PATH。"""
    s = _load_settings()
    g = (s.get("git") or "").strip()
    if g and os.path.isfile(g):
        return g
    for c in (os.path.join(TOOLS_DIR, "git", "cmd", "git.exe"),
              os.path.join(TOOLS_DIR, "git", "bin", "git.exe")):
        if os.path.isfile(c):
            return c
    # PATH 兜底：设置里是具体路径（默认值/手动指定）但文件不存在时，
    # 用裸名再查一次 PATH；设置里本来就是裸名（如 "git"）则直接查。
    found = shutil.which(g) if (g and os.sep not in g and "/" not in g) else shutil.which("git")
    return found or ""


# ---------------- 绿色版 bash ----------------
# IDE 自带的 PortableGit（tools/git）里本来就带 Bash + 一整套 coreutils，不必再单独下载。
# 「环境设置 / 工具链」的 bash 路径按这个顺序定位：
#   1. tools 子目录下存在 bash  → 用 tools 里的（跟着 IDE 一起拷贝，不会失效）
#   2. tools 里没有            → 检查系统（常见安装位置 → PATH）
#   3. 两条都没有              → 留空
TOOLS_DIR = os.path.join(ROOT, "tools")

# tools 下的固定候选（命中率最高，先查这几个，避免每次都遍历整个 tools）
BUNDLED_BASH_CANDIDATES = [
    os.path.join(TOOLS_DIR, "git", "bin", "bash.exe"),
    os.path.join(TOOLS_DIR, "git", "usr", "bin", "bash.exe"),
    os.path.join(TOOLS_DIR, "bash", "bin", "bash.exe"),        # 若单独放了 bash 包
    os.path.join(TOOLS_DIR, "bash", "usr", "bin", "bash.exe"),
]

# 系统里常见的 bash 安装位置（tools 里没有时才查）
SYSTEM_BASH_CANDIDATES = [
    r"C:\Program Files\Git\bin\bash.exe",
    r"C:\Program Files (x86)\Git\bin\bash.exe",
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Git", "bin", "bash.exe"),
    r"C:\cygwin64\bin\bash.exe",
    r"C:\cygwin\bin\bash.exe",
    r"C:\msys64\usr\bin\bash.exe",
]

BASH_SOURCE_LABEL = {
    "tools": "IDE 自带（tools）",
    "system": "系统",
    "setting": "设置项指定",
    "": "未找到",
}


def _tools_bash_candidates() -> list:
    """tools/ 下所有可能的 bash 位置：固定候选 + 各级包目录下的 bin。

    只看 tools/<包>/bin、tools/<包>/usr/bin，以及 tools/<包>/<子目录>/bin（足够覆盖
    PortableGit / MinGit / MSYS2 的排布），**不做全量递归** —— tools 下有数万个文件。"""
    out = list(BUNDLED_BASH_CANDIDATES)
    try:
        packs = [e.path for e in os.scandir(TOOLS_DIR) if e.is_dir()]
    except OSError:
        packs = []
    for d in packs:
        out.append(os.path.join(d, "bin", "bash.exe"))
        out.append(os.path.join(d, "usr", "bin", "bash.exe"))
        try:
            subs = [e.path for e in os.scandir(d) if e.is_dir()]
        except OSError:
            subs = []
        for sd in subs:
            out.append(os.path.join(sd, "bin", "bash.exe"))
            out.append(os.path.join(sd, "usr", "bin", "bash.exe"))
    seen, uniq = set(), []          # 去重且保持顺序
    for p in out:
        k = os.path.normcase(p)
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


def find_bash_in_tools() -> str:
    """在 IDE 的 tools 子目录里找 bash：找到返回路径，否则返回空串。"""
    for c in _tools_bash_candidates():
        if os.path.isfile(c):
            return c
    return ""


def find_bash_system() -> str:
    """系统里的 bash：常见安装位置 → 系统 PATH。"""
    for c in SYSTEM_BASH_CANDIDATES:
        if c and os.path.isfile(c):
            return c
    return shutil.which("bash") or ""


def _norm_p(p: str) -> str:
    """把路径统一成同一种写法（Windows 下正斜杠 → 反斜杠），空值保持空串。

    settings.json 里存的是 normpath 过的反斜杠路径，而 tools / 系统的候选是按
    POSIX 风格拼的（正斜杠）—— 同一个文件会因此被写成两种字符串，「来源」
    判得对、路径却对不上。对外汇报前统一一次，免得各处比较又要各自 normcase。"""
    return os.path.normpath(p) if p else ""


def bash_report() -> dict:
    """bash 定位报告：路径 + 来源（tools / 系统 / 设置项）+ 各自的候选。

    「环境设置」里的 bash 路径输入框就按这个结果自动填入：
    tools 子目录下有就用 tools 里的；没有才去检查系统。
    三个路径都经 _norm_p 统一写法，可直接做字符串比较。"""
    tools = _norm_p(find_bash_in_tools())
    system = _norm_p(find_bash_system())
    p = _norm_p((_load_settings().get("bash") or "").strip())
    if p and os.path.isfile(p):
        # 来源按实际归属标注：自动填进去的就是 tools / 系统的路径，别标成「设置项指定」
        if tools and os.path.normcase(p) == os.path.normcase(tools):
            src = "tools"
        elif system and os.path.normcase(p) == os.path.normcase(system):
            src = "system"
        else:
            src = "setting"
        path = p
    elif tools:
        src, path = "tools", tools
    elif system:
        src, path = "system", system
    else:
        src, path = "", ""
    return {"path": path, "source": src, "label": BASH_SOURCE_LABEL.get(src, src),
            "tools": tools, "system": system}


def find_bash() -> str:
    """定位 bash：设置里的路径 → IDE 自带（tools 子目录）→ 系统。"""
    return bash_report()["path"]


def bash_autofill() -> dict:
    """把 bash 路径自动填进设置项（环境设置里那个输入框的默认值）。

    规则：
      1. tools 子目录下存在 bash → 填入 tools 里的路径；
      2. tools 里没有 → 检查系统，有就填入系统的路径；
      3. 两条都没有 → 保持空（界面上显示「未找到」）；
      4. 设置项里已经是有效路径 → 不覆盖（用户显式指定优先）；
         但若存的是「系统 bash」而 tools 下后来有了自带 bash，则自动升级为自带。
    返回 bash_report() 的结果（多一个 changed 字段表示是否改写了设置）。"""
    cur = (_load_settings().get("bash") or "").strip()
    rep = bash_report()
    tools, system = rep["tools"], rep["system"]
    if cur and os.path.isfile(cur):
        if (tools and os.path.normcase(cur) != os.path.normcase(tools)
                and os.path.normcase(cur) == os.path.normcase(system or "")):
            save_settings({"bash": tools})          # 系统 bash → 升级为自带
            return dict(bash_report(), changed=True)
        return dict(rep, changed=False)
    target = tools or system
    if not target:
        return dict(rep, changed=False)
    save_settings({"bash": target})
    return dict(bash_report(), changed=True)


def bash_env() -> dict:
    """跑 bash 时用的子进程环境。

    刻意**不**把 Git 的 usr/bin 加进全局 PATH：那会让 GNU 的 find / sort / more
    顶掉 Windows 同名命令，可能弄坏 Makefile 和批处理。bash 启动时会自己带上
    /usr/bin（ls / grep / sed / awk 都可用），这里只补两个必要变量。
    """
    env = runtime_env()
    b = find_bash()
    if b:
        env["PATH"] = os.path.dirname(b) + os.pathsep + env.get("PATH", "")
        env["CHERE_INVOKING"] = "1"      # 让 Git Bash 保持当前工作目录
    return env


def _ver(exe: str, arg: str = "--version") -> str:
    try:
        r = subprocess.run([exe, arg], capture_output=True, timeout=15,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        text = (r.stdout or b"") + (r.stderr or b"")
        # 版本号可能被工具按本机代码页输出（老版本 g++ / make），走 compiler 通道兜底，
        # 不再硬编码 utf-8+replace —— 那样中文环境下会变成一片看不出是乱码的乱码。
        line = codec.decode("compiler", text).strip()
        return line.splitlines()[0] if line else ""
    except Exception:
        return ""


# ---------------- Node（智能体 PTC 的 TypeScript 后端运行时） ----------------
NODE_SOURCE_LABEL = {"tools": "IDE 自带（tools/node）", "system": "系统",
                     "setting": "设置里手动指定的路径", "": "未找到"}
_SYSTEM_NODE_CANDIDATES = (
    r"C:\Program Files\nodejs\node.exe",
    r"C:\Program Files (x86)\nodejs\node.exe",
)


def node_report() -> dict:
    """node 定位报告：设置项 → IDE 自带（tools/node/node.exe）→ 系统。

    与 bash_report 同款结构：路径 + 来源（tools / system / setting）+ 各候选。
    「环境设置」里的 node 路径输入框按这个结果自动填入；默认地址就是 tools 目录下的
    node（智能体 PTC 的 TypeScript 后端用它跑模型写的程序）。"""
    tools = _norm_p(os.path.join(TOOLS_DIR, "node", "node.exe"))
    if not os.path.isfile(tools):
        tools = ""
    system = _norm_p(next((c for c in _SYSTEM_NODE_CANDIDATES if os.path.isfile(c)), "")) \
        or _norm_p(shutil.which("node") or "")
    p = _norm_p((_load_settings().get("node") or "").strip())
    if p and os.path.isfile(p):
        if tools and os.path.normcase(p) == os.path.normcase(tools):
            src = "tools"
        elif system and os.path.normcase(p) == os.path.normcase(system):
            src = "system"
        else:
            src = "setting"
        path = p
    elif tools:
        src, path = "tools", tools
    elif system:
        src, path = "system", system
    else:
        src, path = "", ""
    return {"path": path, "source": src, "label": NODE_SOURCE_LABEL.get(src, src),
            "tools": tools, "system": system}


def node_autofill() -> dict:
    """把 node 路径自动填进设置项（环境设置里 node 输入框的默认值）。

    规则与 bash_autofill 一致：自带优先、不覆盖已手动指定的有效路径。"""
    cur = (_load_settings().get("node") or "").strip()
    rep = node_report()
    target = rep["tools"] or rep["system"]
    if cur and os.path.isfile(cur):
        return dict(rep, changed=False)
    if not target:
        return dict(rep, changed=False)
    save_settings({"node": target})
    return dict(node_report(), changed=True)


# ---------------- pip（Python 包管理；住在自带 Python 的 Scripts 下） ----------------
PIP_SOURCE_LABEL = {"tools": "IDE 自带（tools/python/Scripts）", "system": "系统",
                    "setting": "设置里手动指定的路径", "": "未找到"}

# `pip --version` 的典型输出：
#   pip 26.2.1 from C:\...\Python315-32\Lib\site-packages\pip (python 3.15)
_PIP_VER_RE = re.compile(r"pip\s+([^\s]+)\s+from\s+(.+?)\s+\(python\s+([\d.]+)\)", re.I)


def find_pip() -> str:
    """定位 pip：设置中的路径 → IDE 自带（tools/python/Scripts）→ 系统 PATH。"""
    return pip_report()["path"]


def _pip_probe(path: str) -> dict:
    """跑一次 `pip --version`，拆出「版本 / 装包位置 / 归属的 Python」。

    **归属**才是要害：pip.exe 是个写死了目标解释器的壳。把别的 Python 的
    Scripts\\pip.exe 拷进 tools\\python\\Scripts，它照样会往**那个** Python 的
    site-packages 里装包 —— 看起来「pip 能跑」，装的却不是你想要的解释器。
    """
    out = {"version": "", "site": "", "python": "", "raw": ""}
    if not (path and os.path.isfile(path)):
        return out
    raw = _ver(path, "--version")
    out["raw"] = raw
    if not raw:
        return out
    m = _PIP_VER_RE.search(raw)
    if m:
        out["version"] = m.group(1)
        out["site"] = m.group(2).strip()
        out["python"] = m.group(3)
    else:
        m2 = re.search(r"pip\s+([^\s]+)", raw, re.I)
        if m2:
            out["version"] = m2.group(1)
    return out


def python_module_pip() -> dict:
    """自带 Python 能不能 `-m pip`（不依赖 Scripts 下那个壳）。

    `python -m pip` 是最稳的用法：一定用**这个**解释器自己、装进它自己的
    site-packages。自带 Python 没带 pip 模块时这里会失败，并把原因带回来。
    """
    py = find_python()
    if not py:
        return {"ok": False, "version": "", "note": "未找到 Python"}
    try:
        r = subprocess.run([py, "-m", "pip", "--version"], capture_output=True,
                           timeout=30,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        return {"ok": False, "version": "", "note": "执行失败：%s" % e}
    text = codec.decode("compiler", (r.stdout or b"") + (r.stderr or b"")).strip()
    if r.returncode != 0:
        first = text.splitlines()[0] if text else "退出码 %s" % r.returncode
        return {"ok": False, "version": "", "note": first}
    m = re.search(r"pip\s+([^\s]+)", text, re.I)
    return {"ok": True, "version": m.group(1) if m else "", "note": ""}


# pip 探测要跑 3 个子进程（pip --version / python --version / python -m pip --version），
# 而 env_report 会被「切换架构 / 模式」这类接口反复调用 —— 按 (pip 路径, Python 路径)
# 缓存 15 秒，免得每次刷新设置面板或工具栏都要多等 0.7 秒。用户改了路径就是新键，立即重探。
_PIP_CACHE: dict = {}
_PIP_TTL = 15.0


def _pip_probe_all(path: str, bundled: str) -> tuple:
    """(probe, module, bundledVer)，带 15 秒缓存（键 = pip 路径 + Python 路径）。"""
    key = (path or "", bundled or "")
    now = time.time()
    hit = _PIP_CACHE.get(key)
    if hit and (now - hit[0]) < _PIP_TTL:
        return hit[1], hit[2], hit[3]
    probe = _pip_probe(path)
    mod = python_module_pip()
    bver = _ver(bundled, "--version").replace("Python", "").strip() if bundled else ""
    _PIP_CACHE.clear()                 # 只留最近一次，避免键无限增长
    _PIP_CACHE[key] = (now, probe, mod, bver)
    return probe, mod, bver


def pip_report() -> dict:
    """pip 定位报告：路径 + 来源 + **归属的 Python** + 与自带 Python 是否一致。

    「环境设置」里 Python 路径下方那一行就按这个结果填。它一次回答三件事：
      1. 找到的 pip 是哪个（版本）；
      2. 它往哪个 Python 里装包（归属 —— 最容易踩的坑）；
      3. 自带 Python 自己能不能 `-m pip`（不依赖 Scripts 下那个壳）。
    """
    tools = _norm_p(next((c for c in (
        os.path.join(TOOLS_DIR, "python", "Scripts", "pip.exe"),
        os.path.join(TOOLS_DIR, "python", "Scripts", "pip3.exe"),
    ) if os.path.isfile(c)), ""))
    system = _norm_p(shutil.which("pip") or shutil.which("pip3") or "")
    p = _norm_p((_load_settings().get("pip") or "").strip())
    if p and os.path.isfile(p):
        if tools and os.path.normcase(p) == os.path.normcase(tools):
            src = "tools"
        elif system and os.path.normcase(p) == os.path.normcase(system):
            src = "system"
        else:
            src = "setting"
        path = p
    elif tools:
        src, path = "tools", tools
    elif system:
        src, path = "system", system
    else:
        src, path = "", ""

    bundled = find_python()
    probe, mod, bundled_ver = _pip_probe_all(path, bundled)
    # 归属判断**不能只比版本号**：系统里常装着另一个同版本的 Python（比如系统的
    # 3.14 与 IDE 自带的 3.14.6），版本串前缀相同，却完全是两个解释器 ——
    # 只比版本会误报「一致」。直接看 pip 报出的 site-packages 是否落在自带 Python
    # 的安装目录下：这才是「装包会不会进自带 Python」的直接答案。
    py_root = _norm_p(os.path.dirname(os.path.dirname(bundled))) if bundled else ""
    matched = bool(probe["site"] and py_root and os.path.normcase(
        probe["site"]).startswith(os.path.normcase(py_root) + os.sep))

    if not path:
        note = ("未找到 pip。把 pip.exe 放进 tools\\python\\Scripts 即可"
                "（或在上面指定路径）——注意它必须属于 IDE 自带的那个 Python。")
    elif not probe["version"]:
        note = "找到了 %s，但它不是可用的 pip（`pip --version` 没有正常输出）。" % path
    elif matched:
        note = ("pip %s，装包位置 %s —— 就在 IDE 自带 Python（%s，%s）里面，可直接用。"
                % (probe["version"], probe["site"] or "?", py_root or "?",
                   bundled_ver or "?"))
    else:
        note = ("pip %s 装包会落到 %s，而 IDE 自带 Python 装在 %s（%s）—— 不是同一个"
                "解释器：用它装包不会进自带 Python。要装进自带 Python 请用 python -m pip。"
                % (probe["version"], probe["site"] or "?", py_root or "?",
                   bundled_ver or "?"))
    return {"path": path, "source": src, "label": PIP_SOURCE_LABEL.get(src, src),
            "tools": tools, "system": system,
            "version": probe["version"], "python": probe["python"], "site": probe["site"],
            "bundled": bundled, "bundledVer": bundled_ver,
            "matched": matched, "moduleOk": mod["ok"], "moduleNote": mod["note"],
            "note": note}


def pip_autofill() -> dict:
    """把 pip 路径自动填进设置项（环境设置里 pip 输入框的默认值）。

    规则与 node_autofill 一致：自带优先、不覆盖已手动指定的有效路径。"""
    cur = (_load_settings().get("pip") or "").strip()
    rep = pip_report()
    target = rep["tools"] or rep["system"]
    if cur and os.path.isfile(cur):
        return dict(rep, changed=False)
    if not target:
        return dict(rep, changed=False)
    save_settings({"pip": target})
    return dict(pip_report(), changed=True)


# ---------------- tools 目录下的运行库包（只做本地存在性检查，不联网） ----------------
# 每项：(env_report 字段名, 展示名, 哨兵路径)。哨兵存在 = 包完整可用。
# zstd 特殊：解压出来是带版本号的目录（zstd-v1.5.6-win64），用 glob 找 zstd.exe。
def _zstd_exe() -> str:
    base = os.path.join(TOOLS_DIR, "zstd")
    try:
        for name in sorted(os.listdir(base)):
            exe = os.path.join(base, name, "zstd.exe")
            if name.startswith("zstd-") and os.path.isfile(exe):
                return exe
    except OSError:
        pass
    return ""


def tools_packages_report() -> dict:
    """Qt / Qtx86 / sciter / sciterx86 / zstd 五个运行库包的本地检查。

    路径来源：设置里手动指定的有效路径优先 → tools 目录默认哨兵。
    只做本地存在性检查（**不联网、不跑版本命令**——这些都是解压即用的运行库）。
    值为实际使用的路径，空串 = 缺失。"""
    sentinels = (
        ("qt", os.path.join(TOOLS_DIR, "Qt", "ucrt64", "bin")),
        ("qtx86", os.path.join(TOOLS_DIR, "Qtx86", "ucrt32", "bin")),
        ("sciter", os.path.join(TOOLS_DIR, "sciter", "bin")),
        ("sciterx86", os.path.join(TOOLS_DIR, "sciterx86", "yysciter_x86.dll")),
    )
    cfg = _load_settings()
    out = {}
    for key, sent in sentinels:
        custom = _norm_p((cfg.get(key) or "").strip())
        if custom and os.path.exists(custom):
            out[key] = custom
        else:
            out[key] = sent if os.path.exists(sent) else ""
    # zstd：设置项优先（直接指向 zstd.exe），否则在 tools/zstd 的版本目录里找
    zcustom = _norm_p((cfg.get("zstd") or "").strip())
    z = _zstd_exe()
    if zcustom and os.path.isfile(zcustom):
        z = zcustom
    elif zcustom and os.path.isdir(zcustom):
        cand = os.path.join(zcustom, "zstd.exe")
        if os.path.isfile(cand):
            z = cand
    out["zstd"] = z
    # 版本号从目录名提取（zstd-v1.5.6-win64 → v1.5.6），其余包不标版本
    m = re.search(r"zstd-v([\d.]+)", z) if z else None
    out["zstdVer"] = ("v" + m.group(1)) if m else ""
    return out


def packages_autofill() -> dict:
    """把五个运行库包的默认路径自动填进设置项（环境设置里对应输入框的默认值）。

    规则与 bash_autofill 一致：tools 下找得到就填入；已手动指定过的有效路径
    不覆盖；找不到保持空。返回 {字段名: 是否新填入}。"""
    pkgs = tools_packages_report()
    cfg = _load_settings()
    upd = {}
    for key in ("qt", "qtx86", "sciter", "sciterx86", "zstd"):
        cur = (cfg.get(key) or "").strip()
        found = pkgs.get(key) or ""
        if not cur and found:
            upd[key] = found
    if upd:
        save_settings(upd)
    return upd


def core_autofill() -> dict:
    """把 g++ / make / git / Python 的实际路径写进设置项（输入框不再空着）。

    规则：设置项已是有效文件路径 → 不覆盖（用户显式指定优先）；
    留空或指向不存在的文件 → 用 find_* 探测到的实际路径（tools 优先）写入。
    返回 {字段名: 写入的路径}（无改动时为空表）。"""
    cfg = _load_settings()
    upd = {}
    for key in ("gxx", "make", "python"):
        cur = (cfg.get(key) or "").strip()
        if cur and os.path.isfile(cur):
            continue
        found = {"gxx": find_gxx, "make": find_make, "python": find_python}[key]()
        if found:
            upd[key] = _norm_p(found)
    # git：指向的文件不存在（含默认占位）→ 写成探测到的具体路径
    cur = (cfg.get("git") or "").strip()
    if not (cur and os.path.isfile(cur)):
        g = find_git()
        if g:
            upd["git"] = _norm_p(g)
    if upd:
        save_settings(upd)
    return upd


BUNDLED_PYTHON_BIN = os.path.join(ROOT, "tools", "python", "bin")


def runtime_env() -> dict:
    """子进程环境：把自带 Python（tools/python/bin）加进 PATH，并**全链路统一 UTF-8**。

    为什么必须显式设 PYTHONUTF8 / PYTHONIOENCODING：
      · Windows 上 Python 默认按本机代码页（中文 = GBK）读写文件与标准流 —— 实测自带
        Python 子进程 `sys.stdout.encoding == 'gbk'`，中文输出若按 UTF-8 解码会变替换符；
      · 设 PYTHONUTF8=1 后子进程进入 UTF-8 模式：`open()` 不带 encoding 也是 UTF-8，
        标准流也是 UTF-8，与「全工程文本都是 UTF-8」的约定一致；
      · 这两个变量会被子进程继续继承，所以整条调用链（编译器脚本 → 用户脚本 →
        智能体工具 → 被编译程序）都是 UTF-8。
    （g++ / make 等非 Python 程序忽略这两个变量；make 读 Makefile 仍按 ANSI 代码页，
      因此生成的 Makefile 保持 GBK —— 依据见 yunyi/textio.py 的模块说明。）"""
    env = dict(os.environ)
    if os.path.isdir(BUNDLED_PYTHON_BIN):
        env["PATH"] = BUNDLED_PYTHON_BIN + os.pathsep + env.get("PATH", "")
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


# ---------------------------------------------------------------------------
# dsh 沙箱兼容：智能体（dsh）在 Windows 上用「受限令牌」沙箱执行命令，此时
#   ① 带 CREATE_NO_WINDOW / CREATE_NEW_CONSOLE 的子进程会在 DLL 初始化期间以
#      0xC0000142 死亡（正是「应用程序无法正常启动(0xc0000142)」弹窗的来源）；
#   ② 创建管道捕获输出会被拒绝（CreatePipe → WinError 5 拒绝访问）。
# IDE 自己点「编译 / 运行 / 测试」走的是 IDE 服务进程（不在沙箱里），一切正常；
# 只有智能体在自己沙箱里跑 yunyi_cli / builder 时才会踩中。对策：run() 一旦
# 识别出这两种特征，记住并改用「继承宿主控制台 + 输出落临时文件再读回」。
#   临时文件用的是沙箱重写过的 TMP/TEMP（dsh 只授权这个私有目录可写）。
_SANDBOX_MODE = False


def _run_sandboxed(cmd, cwd, timeout, env=None, detached=True):
    """受限令牌沙箱下的执行：不用管道捕获（CreatePipe 被拒），输出落临时文件再读回。

    detached=True（默认）用 DETACHED_PROCESS：子进程**不关联任何控制台** ——
      · 避开沙箱里 CREATE_NO_WINDOW / CREATE_NEW_CONSOLE 的 0xC0000142；
      · 也不继承宿主控制台：宿主若是 65001（UTF-8）代码页，MinGW 工具链的
        中文路径 argv 会损坏（ld 报 cannot open output file … No such file or
        directory，路径里的中文变成 ?）；无控制台时 argv 走系统 ANSI 代码页，中文正常。
    """
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) if (detached and os.name == "nt") else 0
    paths = []
    try:
        mk = [(tempfile.mkstemp(prefix="yyrun", suffix=".txt")) for _ in range(2)]
        paths = [p for _, p in mk]
        for fd, _ in mk:
            os.close(fd)
        with open(paths[0], "wb") as fo, open(paths[1], "wb") as fe:
            r = subprocess.run(cmd, cwd=cwd, timeout=timeout, env=env,
                               stdin=subprocess.DEVNULL, stdout=fo, stderr=fe,
                               creationflags=flags)
        with open(paths[0], "rb") as f:
            out = f.read()
        with open(paths[1], "rb") as f:
            err = f.read()
        return r.returncode, out, err
    except subprocess.TimeoutExpired:
        return -9, b"", "编译超时\n".encode("utf-8")
    except Exception as e:
        return -1, b"", str(e).encode("utf-8", "replace")
    finally:
        for p in paths:
            try:
                os.remove(p)
            except OSError:
                pass


def _run_sandbox_fallback(cmd, cwd, timeout, env):
    """沙箱降级：先 DETACHED_PROCESS；若仍以 0xC0000142 死亡（沙箱拦得比文档更宽），
    最后退到「继承宿主控制台」（中文路径工程在这种宿主下可能编码损坏，但聊胜于无）。"""
    rc, out, err = _run_sandboxed(cmd, cwd, timeout, env, detached=True)
    if rc == 0xC0000142:
        rc, out, err = _run_sandboxed(cmd, cwd, timeout, env, detached=False)
    return rc, out, err


def run(cmd, cwd=None, timeout=180, env_extra=None):
    """运行外部命令，返回 (returncode, stdout, stderr)。"""
    global _SANDBOX_MODE
    env = runtime_env()
    env["PYTHONIOENCODING"] = "utf-8"
    if env_extra:
        env.update(env_extra)
    if _SANDBOX_MODE:
        return _run_sandbox_fallback(cmd, cwd, timeout, env)
    cr = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        r = subprocess.run(cmd, capture_output=True, cwd=cwd, timeout=timeout,
                           env=env, creationflags=cr)
    except PermissionError:
        _SANDBOX_MODE = True              # 管道创建被拒 → 受限令牌沙箱，降级执行
        return _run_sandbox_fallback(cmd, cwd, timeout, env)
    except subprocess.TimeoutExpired:
        return -9, b"", "编译超时\n".encode("utf-8")
    except Exception as e:
        return -1, b"", str(e).encode("utf-8", "replace")
    if r.returncode == 0xC0000142:        # DLL 初始化失败：沙箱里 CREATE_NO_WINDOW 必死
        _SANDBOX_MODE = True
        return _run_sandbox_fallback(cmd, cwd, timeout, env)
    return r.returncode, r.stdout, r.stderr


def kill_locked_process(path: str, timeout: float = 3.0) -> str:
    """结束正在占用/运行指定文件的进程（Windows）。

    场景：编译输出的 exe/dll 正被之前「运行/测试」留下的进程占用时，
    链接器写入会报 Permission denied。编译前调用本函数清理。

    实现：taskkill /F /T /IM <文件名>——按镜像名结束（含子进程）。
    按文件名匹配是因为输出文件名即进程镜像名，且该名字只会在
    本工程构建产物中出现，不会误伤系统进程。

    返回值：结束成功时返回提示文字（用于编译日志），无需处理时返回 ""。
    """
    if not path or not os.path.exists(path) or os.name != "nt":
        return ""
    name = os.path.basename(path)
    # 短暂尝试独占打开：能打开说明没有进程锁定，无需清理
    try:
        with open(path, "ab"):
            return ""
    except OSError:
        pass
    # 被占用 → taskkill 按镜像名结束（/T 连带子进程树）
    cr = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        r = subprocess.run(["taskkill", "/F", "/T", "/IM", name],
                           capture_output=True, timeout=timeout,
                           creationflags=cr)
        ok = r.returncode == 0
        # 系统工具消息按 ANSI 代码页（原先硬编码 gbk：非中文系统上会乱码）
        detail = codec.decode("taskkill", r.stdout or r.stderr).strip()
    except PermissionError:
        # 沙箱里管道被拒 → 降级执行（同 run() 的对策）
        ok, detail2 = _run_sandboxed(["taskkill", "/F", "/T", "/IM", name],
                                     None, timeout, None)
        detail = codec.decode("taskkill", detail2 or b"").strip()
    except Exception as e:
        ok, detail = False, str(e)
    if not ok:
        # 结束失败（比如权限不足）：提示用户手动处理
        return ("提示：输出文件被其他进程占用且自动结束失败（" + detail + "），"
                "请手动关闭正在运行的 " + name + " 后重试。")
    # 等待文件锁释放（taskkill 返回后锁的释放略有延迟）
    for _ in range(10):
        try:
            with open(path, "ab"):
                return "已自动结束残留的 " + name + " 进程（之前运行/测试的程序仍在占用输出文件）。"
        except OSError:
            time.sleep(0.2)
    return ("已结束 " + name + " 进程，但文件仍被占用；"
            "请稍后重试或手动关闭相关程序。")


def env_report() -> dict:
    """环境报告：本地工具链路径与版本 + 相关设置项。

    只做本机检测（每个工具跑一次 --version），**不访问网络**：
    「下载地址」等设置项只原样返回，不做连通性检查 —— IDE 启动/自检不会因为
    下载地址写出错或暂时不可达而变慢或报错。"""
    gxx, make, git = find_gxx(), find_make(), find_git()
    brep = bash_report()
    bash = brep["path"]
    nrep = node_report()
    node = nrep["path"]
    pkgs = tools_packages_report()
    prep = pip_report()
    return {
        "gxx": gxx or "",
        "gxxVer": _ver(gxx) if gxx else "",
        "make": make or "",
        "makeVer": _ver(make) if make else "",
        "git": git or "",
        "gitVer": _ver(git) if git else "",
        "bash": bash or "",
        "bashVer": _ver(bash) if bash else "",
        # bash 从哪来的：tools（IDE 自带）/ system（系统）/ setting（手动填的）/ ""（没有）
        "bashSource": brep["source"],
        "bashSourceLabel": brep["label"],
        "bashTools": brep["tools"],
        "bashSystem": brep["system"],
        # node（智能体 PTC 的 TypeScript 后端）：默认 tools/node/node.exe
        "node": node or "",
        "nodeVer": _ver(node) if node else "",
        "nodeSource": nrep["source"],
        "nodeSourceLabel": nrep["label"],
        "nodeTools": nrep["tools"],
        "nodeSystem": nrep["system"],
        # tools 目录下的运行库包（哨兵路径，空串 = 缺失；只做本地检查不联网）
        "qt": pkgs["qt"],
        "qtx86": pkgs["qtx86"],
        "sciter": pkgs["sciter"],
        "sciterx86": pkgs["sciterx86"],
        "zstd": pkgs["zstd"],
        "zstdVer": pkgs["zstdVer"],
        "workspace": get_settings().get("workspace", ""),
        "arch": get_arch(),
        "subsystem": get_subsystem(),
        "mode": get_mode(),
        "python": sys.version.split()[0],
        "pythonPath": find_python(),
        # pip（Python 包管理）：重点报告**它属于哪个 Python** —— pip.exe 是个写死了
        # 目标解释器的壳，来源拷错会变成「能跑，但包装到别的 Python 里去了」
        "pip": prep["path"],
        "pipVer": prep["version"],
        "pipPython": prep["python"],
        "pipSite": prep["site"],
        "pipMatched": prep["matched"],
        "pipModuleOk": prep["moduleOk"],
        "pipNote": prep["note"],
        "pipSource": prep["source"],
        "pipSourceLabel": prep["label"],
        "pipTools": prep["tools"],
        "pipSystem": prep["system"],
    }


# ---------------- 在线下载 MinGW ----------------
_MINGW_ZIP = re.compile(r".*x86_64.*posix-seh.*\.zip", re.I)

# ---------------- 在线下载 tools 四件套（git / python / mingw32 / mingw64） ----------------
# 下载地址：<下载地址>/<包名>.zip（下载地址默认见 DEFAULT_SETTINGS["downloadUrl"]）
TOOLS_PACKAGES = ("git", "python", "mingw32", "mingw64")
TOOLS_PACKAGE_LABEL = {
    "git": "Git + 绿色版 Bash（PortableGit 便携包，含 bash / coreutils）",
    "python": "自带 Python 运行环境",
    "mingw32": "x86（32 位）工具链",
    "mingw64": "x64 工具链",
}


def tools_base_url() -> str:
    """下载 tools 四个包的基地址（设置项 downloadUrl；留空则用默认地址）。"""
    base = (get_settings().get("downloadUrl") or "").strip()
    if not base:
        base = str(DEFAULT_SETTINGS.get("downloadUrl") or "")
    if base and not base.endswith("/"):
        base += "/"
    return base


def tools_package_url(name: str, base: str = "") -> str:
    """某个包的下载地址：<base><name>.zip。"""
    b = (base or tools_base_url()).strip()
    if b and not b.endswith("/"):
        b += "/"
    return b + name + ".zip"


# 下载用的浏览器 UA：部分资源站做了防盗链，拒绝 Python-urllib 之类的默认 UA（会返回 403）
_DL_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def _download_to(url: str, zpath: str, referer: str = "", progress=None,
                 name: str = "") -> str:
    """把 url 流式下载到 zpath（带浏览器 UA / Referer，规避防盗链；支持进度回调）。"""
    req = urllib.request.Request(url, headers={
        "User-Agent": _DL_UA,
        "Accept": "*/*",
        "Accept-Encoding": "identity",
    })
    if referer:
        req.add_header("Referer", referer)
    try:
        with urllib.request.urlopen(req, timeout=60) as rp:
            total = int(rp.headers.get("Content-Length") or 0)
            got = 0
            with open(zpath, "wb") as fp:
                while True:
                    chunk = rp.read(1024 * 256)
                    if not chunk:
                        break
                    fp.write(chunk)
                    got += len(chunk)
                    if progress:
                        progress({"stage": "下载", "detail": name, "got": got,
                                  "total": total})
    except urllib.error.HTTPError as e:
        hint = "（服务器拒绝下载，可能是防盗链；请检查「下载地址」或资源站权限）" \
            if e.code in (401, 403) else ""
        raise RuntimeError("HTTP %s %s%s" % (e.code, e.reason, hint)) from e
    return zpath


def _zip_payload_root(tmp: str, name: str) -> str:
    """在解压出的临时目录里定位「包根目录」：
    兼容 <name>/…、tools/<name>/…、<name>-<版本>/… 以及内容直接铺开四种打包方式。"""
    cands = [os.path.join(tmp, name), os.path.join(tmp, "tools", name)]
    try:
        for e in sorted(os.listdir(tmp)):
            p = os.path.join(tmp, e)
            if os.path.isdir(p) and e.lower().startswith(name.lower()):
                cands.append(p)
    except OSError:
        pass
    for c in cands:
        if os.path.isdir(c):
            return c
    # 退化：临时目录下只有一个目录、且没有散落文件 → 它就是包根
    try:
        entries = os.listdir(tmp)
    except OSError:
        return tmp
    dirs = [e for e in entries if os.path.isdir(os.path.join(tmp, e))]
    files = [e for e in entries if not os.path.isdir(os.path.join(tmp, e))]
    if len(dirs) == 1 and not files:
        return os.path.join(tmp, dirs[0])
    return tmp


def download_tool_package(name: str, dest_dir: str, base: str = "",
                          force: bool = False, progress=None) -> dict:
    """下载并解压一个 tools 包（<base><name>.zip）到 dest_dir/tools/<name>。

    目标目录已存在且未指定 force 时直接跳过（不重复下载）。
    注意：tools/python 可能正被运行中的 IDE 占用，覆盖前请先退出 IDE。
    返回 {name, ok, skipped, url, note, dir}。"""
    if name not in TOOLS_PACKAGES:
        raise ValueError("未知的 tools 包：" + str(name))
    url = tools_package_url(name, base)
    target = os.path.join(dest_dir, "tools", name)
    if os.path.isdir(target) and not force:
        return {"name": name, "ok": True, "skipped": True, "url": url, "dir": target,
                "note": "已存在，跳过（不重复下载）"}
    os.makedirs(os.path.join(dest_dir, "tools"), exist_ok=True)
    tmp = os.path.join(dest_dir, "tools", ".dl_" + name)
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    zpath = os.path.join(tmp, name + ".zip")
    if progress:
        progress({"stage": "下载", "detail": "下载 " + url})
    _download_to(url, zpath, referer=base or tools_base_url(), progress=progress, name=name)
    if progress:
        progress({"stage": "解压", "detail": "解压 " + name + ".zip"})
    with zipfile.ZipFile(zpath) as zf:
        zf.extractall(tmp)
    payload = _zip_payload_root(tmp, name)
    if os.path.abspath(payload) == os.path.abspath(tmp):
        os.remove(zpath)                     # 内容直接铺开：整个临时目录挪过去
        shutil.rmtree(target, ignore_errors=True)
        shutil.move(tmp, target)
    else:
        shutil.rmtree(target, ignore_errors=True)
        shutil.move(payload, target)
        shutil.rmtree(tmp, ignore_errors=True)
    return {"name": name, "ok": True, "skipped": False, "url": url, "dir": target,
            "note": "已解压到 tools\\" + name}


def download_tools(dest_dir: str, base: str = "", names=None, force: bool = False,
                   progress=None) -> dict:
    """下载并解压 tools 的若干包（默认四个：git / python / mingw32 / mingw64）。

    地址取自「设置 → 下载地址」，实际为 <地址>/git.zip、<地址>/python.zip、
    <地址>/mingw32.zip、<地址>/mingw64.zip；已存在的包默认跳过。
    返回 {ok, base, items, gxx, make, git, python}。"""
    os.makedirs(dest_dir, exist_ok=True)
    b = base or tools_base_url()
    items = []
    for n in (names or list(TOOLS_PACKAGES)):
        try:
            items.append(download_tool_package(n, dest_dir, base=b, force=force,
                                               progress=progress))
        except Exception as e:               # 单个包失败不影响其余包
            items.append({"name": n, "ok": False, "skipped": False,
                          "url": tools_package_url(n, b), "note": "失败：" + str(e)})
    tools = os.path.join(dest_dir, "tools")

    def _p(*parts):
        p = os.path.join(tools, *parts)
        return p if os.path.isfile(p) else ""

    # g++ 与 make 取同一架构目录（x64 优先，其次 x86），避免两者混用
    gxx, make = _p("mingw64", "bin", "g++.exe"), _p("mingw64", "bin", "mingw32-make.exe")
    if not gxx:
        gxx = _p("mingw32", "bin", "g++.exe")
        make = _p("mingw32", "bin", "mingw32-make.exe")
    return {
        "ok": all(i.get("ok") for i in items),
        "base": b,
        "items": items,
        "gxx": gxx,
        "make": make,
        "git": _p("git", "cmd", "git.exe"),
        "bash": _p("git", "bin", "bash.exe"),
        "python": _p("python", "bin", "python3.14.exe"),
    }


def winlibs_release_url() -> str:
    """获取 winlibs 最新版可下载压缩包地址。"""
    req = urllib.request.Request(
        "https://api.github.com/repos/brechtsanders/winlibs_mingw/releases/latest",
        headers={"User-Agent": "yunyi-ide"})
    with urllib.request.urlopen(req, timeout=20) as rp:
        data = json.loads(codec.decode("http", rp.read()))
    for asset in data.get("assets", []):
        name = asset.get("name", "")
        if "win64" in name and "posix-seh" in name and name.endswith(".zip"):
            return asset.get("browser_download_url", "")
    raise RuntimeError("未在 winlibs 最新版发布中找到合适的压缩包")


def download_mingw(dest_dir: str, url: str = "", progress=None) -> dict:
    """下载并解压 MinGW-w64 到 dest_dir/tools。返回报告 dict。"""
    os.makedirs(dest_dir, exist_ok=True)
    if not url:
        url = get_settings().get("downloadUrl") or winlibs_release_url()
    fname = url.split("/")[-1] or "mingw.zip"
    zpath = os.path.join(dest_dir, fname)
    if progress:
        progress({"stage": "下载", "detail": f"下载 {url}"})
    urllib.request.urlretrieve(url, zpath)
    tools = os.path.join(dest_dir, "tools")
    os.makedirs(tools, exist_ok=True)
    if progress:
        progress({"stage": "解压", "detail": f"解压 {fname}"})
    with zipfile.ZipFile(zpath) as zf:
        zf.extractall(tools)
    # 找到内层 mingw64/bin/g++.exe
    for root, dirs, files in os.walk(tools):
        if "g++.exe" in files:
            gxx = os.path.join(root, "g++.exe")
            return {"ok": True, "gxx": gxx, "zip": zpath}
    return {"ok": False, "detail": "解压完成，但未在压缩包内找到 g++.exe", "zip": zpath}
