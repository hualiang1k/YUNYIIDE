# -*- coding: utf-8 -*-
"""类库自动引入（lib/*.class + lib/*.api）。

「类」/「API」选项卡展示的类库定义都允许工程源码**直接使用**（无需先把定义复制进 .yy）：
翻译（运行 / 编译 / 测试 / 发布 / 导出C++ / 构建脚本共用同一条链）时，本模块把工程里
引用到、但没有定义的类库定义自动合并进翻译输入（AST 级合并，不改动 .yy 文件）。

文件分工（重要）：
- ``*.class`` → 只提供「数据类型 + 类函数」（里面的 API 声明**不会**被加载）；
- ``*.api``   → 只提供 API 声明（``API 返回类型 名称(参数) 在库 "xxx.dll"``）；
- 加载顺序：``core.class`` 最前 → 其余 ``*.class`` 按文件名；然后 ``core.api`` 最前 →
  其余 ``*.api`` 按文件名（同名定义以先出现者为准）。

分两步：
1) parse 前：把类库类型名传给语法分析器（extra_types），
   让「变量 类库类型 名 / 参数 / 返回类型」等写法直接可用；
2) parse 后：扫描工程 AST，按需注入
   - 调用需求：「对象.方法(…) / 类型.方法(…)」调到了、工程未定义的类函数；
   - 类型需求：变量 / 参数 / 返回类型用到了、工程未定义的类库数据类型；
   - API 需求：调用了、工程未声明的类库 API 声明（如 GetTickCount()）；
   - 值需求：类函数体内引用了、`*.class` 里定义的常量 / 全局变量；
   - 辅助子程序需求：类函数体内调用了、类库里定义的子程序。
   （后面两条是「`*.class` 内定义的东西要能被同文件的类函数引用」的关键：
     少了它们，注入进来的类函数一编译就报「未声明名称 'X'」）

规则：
- 以工程为准：工程里已有的同名「数据类型 / 类函数 / API 声明」不会重复引入；
- 类函数的宿主类型工程与类库都没有时，补一个空数据类型（当命名空间）；
- 递归引入：类库类函数体内再引用其它类库类型 / 类函数 / API 声明，同样会被引入；
- 类库里也没有的不引入，由语法 / 语义检查照常报错；
- 本模块任何异常都不影响原编译流程（失败 = 回到不引入的旧行为）。
"""
from __future__ import annotations
import sys
import copy
import os

from . import ast
from . import codec
from .parser import parse_source

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    _ROOT = os.path.dirname(os.path.abspath(sys.executable))
LIB_DIR = os.path.join(_ROOT, "lib")


def lib_dirs() -> list:
    r"""按当前界面语言给出候选类库目录（优先级从高到低）：
    界面语言非 zh_cn 且 ``lib\<语言>`` 存在（如 lib\en_us）→ 它排最前；
    基础 lib 目录随后兜底。语言目录里的同名文件**取代**基础目录的同名文件。"""
    dirs = []
    lang = "zh_cn"
    try:
        from . import toolchain as TC
        lang = str(TC.get_settings().get("language") or "zh_cn").strip() or "zh_cn"
    except Exception:
        pass
    if lang != "zh_cn":
        d = os.path.join(_ROOT, "lib", lang)
        if os.path.isdir(d):
            dirs.append(d)
    if os.path.isdir(LIB_DIR):
        dirs.append(LIB_DIR)
    return dirs


def lib_files() -> dict:
    r"""当前语言可用的全部类库文件：{相对名 → 绝对路径}。

    · 基础 lib 目录的文件相对名就是文件名（``core.class``）；
    · 语言目录（lib\en_us …）的文件相对名带语言前缀（``en_us/core.class``），
      并按文件名（不分大小写）顶掉基础目录里的同名文件；
    · 基础目录里语言目录没有的文件照常兜底（如 test.class）。
    编译链（load_lib_defs）与 IDE 侧栏（server._read_lib_classes）共用本表，
    保证「面板展示什么」与「编译时引入什么」永远一致。"""
    out = {}
    dirs = lib_dirs()
    base = LIB_DIR
    lang = dirs[0] if (dirs and dirs[0] != LIB_DIR) else None
    if os.path.isdir(base):
        try:
            for n in sorted(os.listdir(base)):
                p = os.path.join(base, n)
                if os.path.isfile(p):
                    out[n] = p
        except Exception:
            pass
    if lang:
        try:
            for n in sorted(os.listdir(lang)):
                p = os.path.join(lang, n)
                if not os.path.isfile(p):
                    continue
                for k in [k for k in out if k.lower() == n.lower()]:
                    del out[k]                      # 语言目录同名文件顶掉基础文件
                out[os.path.basename(lang) + "/" + n] = p
        except Exception:
            pass
    return out

_MAX_ROUNDS = 12          # 递归引入轮数上限（类库类函数互相引用成环时兜底）

_BASIC_TYPES = {"逻辑型", "字节型", "短整数型", "整数型", "长整数型", "小数型", "文本型", "字节集",
                "日期时间型", "双精度小数型", "子程序指针"}

_CORE_CMDS = None             # 核心库内置命令名集合（懒加载，见 _is_core_command）


def _is_core_command(name: str) -> bool:
    """是否为核心库内置命令：是的话不要把同名的类库子程序引进来（内置命令优先）。"""
    global _CORE_CMDS
    if _CORE_CMDS is None:
        try:
            from . import corelib
            _CORE_CMDS = {c.get("name") for c in corelib.commands()}
        except Exception:
            _CORE_CMDS = set()
    return name in _CORE_CMDS


class _LibDefs:
    """lib 解析结果：
    · ``*.class`` → 数据类型 / 类函数 / 常量 / 全局变量 / 子程序
    · ``*.api``   → API 声明
    （同名先出现者优先，core.class / core.api 排最前。）

    「值」类定义（常量 / 全局变量）与辅助「子程序」也一并收进来：
    *.class 里的类函数引用到的同文件常量 / 全局变量 / 子程序，会跟着一起自动引入
    （见 _Scan / _inject）—— 否则注入的类函数一编译就报「未声明名称 'X'」。"""

    def __init__(self):
        self.structs = {}      # 类型名 -> (StructDecl, 来源文件名)
        self.methods = {}      # "类型.函数" -> (MethodDecl, 来源文件名)
        self.apis = {}         # API 名 -> (ApiDecl, 来源文件名)
        self.consts = {}       # 常量名 -> (GlobalConst, 来源文件名)
        self.globals = {}      # 全局变量名 -> (GlobalVar, 来源文件名)
        self.funcs = {}        # 子程序名 -> (Func, 来源文件名)
        self.values = {}       # 「值」类定义合并视图：名 -> (声明, 来源, '常量' | '全局变量')

    def type_names(self):
        """类库里出现过的全部类型名（数据类型名 + 类函数宿主名）。"""
        out = set(self.structs)
        out.update(self.method_hosts())
        return out

    def method_hosts(self):
        """类函数宿主类型名（含只写类函数、没写「数据类型」的空命名空间）。"""
        return {key.split(".", 1)[0] for key in self.methods}


def _arch_skip_names(names, arch: str) -> set:
    """按 ``*_x86.*`` 成对切换规则算出当前架构**不加载**的文件名集合：

    · x64 → 跳过所有名字带 ``_x86`` 的文件（载入对应的 x64 版）；
    · x86 → 有 ``_x86`` 版本的文件跳过本体，载入 ``_x86`` 版
      （如 qt.class ↔ qt_x86.class、sciter.api ↔ sciter_x86.api、
      core.class ↔ core_x86.class）。

    没有 ``_x86`` 对应版本的文件（如 core.const / Mine.* / test.class）
    两种架构都照常加载。"""
    import os
    skip = set()
    if arch not in ("x86", "x64"):
        return skip
    if arch == "x64":
        for n in names:
            if os.path.splitext(n)[0].lower().endswith("_x86"):
                skip.add(n)
        return skip
    # x86：找齐 "_x86" 版本，跳过它们的本体
    x86_of = {}
    for n in names:
        stem, ext = os.path.splitext(n)
        if stem.lower().endswith("_x86"):
            x86_of[(stem[:-4].lower() + ext.lower())] = n
    for n in names:
        base = x86_of.get(n.lower())
        if base is not None and base != n:
            skip.add(n)
    return skip


def _names_of(names, ext: str, first) -> list:
    """挑出指定后缀的文件名：``first``（core 系文件，按优先级给多个候选，
    如 ("core.class", "core_x86.class")）排最前，其余按名称排序。

    架构过滤：**所有名字带 ``_x86`` 的文件都按 x64 / x86 成对切换，只载入
    当前架构的那一份**（见 _arch_skip_names）。core 前缀的文件最先加载，
    其余文件按名称排序随后。

    为什么必须过滤：两份文件里的「数据类型 / 类函数」同名（如 界面.新建窗口），
    同时载入会重复定义；API 声明同名更危险 —— 声明里的 `在库 "xxx.dll"` 不同
    （yysciter.dll / yysciter_x86.dll），挑错就会 LoadLibrary 失败。

    架构取自全局设置（toolchain.get_arch()）：翻译 / 编译前
    ``project.apply_project_env()`` 已把「本工程的架构」同步过去，所以这里拿到的是
    当前工程的架构，命令行 / 构建脚本 / CI 等入口同样有效。"""
    from . import toolchain as TC
    arch = TC.get_arch()  # "x64" / "x86"
    _arch_skip = _arch_skip_names(names, arch)
    out = sorted((f for f in names if f.lower().endswith(ext) and f not in _arch_skip),
                 key=lambda f: f.lower())
    # core 前缀文件排最前：按优先级取第一个在场的候选（x86 时 core_x86.* 优先）。
    # 按文件名（basename）匹配 —— 语言目录里的文件相对名带前缀（en_us/core.class）。
    for cand in ([first] if isinstance(first, str) else first):
        hit = next((f for f in out if os.path.basename(f).lower() == cand.lower()), None)
        if hit is not None:
            out.sort(key=lambda f: f != hit)
            break
    return out


def _parse_lib_file(fn: str, abspath: str, extra_types=None):
    """解析一个类库文件（云易语法片段，允许没有子程序）；失败返回 None。
    abspath：文件绝对路径（来自 lib_files()，可能在语言目录里）。
    extra_types：额外已知类型名（*.class 里定义的数据类型，供 *.api 的参数引用）。"""
    try:
        with codec.open_text("classlib", abspath, "r") as fp:
            text = fp.read()
        return parse_source(text, "lib/" + fn, require_funcs=False,
                            extra_types=extra_types)
    except Exception:
        return None                      # 类库文件自身解析失败：跳过，不影响工程编译


def load_lib_defs() -> _LibDefs:
    """读取 lib 目录下的类库定义（单个文件失败只跳过该文件）。

    · ``*.class`` → 数据类型 + 类函数（**忽略**文件里的 API 声明）
    · ``*.api``   → 只取 API 声明
    · 顺序：core 系排最前（x64 → core.class/core.api，x86 → core_x86.*），
      其余按文件名排序
    """
    lib = _LibDefs()
    fmap = lib_files()
    if not fmap:
        return lib
    names = list(fmap.keys())
    # ① 类库：数据类型 + 类函数（+ 常量 / 全局变量 / 子程序：供类函数体内引用）
    for fn in _names_of(names, ".class", ("core.class", "core_x86.class")):
        p = _parse_lib_file(fn, fmap[fn])
        if p is None:
            continue
        for s in getattr(p, "structs", []) or []:
            if s.name and s.name not in lib.structs:
                lib.structs[s.name] = (s, fn)
        for m in getattr(p, "methods", []) or []:
            key = (m.owner or "") + "." + (m.name or "")
            if m.owner and m.name and key not in lib.methods:
                lib.methods[key] = (m, fn)
        for c in getattr(p, "consts", []) or []:
            if c.name and c.name not in lib.consts:
                lib.consts[c.name] = (c, fn)
        for g in getattr(p, "globals_", []) or []:
            if g.name and g.name not in lib.globals:
                lib.globals[g.name] = (g, fn)
        for f in getattr(p, "funcs", []) or []:
            if f.name and f.name not in lib.funcs:
                lib.funcs[f.name] = (f, fn)
    # ② API 声明：只认 *.api（*.class 里的 API 声明不加载）
    #    解析 *.api 时带上类库数据类型名 —— API 参数可引用 core.class 里定义的结构体
    struct_names = set(lib.structs.keys())
    for fn in _names_of(names, ".api", ("core.api", "core_x86.api")):
        p = _parse_lib_file(fn, fmap[fn], extra_types=struct_names)
        if p is None:
            continue
        for a in getattr(p, "apis", []) or []:
            # API 声明（Windows API / 云易 DLL 导出函数），语法与工程 .yy 里完全一致
            if a.name and a.name not in lib.apis:
                lib.apis[a.name] = (a, fn)
    # 「值」类定义（常量优先于同名全局变量）的合并视图，供按名查找
    for n, (d, fn) in lib.consts.items():
        lib.values[n] = (d, fn, "常量")
    for n, (d, fn) in lib.globals.items():
        lib.values.setdefault(n, (d, fn, "全局变量"))
    return lib


# ---------- 引用分析（找出工程用到、但工程里没定义的类库定义） ----------

def _collect_locals(params, body, out):
    """收集一个函数/类函数体内的名字 → 类型（参数、变量、计次循环变量；全部提升）。"""
    for p in params or []:
        if p.name:
            out[p.name] = p.type
    _collect_body_names(body, out)
    return out


def _collect_body_names(body, out):
    for st in body or []:
        if isinstance(st, ast.VarDecl):
            if st.name:
                out[st.name] = st.type
        elif isinstance(st, ast.IfStmt):
            for _c, b in st.branches:
                _collect_body_names(b, out)
            _collect_body_names(st.else_body, out)
        elif isinstance(st, ast.ForRange):
            if st.var:
                out[st.var] = "整数型"
            _collect_body_names(st.body, out)
        elif isinstance(st, (ast.WhileStmt, ast.DoWhileStmt)):
            _collect_body_names(st.body, out)


def _find_field_type(structs, tname, fname):
    s = structs.get(tname)
    if s is None:
        return ""
    for fld in s.fields:
        if fld.name == fname:
            return fld.type
    return ""


def _expr_type(e, loc, structs, funcs_ret, methods_ret):
    """推导表达式类型名（未知返回 ''）。与语义检查同思路的轻量版：
    变量/参数/成员按类型表推，类型名本身（静态调用 类型.方法）也算。"""
    if isinstance(e, ast.Name):
        t = loc.get(e.id)
        if t:
            return t
        return e.id if e.id in structs else ""
    if isinstance(e, ast.Member):
        b = _expr_type(e.base, loc, structs, funcs_ret, methods_ret)
        return _find_field_type(structs, b, e.name) if b else ""
    if isinstance(e, ast.Index):
        return _expr_type(e.base, loc, structs, funcs_ret, methods_ret)
    if isinstance(e, ast.StrLit):
        return "文本型"
    if isinstance(e, ast.NumLit):
        return "小数型" if isinstance(e.value, float) else "整数型"
    if isinstance(e, ast.BoolLit):
        return "逻辑型"
    if isinstance(e, ast.Call):
        obj = getattr(e, "obj", None)
        if obj is not None:
            ot = _expr_type(obj, loc, structs, funcs_ret, methods_ret)
            return methods_ret.get((ot, e.func), "")
        return funcs_ret.get(e.func, "")
    return ""


class _Scan:
    """遍历工程 AST，收集「用到但工程未定义」的类库类型与类函数需求。"""

    def __init__(self, prog, lib):
        self.lib = lib
        self._prog_structs = {s.name for s in getattr(prog, "structs", []) or []}
        self.structs = {}          # 类型名 -> StructDecl（工程 + 类库，用于推导字段类型）
        for s in getattr(prog, "structs", []) or []:
            self.structs[s.name] = s
        for n, (s, _fn) in lib.structs.items():
            self.structs.setdefault(n, s)
        # 只写类函数、没写「数据类型」的空命名空间也算宿主（值为 None：无成员表）
        for n in lib.method_hosts():
            self.structs.setdefault(n, None)
        self.have = {}             # 工程已有类函数：owner -> {方法名}
        for m in getattr(prog, "methods", []) or []:
            self.have.setdefault(m.owner, set()).add(m.name)
        self.funcs_ret = {}        # 子程序名 -> 返回类型（链式调用的类型推导用）
        for f in getattr(prog, "funcs", []) or []:
            self.funcs_ret[f.name] = f.ret_type or ""
        self.need_methods = set()  # {(宿主类型, 方法名)}
        self.need_types = set()    # {类型名}
        self.need_apis = set()     # {API 名}（工程里没声明、类库里有）
        self.need_consts = set()   # {常量名}（类函数 / 类库常量引用到、工程里没有）
        self.need_globals = set()  # {全局变量名}
        self.need_funcs = set()    # {子程序名}（类库里的辅助子程序）
        self.prog_apis = {a.name for a in getattr(prog, "apis", []) or []}
        self.prog_consts = {c.name for c in getattr(prog, "consts", []) or []}
        self.prog_globals = {g.name for g in getattr(prog, "globals_", []) or []}
        self.prog_funcs = {f.name for f in getattr(prog, "funcs", []) or []}

    def _name_ref(self, name, loc):
        """表达式里出现的一个名字：本地（参数 / 变量 / 成员）或工程已定义的不算；
        类库 *.class 里有同名的 常量 / 全局变量 时记下要一并引入。"""
        if not name or name in loc:
            return
        if name in self.prog_consts or name in self.prog_globals:
            return
        v = self.lib.values.get(name)
        if v is None:
            return
        if v[2] == "常量":
            self.need_consts.add(name)
        else:
            self.need_globals.add(name)

    def run(self, prog):
        self.prog = prog
        self._mret = {(m.owner, m.name): (m.ret_type or "")
                      for m in getattr(prog, "methods", []) or []}
        # 全局变量 / 常量的类型（初值 / 数组长度里也可能引用类库的常量、子程序）
        for g in getattr(prog, "globals_", []) or []:
            self._type_ref(g.type)
            self._expr(getattr(g, "init", None), {})
            self._expr(getattr(g, "array_size", None), {})
        for c in getattr(prog, "consts", []) or []:
            self._type_ref(c.type)
            self._expr(getattr(c, "value", None), {})
        # 子程序（含 测试函数 / 程序入口）
        for f in getattr(prog, "funcs", []) or []:
            self._type_ref(f.ret_type)
            loc = _collect_locals(f.params, f.body, {})
            for _n, t in loc.items():
                self._type_ref(t)
            for st in f.body or []:
                self._stmt(st, loc)
        # 类函数（含已注入的）；宿主成员可当局部变量直接用（隐式 this）
        for m in getattr(prog, "methods", []) or []:
            self._type_ref(m.ret_type)
            loc = {}
            s = self.structs.get(m.owner)
            if s is not None:
                for fld in s.fields:
                    loc[fld.name] = fld.type
            _collect_locals(m.params, m.body, loc)
            for _n, t in loc.items():
                self._type_ref(t)
            for st in m.body or []:
                self._stmt(st, loc)
        # 工程自带的 API 声明：参数 / 返回值引用的结构体类型也要引入
        # （如 工程里声明 RtlMoveMemory_Read_X(自定义结构 p 传址, ...) 而
        #   该结构定义在 core.class —— 生成 C++ 时结构体必须已定义）
        for a in getattr(prog, "apis", []) or []:
            for p in getattr(a, "params", []) or []:
                self._type_ref(p.type)
            self._type_ref(getattr(a, "ret_type", ""))

    def _type_ref(self, tname):
        """类型引用：非基本类型、工程未定义、类库里有 → 需要引入该数据类型。"""
        if tname and tname not in _BASIC_TYPES and tname not in self._prog_structs:
            if tname in self.lib.structs:
                self.need_types.add(tname)

    def _stmt(self, st, loc):
        if st is None:
            return
        if isinstance(st, ast.VarDecl):
            self._expr(st.init, loc)
            self._expr(st.array_size, loc)
        elif isinstance(st, ast.Assign):
            self._expr(st.target, loc)
            self._expr(st.value, loc)
        elif isinstance(st, ast.ExprStmt):
            self._expr(st.expr, loc)
        elif isinstance(st, ast.IfStmt):
            for c, b in st.branches:
                self._expr(c, loc)
                for s2 in b or []:
                    self._stmt(s2, loc)
            for s2 in st.else_body or []:
                self._stmt(s2, loc)
        elif isinstance(st, ast.ForRange):
            self._expr(st.start, loc)
            self._expr(st.end, loc)
            for s2 in st.body or []:
                self._stmt(s2, loc)
        elif isinstance(st, (ast.WhileStmt, ast.DoWhileStmt)):
            self._expr(st.cond, loc)
            for s2 in st.body or []:
                self._stmt(s2, loc)
        elif isinstance(st, ast.ReturnStmt):
            self._expr(st.expr, loc)

    def _expr(self, e, loc):
        if e is None:
            return
        if isinstance(e, ast.Call):
            obj = getattr(e, "obj", None)
            if obj is not None:
                otype = _expr_type(obj, loc, self.structs, self.funcs_ret, self._mret)
                # 只有自定义数据类型（工程或类库里的）才可能是类函数宿主
                if otype and otype not in _BASIC_TYPES and otype in self.structs:
                    if e.func not in self.have.get(otype, ()):
                        self.need_methods.add((otype, e.func))
                self._expr(obj, loc)
            elif e.func in self.lib.apis and e.func not in self.prog_apis:
                # 直接调用了类库里的 API 声明（如 GetTickCount()），工程自己没声明 → 引入
                self.need_apis.add(e.func)
                # API 参数 / 返回值用到的结构体类型也要一并引入（如 GetCursorPos 的 POINT_）
                a = self.lib.apis.get(e.func, (None,))[0]
                if a is not None:
                    for p in getattr(a, "params", []) or []:
                        self._type_ref(p.type)
                    self._type_ref(getattr(a, "ret_type", ""))
            elif (e.func in self.lib.funcs and e.func not in self.prog_funcs
                  and not _is_core_command(e.func)):
                # 类库 *.class 里的辅助子程序（如类函数体内调用的 库辅助()）
                self.need_funcs.add(e.func)
            for a in e.args or []:
                self._expr(a, loc)
        elif isinstance(e, ast.Name):
            # 普通名字（常量 / 全局变量 / 变量…）：类库里的常量 / 全局变量也要引入
            self._name_ref(e.id, loc)
        elif isinstance(e, ast.Binary):
            self._expr(e.left, loc)
            self._expr(e.right, loc)
        elif isinstance(e, ast.Unary):
            self._expr(e.operand, loc)
        elif isinstance(e, ast.Index):
            self._expr(e.base, loc)
            self._expr(e.index, loc)
        elif isinstance(e, ast.Member):
            self._expr(e.base, loc)


def _missing_refs(prog, lib):
    """返回 (类函数 [(owner, name)], 数据类型 [名], API [名],
             常量 [名], 全局变量 [名], 子程序 [名])：工程用到、类库里有、工程还没定义的。

    结果按类库声明顺序给出（core.class 最前 → 其余 *.class 按文件名，
    文件内按定义先后）——注入顺序与书写顺序一致，保证
    「常量引用常量」「子程序引用常量」等依赖按顺序就位。"""
    scan = _Scan(prog, lib)
    scan.run(prog)
    # 递归展开：引入的数据类型其成员若嵌套引用其它类库数据类型，一并引入
    # （如 WPCAP_TCP 嵌套 Raw_以太网头 / Raw_IP报头 / Raw_TCP报头——
    #   工程只写 变量 pk WPCAP_TCP 时，只靠直接引用收集不到嵌套类型）
    expanded = True
    while expanded:
        expanded = False
        for tname in list(scan.need_types):
            entry = lib.structs.get(tname)
            s = entry[0] if entry else None
            if s is None:
                continue
            for fld in s.fields:
                ft = getattr(fld, "type", "")
                if (ft and ft not in _BASIC_TYPES and ft not in scan._prog_structs
                        and ft in lib.structs and ft not in scan.need_types):
                    scan.need_types.add(ft)
                    expanded = True
    methods = [tuple(k.split(".", 1)) for k in lib.methods
               if tuple(k.split(".", 1)) in scan.need_methods]
    types = [t for t in lib.structs if t in scan.need_types]
    apis = [n for n in lib.apis if n in scan.need_apis]
    consts = [n for n in lib.consts if n in scan.need_consts]
    globals_ = [n for n in lib.globals if n in scan.need_globals]
    funcs = [n for n in lib.funcs if n in scan.need_funcs]
    return methods, types, apis, consts, globals_, funcs


def _inject(prog, lib, methods, types, injected, apis=(), consts=(), globals_=(), funcs=()):
    """把缺失的类库「数据类型 + 类函数 + API 声明」合并进 prog。"""
    struct_names = {s.name for s in getattr(prog, "structs", []) or []}

    def add_struct(owner, src_file, line=0, col=0):
        s = lib.structs.get(owner)
        if s is not None:
            s2 = copy.deepcopy(s[0])
            s2.file = "lib/" + src_file
        else:
            # 类库里也没有类型定义（如只写类函数不写数据类型的 .class）：
            # 补一个空数据类型当命名空间，让类函数有宿主
            s2 = ast.StructDecl(name=owner, fields=[],
                                file="lib/" + src_file, line=line, col=col)
        prog.structs.append(s2)
        struct_names.add(owner)

    # ① 类型需求（只声明了变量 / 参数，没调用方法）
    for owner in types:
        if owner not in struct_names:
            s, fn = lib.structs[owner]
            add_struct(owner, fn)
            injected.setdefault("_types", {}).setdefault(owner, fn)
    # ② 类函数需求（含宿主类型）
    for owner, name in methods:
        key = owner + "." + name
        if key in injected.get("_keys", {}):
            continue
        m, fn = lib.methods[key]
        m2 = copy.deepcopy(m)
        m2.file = "lib/" + fn       # 来源标注（#line 指令与报错信息用；语言目录带 en_us/ 前缀）
        prog.methods.append(m2)
        injected.setdefault("_keys", {})[key] = fn
        if owner not in struct_names:
            add_struct(owner, fn, m.line, m.col)
    # ③ API 声明需求（工程里没声明、类库里有）
    if apis:
        if getattr(prog, "apis", None) is None:
            prog.apis = []
        have_api = {a.name for a in prog.apis}
        for name in apis:
            if name in have_api:
                continue
            a, fn = lib.apis[name]
            a2 = copy.deepcopy(a)
            a2.file = "lib/" + fn      # 来源标注（报错信息与 #line 用）
            prog.apis.append(a2)
            have_api.add(name)
            injected.setdefault("_apis", {})[name] = fn
    # ④ 常量 / 全局变量 / 子程序（*.class 里定义、被类函数引用到的）
    #    没有它们，注入的类函数一编译就报「未声明名称 'X' / 未找到子程序 X()」
    #    （调用方 _missing_refs 已按类库声明顺序排好，这里按序注入）
    if consts:
        have = {c.name for c in getattr(prog, "consts", []) or []}
        for name in consts:
            if name in have:
                continue
            c, fn = lib.consts[name]
            c2 = copy.deepcopy(c)
            c2.file = "lib/" + fn
            prog.consts.append(c2)
            have.add(name)
            injected.setdefault("_consts", {})[name] = fn
    if globals_:
        have = {g.name for g in getattr(prog, "globals_", []) or []}
        for name in globals_:
            if name in have:
                continue
            g, fn = lib.globals[name]
            g2 = copy.deepcopy(g)
            g2.file = "lib/" + fn
            prog.globals_.append(g2)
            have.add(name)
            injected.setdefault("_globals", {})[name] = fn
    if funcs:
        have = {f.name for f in getattr(prog, "funcs", []) or []}
        for name in funcs:
            if name in have:
                continue
            f, fn = lib.funcs[name]
            f2 = copy.deepcopy(f)
            f2.file = "lib/" + fn
            prog.funcs.append(f2)
            have.add(name)
            injected.setdefault("_funcs", {})[name] = fn


def inject_lib_refs(prog, messages=None, lib=None):
    """把工程用到、但工程里没定义的类库定义合并进 prog（就地修改）。

    messages: 编译结果消息列表（可选）；发生引入时追加一条 info，
    让「输出」面板能看到本次自动引入了哪些类函数 / 数据类型 / API 声明。
    返回引入的类函数 key 列表（空 = 没有需要引入的）。
    """
    try:
        if lib is None:
            lib = load_lib_defs()
        if not (lib.methods or lib.structs or lib.apis
                or lib.consts or lib.globals or lib.funcs):
            return []
        injected = {"_keys": {}, "_types": {}, "_apis": {},
                    "_consts": {}, "_globals": {}, "_funcs": {}}
        for _round in range(_MAX_ROUNDS):
            methods, types, apis, consts, globals_, funcs = _missing_refs(prog, lib)
            if not (methods or types or apis or consts or globals_ or funcs):
                break
            _inject(prog, lib, methods, types, injected, apis, consts, globals_, funcs)
        keys = injected["_keys"]
        types = injected["_types"]
        apis = injected["_apis"]
        consts = injected["_consts"]
        globals_ = injected["_globals"]
        funcs = injected["_funcs"]
        if (keys or types or apis or consts or globals_ or funcs) and messages is not None:
            by_from = {}
            for key, fn in keys.items():
                by_from.setdefault(fn, []).append("类函数 " + key)
            for tname, fn in types.items():
                by_from.setdefault(fn, []).append("数据类型 " + tname)
            for aname, fn in apis.items():
                by_from.setdefault(fn, []).append("API 声明 " + aname)
            for cname, fn in consts.items():
                by_from.setdefault(fn, []).append("常量 " + cname)
            for gname, fn in globals_.items():
                by_from.setdefault(fn, []).append("全局变量 " + gname)
            for fname, fn in funcs.items():
                by_from.setdefault(fn, []).append("子程序 " + fname)
            for fn in sorted(by_from):
                messages.append({
                    "kind": "info", "file": "", "line": 0, "col": 0,
                    "text": "已自动引入类库定义：%s（来自 lib/%s，无需复制进源码）"
                            % ("、".join(sorted(by_from[fn])), fn),
                })
        return sorted(keys.keys())
    except Exception:
        return []              # 自动引入失败：不影响原编译流程
