# -*- coding: utf-8 -*-
"""云易 语法分析器：Token 流 -> AST。"""
from __future__ import annotations
from typing import List, Optional, Set, Tuple

from .lexer import Token, tokenize, YyError
from . import ast


TYPE_SET = {"逻辑型", "字节型", "短整数型", "整数型", "长整数型", "小数型", "文本型", "字节集",
            "日期时间型", "双精度小数型", "子程序指针"}
TYPE_CPP = {"逻辑型": "bool", "字节型": "unsigned char", "短整数型": "short",
            "整数型": "int", "长整数型": "long long", "小数型": "float", "文本型": "std::string",
            "日期时间型": "long long", "双精度小数型": "double", "子程序指针": "long long"}

# 运算符规范化
EQ_OPS = {"=": "==", "==": "==", "!=": "!="}
CMP_OPS = {"<": "<", "<=": "<=", ">": ">", ">=": ">="}
ADD_OPS = {"+": "+", "-": "-"}
MUL_OPS = {"*": "*", "/": "/", "%": "%", "\\": "整除"}
AND_WORDS = {"且", "&&"}
OR_WORDS = {"或", "||"}
NOT_WORDS = {"非", "!"}

LINE_END_KW = {"结束如果", "结束如果真", "结束循环", "结束判断", "循环判断尾", "结束子程序", "否则", "否则如果"}
# 汇编块的收尾关键字（asm 块由词法整块读入，这里只用来报「没有与之匹配的开头语句」）
ASM_END_KW = {"结束asm", "结束汇编"}


def _const_type_of(val) -> str:
    """按常量初值推断类型（「常量 名称 = 值」省略类型时用；认不出按整数）。"""
    if isinstance(val, ast.StrLit):
        return "文本型"
    if isinstance(val, ast.BoolLit):
        return "逻辑型"
    if isinstance(val, ast.NumLit):
        return "小数型" if isinstance(val.value, float) else "整数型"
    return "整数型"


class Parser:
    def __init__(self, tokens: List[Token], filename: str = "", extra_types=None):
        self.toks = tokens
        self.filename = filename
        self.i = 0
        self._depth = 0          # 括号嵌套深度（用于跨行）
        self.entry_names = {"程序入口", "_启动子程序"}
        # 已知类型 = 基本类型 + 源码中定义的「数据类型」名称（预扫描，支持先使用后定义/跨文件顺序）
        # extra_types：额外类型名（类库 lib/*.class 的数据类型，供「变量 类库类型 名」等写法直接使用）
        self.known_types = set(TYPE_SET)
        if extra_types:
            self.known_types.update(extra_types)
        for j, t in enumerate(self.toks):
            if t.kind == "ident" and t.text == "数据类型":
                k = j + 1
                if k < len(self.toks) and self.toks[k].kind == "ident":
                    self.known_types.add(self.toks[k].text)

    # ---------- 基础工具 ----------
    def peek(self, off: int = 0) -> Token:
        j = min(self.i + off, len(self.toks) - 1)
        return self.toks[j]

    def next(self) -> Token:
        t = self.toks[self.i]
        if t.kind != "eof":
            self.i += 1
        return t

    def err(self, msg: str, tok: Optional[Token] = None) -> YyError:
        tok = tok or self.peek()
        return YyError(msg, tok.line, tok.col, self.filename)

    def skip_nl(self):
        while self.peek().kind == "newline":
            self.i += 1

    def expect(self, kind: str, val: Optional[str] = None) -> Token:
        t = self.peek()
        if kind == "ident":
            if t.kind == "ident" and (val is None or t.text == val):
                return self.next()
        elif kind == "sym":
            if t.kind == "sym" and (val is None or t.value == val):
                return self.next()
        elif t.kind == kind:
            return self.next()
        if val is not None:
            raise self.err(f"缺少 {val!r}，实际得到 {t.text or t.value!r}", t)
        raise self.err(f"语法错误：实际得到 {t.text or t.value!r}", t)

    def _after_cond_newline_ok(self):
        """解析表达式时若括号内遇换行则忽略（用于多行表达式）。"""
        return self._depth > 0

    # ---------- 顶层 ----------
    def parse_program(self, require_funcs: bool = True) -> ast.Program:
        prog = ast.Program()
        self.skip_nl()
        while self.peek().kind != "eof":
            t = self.peek()
            if t.kind != "ident":
                raise self.err("此处应为 全局变量 / 常量 / 数据类型 / 子程序 / 测试函数 / API", t)
            if t.text == "全局变量":
                prog.globals_.append(self._parse_global_var())
            elif t.text == "常量":
                prog.consts.append(self._parse_const())
            elif t.text == "数据类型":
                prog.structs.append(self._parse_struct())
            elif t.text == "类函数":
                prog.methods.append(self._parse_method())
            elif t.text in ("子程序", "测试函数", "导出子程序"):
                prog.funcs.append(self._parse_func())
            elif t.text == "API":
                prog.apis.append(self._parse_api())
            elif t.text == "程序集" or t.text == ".版本" or t.text.startswith("."):
                raise self.err("不支持的语法结构（本版本仅支持控制台风格子程序）", t)
            else:
                raise self.err(
                    f"顶层不识别 {t.text!r}，应为 全局变量/常量/数据类型/类函数/子程序/测试函数/API。"
                    f"若 {t.text!r} 是子程序或 API 的调用语句，请把它移入某个子程序体内（如 程序入口）", t)
            self.skip_nl()
        if require_funcs and not prog.funcs:
            raise YyError("工程中没有定义任何子程序", 1, 1, self.filename)
        return prog

    def _parse_type(self, ctx: str = "变量") -> str:
        t = self.peek()
        if t.kind != "ident" or t.text not in self.known_types:
            raise self.err(f"{ctx}需要数据类型（逻辑型/字节型/短整数型/整数型/长整数型/小数型/文本型/字节集/"
                           f"日期时间型/双精度小数型/子程序指针 或已定义的数据类型名称），实际为 {t.text or t.value!r}", t)
        return self.next().text

    def _parse_global_var(self) -> ast.GlobalVar:
        """全局变量：变量 两种顺序（名称 类型 / 类型 名称）都支持，
        但不能带初值 —— 全局只在编译期初始化，要给初值请用「常量」或在 程序入口 里赋值。"""
        start = self.next()                      # 吃掉 全局变量
        name, t = self._parse_name_and_type("全局变量")
        gv = ast.GlobalVar(name=name, type=t, line=start.line, col=start.col)
        if self.peek().is_sym("["):
            self.next()
            if self.peek().is_sym("]"):
                gv.array_dynamic = True
            else:
                gv.array_size = self._parse_expr()
            self.expect("sym", "]")
        if self.peek().is_sym("="):
            raise self.err("全局变量不能带初值（解析器不读 =，只有局部 变量 支持 = 默认值）",
                           self.peek())
        self._end_line("全局变量声明")
        return gv

    def _parse_const(self) -> ast.GlobalConst:
        """常量声明，两种写法：
        ① 常量 名称 类型 = 值 / 常量 类型 名称 = 值（与变量一致）
        ② 常量 名称 = 值 —— 类型省略，按值推断（整数型/小数型/文本型/逻辑型）；
           类库 lib/*.class 用的是写法②，不认它整个文件都会解析失败。"""
        start = self.next()                      # 吃掉 常量
        t1 = self.next()
        if t1.kind != "ident":
            raise self.err("常量声明缺少名称或类型", t1)
        if t1.text in self.known_types:          # 写法①：类型在前
            name = self.expect("ident").text
            t = t1.text
        else:                                    # 名称在前
            name = t1.text
            pt = self.peek()
            t = self.next().text if pt.kind == "ident" else ""
        self.expect("sym", "=")
        val = self._parse_expr()
        if not t:
            t = _const_type_of(val)
        self._end_line("常量定义")
        return ast.GlobalConst(name=name, type=t, value=val,
                               line=start.line, col=start.col)

    def _parse_param(self, ctx: str) -> ast.Param:
        """参数定义（子程序 / 类函数 / API 通用）：
          [参考] 类型 名称 [ [长度 | []] ] [传址]
        · 「传址」后缀写在变量名（含数组）之后，表示按地址传递（与旧的前缀「参考」等价）；
        · 数组：名称[长度]（固定）/ 名称[]（动态）。"""
        tok = self.peek()
        byref = False
        if self.peek().is_kw("参考"):            # 旧写法：前缀 参考
            self.next()
            byref = True
        t_tok = self.peek()
        if t_tok.kind == "ident" and t_tok.text not in self.known_types \
                and ctx == "API 参数":
            # API 参数允许引用尚未定义的数据类型（类库 core.api 可先于结构体定义存在；
            # 只有真正调用该 API 且类型未定义时才会在生成阶段报错）
            t = self.next().text
        else:
            t = self._parse_type(ctx)
        pname = self.expect("ident")
        arr_size = None
        arr_dynamic = False
        if self.peek().is_sym("["):
            self.next()
            if self.peek().is_sym("]"):
                arr_dynamic = True
            else:
                arr_size = self._parse_expr()
            self.expect("sym", "]")
            if self.peek().is_sym("["):
                raise self.err("参数暂不支持多维数组", self.peek())
        if self.peek().is_kw("传址"):            # 新写法：后缀 传址
            self.next()
            byref = True
        return ast.Param(name=pname.text, type=t, byref=byref, array_size=arr_size,
                         array_dynamic=arr_dynamic, line=tok.line, col=tok.col)

    def _parse_name_and_type(self, ctx: str):
        """变量/常量声明支持两种写法：
          写法A(推荐)：变量 名称 类型 [数组]
          写法B（云易习惯）：变量 类型 名称 [数组]（含自定义数据类型名）
        返回 (名称, 类型)。"""
        t1 = self.next()
        if t1.kind != "ident":
            raise self.err(f"{ctx}声明缺少名称或类型", t1)
        if t1.text in self.known_types:
            return self.expect("ident").text, t1.text     # 类型在前
        return t1.text, self._parse_type(ctx)             # 名称在前

    def _parse_struct(self) -> ast.StructDecl:
        """自定义数据类型：
        数据类型 名称
            成员类型 成员名 [数组长度 | []] [传址]
        结束数据类型
        成员支持：
          · 传址 后缀：写在成员名（含数组）之后，显式声明按值嵌入（成员默认即按值；
            兼容旧写法：传址 前缀仍可放在成员类型之前）；
          · 固定数组：成员名[长度]（长度须为常量表达式）；
          · 动态数组：成员名[]（配合 加入成员 / 重定义数组 等命令）；
          · 成员类型可为基本类型或已定义的自定义数据类型（嵌套，按值嵌入）。"""
        start = self.next()                              # 吃掉 数据类型
        name_tok = self.expect("ident")
        sd = ast.StructDecl(name=name_tok.text, file=self.filename,
                            line=start.line, col=start.col)
        self._end_line("数据类型定义")
        seen_fields = set()
        while True:
            self.skip_nl()
            t = self.peek()
            if t.kind == "eof":
                raise self.err("数据类型缺少 结束数据类型", start)
            if t.kind == "ident" and t.text == "结束数据类型":
                self.next()
                self._end_line_optional()
                break
            if t.kind != "ident":
                raise self.err(f"数据类型成员应为「成员类型 成员名 [数组长度] [传址]」，实际得到 {t.text or t.value!r}", t)
            ftok = self.next()
            # 可选「传址」前缀：显式声明成员按值传递（成员默认即按值嵌入）
            byval = False
            if ftok.text == "传址":
                byval = True
                ftok = self.next()
            if ftok.text not in self.known_types:
                raise self.err(f"成员类型 {ftok.text!r} 不是基本数据类型或已定义的数据类型"
                               f"（逻辑型/字节型/短整数型/整数型/长整数型/小数型/文本型/字节集/"
                               f"日期时间型/双精度小数型/子程序指针，或数据类型名称）", ftok)
            fname_tok = self.expect("ident")
            if fname_tok.text in seen_fields:
                raise self.err(f"数据类型 {name_tok.text!r} 中成员 {fname_tok.text!r} 重复", fname_tok)
            seen_fields.add(fname_tok.text)
            # 可选数组：成员名[长度]（固定）/ 成员名[]（动态）
            arr_size = None
            arr_dynamic = False
            if self.peek().is_sym("["):
                self.next()
                if self.peek().is_sym("]"):
                    arr_dynamic = True
                else:
                    arr_size = self._parse_expr()
                self.expect("sym", "]")
                if self.peek().is_sym("["):
                    raise self.err("数据类型成员暂不支持多维数组", self.peek())
            # 可选「传址」后缀：写在成员名（含数组）之后（兼容旧的前缀写法）
            if self.peek().kind == "ident" and self.peek().text == "传址":
                self.next()
                byval = True
            sd.fields.append(ast.Param(name=fname_tok.text, type=ftok.text,
                                       byval=byval, array_size=arr_size,
                                       array_dynamic=arr_dynamic,
                                       line=ftok.line, col=ftok.col))
            self._end_line("成员声明")
        # 允许「空数据类型」：不声明成员，仅把相关类函数归到一个类型名下
        # （相当于命名空间，例如 lib/core.class 的 数据类型 运算；方法只处理传入的参数）。
        # 调用方式见 checker/codegen：「类型名.方法(参数)」在临时实例上执行。
        return sd

    def _parse_method(self) -> ast.MethodDecl:
        """类函数（数据类型的成员函数）：
        类函数 类型名.函数名(参数...) [返回类型]
            ...
        结束类函数"""
        start = self.next()                          # 吃掉 类函数
        owner_tok = self.expect("ident")
        self.expect("sym", ".")
        name_tok = self.expect("ident")
        m = ast.MethodDecl(owner=owner_tok.text, name=name_tok.text,
                           file=self.filename, line=start.line, col=start.col)
        self.expect("sym", "(")
        self._depth += 1
        try:
            while not self.peek().is_sym(")"):
                m.params.append(self._parse_param("类函数参数"))
                if self.peek().is_sym(","):
                    self.next()
                    continue
                break
            self.expect("sym", ")")
        finally:
            self._depth -= 1
        # 返回类型（可省略；也支持自定义数据类型按值返回）
        pt = self.peek()
        if pt.kind == "ident" and pt.text in self.known_types:
            m.ret_type = self.next().text
        elif pt.kind == "ident" and pt.text in ("空", "无"):
            self.next()
        self._end_line("类函数定义")
        body, stop = self._parse_body_until({"结束类函数"})
        if stop is None:
            raise self.err("缺少 结束类函数", start)
        self.next()                                  # 吃掉 结束类函数
        self._end_line_optional()
        m.body = body
        return m

    def _parse_func(self) -> ast.Func:
        kw_tok = self.next()                     # 子程序 / 测试函数 / 导出子程序
        name_tok = self.expect("ident")
        fn = ast.Func(kind="测试函数" if kw_tok.text == "测试函数" else "子程序",
                      name=name_tok.text, file=self.filename,
                      line=kw_tok.line, col=kw_tok.col)
        fn.export = (kw_tok.text == "导出子程序")   # 导出子程序：DLL 导出函数
        self.expect("sym", "(")
        self._depth += 1
        try:
            while not self.peek().is_sym(")"):
                fn.params.append(self._parse_param("参数"))
                if self.peek().is_sym(","):
                    self.next()
                    continue
                break
            self.expect("sym", ")")
        finally:
            self._depth -= 1
        # 返回类型（可省略；也支持自定义数据类型按值返回）
        pt = self.peek()
        if pt.kind == "ident" and pt.text in self.known_types:
            fn.ret_type = self.next().text
        elif pt.kind == "ident" and pt.text == "空":
            self.next()
        # 可选：自定义 DLL 导出名 —— 导出名 "Add"（仅「导出子程序」可用）
        if self.peek().is_kw("导出名"):
            import re
            kw = self.next()
            if not fn.export:
                raise self.err("只有「导出子程序」才能指定「导出名」", kw)
            nm_tok = self.expect("str")
            nm = str(nm_tok.value).strip()
            if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", nm):
                raise self.err('导出名只能用英文字母、数字与下划线，且以字母或下划线开头（如 导出名 "Add"）',
                               nm_tok)
            fn.export_name = nm
        # 同名子程序不允许与其它冲突在语义阶段检查
        self._end_line("子程序定义")
        # 函数体：测试函数允许用「结束测试函数」收尾，其余用「结束子程序」
        end_kw = "结束测试函数" if fn.kind == "测试函数" else "结束子程序"
        body, stop = self._parse_body_until({end_kw, "结束子程序"})
        if stop is None:
            raise self.err(f"缺少 {end_kw}", fn)
        self.next()                              # 吃掉 结束子程序 / 结束测试函数
        self._end_line_optional()
        fn.body = body
        return fn

    def _parse_api(self) -> ast.ApiDecl:
        """Windows API 声明：
        API 返回类型 名称([参考]类型 参数[[长度|[]]] [传址], ...) 在库 "xxx.dll[,真实API名]"
        写成 "xxx.dll,真实API名" 时，声明名是别名（调用点用它），逗号后是 DLL 里的
        真实导出函数名（WinAPI 函数名，如 在库 "user32.dll,MessageBoxA"）；
        不写逗号时真实名就是声明名本身（兼容旧写法）。参数支持数组与传址。"""
        import re
        start = self.next()                       # 吃掉 API
        pt = self.peek()
        if pt.kind == "ident" and pt.text in ("空", "无"):
            self.next()
            rt = "空"
        else:
            rt = self._parse_type("API 返回类型")
        name_tok = self.expect("ident")
        # 名称习惯为大写英文字母开头（Windows API 惯例，如 MessageBoxW、GetTickCount）；
        # 也允许小写开头（如 wvsprintf）、中英混合（如 wvsprintf_数组）
        # 与中文名 —— 用于按名调用「云易生成的 DLL」里的导出函数
        if not (re.fullmatch(r"[^\W\d][\w]*", name_tok.text, re.UNICODE)):
            raise self.err("API 名称需以英文字母/中文/下划线开头"
                           "（如 MessageBoxW、GetTickCount、wvsprintf_数组），"
                           "或使用中文名（调用云易 DLL 的导出函数）", name_tok)
        api = ast.ApiDecl(ret_type=rt, name=name_tok.text, file=self.filename,
                          line=start.line, col=start.col)
        self.expect("sym", "(")
        self._depth += 1
        try:
            while not self.peek().is_sym(")"):
                api.params.append(self._parse_param("API 参数"))
                if self.peek().is_sym(","):
                    self.next()
                    continue
                break
            self.expect("sym", ")")
        finally:
            self._depth -= 1
        self._require_kw("在库")
        dll = self.expect("str")
        raw = str(dll.value).strip()
        # 在库 "xxx.dll[,真实API名]"：逗号后是 DLL 里的真实导出函数名（声明名是别名）
        parts = [p.strip() for p in raw.split(",")]
        api.dll = parts[0]
        if len(parts) > 2:
            raise self.err('在库 只能写 "DLL名" 或 "DLL名,真实API名"'
                           '（如 在库 "user32.dll,MessageBoxA"）', dll)
        if len(parts) == 2:
            if not parts[1]:
                raise self.err('在库 逗号后要写真实 API 名'
                               '（如 在库 "user32.dll,MessageBoxA"）', dll)
            api.real_name = parts[1]
        if not api.dll:
            raise self.err("API 声明需要填写所在 DLL，例如 在库 \"user32.dll\""
                           " 或 在库 \"user32.dll,MessageBoxA\"", dll)
        self._end_line("API 声明")
        return api

    def _end_line(self, ctx: str):
        t = self.peek()
        if t.kind in ("eof", "newline"):
            if t.kind == "newline":
                self.next()
            return
        raise self.err(f"{ctx}结束后有多余内容：{t.text or t.value!r}", t)

    def _end_line_optional(self):
        if self.peek().kind == "newline":
            self.next()

    # ---------- 语句块 ----------
    def _parse_body_until(self, stop_set: Set[str]):
        """连续解析语句直到遇到 stop_set 中的关键字；返回 (语句列表, 停止token或None)。"""
        stmts: List[ast.Stmt] = []
        while True:
            self.skip_nl()
            t = self.peek()
            if t.kind == "eof":
                return stmts, None
            if t.kind == "ident" and t.text in stop_set:
                return stmts, t
            stmts.append(self._parse_stmt())

    def _parse_stmt(self) -> ast.Stmt:
        t = self.peek()
        if t.kind == "asm":
            # 裸写汇编块：块体已由词法按原文读入（见 lexer._read_asm_block）
            tk = self.next()
            v = tk.value if isinstance(tk.value, dict) else {}
            return ast.AsmBlock(code=v.get("code", "") or "",
                                dialect=v.get("dialect", "") or "",
                                line=tk.line, col=tk.col)
        if t.kind == "hashconst":
            # #常量 出现在语句开头：按表达式语句解析，交给检查器报「常量不能被赋值」
            return self._parse_expr_stmt()
        if t.kind != "ident":
            raise self.err(f"语句应以关键字/赋值/函数调用开始，实际得到 {t.text or t.value!r}", t)
        kw = t.text
        if kw == "变量":
            return self._parse_var_decl()
        if kw == "常量":
            raise self.err("常量仅可定义在顶层（子程序之外）", t)
        if kw == "如果":
            return self._parse_if()
        if kw == "如果真":
            return self._parse_if_true()
        if kw == "判断":
            return self._parse_judge()
        if kw == "计次循环":
            return self._parse_for()
        if kw == "变量循环首":
            return self._parse_for_step()
        if kw == "当循环":
            return self._parse_while({"结束循环"})
        if kw == "判断循环首":
            # 配对结束：判断循环尾（也兼容 结束循环）
            return self._parse_while({"判断循环尾", "结束循环"})
        if kw == "循环判断首":
            return self._parse_do_while()
        if kw == "返回":
            return self._parse_return()
        if kw == "跳出循环":
            self.next()
            self._end_line("跳出循环")
            return ast.BreakStmt(line=t.line, col=t.col)
        if kw == "到循环尾":
            self.next()
            self._end_line("到循环尾")
            return ast.ContinueStmt(line=t.line, col=t.col)
        if kw in LINE_END_KW:
            raise self.err(f"{kw!r} 没有与之匹配的开头语句", t)
        if kw in ASM_END_KW:
            raise self.err(f"{kw!r} 没有与之匹配的 asm 块", t)
        return self._parse_expr_stmt()

    # ---------- 声明 ----------
    def _parse_var_decl(self) -> ast.VarDecl:
        start = self.next()                      # 变量
        name, t = self._parse_name_and_type("变量")
        vd = ast.VarDecl(name=name, type=t, line=start.line, col=start.col)
        if self.peek().is_sym("["):
            self.next()
            # 空方括号「名字[]」→ 动态数组（std::vector），可用 加入成员 / 重定义数组 等命令
            if self.peek().is_sym("]"):
                vd.array_dynamic = True
            else:
                vd.array_size = self._parse_expr()
            self.expect("sym", "]")
            if self.peek().is_sym("["):
                raise self.err("暂不支持多维数组", self.peek())
        # 可选默认值：变量 x 整数型 = 5
        if self.peek().is_sym("="):
            self.next()
            vd.init = self._parse_expr()
        self._end_line("变量声明")
        return vd

    # ---------- 分支 ----------
    def _parse_cond_until(self, until_kw: str) -> ast.Expr:
        """if/while 等条件：可带括号也可不带，直到遇到 until_kw。"""
        if self.peek().is_sym("("):
            self.next()
            self._depth += 1
            try:
                cond = self._parse_expr()
                self.expect("sym", ")")
            finally:
                self._depth -= 1
            return cond
        cond = self._parse_expr()
        return cond

    def _parse_if(self) -> ast.IfStmt:
        start = self.next()                      # 如果
        cond = self._parse_cond_until("那么")
        if self.peek().is_kw("那么"):            # 「那么」可省略：如果 (a > 0) … 结束如果
            self.next()
        self._end_line("如果")
        branches: List[Tuple[Optional[ast.Expr], List[ast.Stmt]]] = []
        else_body: List[ast.Stmt] = []
        body, stop = self._parse_body_until({"结束如果", "否则", "否则如果"})
        branches.append((cond, body))
        while stop is not None and stop.text == "否则如果":
            self.next()                          # 吃掉 否则如果
            c2 = self._parse_cond_until("那么")
            if self.peek().is_kw("那么"):        # 同样可省略
                self.next()
            self._end_line("否则如果")
            body2, stop = self._parse_body_until({"结束如果", "否则", "否则如果"})
            branches.append((c2, body2))
        if stop is not None and stop.text == "否则":
            self.next()
            self._end_line("否则")
            else_body, stop = self._parse_body_until({"结束如果"})
        if stop is None:
            raise self.err("缺少 结束如果", start)
        self.next()                              # 吃掉 结束如果
        self._end_line_optional()
        return ast.IfStmt(branches=branches, else_body=else_body, line=start.line, col=start.col)

    def _parse_if_true(self) -> ast.IfStmt:
        start = self.next()                      # 如果真
        cond = self._parse_cond_until("那么")    # 那么 可选
        if self.peek().is_kw("那么"):
            self.next()
        self._end_line("如果真")
        body, stop = self._parse_body_until({"结束如果真"})
        if stop is None:
            raise self.err("缺少 结束如果真", start)
        self.next()
        self._end_line_optional()
        return ast.IfStmt(branches=[(cond, body)], else_body=[], line=start.line, col=start.col)

    def _parse_judge(self) -> ast.IfStmt:
        """易语言式「判断」链，以「结束判断」收尾：
        判断 (条件1)
            …
        判断 (条件2)
            …
        结束判断
        连续多个「判断」行构成一个整体：从上到下逐个检查条件，
        哪个条件成立就执行哪一段，然后跳出整段（同 如果 / 否则如果 链）。
        规则：
          · 分支体必须比「判断」缩进更深（列位置更大）；
          · 同缩进的下一个「判断」并入同一条链；
          · 同缩进的「结束判断」结束整条链（嵌套的判断链自带自己的「结束判断」）；
          · 链必须以「结束判断」结束，否则报错。"""
        start = self.next()                      # 判断
        col0 = start.col                         # 链的基准缩进
        branches: List[Tuple[Optional[ast.Expr], List[ast.Stmt]]] = []
        cond = self._parse_cond_until("那么")    # 那么 可选
        if self.peek().is_kw("那么"):
            self.next()
        self._end_line("判断")
        while True:
            body, stop = self._judge_body(col0)
            branches.append((cond, body))
            if stop == "判断":                   # 同缩进的下一个 判断 → 并入链
                self.next()
                cond = self._parse_cond_until("那么")
                if self.peek().is_kw("那么"):
                    self.next()
                self._end_line("判断")
                continue
            if stop == "结束判断":                # 同缩进的 结束判断 → 收尾
                self.next()
                self._end_line_optional()
                break
            # stop 为 None / 更浅列：链没有用「结束判断」收尾
            raise self.err("缺少 结束判断", start)
        return ast.IfStmt(branches=branches, else_body=[], line=start.line, col=start.col)

    def _judge_body(self, col0: int):
        """解析一个判断分支的语句体。
        返回 (语句列表, 停止标记)：标记可以是 '判断'（同缩进的链延续）、
        '结束判断'（同缩进的收尾）、或 None（外层块结束关键字 / eof / 更浅列）。
        嵌套的判断链由 _parse_stmt 递归解析并自带「结束判断」，不会在此中断。"""
        # 外层块的结束关键字（注意：本链自身的「结束判断」需单独识别，不能算外层）
        outer_stop = (LINE_END_KW - {"结束判断"}) | {"判断循环尾"}
        body: List[ast.Stmt] = []
        while True:
            self.skip_nl()
            t = self.peek()
            if t.kind == "eof":
                return body, None
            if t.kind == "ident" and t.text == "结束判断":
                if t.col <= col0:
                    return body, "结束判断" if t.col == col0 else None
                body.append(self._parse_stmt())   # 更深的 结束判断（异常，交给递归/报错）
                continue
            if t.kind == "ident" and t.text in outer_stop:
                return body, None                # 外层块结束关键字，交还外层
            if t.kind == "ident":
                if t.text == "判断":
                    if t.col <= col0:
                        return body, "判断" if t.col == col0 else None
                    body.append(self._parse_stmt())   # 更深 → 嵌套判断链
                    continue
            body.append(self._parse_stmt())

    def _require_kw(self, kw: str):
        t = self.peek()
        if not (t.kind == "ident" and t.text == kw):
            raise self.err(f"缺少关键字 {kw!r}，实际为 {t.text or t.value!r}", t)
        self.next()

    # ---------- 循环 ----------
    def _parse_for(self) -> ast.ForRange:
        start = self.next()                      # 计次循环
        if self.peek().is_sym("("):
            self.next()
            self._depth += 1
            try:
                var = self.expect("ident").text
                self.expect("sym", ",")
                s = self._parse_expr()
                self.expect("sym", ",")
                e = self._parse_expr()
                self.expect("sym", ")")
            finally:
                self._depth -= 1
        else:
            var = self.expect("ident").text
            self.expect("sym", ",")
            s = self._parse_expr()
            self.expect("sym", ",")
            e = self._parse_expr()
        self._end_line("计次循环")
        body, stop = self._parse_body_until({"结束循环"})
        if stop is None:
            raise self.err("缺少 结束循环", start)
        self.next()
        self._end_line_optional()
        return ast.ForRange(var=var, start=s, end=e, body=body, line=start.line, col=start.col)

    def _parse_for_step(self) -> ast.ForRange:
        """变量循环首（起始值, 目标值, 步长, 循环变量）… 结束循环 —— 带步长的循环。"""
        start = self.next()                      # 变量循环首
        if self.peek().is_sym("("):
            self.next()
            self._depth += 1
            try:
                s = self._parse_expr()
                self.expect("sym", ",")
                e = self._parse_expr()
                self.expect("sym", ",")
                step = self._parse_expr()
                self.expect("sym", ",")
                var = self.expect("ident").text
                self.expect("sym", ")")
            finally:
                self._depth -= 1
        else:
            s = self._parse_expr()
            self.expect("sym", ",")
            e = self._parse_expr()
            self.expect("sym", ",")
            step = self._parse_expr()
            self.expect("sym", ",")
            var = self.expect("ident").text
        self._end_line("变量循环首")
        body, stop = self._parse_body_until({"结束循环"})
        if stop is None:
            raise self.err("缺少 结束循环", start)
        self.next()
        self._end_line_optional()
        return ast.ForRange(var=var, start=s, end=e, step=step, body=body,
                            line=start.line, col=start.col)

    def _parse_while(self, stop_set=None) -> ast.WhileStmt:
        stop_set = stop_set or {"结束循环"}
        start = self.next()
        cond = self._parse_cond_until("")
        self._end_line("循环条件")
        body, stop = self._parse_body_until(stop_set)
        if stop is None:
            raise self.err(f"缺少 {' / '.join(sorted(stop_set))}", start)
        self.next()
        self._end_line_optional()
        return ast.WhileStmt(cond=cond, body=body, line=start.line, col=start.col)

    def _parse_do_while(self) -> ast.DoWhileStmt:
        start = self.next()                      # 循环判断首（首部无条件，条件在尾部）
        self._end_line("循环判断首")
        body, stop = self._parse_body_until({"循环判断尾"})
        if stop is None:
            raise self.err("缺少 循环判断尾", start)
        self.next()                              # 吃掉 循环判断尾
        cond2 = self._parse_cond_until("")
        self._end_line("循环判断尾 条件")
        return ast.DoWhileStmt(cond=cond2, body=body, line=start.line, col=start.col)

    # ---------- 返回 / 表达式语句 ----------
    def _parse_return(self) -> ast.ReturnStmt:
        start = self.next()                      # 返回
        r = ast.ReturnStmt(line=start.line, col=start.col)
        if self.peek().kind == "newline" or self.peek().kind == "eof":
            self._end_line("返回")
            return r
        if self.peek().is_sym("("):
            self.next()
            self._depth += 1
            try:
                if self.peek().is_sym(")"):
                    pass
                else:
                    r.expr = self._parse_expr()
                self.expect("sym", ")")
            finally:
                self._depth -= 1
        else:
            r.expr = self._parse_expr()
        self._end_line("返回")
        return r

    def _parse_expr_stmt(self) -> ast.Stmt:
        t = self.peek()
        save = self.i
        # 先按"左值(=名称/数组元素)+赋值号"尝试：x = 5、a[0] += 2
        try:
            lhs = self._parse_postfix()
        except YyError:
            self.i = save
            lhs = None
        pt = self.peek()
        if (pt.kind == "sym" and pt.value in ("=", "+=", "-=", "*=", "/=")
                and isinstance(lhs, (ast.Name, ast.Index, ast.Member))):
            op = self.next().value
            rhs = self._parse_expr()
            self._end_line("赋值语句")
            return ast.Assign(target=lhs, op=op, value=rhs, line=t.line, col=t.col)
        # 不是赋值：回退后按完整表达式解析（必须是函数调用）
        self.i = save
        expr = self._parse_expr()
        if not isinstance(expr, ast.Call):
            raise self.err("独立语句必须是函数调用或赋值", t)
        self._end_line("语句")
        return ast.ExprStmt(expr=expr, line=t.line)

    # ---------- 表达式（优先级爬升） ----------
    def _parse_expr(self) -> ast.Expr:
        return self._parse_or()

    def _eat_nl_if_nested(self):
        while self._depth > 0 and self.peek().kind == "newline":
            self.i += 1

    def _bin_op_next(self, ops: set) -> Optional[str]:
        self._eat_nl_if_nested()
        t = self.peek()
        if t.kind == "sym" and t.value in ops:
            self.next()
            return t.value
        if t.kind == "ident":
            # 中文别名检查：只查与 ops 对应的别名集（避免 _parse_add/_parse_mul 误吞 或/且）。
            # 判断方式：该别名对应的符号别名（&&/||）是否在 ops 里。
            for words, alias_name in ((AND_WORDS, "且"), (OR_WORDS, "或")):
                if t.text in words and (words & ops):
                    self.next()
                    return alias_name
        return None

    def _parse_or(self) -> ast.Expr:
        """或 链：`x = 1 或 x = 2` → 或(x=1, x=2)。
        左操作数 = 一个「且 链」（_parse_and）；遇到 或 后，右操作数递归回 _parse_or，
        这样连续多个 或 自然右结合：`a 或 b 或 c` → a 或 (b 或 c)。
        关键：左操作数只到 且 链为止（不再往下吞 或），右操作数递归回 或 级，
        这样 `a = x 或 a = y` 解析为 或(a=x, a=y)，而不是 ((a=x) 或 a) = y。"""
        left = self._parse_and()
        op = self._bin_op_next(OR_WORDS)
        if op is None:
            return left
        right = self._parse_or()
        return ast.Binary(op="或", left=left, right=right, line=left.line, col=left.col)

    def _parse_and(self) -> ast.Expr:
        """且 链：与 _parse_or 同构。`x = 1 且 x = 2` → 且(x=1, x=2)。"""
        left = self._parse_cmp()
        op = self._bin_op_next(AND_WORDS)
        if op is None:
            return left
        right = self._parse_and()
        return ast.Binary(op="且", left=left, right=right, line=left.line, col=left.col)

    def _parse_cmp(self) -> ast.Expr:
        left = self._parse_add()
        while True:
            op = self._bin_op_next(EQ_OPS.keys() | CMP_OPS.keys())
            if op is None:
                return left
            right = self._parse_add()
            norm = EQ_OPS.get(op, op)
            left = ast.Binary(op=norm, left=left, right=right, line=left.line, col=left.col)

    def _parse_add(self) -> ast.Expr:
        left = self._parse_mul()
        while True:
            op = self._bin_op_next(ADD_OPS.keys())
            if op is None:
                return left
            right = self._parse_mul()
            left = ast.Binary(op=op, left=left, right=right, line=left.line, col=left.col)

    def _parse_mul(self) -> ast.Expr:
        left = self._parse_unary()
        while True:
            op = self._bin_op_next(MUL_OPS.keys())
            if op is None:
                return left
            right = self._parse_unary()
            norm = MUL_OPS.get(op, op)
            left = ast.Binary(op=norm, left=left, right=right, line=left.line, col=left.col)

    def _parse_unary(self) -> ast.Expr:
        self._eat_nl_if_nested()
        t = self.peek()
        if t.kind == "sym" and t.value in ("-", "+", "!", "~"):
            self.next()
            operand = self._parse_unary()
            return ast.Unary(op=t.value, operand=operand, line=t.line, col=t.col)
        if t.kind == "ident" and t.text in NOT_WORDS:
            self.next()
            operand = self._parse_unary()
            return ast.Unary(op="!", operand=operand, line=t.line, col=t.col)
        return self._parse_postfix()

    def _parse_postfix(self) -> ast.Expr:
        e = self._parse_primary()
        while True:
            self._eat_nl_if_nested()
            t = self.peek()
            if t.is_sym("["):
                self.next()
                self._depth += 1
                try:
                    idx = self._parse_expr()
                    self.expect("sym", "]")
                finally:
                    self._depth -= 1
                e = ast.Index(base=e, index=idx, line=e.line, col=e.col)
            elif t.is_sym("."):
                self.next()
                m = self.expect("ident")
                if self.peek().is_sym("("):          # 类函数（成员函数）调用
                    self.next()
                    self._depth += 1
                    try:
                        args = []
                        while not self.peek().is_sym(")"):
                            args.append(self._parse_expr())
                            if self.peek().is_sym(","):
                                self.next()
                                continue
                            break
                        self.expect("sym", ")")
                    finally:
                        self._depth -= 1
                    e = ast.Call(func=m.text, args=args, obj=e, line=e.line, col=e.col)
                else:
                    e = ast.Member(base=e, name=m.text, line=e.line, col=e.col)
            else:
                return e

    def _parse_primary(self) -> ast.Expr:
        self._eat_nl_if_nested()
        t = self.peek()
        if t.kind == "num":
            self.next()
            return ast.NumLit(value=t.value, raw=t.text, line=t.line, col=t.col)
        if t.kind == "str":
            self.next()
            return ast.StrLit(value=str(t.value), line=t.line, col=t.col)
        if t.kind == "ident":
            if t.text == "真":
                self.next()
                return ast.BoolLit(value=True, line=t.line, col=t.col)
            if t.text == "假":
                self.next()
                return ast.BoolLit(value=False, line=t.line, col=t.col)
            name = self.next()
            if self.peek().is_sym("("):
                return self._parse_call(name)
            return ast.Name(id=name.text, line=name.line, col=name.col)
        if t.kind == "hashconst":
            # 常量引用：#名称（常量不是子程序，后面跟「(」直接报错）
            self.next()
            if self.peek().is_sym("("):
                raise self.err(f"常量 {t.value} 不能被调用", t)
            return ast.Name(id=t.value, is_const=True, line=t.line, col=t.col)
        if t.is_sym("("):
            self.next()
            self._depth += 1
            try:
                e = self._parse_expr()
                self.expect("sym", ")")
            finally:
                self._depth -= 1
            return e
        raise self.err(f"表达式错误：不能以 {t.text or t.value!r} 开头", t)

    def _parse_call(self, name_tok: Token) -> ast.Call:
        self.next()                              # (
        self._depth += 1
        args: List[ast.Expr] = []
        try:
            self._eat_nl_if_nested()
            while not self.peek().is_sym(")"):
                args.append(self._parse_expr())
                self._eat_nl_if_nested()
                if self.peek().is_sym(","):
                    self.next()
                    self._eat_nl_if_nested()
                    continue
                break
            self.expect("sym", ")")
        finally:
            self._depth -= 1
        return ast.Call(func=name_tok.text, args=args, line=name_tok.line, col=name_tok.col)


# ---------- 便捷函数 ----------
def parse_source(source: str, filename: str = "", extra_types=None,
                 require_funcs: bool = True) -> ast.Program:
    """extra_types：额外已知类型名（类库数据类型）；
    require_funcs=False 允许没有子程序（解析 lib/*.class 类库片段用）。"""
    prog = Parser(tokenize(source, filename), filename, extra_types).parse_program(require_funcs)
    for g in prog.globals_:
        g.file = filename
    for c in prog.consts:
        c.file = filename
    for f in prog.funcs:
        f.file = filename
    for m in getattr(prog, "methods", []):
        m.file = filename
    for a in prog.apis:
        a.file = filename
    return prog


def parse_files(files: List[Tuple[str, str]], extra_types=None) -> ast.Program:
    """files: [(文件名, 源码文本), ...]
    extra_types: 额外的已知类型名集合（类库 lib/*.class 的数据类型）"""
    prog = ast.Program()
    seen_funcs = set()
    seen_structs = set()
    seen_methods = set()
    for fname, src in files:
        p = parse_source(src, fname, extra_types)
        prog.files.append(fname)
        prog.globals_.extend(p.globals_)
        prog.consts.extend(p.consts)
        for s in getattr(p, "structs", []):
            if s.name in seen_structs:
                raise YyError(f"重复定义数据类型 {s.name!r}", s.line, s.col, fname)
            seen_structs.add(s.name)
            prog.structs.append(s)
        for m in getattr(p, "methods", []):
            key = m.owner + "." + m.name
            if key in seen_methods:
                raise YyError(f"重复定义类函数 {key!r}", m.line, m.col, fname)
            seen_methods.add(key)
            prog.methods.append(m)
        prog.apis.extend(p.apis)
        for f in p.funcs:
            if f.name in seen_funcs:
                raise YyError(f"重复定义子程序 {f.name!r}", f.line, f.col, fname)
            seen_funcs.add(f.name)
            prog.funcs.append(f)
    return prog
