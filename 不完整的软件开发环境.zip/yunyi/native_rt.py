# -*- coding: utf-8 -*-
"""云易「原生模式」运行时片段（英文标识符）。

「导出 C++」时若选 native（纯正 C++），生成器会把中文类型名换成 int/std::string，
把中文内置函数换成这里的英文实现，并按需注入到生成的文件里 —— 这样产出的 .cpp
不再 #include "yunyi_rt.hpp"，也不需要任何中文转译层。

NATIVE_FUNCS: 中文内置函数名 → (英文函数名, 实现代码)
  * 只有真正出现在生成代码里的函数才会被注入
  * 实现尽量与 yunyi_rt.hpp 保持同样的语义（含返回值取整、)](等约定）
"""
from __future__ import annotations

# 中文类型 → 原生 C++ 类型
NATIVE_TYPE = {
    "逻辑型": "bool",
    "字节型": "unsigned char",
    "短整数型": "short",
    "整数型": "int",
    "长整数型": "long long",
    "小数型": "float",
    "文本型": "std::string",
    "日期时间型": "long long",
    "双精度小数型": "double",
    "子程序指针": "long long",
    "字节集": "std::vector<unsigned char>",
    "空": "void",
}

# 布尔字面量
NATIVE_LIT = {"真": "true", "假": "false"}

# DLL 名 → 需要链接的库（kernel32 / user32 默认已链，这里只列额外的）
DLL_LIBS = {
    "kernel32.dll": "",
    "user32.dll": "user32",
    "gdi32.dll": "gdi32",
    "shlwapi.dll": "shlwapi",
    "comctl32.dll": "comctl32",
    "advapi32.dll": "advapi32",
    "shell32.dll": "shell32",
    "ole32.dll": "ole32",
    "oleaut32.dll": "oleaut32",
    "winmm.dll": "winmm",
    "ws2_32.dll": "ws2_32",
    "wsock32.dll": "wsock32",
    "wininet.dll": "wininet",
    "msimg32.dll": "msimg32",
    "comdlg32.dll": "comdlg32",
    "version.dll": "version",
    "winspool.drv": "winspool",
    "psapi.dll": "psapi",
    "uuid.dll": "uuid",
    "dwmapi.dll": "dwmapi",
    "winhttp.dll": "winhttp",
    "iphlpapi.dll": "iphlpapi",
    "crypt32.dll": "crypt32",
    "netapi32.dll": "netapi32",
    "userenv.dll": "userenv",
    "setupapi.dll": "setupapi",
    "dnsapi.dll": "dnsapi",
    "secur32.dll": "secur32",
    "mpr.dll": "mpr",
    "imm32.dll": "imm32",
    "opengl32.dll": "opengl32",
    "glu32.dll": "glu32",
    "hid.dll": "hid",
    "winusb.dll": "winusb",
    "ntdll.dll": "ntdll",
    "PowrProf.dll": "PowrProf",
    "propsys.dll": "propsys",
    "d2d1.dll": "d2d1",
    "dwrite.dll": "dwrite",
    "windowscodecs.dll": "windowscodecs",
    "sensapi.dll": "sensapi",
}

# 特殊 API 的实参转换表：C++ 编译器 intrinsic / 重载函数（如 Interlocked* 系列）
# 无法按「云易声明」直接取函数指针，这里按真实 Win32 签名给出逐参数 cast，
# {a} 是调用点参数表达式。仅当参数个数与声明一致时启用。
KNOWN_API_SIGS = {
    "InterlockedExchange": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})"],
    "InterlockedExchangeAdd": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})"],
    "InterlockedIncrement": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))"],
    "InterlockedDecrement": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))"],
    "InterlockedCompareExchange": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})",
        "static_cast<long>({a})"],
    "InterlockedAnd": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})"],
    "InterlockedOr": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})"],
    "InterlockedXor": [
        "reinterpret_cast<volatile long*>(static_cast<uintptr_t>({a}))",
        "static_cast<long>({a})"],
}

# shlwapi 的 Str*/Path* 是 cdecl 平名导出：不能按 __stdcall 重声明，
# 直接用 <shlwapi.h> 的真实声明调用（见 KNOWN_API_SIGS）。
_PIN = "yynative::wc({a}).c_str()"      # LPCWSTR 输入串（文本型 / 宽串地址都行）
_POUT = "reinterpret_cast<LPWSTR>(static_cast<uintptr_t>({a}))"   # LPWSTR 输出缓冲
_IN2 = [_PIN, _PIN]
KNOWN_API_SIGS.update({
    "StrCpyW": [_POUT, _PIN],
    "StrCatW": [_POUT, _PIN],
    "StrCpyNW": [_POUT, _PIN, "static_cast<int>({a})"],
    "StrCatBuffW": [_POUT, _PIN, "static_cast<int>({a})"],
    "StrCmpW": _IN2, "StrCmpIW": _IN2,
    "StrStrW": _IN2, "StrStrIW": _IN2,
    "StrCmpNW": [_PIN, _PIN, "static_cast<int>({a})"],
    "StrCmpNIW": [_PIN, _PIN, "static_cast<int>({a})"],
    "StrChrW": [_PIN, "static_cast<wchar_t>({a})"],
    "StrRChrW": [_PIN, "static_cast<wchar_t>({a})"],
    "StrToIntW": [_PIN],
    "PathFileExistsW": [_PIN],
    "PathIsDirectoryW": [_PIN],
    "PathFindFileNameW": [_PIN],
    "PathFindExtensionW": [_PIN],
    "PathRemoveFileSpecW": [_POUT],
    "PathRemoveExtensionW": [_POUT],
    "PathStripPathW": [_POUT],
    "PathAddBackslashW": [_POUT],
    "PathAppendW": [_POUT, _PIN],
    "PathCombineW": [_POUT, _PIN, _PIN],
    "PathQuoteSpacesW": [_POUT],
})


# ---------------------------------------------------------------------------
# 常见 Win32 API 的真实 C 签名表（native 模式「直接调用」用）
# ---------------------------------------------------------------------------
# 一旦某个 API 出现在本表里，native 导出就 *直接* 生成 ::API(实参…) 调用，
# 并按真实形参类型在调用点显式 cast（句柄/指针按 intptr_t 中转，x86/x64 都安全），
# 不再走 yynative 的 api_call / arg_cast 模板翻译层。
#
# 约定：
#   · 值格式  "API名": ("返回类型", ["形参类型", ...])
#   · 文本形参（云易声明为 文本型）且真实类型为 LPCWSTR/LPCSTR → 自动 to_wide().c_str()
#   · 文本形参但真实类型是指针/整数型（如 SendMessageW 的 LPARAM 收字符串）→ 传宽串地址
#   · 其余指针/句柄类型 → reinterpret_cast<真实类型>(static_cast<intptr_t>(云易整数))
#   · 其余整数/浮点类型 → static_cast<真实类型>(云易整数)
# 不在本表、也不在 KNOWN_API_SIGS 的 API 自动回退到通用翻译层（保留完整脚手架）。
WIN32_PTR_TYPEDEFS = {
    "HINSTANCE", "HMODULE", "HANDLE", "HWND", "HMENU", "HICON", "HCURSOR",
    "HBRUSH", "HGDIOBJ", "HBITMAP", "HDC", "HFONT", "HACCEL", "HRGN",
    "HLOCAL", "HGLOBAL", "FARPROC", "HKEY", "HTREEITEM", "HDROP",
    "HBLOB", "WNDPROC", "TIMERPROC", "SUBCLASSPROC",
    "LPCWSTR", "LPCSTR", "LPWSTR", "LPSTR", "LPTSTR", "LPCVOID",
    "PVOID", "LPVOID",
}

WIN32_SIGS = {
    # ---- kernel32 ----
    "GetModuleHandleW": ("HMODULE", ["LPCWSTR"]),
    "GetModuleHandleA": ("HMODULE", ["LPCSTR"]),
    "LoadLibraryW": ("HMODULE", ["LPCWSTR"]),
    "LoadLibraryA": ("HMODULE", ["LPCSTR"]),
    "FreeLibrary": ("BOOL", ["HMODULE"]),
    "GetProcAddress": ("FARPROC", ["HMODULE", "LPCSTR"]),
    "GetModuleFileNameW": ("DWORD", ["HMODULE", "LPWSTR", "DWORD"]),
    "LocalAlloc": ("HLOCAL", ["UINT", "SIZE_T"]),
    "LocalFree": ("HLOCAL", ["HLOCAL"]),
    "GlobalAlloc": ("HGLOBAL", ["UINT", "SIZE_T"]),
    "GlobalFree": ("HGLOBAL", ["HGLOBAL"]),
    "GetLastError": ("DWORD", []),
    "SetLastError": ("void", ["DWORD"]),
    "lstrcpyW": ("LPWSTR", ["LPWSTR", "LPCWSTR"]),
    "lstrcatW": ("LPWSTR", ["LPWSTR", "LPCWSTR"]),
    "lstrlenW": ("int", ["LPCWSTR"]),
    "OutputDebugStringW": ("void", ["LPCWSTR"]),
    "GetCommandLineW": ("LPWSTR", []),
    "GetEnvironmentVariableW": ("DWORD", ["LPCWSTR", "LPWSTR", "DWORD"]),
    "SetEnvironmentVariableW": ("BOOL", ["LPCWSTR", "LPCWSTR"]),
    "GetCurrentDirectoryW": ("DWORD", ["DWORD", "LPWSTR"]),
    "SetCurrentDirectoryW": ("BOOL", ["LPCWSTR"]),
    "CreateDirectoryW": ("BOOL", ["LPCWSTR", "SECURITY_ATTRIBUTES*"]),
    "RemoveDirectoryW": ("BOOL", ["LPCWSTR"]),
    "FindFirstFileW": ("HANDLE", ["LPCWSTR", "WIN32_FIND_DATAW*"]),
    "FindNextFileW": ("BOOL", ["HANDLE", "WIN32_FIND_DATAW*"]),
    "FindClose": ("BOOL", ["HANDLE"]),
    "CopyFileW": ("BOOL", ["LPCWSTR", "LPCWSTR", "BOOL"]),
    "MoveFileW": ("BOOL", ["LPCWSTR", "LPCWSTR"]),
    "DeleteFileW": ("BOOL", ["LPCWSTR"]),
    "GetFileAttributesW": ("DWORD", ["LPCWSTR"]),
    "SetFileAttributesW": ("BOOL", ["LPCWSTR", "DWORD"]),
    "CreateProcessW": ("BOOL", ["LPCWSTR", "LPWSTR", "SECURITY_ATTRIBUTES*",
                                "SECURITY_ATTRIBUTES*", "BOOL", "DWORD",
                                "LPVOID", "LPCWSTR", "STARTUPINFOW*",
                                "PROCESS_INFORMATION*"]),
    "GetExitCodeProcess": ("BOOL", ["HANDLE", "DWORD*"]),
    "WaitForSingleObject": ("DWORD", ["HANDLE", "DWORD"]),
    "CloseHandle": ("BOOL", ["HANDLE"]),
    "Sleep": ("void", ["DWORD"]),
    "GetTickCount": ("DWORD", []),
    "GetSystemTime": ("void", ["SYSTEMTIME*"]),
    "GetLocalTime": ("void", ["SYSTEMTIME*"]),
    "MulDiv": ("int", ["int", "int", "int"]),
    "WinExec": ("UINT", ["LPCSTR", "UINT"]),
    "ExitProcess": ("void", ["UINT"]),
    "TerminateProcess": ("BOOL", ["HANDLE", "UINT"]),
    "GetStdHandle": ("HANDLE", ["DWORD"]),
    "WriteConsoleW": ("BOOL", ["HANDLE", "LPCWSTR", "DWORD", "DWORD*", "LPVOID"]),
    "ReadConsoleW": ("BOOL", ["HANDLE", "LPWSTR", "DWORD", "DWORD*", "LPVOID"]),
    "SetConsoleTitleW": ("BOOL", ["LPCWSTR"]),
    "IsBadReadPtr": ("BOOL", ["LPCVOID", "UINT_PTR"]),
    "GetVersionExW": ("BOOL", ["OSVERSIONINFOW*"]),
    # ---- user32 ----
    "LoadCursorW": ("HCURSOR", ["HINSTANCE", "LPCWSTR"]),
    "LoadIconW": ("HICON", ["HINSTANCE", "LPCWSTR"]),
    "LoadImageW": ("HANDLE", ["HINSTANCE", "LPCWSTR", "UINT", "int", "int", "UINT"]),
    "CreateCursor": ("HCURSOR", ["HINSTANCE", "int", "int", "int", "int", "LPCVOID", "LPCVOID"]),
    "GetSysColorBrush": ("HBRUSH", ["int"]),
    "RegisterClassExW": ("ATOM", ["const WNDCLASSEXW*"]),
    "UnregisterClassW": ("BOOL", ["LPCWSTR", "HINSTANCE"]),
    "CreateWindowExW": ("HWND", ["DWORD", "LPCWSTR", "LPCWSTR", "DWORD", "int", "int",
                                 "int", "int", "HWND", "HMENU", "HINSTANCE", "LPVOID"]),
    "DestroyWindow": ("BOOL", ["HWND"]),
    "ShowWindow": ("BOOL", ["HWND", "int"]),
    "ShowWindowAsync": ("BOOL", ["HWND", "int"]),
    "UpdateWindow": ("BOOL", ["HWND"]),
    "SetWindowTextW": ("BOOL", ["HWND", "LPCWSTR"]),
    "GetWindowTextW": ("int", ["HWND", "LPWSTR", "int"]),
    "GetWindowTextLengthW": ("int", ["HWND"]),
    "EnableWindow": ("BOOL", ["HWND", "BOOL"]),
    "IsWindowEnabled": ("BOOL", ["HWND"]),
    "IsWindowVisible": ("BOOL", ["HWND"]),
    "MoveWindow": ("BOOL", ["HWND", "int", "int", "int", "int", "BOOL"]),
    "SetWindowPos": ("BOOL", ["HWND", "HWND", "int", "int", "int", "int", "UINT"]),
    "GetWindowRect": ("BOOL", ["HWND", "RECT*"]),
    "GetClientRect": ("BOOL", ["HWND", "RECT*"]),
    "InvalidateRect": ("BOOL", ["HWND", "const RECT*", "BOOL"]),
    "ValidateRect": ("BOOL", ["HWND", "const RECT*"]),
    "RedrawWindow": ("BOOL", ["HWND", "const RECT*", "HRGN", "UINT"]),
    "GetMessageW": ("BOOL", ["MSG*", "HWND", "UINT", "UINT"]),
    "PeekMessageW": ("BOOL", ["MSG*", "HWND", "UINT", "UINT", "UINT"]),
    "TranslateMessage": ("BOOL", ["const MSG*"]),
    "DispatchMessageW": ("LRESULT", ["const MSG*"]),
    "PostMessageW": ("BOOL", ["HWND", "UINT", "WPARAM", "LPARAM"]),
    "SendMessageW": ("LRESULT", ["HWND", "UINT", "WPARAM", "LPARAM"]),
    "PostQuitMessage": ("void", ["int"]),
    "DefWindowProcW": ("LRESULT", ["HWND", "UINT", "WPARAM", "LPARAM"]),
    "CallWindowProcW": ("LRESULT", ["WNDPROC", "HWND", "UINT", "WPARAM", "LPARAM"]),
    "MessageBoxW": ("int", ["HWND", "LPCWSTR", "LPCWSTR", "UINT"]),
    "SetTimer": ("UINT_PTR", ["HWND", "UINT_PTR", "UINT", "TIMERPROC"]),
    "KillTimer": ("BOOL", ["HWND", "UINT_PTR"]),
    "GetDlgItem": ("HWND", ["HWND", "int"]),
    "SendDlgItemMessageW": ("LRESULT", ["HWND", "int", "UINT", "WPARAM", "LPARAM"]),
    "SetDlgItemTextW": ("BOOL", ["HWND", "int", "LPCWSTR"]),
    "GetDlgItemTextW": ("int", ["HWND", "int", "LPWSTR", "int"]),
    "GetWindowLongW": ("LONG", ["HWND", "int"]),
    "SetWindowLongW": ("LONG", ["HWND", "int", "LONG"]),
    "GetWindowLongPtrW": ("LONG_PTR", ["HWND", "int"]),
    "SetWindowLongPtrW": ("LONG_PTR", ["HWND", "int", "LONG_PTR"]),
    "GetParent": ("HWND", ["HWND"]),
    "SetParent": ("HWND", ["HWND", "HWND"]),
    "GetForegroundWindow": ("HWND", []),
    "SetForegroundWindow": ("BOOL", ["HWND"]),
    "GetActiveWindow": ("HWND", []),
    "SetActiveWindow": ("HWND", ["HWND"]),
    "BringWindowToTop": ("BOOL", ["HWND"]),
    "IsWindow": ("BOOL", ["HWND"]),
    "GetDesktopWindow": ("HWND", []),
    "GetWindow": ("HWND", ["HWND", "UINT"]),
    "GetClassNameW": ("int", ["HWND", "LPWSTR", "int"]),
    "SetFocus": ("HWND", ["HWND"]),
    "GetFocus": ("HWND", []),
    "SetCursor": ("HCURSOR", ["HCURSOR"]),
    "SetCursorPos": ("BOOL", ["int", "int"]),
    "GetCursorPos": ("BOOL", ["POINT*"]),
    "ScreenToClient": ("BOOL", ["HWND", "POINT*"]),
    "ClientToScreen": ("BOOL", ["HWND", "POINT*"]),
    "BeginPaint": ("HDC", ["HWND", "PAINTSTRUCT*"]),
    "EndPaint": ("BOOL", ["HWND", "const PAINTSTRUCT*"]),
    "GetDC": ("HDC", ["HWND"]),
    "GetWindowDC": ("HDC", ["HWND"]),
    "ReleaseDC": ("int", ["HWND", "HDC"]),
    "DeleteDC": ("BOOL", ["HDC"]),
    "GetSystemMetrics": ("int", ["int"]),
    "SystemParametersInfoW": ("BOOL", ["UINT", "UINT", "PVOID", "UINT"]),
    "GetKeyState": ("SHORT", ["int"]),
    "GetAsyncKeyState": ("SHORT", ["int"]),
    "SendInput": ("UINT", ["UINT", "INPUT*", "int"]),
    "OpenClipboard": ("BOOL", ["HWND"]),
    "CloseClipboard": ("BOOL", []),
    "EmptyClipboard": ("BOOL", []),
    "SetClipboardData": ("HANDLE", ["UINT", "HANDLE"]),
    "GetClipboardData": ("HANDLE", ["UINT"]),
    "IsClipboardFormatAvailable": ("BOOL", ["UINT"]),
    "CreateMenu": ("HMENU", []),
    "CreatePopupMenu": ("HMENU", []),
    "AppendMenuW": ("BOOL", ["HMENU", "UINT", "UINT_PTR", "LPCWSTR"]),
    "DestroyMenu": ("BOOL", ["HMENU"]),
    "SetMenu": ("BOOL", ["HWND", "HMENU"]),
    "GetMenu": ("HMENU", ["HWND"]),
    "DrawMenuBar": ("BOOL", ["HWND"]),
    "EnableMenuItem": ("BOOL", ["HMENU", "UINT", "UINT"]),
    "CheckMenuItem": ("DWORD", ["HMENU", "UINT", "UINT"]),
    "TrackMouseEvent": ("BOOL", ["TRACKMOUSEEVENT*"]),
    "RegisterHotKey": ("BOOL", ["HWND", "int", "UINT", "UINT"]),
    "UnregisterHotKey": ("BOOL", ["HWND", "int"]),
    "CreateAcceleratorTableW": ("HACCEL", ["ACCEL*", "int"]),
    "TranslateAcceleratorW": ("int", ["HWND", "HACCEL", "MSG*"]),
    "GetWindowSubclass": ("BOOL", ["HWND", "SUBCLASSPROC", "UINT_PTR", "DWORD_PTR*"]),
    # ---- gdi32 ----
    "TextOutW": ("BOOL", ["HDC", "int", "int", "LPCWSTR", "int"]),
    "DrawTextW": ("int", ["HDC", "LPCWSTR", "int", "RECT*", "UINT"]),
    "Rectangle": ("BOOL", ["HDC", "int", "int", "int", "int"]),
    "Ellipse": ("BOOL", ["HDC", "int", "int", "int", "int"]),
    "RoundRect": ("BOOL", ["HDC", "int", "int", "int", "int", "int", "int"]),
    "MoveToEx": ("BOOL", ["HDC", "int", "int", "POINT*"]),
    "LineTo": ("BOOL", ["HDC", "int", "int"]),
    "SetTextColor": ("COLORREF", ["HDC", "COLORREF"]),
    "SetBkColor": ("COLORREF", ["HDC", "COLORREF"]),
    "SetBkMode": ("int", ["HDC", "int"]),
    "SetTextAlign": ("UINT", ["HDC", "UINT"]),
    "CreateSolidBrush": ("HBRUSH", ["COLORREF"]),
    "CreateBrushIndirect": ("HBRUSH", ["LOGBRUSH*"]),
    "CreatePen": ("HPEN", ["int", "int", "COLORREF"]),
    "SelectObject": ("HGDIOBJ", ["HDC", "HGDIOBJ"]),
    "DeleteObject": ("BOOL", ["HGDIOBJ"]),
    "GetStockObject": ("HGDIOBJ", ["int"]),
    "BitBlt": ("BOOL", ["HDC", "int", "int", "int", "int", "HDC", "int", "int", "DWORD"]),
    "StretchBlt": ("BOOL", ["HDC", "int", "int", "int", "int", "HDC", "int",
                            "int", "int", "int", "DWORD"]),
    "CreateCompatibleDC": ("HDC", ["HDC"]),
    "CreateCompatibleBitmap": ("HBITMAP", ["HDC", "int", "int"]),
    "FillRect": ("int", ["HDC", "const RECT*", "HBRUSH"]),
    "FrameRect": ("int", ["HDC", "const RECT*", "HBRUSH"]),
    "SetPixel": ("COLORREF", ["HDC", "int", "int", "COLORREF"]),
    "GetPixel": ("COLORREF", ["HDC", "int", "int"]),
    "GetTextExtentPoint32W": ("BOOL", ["HDC", "LPCWSTR", "int", "SIZE*"]),
    "CreateFontW": ("HFONT", ["int", "int", "int", "int", "int", "int", "int", "int",
                              "int", "int", "int", "int", "int", "int", "LPCWSTR"]),
    "GetDeviceCaps": ("int", ["HDC", "int"]),
    "SaveDC": ("int", ["HDC"]),
    "RestoreDC": ("BOOL", ["HDC", "int"]),
    # ---- shlwapi（cdecl 平名，直接声明调用） ----
    "StrCpyW": ("LPWSTR", ["LPWSTR", "LPCWSTR"]),
    "StrCatW": ("LPWSTR", ["LPWSTR", "LPCWSTR"]),
    "StrCpyNW": ("LPWSTR", ["LPWSTR", "LPCWSTR", "int"]),
    "StrCmpW": ("int", ["LPCWSTR", "LPCWSTR"]),
    "StrCmpIW": ("int", ["LPCWSTR", "LPCWSTR"]),
    "StrStrW": ("LPCWSTR", ["LPCWSTR", "LPCWSTR"]),
    "StrStrIW": ("LPCWSTR", ["LPCWSTR", "LPCWSTR"]),
    "StrChrW": ("LPCWSTR", ["LPCWSTR", "wchar_t"]),
    "StrRChrW": ("LPCWSTR", ["LPCWSTR", "wchar_t"]),
    "StrToIntW": ("int", ["LPCWSTR"]),
    "PathFileExistsW": ("BOOL", ["LPCWSTR"]),
    "PathIsDirectoryW": ("BOOL", ["LPCWSTR"]),
    "PathFindFileNameW": ("LPCWSTR", ["LPCWSTR"]),
    "PathFindExtensionW": ("LPCWSTR", ["LPCWSTR"]),
    "PathCombineW": ("LPWSTR", ["LPWSTR", "LPCWSTR", "LPCWSTR"]),
}


# ---------------------------------------------------------------------------
# 固定前缀：标准头 + Windows API 调用适配器
# ---------------------------------------------------------------------------
PROLOGUE = r'''// 本文件由「云易IDE」自动翻译生成（云易语法 → 原生 C++17）
// 纯 C++17 / Win32：不依赖任何中文运行库
#define NOMINMAX
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <direct.h>
#include <io.h>
#include <iomanip>
#include <iostream>
#include <random>
#include <shlwapi.h>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <vector>
#include <windows.h>
#include <cstdint>

// API 声明的整数参数槽宽：x86 按 4 字节栈槽（与 stdcall @N 一致），x64 按 8 字节寄存器槽
#ifdef _WIN64
#define YYAPI_INT long long
#else
#define YYAPI_INT int
#endif

namespace yynative {

// ---------- 宽窄字符串互转 ----------
inline std::wstring to_wide(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    if (n <= 0) return std::wstring();
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
inline std::string to_narrow(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return "";
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
inline std::string to_narrow(const wchar_t* w) { return w ? to_narrow(std::wstring(w)) : ""; }
inline std::wstring to_wide_cstr(const char* s) { return to_wide(s ? s : ""); }

// ---------- Windows API 调用适配器 ----------
// 云易的 文本型(std::string) → Win32 宽字符串参数：调用点包一层 wc()，
// 返回的 std::wstring 临时对象存活到整个表达式结束，c_str() 安全。
inline std::wstring wc(const std::string& s) { return to_wide(s); }
inline std::wstring wc(const char* s) { return to_wide(s ? s : ""); }

// API 返回值 → 云易里的整数（句柄、指针等按地址转成 long long）
inline long long as_value(long long v) { return v; }
inline long long as_value(long v) { return v; }
inline long long as_value(int v) { return v; }
inline long long as_value(short v) { return v; }
inline long long as_value(char v) { return v; }
inline long long as_value(signed char v) { return v; }
inline long long as_value(unsigned char v) { return v; }
inline long long as_value(unsigned short v) { return v; }
inline long long as_value(unsigned int v) { return v; }
inline long long as_value(unsigned long v) { return v; }
inline long long as_value(unsigned long long v) { return (long long)v; }
inline long long as_value(wchar_t v) { return v; }
inline long long as_value(bool v) { return v ? 1 : 0; }
inline long long as_value(double v) { return (long long)v; }
inline long long as_value(float v) { return (long long)v; }
template <class V>
inline long long as_value(V* v) { return (long long)reinterpret_cast<uintptr_t>(v); }

// 云易里的值是通用类型（int / long long / std::string），这里按目标 API 的形参类型
// 逐个适配：整型→static_cast，指针→reinterpret_cast，宽字符串→自动转宽。
template <class T>
struct api_cast {
    template <class V> static T go(V v) { return static_cast<T>(v); }
};
template <class T>
struct api_cast_ptr {
    template <class V> static T go(V v) {
        return reinterpret_cast<T>(static_cast<uintptr_t>(v));
    }
};
template <class T> struct api_cast<T*> : api_cast_ptr<T*> {};
// 宽字符串参数：接受 std::string / const char*（自动转宽）或已经是宽串的值
template <class V>
inline std::wstring to_wstr(V&& v) {
    if constexpr (std::is_convertible_v<V, std::wstring>)
        return std::wstring(std::forward<V>(v));
    else
        return to_wide(std::string(std::forward<V>(v)));
}
template <> struct api_cast<const wchar_t*> {
    template <class V> static const wchar_t* go(V&& v) {
        static thread_local std::wstring buf;
        if constexpr (std::is_integral_v<std::remove_reference_t<V>>) {
            // 云易里直接给了「宽字符串缓冲地址」（整数型）
            return reinterpret_cast<const wchar_t*>(static_cast<uintptr_t>(v));
        } else {
            buf = to_wstr(std::forward<V>(v));
            return buf.c_str();
        }
    }
};
template <> struct api_cast<wchar_t*> {          // 可写字符串出参：云易里传的是地址
    template <class V> static wchar_t* go(V v) {
        return reinterpret_cast<wchar_t*>(static_cast<uintptr_t>(v));
    }
};
template <std::size_t I, class T> struct arg_cast {
    template <class V> static T go(V&& v) {
        if constexpr (std::is_integral_v<T> && std::is_convertible_v<V, std::wstring>) {
            // 整数形参（如 LPARAM）却传了字符串（LB_ADDSTRING 等）：把宽串地址当整数传
            static thread_local std::wstring buf;
            buf = to_wstr(std::forward<V>(v));
            return static_cast<T>(reinterpret_cast<uintptr_t>(buf.c_str()));
        } else {
            return api_cast<T>::go(std::forward<V>(v));
        }
    }
};
template <std::size_t I> struct arg_cast<I, const wchar_t*> {
    template <class V> static const wchar_t* go(V&& v) {
        static thread_local std::wstring buf;
        if constexpr (std::is_integral_v<std::remove_reference_t<V>>) {
            return reinterpret_cast<const wchar_t*>(static_cast<uintptr_t>(v));
        } else {
            buf = to_wstr(std::forward<V>(v));
            return buf.c_str();
        }
    }
};
template <std::size_t I> struct arg_cast<I, wchar_t*> {
    template <class V> static wchar_t* go(V v) {
        return reinterpret_cast<wchar_t*>(static_cast<uintptr_t>(v));
    }
};

template <class R, class... A, std::size_t... Is, class... V>
decltype(auto) api_call_seq(R (__stdcall *fn)(A...), std::index_sequence<Is...>, V&&... vs) {
    return fn(arg_cast<Is, A>::go(std::forward<V>(vs))...);
}
template <class R, class... A, class... V>
decltype(auto) api_call(R (__stdcall *fn)(A...), V&&... vs) {
    return api_call_seq(fn, std::index_sequence_for<A...>{}, std::forward<V>(vs)...);
}
// 返回值按云易整数语义取回：真实 API 返回 void 时（如 PostQuitMessage）给 0
template <class F, class... V>
long long api_call_int(F fn, V&&... vs) {
    if constexpr (std::is_void_v<decltype(api_call(fn, std::forward<V>(vs)...))>) {
        api_call(fn, std::forward<V>(vs)...);
        return 0;
    } else {
        return as_value(api_call(fn, std::forward<V>(vs)...));
    }
}
#if defined(_WIN32) && !defined(_WIN64)
// x86 上的 cdecl API（如 wsprintfW）：单独一组重载
template <class R, class... A, std::size_t... Is, class... V>
decltype(auto) api_call_seq(R (__cdecl *fn)(A...), std::index_sequence<Is...>, V&&... vs) {
    return fn(arg_cast<Is, A>::go(std::forward<V>(vs))...);
}
template <class R, class... A, class... V>
decltype(auto) api_call(R (__cdecl *fn)(A...), V&&... vs) {
    return api_call_seq(fn, std::index_sequence_for<A...>{}, std::forward<V>(vs)...);
}
#endif

// API 返回值 → 云易里的整数（句柄、指针等按地址转成 long long）

// ---------- UTF-8 字符（按码点处理，中文按一个字符算） ----------
inline size_t seq_len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c >> 5) == 0x6) return 2;
    if ((c >> 4) == 0xE) return 3;
    if ((c >> 3) == 0x1E) return 4;
    return 1;
}
inline size_t char_count(const std::string& s) {
    size_t n = 0;
    for (unsigned char c : s)
        if ((c & 0xC0) != 0x80) ++n;
    return n;
}
inline size_t byte_offset(const std::string& s, size_t cp) {
    size_t b = 0, c = 0, L = s.size();
    while (b < L && c < cp) { b += seq_len((unsigned char)s[b]); ++c; }
    return b > L ? L : b;
}
inline std::string substring(const std::string& s, size_t start, size_t count) {
    size_t L = s.size();
    size_t b = byte_offset(s, start), e = b, got = 0;
    while (e < L && got < count) { e += seq_len((unsigned char)s[e]); ++got; }
    return s.substr(b, e - b);
}
inline std::string encode_utf8(unsigned int cp) {
    std::string r;
    if (cp < 0x80) r += (char)cp;
    else if (cp < 0x800) { r += (char)(0xC0 | (cp >> 6)); r += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) {
        r += (char)(0xE0 | (cp >> 12));
        r += (char)(0x80 | ((cp >> 6) & 0x3F));
        r += (char)(0x80 | (cp & 0x3F));
    } else {
        r += (char)(0xF0 | (cp >> 18));
        r += (char)(0x80 | ((cp >> 12) & 0x3F));
        r += (char)(0x80 | ((cp >> 6) & 0x3F));
        r += (char)(0x80 | (cp & 0x3F));
    }
    return r;
}
inline unsigned int decode_utf8(const std::string& s, size_t& i) {
    unsigned char c = (unsigned char)s[i];
    unsigned int cp; size_t extra;
    if (c < 0x80) { cp = c; extra = 0; }
    else if ((c >> 5) == 0x6) { cp = c & 0x1Fu; extra = 1; }
    else if ((c >> 4) == 0xE) { cp = c & 0x0Fu; extra = 2; }
    else if ((c >> 3) == 0x1E) { cp = c & 0x07u; extra = 3; }
    else { cp = c; extra = 0; }
    ++i;
    for (size_t k = 0; k < extra && i < s.size(); ++k, ++i)
        cp = (cp << 6) | ((unsigned char)s[i] & 0x3Fu);
    return cp;
}
inline std::vector<unsigned int> to_codepoints(const std::string& s) {
    std::vector<unsigned int> v;
    for (size_t i = 0; i < s.size();) v.push_back(decode_utf8(s, i));
    return v;
}
inline bool is_space_cp(unsigned int cp) {
    return cp == ' ' || cp == '\t' || cp == '\r' || cp == '\n';
}
// 控制台切换 UTF-8 代码页：保证中文输入输出正常
struct console_init {
    console_init() { SetConsoleOutputCP(65001); SetConsoleCP(65001); }
};
inline console_init _console_init_instance;

}  // namespace yynative
using namespace yynative;
'''

# 完整前缀（保留通用翻译层）：当工程里出现本签名表 / KNOWN_API_SIGS 都覆盖不到的
# Windows API 时，仍用 yynative 的 api_call / arg_cast 模板机制兜底（保证不破坏旧工程）。
PROLOGUE_FULL = PROLOGUE

# 精简前缀：所有 API 都有真实签名时使用的「纯正」版本 —— 不含任何翻译脚手架
# （api_call / arg_cast / as_value / wc 等），API 在调用点直接以真实签名写出。
PROLOGUE_MIN = r'''// 本文件由「云易IDE」自动翻译生成（云易语法 → 原生 C++17）
// 纯 C++17 / Win32：不依赖任何中文运行库，Windows API 直接在调用点以真实签名写出
// 说明：本前缀不定义 UNICODE/_UNICODE（代码一律显式使用 ::XxxW 与 L"" 宽串字面量）；
//       需要 shlwapi（StrCpyW 等 cdecl 平名函数）时仍包含其头文件。
#define NOMINMAX
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <direct.h>
#include <io.h>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <vector>
#include <windows.h>
#include <shlwapi.h>

namespace yynative {

// ---------- 宽窄字符串互转 ----------
inline std::wstring to_wide(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    if (n <= 0) return std::wstring();
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
inline std::string to_narrow(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return "";
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
inline std::string to_narrow(const wchar_t* w) { return w ? to_narrow(std::wstring(w)) : ""; }

// ---------- UTF-8 字符（按码点处理，中文按一个字符算） ----------
inline size_t seq_len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c >> 5) == 0x6) return 2;
    if ((c >> 4) == 0xE) return 3;
    if ((c >> 3) == 0x1E) return 4;
    return 1;
}
inline size_t char_count(const std::string& s) {
    size_t n = 0;
    for (unsigned char c : s)
        if ((c & 0xC0) != 0x80) ++n;
    return n;
}
inline size_t byte_offset(const std::string& s, size_t cp) {
    size_t b = 0, c = 0, L = s.size();
    while (b < L && c < cp) { b += seq_len((unsigned char)s[b]); ++c; }
    return b > L ? L : b;
}
inline std::string substring(const std::string& s, size_t start, size_t count) {
    size_t L = s.size();
    size_t b = byte_offset(s, start), e = b, got = 0;
    while (e < L && got < count) { e += seq_len((unsigned char)s[e]); ++got; }
    return s.substr(b, e - b);
}
inline std::string encode_utf8(unsigned int cp) {
    std::string r;
    if (cp < 0x80) r += (char)cp;
    else if (cp < 0x800) { r += (char)(0xC0 | (cp >> 6)); r += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) {
        r += (char)(0xE0 | (cp >> 12));
        r += (char)(0x80 | ((cp >> 6) & 0x3F));
        r += (char)(0x80 | (cp & 0x3F));
    } else {
        r += (char)(0xF0 | (cp >> 18));
        r += (char)(0x80 | ((cp >> 12) & 0x3F));
        r += (char)(0x80 | ((cp >> 6) & 0x3F));
        r += (char)(0x80 | (cp & 0x3F));
    }
    return r;
}
inline unsigned int decode_utf8(const std::string& s, size_t& i) {
    unsigned char c = (unsigned char)s[i];
    unsigned int cp; size_t extra;
    if (c < 0x80) { cp = c; extra = 0; }
    else if ((c >> 5) == 0x6) { cp = c & 0x1Fu; extra = 1; }
    else if ((c >> 4) == 0xE) { cp = c & 0x0Fu; extra = 2; }
    else if ((c >> 3) == 0x1E) { cp = c & 0x07u; extra = 3; }
    else { cp = c; extra = 0; }
    ++i;
    for (size_t k = 0; k < extra && i < s.size(); ++k, ++i)
        cp = (cp << 6) | ((unsigned char)s[i] & 0x3Fu);
    return cp;
}
inline std::vector<unsigned int> to_codepoints(const std::string& s) {
    std::vector<unsigned int> v;
    for (size_t i = 0; i < s.size();) v.push_back(decode_utf8(s, i));
    return v;
}
inline bool is_space_cp(unsigned int cp) {
    return cp == ' ' || cp == '\t' || cp == '\r' || cp == '\n';
}
// 控制台切换 UTF-8 代码页：保证中文输入输出正常
struct console_init {
    console_init() { SetConsoleOutputCP(65001); SetConsoleCP(65001); }
};
inline console_init _console_init_instance;

}  // namespace yynative
using namespace yynative;
'''


# ---------------------------------------------------------------------------
# 内置函数：中文名 → (英文名, 实现)
# ---------------------------------------------------------------------------
_F = {}

_F["到文本"] = ("to_text", '''inline std::string to_text(const std::string& s) { return s; }
inline std::string to_text(const char* s) { return s ? s : ""; }
inline std::string to_text(bool v) { return v ? "true" : "false"; }
inline std::string to_text(long long v) { return std::to_string(v); }
inline std::string to_text(int v) { return std::to_string(v); }
inline std::string to_text(short v) { return std::to_string((int)v); }
inline std::string to_text(unsigned char v) { return std::to_string((int)v); }
inline std::string to_text(double v) {
    std::ostringstream os; os << std::setprecision(15) << v; return os.str();
}
inline std::string to_text(float v) { return to_text((double)v); }''')

_F["到整数"] = ("to_int", '''inline int to_int(const std::string& s) {
    try { size_t p = 0; long long v = std::stoll(s, &p); return (int)v; } catch (...) { return 0; }
}
inline int to_int(double v) { return (int)v; }
inline int to_int(int v) { return v; }''')

_F["到长整数"] = ("to_long", '''inline long long to_long(const std::string& s) {
    try { return std::stoll(s); } catch (...) { return 0; }
}
inline long long to_long(double v) { return (long long)v; }
inline long long to_long(int v) { return (long long)v; }''')

_F["到小数"] = ("to_double", '''inline double to_double(const std::string& s) {
    try { return std::stod(s); } catch (...) { return 0.0; }
}
inline double to_double(int v) { return (double)v; }
inline double to_double(double v) { return v; }''')

_F["到逻辑"] = ("to_bool", '''inline bool to_bool(const std::string& s) {
    return s == "true" || s == "1";
}''')

_F["到字节"] = ("to_byte", '''inline unsigned char to_byte(long long v) { return (unsigned char)(v & 0xFF); }''')

_F["数值到文本"] = ("number_to_text", '''inline std::string number_to_text(double v, long long digits = 0) {
    std::ostringstream os; os << std::fixed << std::setprecision((int)digits) << v; return os.str();
}''')

_F["输出"] = ("print_line", '''inline void write_one(std::ostream& os, const std::string& v) { os << v; }
inline void write_one(std::ostream& os, const char* v) { os << (v ? v : ""); }
inline void write_one(std::ostream& os, bool v) { os << (v ? "true" : "false"); }
inline void write_one(std::ostream& os, unsigned char v) { os << (int)v; }
inline void write_one(std::ostream& os, double v) { os << to_text(v); }
inline void write_one(std::ostream& os, float v) { os << to_text((double)v); }
inline void write_one(std::ostream& os, long long v) { os << v; }
inline void write_one(std::ostream& os, int v) { os << v; }
inline void write_one(std::ostream& os, short v) { os << v; }
inline void write_one(std::ostream& os, const std::vector<unsigned char>& b) {
    os << "bytes(" << b.size() << "){";
    for (size_t i = 0; i < b.size(); ++i) { if (i) os << ", "; os << (int)b[i]; }
    os << "}";
}
template <typename... Args>
void print_line(const Args&... args) {
    bool first = true;
    auto emit = [&](const auto& v) { if (!first) std::cout << ' '; first = false; write_one(std::cout, v); };
    (emit(args), ...);
    std::cout << std::endl;
}''')

_F["调试输出"] = ("debug_print", '''template <typename... Args>
void debug_print(const Args&... args) { print_line(args...); }''')

_F["提示等待输入"] = ("prompt_wait_input", '''inline void prompt_wait_input() {
    if (!::_isatty(::_fileno(stdout))) std::cout << "\\x1b[?yy-in]" << std::endl;
}''')

_F["输入文本"] = ("input_text", '''inline std::string input_text() {
    prompt_wait_input();
    std::string line;
    if (!std::getline(std::cin, line)) line.clear();
    return line;
}''')

_F["输入整数"] = ("input_int", '''inline int input_int() { return to_int(input_text()); }''')

_F["输入小数"] = ("input_double", '''inline double input_double() { return to_double(input_text()); }''')

_F["等待按键"] = ("wait_key", '''inline void wait_key() { std::cin.clear(); (void)std::cin.get(); }''')

_F["清屏"] = ("clear_screen", '''inline void clear_screen() { (void)system("cls"); }''')

_F["信息框"] = ("message_box", '''inline void message_box(const std::string& text) {
    ::MessageBoxW(nullptr, to_wide(text).c_str(), L"Tip", MB_OK | MB_ICONINFORMATION);
}
inline void message_box(const std::string& text, const std::string& title) {
    ::MessageBoxW(nullptr, to_wide(text).c_str(), to_wide(title).c_str(),
                  MB_OK | MB_ICONINFORMATION);
}''')

_F["取文本长度"] = ("text_length", '''inline int text_length(const std::string& s) { return (int)char_count(s); }''')

_F["取文本左边"] = ("text_left", '''inline std::string text_left(const std::string& s, long long n) {
    if (n <= 0) return ""; return substring(s, 0, (size_t)n);
}''')

_F["取文本右边"] = ("text_right", '''inline std::string text_right(const std::string& s, long long n) {
    if (n <= 0) return "";
    size_t total = char_count(s);
    if ((size_t)n >= total) return s;
    return substring(s, total - (size_t)n, (size_t)n);
}''')

_F["取文本中间"] = ("text_mid", '''inline std::string text_mid(const std::string& s, long long start, long long n) {
    if (n <= 0 || start < 1) return "";
    return substring(s, (size_t)start - 1, (size_t)n);
}''')

_F["寻找文本"] = ("find_text", '''inline int find_text(const std::string& s, const std::string& sub, long long start = 1) {
    if (sub.empty()) return start <= (long long)char_count(s) ? (int)start : 0;
    if (start < 1) start = 1;
    size_t pos = s.find(sub, byte_offset(s, (size_t)start - 1));
    if (pos == std::string::npos) return 0;
    return (int)char_count(s.substr(0, pos)) + 1;
}''')

_F["倒找文本"] = ("rfind_text", '''inline int rfind_text(const std::string& s, const std::string& sub, long long start = -1) {
    if (sub.empty()) return 0;
    size_t total = char_count(s), byte_end;
    if (start < 0 || start > (long long)total) byte_end = s.size();
    else byte_end = byte_offset(s, (size_t)start);
    size_t pos = s.rfind(sub, byte_end);
    if (pos == std::string::npos) return 0;
    return (int)char_count(s.substr(0, pos)) + 1;
}''')

_F["替换文本"] = ("replace_text", '''inline std::string replace_text(const std::string& src, const std::string& find,
                                const std::string& replacement) {
    if (find.empty()) return src;
    std::string out;
    size_t pos = 0, last = 0;
    while ((pos = src.find(find, pos)) != std::string::npos) {
        out.append(src, last, pos - last);
        out.append(replacement);
        pos += find.size();
        last = pos;
    }
    out.append(src, last, src.size() - last);
    return out;
}''')

_F["文本替换"] = ("replace_text_once", '''inline std::string replace_text_once(const std::string& src, const std::string& find,
                                     const std::string& replacement) {
    // 文本替换：只替换第一次出现
    if (find.empty()) return src;
    size_t pos = src.find(find);
    if (pos == std::string::npos) return src;
    std::string out = src;
    out.replace(pos, find.size(), replacement);
    return out;
}''')

_F["子文本替换"] = ("replace_sub_text", '''inline std::string replace_sub_text(const std::string& src, const std::string& find,
                                    const std::string& replacement, long long start = 1,
                                    long long count = -1) {
    if (find.empty() || start < 1) return src;
    size_t start_byte = byte_offset(src, (size_t)start - 1);
    std::string head = src.substr(0, start_byte);
    std::string tail = src.substr(start_byte);
    std::string mid;
    size_t pos = 0, last = 0, n = 0;
    while ((pos = tail.find(find, pos)) != std::string::npos) {
        mid.append(tail, last, pos - last);
        mid.append(replacement);
        pos += find.size();
        last = pos;
        ++n;
        if (count > 0 && n >= (size_t)count) break;
    }
    mid.append(tail, last, tail.size() - last);
    return head + mid;
}''')

_F["分割文本"] = ("split_text", '''inline std::string split_text(const std::string& s, const std::string& sep, long long index) {
    if (index < 1) return "";
    std::vector<std::string> parts;
    size_t pos = 0, last = 0;
    while ((pos = s.find(sep, last)) != std::string::npos) {
        parts.push_back(s.substr(last, pos - last));
        pos += sep.size();
        last = pos;
    }
    parts.push_back(s.substr(last));
    return ((size_t)index <= parts.size()) ? parts[(size_t)index - 1] : "";
}''')

_F["取文本段数"] = ("split_count", '''inline int split_count(const std::string& s, const std::string& sep) {
    if (sep.empty()) return 1;
    int n = 1;
    size_t pos = 0, last = 0;
    while ((pos = s.find(sep, last)) != std::string::npos) { ++n; pos += sep.size(); last = pos; }
    return n;
}''')

_F["到大写"] = ("to_upper", '''inline std::string to_upper(const std::string& s) {
    std::string r = s;
    for (auto& c : r) if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    return r;
}''')

_F["到小写"] = ("to_lower", '''inline std::string to_lower(const std::string& s) {
    std::string r = s;
    for (auto& c : r) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return r;
}''')

_F["删首尾空"] = ("trim_text", '''inline std::string trim_text(const std::string& s) {
    size_t b = 0, e = s.size();
    auto sp = [](char c) { return c == ' ' || c == '\\t' || c == '\\r' || c == '\\n'; };
    while (b < e && sp(s[b])) ++b;
    while (e > b && sp(s[e - 1])) --e;
    return s.substr(b, e - b);
}''')

_F["删首空"] = ("trim_start", '''inline std::string trim_start(const std::string& s) {
    size_t i = 0;
    while (i < s.size() && (s[i] == ' ' || s[i] == '\\t' || s[i] == '\\r' || s[i] == '\\n')) ++i;
    return s.substr(i);
}''')

_F["删尾空"] = ("trim_end", '''inline std::string trim_end(const std::string& s) {
    size_t e = s.size();
    while (e > 0 && (s[e - 1] == ' ' || s[e - 1] == '\\t' || s[e - 1] == '\\r' || s[e - 1] == '\\n')) --e;
    return s.substr(0, e);
}''')

_F["删全部空"] = ("trim_all", '''inline std::string trim_all(const std::string& s) {
    std::string r;
    for (unsigned int cp : to_codepoints(s)) if (!is_space_cp(cp)) r += encode_utf8(cp);
    return r;
}''')

_F["取空白文本"] = ("spaces", '''inline std::string spaces(long long n) {
    return n <= 0 ? "" : std::string((size_t)n, ' ');
}''')

_F["取重复文本"] = ("repeat_text", '''inline std::string repeat_text(long long times, const std::string& s) {
    if (times <= 0) return "";
    std::string r;
    for (long long i = 0; i < times; ++i) r += s;
    return r;
}''')

_F["文本比较"] = ("compare_text", '''inline int compare_text(const std::string& a, const std::string& b, bool case_sensitive = false) {
    std::string x = a, y = b;
    if (!case_sensitive) { x = to_lower(x); y = to_lower(y); }
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}''')

_F["文本开头为"] = ("starts_with", '''inline bool starts_with(const std::string& s, const std::string& prefix) {
    return s.size() >= prefix.size() && s.compare(0, prefix.size(), prefix) == 0;
}''')

_F["文本结尾为"] = ("ends_with", '''inline bool ends_with(const std::string& s, const std::string& suffix) {
    return s.size() >= suffix.size() &&
           s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}''')

_F["取字符"] = ("char_at", '''inline std::string char_at(const std::string& s, long long pos) {
    return pos < 1 ? "" : substring(s, (size_t)pos - 1, 1);
}''')

_F["取字符代码"] = ("char_code_at", '''inline int char_code_at(const std::string& s, long long pos) {
    std::string c = char_at(s, pos);
    if (c.empty()) return 0;
    size_t i = 0;
    return (int)decode_utf8(c, i);
}''')

_F["字符代码到文本"] = ("char_from_code", '''inline std::string char_from_code(long long code) {
    return encode_utf8((unsigned int)code);
}''')

_F["文本倒序"] = ("reverse_text", '''inline std::string reverse_text(const std::string& s) {
    auto cps = to_codepoints(s);
    std::string r;
    for (size_t i = cps.size(); i-- > 0;) r += encode_utf8(cps[i]);
    return r;
}''')

_F["是否为空文本"] = ("is_empty_text", '''inline bool is_empty_text(const std::string& s) { return s.empty(); }''')

_F["到全角"] = ("to_fullwidth", '''inline std::string to_fullwidth(const std::string& s) {
    std::string r;
    for (unsigned int cp : to_codepoints(s)) {
        if (cp == 0x20) cp = 0x3000;
        else if (cp >= 0x21 && cp <= 0x7E) cp += 0xFEE0;
        r += encode_utf8(cp);
    }
    return r;
}''')

_F["到半角"] = ("to_halfwidth", '''inline std::string to_halfwidth(const std::string& s) {
    std::string r;
    for (unsigned int cp : to_codepoints(s)) {
        if (cp == 0x3000) cp = 0x20;
        else if (cp >= 0xFF01 && cp <= 0xFF5E) cp -= 0xFEE0;
        r += encode_utf8(cp);
    }
    return r;
}''')

_F["取绝对值"] = ("abs_value", '''inline long long abs_value(long long v) { return v < 0 ? -v : v; }
inline double abs_value(double v) { return std::fabs(v); }''')

_F["取整"] = ("trunc_value", '''inline long long trunc_value(double x) { return (long long)x; }''')

_F["四舍五入"] = ("round_value", '''inline double round_value(double x, long long digits = 0) {
    double p = std::pow(10.0, (double)digits);
    return std::round(x * p) / p;
}''')

_F["求平方根"] = ("sqrt_value", '''inline double sqrt_value(double x) { return std::sqrt(x); }''')

_F["整除"] = ("div_floor", '''inline long long div_floor(long long a, long long b) {
    if (b == 0) return 0;
    long long q = a / b, r = a % b;
    if (r != 0 && ((r < 0) != (b < 0))) --q;
    return q;
}''')

_F["取符号"] = ("sign_of", '''inline int sign_of(double v) { return v > 0 ? 1 : (v < 0 ? -1 : 0); }''')

_F["向上取整"] = ("ceil_value", '''inline long long ceil_value(double x) { return (long long)std::ceil(x); }''')

_F["向下取整"] = ("floor_value", '''inline long long floor_value(double x) { return (long long)std::floor(x); }''')

_F["求次方"] = ("pow_value", '''inline double pow_value(double x, double y) { return std::pow(x, y); }''')

_F["取自然对数"] = ("log_value", '''inline double log_value(double x) { return std::log(x); }''')

_F["取常用对数"] = ("log10_value", '''inline double log10_value(double x) { return std::log10(x); }''')

_F["求正弦"] = ("sin_value", '''inline double sin_value(double x) { return std::sin(x); }''')

_F["求余弦"] = ("cos_value", '''inline double cos_value(double x) { return std::cos(x); }''')

_F["求正切"] = ("tan_value", '''inline double tan_value(double x) { return std::tan(x); }''')

_F["求反正切"] = ("atan_value", '''inline double atan_value(double x) { return std::atan(x); }''')

_F["取余数"] = ("fmod_value", '''inline double fmod_value(double a, double b) { return b == 0 ? 0 : std::fmod(a, b); }''')

_F["取最大值"] = ("max_of", '''template <typename T> inline T max_of(T a, T b) { return a > b ? a : b; }
template <typename T, typename... R> inline T max_of(T a, T b, R... r) {
    return max_of(a > b ? a : b, r...);
}''')

_F["取最小值"] = ("min_of", '''template <typename T> inline T min_of(T a, T b) { return a < b ? a : b; }
template <typename T, typename... R> inline T min_of(T a, T b, R... r) {
    return min_of(a < b ? a : b, r...);
}''')

_F["取圆周率"] = ("pi_value", '''inline double pi_value() { return 3.14159265358979323846; }''')

_F["随机数引擎"] = ("random_engine", '''inline std::mt19937_64& random_engine() {
    static std::mt19937_64 engine{std::random_device{}()};
    return engine;
}''')

_F["取随机数"] = ("random_int", '''inline long long random_int(long long low, long long high) {
    if (low > high) std::swap(low, high);
    std::uniform_int_distribution<long long> d(low, high);
    return d(random_engine());
}''')

_F["取随机小数"] = ("random_double", '''inline double random_double() {
    std::uniform_real_distribution<double> d(0.0, 1.0);
    return d(random_engine());
}''')

_F["置随机数种子"] = ("seed_random", '''inline void seed_random(long long s) { random_engine().seed((unsigned long long)s); }''')

_F["文本到字节集"] = ("text_to_bytes", '''inline std::vector<unsigned char> text_to_bytes(const std::string& s) {
    return std::vector<unsigned char>(s.begin(), s.end());
}''')

_F["字节集到文本"] = ("bytes_to_text", '''inline std::string bytes_to_text(const std::vector<unsigned char>& b) {
    return std::string(b.begin(), b.end());
}''')

_F["取字节集长度"] = ("bytes_length", '''inline int bytes_length(const std::vector<unsigned char>& b) { return (int)b.size(); }''')

_F["取字节集字节"] = ("byte_at", '''inline unsigned char byte_at(const std::vector<unsigned char>& b, int pos) {
    int i = pos - 1;
    return (i >= 0 && i < (int)b.size()) ? b[(size_t)i] : (unsigned char)0;
}''')

_F["取字节集左边"] = ("bytes_left", '''inline std::vector<unsigned char> bytes_left(const std::vector<unsigned char>& b, int n) {
    if (n < 0) n = 0;
    if ((size_t)n > b.size()) n = (int)b.size();
    return std::vector<unsigned char>(b.begin(), b.begin() + n);
}''')

_F["取数组成员数"] = ("array_size", '''template <typename T> inline long long array_size(const std::vector<T>& v) { return (long long)v.size(); }
template <typename T, std::size_t N> inline long long array_size(const std::array<T, N>&) { return (long long)N; }''')

_F["加入成员"] = ("array_push", '''// 成员类型单独用一个模板参数：这样「加入成员(文本数组, "张三")」也能直接写（否则
// const T& 会同时从 vector 元素类型与字符串字面量推导出冲突的 T）
template <typename T, typename U>
inline void array_push(std::vector<T>& v, const U& item) { v.push_back((T)item); }''')

_F["重定义数组"] = ("array_resize", '''template <typename T> inline void array_resize(std::vector<T>& v, long long n) {
    if (n < 0) n = 0;
    v.resize((size_t)n);
}''')

_F["删除成员"] = ("array_remove", '''template <typename T> inline void array_remove(std::vector<T>& v, long long index) {
    if (index >= 1 && (size_t)index <= v.size()) v.erase(v.begin() + (index - 1));
}''')

_F["插入成员"] = ("array_insert", '''// 欲插入的成员数据为单个值：只插入一个成员（位置 1 起）
template <typename T, typename U>
inline void array_insert(std::vector<T>& v, long long index, const U& item) {
    size_t i = (index < 1) ? 0 : (size_t)(index - 1);
    if (i > v.size()) i = v.size();
    v.insert(v.begin() + i, (T)item);
}
// 欲插入的成员数据为数组：把该数组的所有成员依次插入
template <typename T, typename U, typename A>
inline void array_insert(std::vector<T>& v, long long index, const std::vector<U, A>& items) {
    size_t i = (index < 1) ? 0 : (size_t)(index - 1);
    if (i > v.size()) i = v.size();
    for (const auto& m : items) {
        v.insert(v.begin() + i, (T)m);
        ++i;
    }
}''')

_F["数组排序"] = ("array_sort", '''template <typename T> inline void array_sort(std::vector<T>& v) { std::sort(v.begin(), v.end()); }''')

_F["数组反转"] = ("array_reverse", '''template <typename T> inline void array_reverse(std::vector<T>& v) { std::reverse(v.begin(), v.end()); }''')

_F["清除数组"] = ("array_clear", '''template <typename T> inline void array_clear(std::vector<T>& v) { v.clear(); }''')

_F["取当前时间"] = ("current_time_text", '''inline std::string current_time_text() {
    SYSTEMTIME st; ::GetLocalTime(&st);
    char buf[64];
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
             (int)st.wYear, (int)st.wMonth, (int)st.wDay,
             (int)st.wHour, (int)st.wMinute, (int)st.wSecond);
    return buf;
}''')

_F["取日期"] = ("current_date", '''inline std::string current_date() {
    SYSTEMTIME st; ::GetLocalTime(&st);
    char b[32];
    snprintf(b, sizeof(b), "%04d-%02d-%02d", (int)st.wYear, (int)st.wMonth, (int)st.wDay);
    return b;
}''')

for _n, _code in (("取年份", "wYear"), ("取月份", "wMonth"), ("取日", "wDay"),
                  ("取小时", "wHour"), ("取分钟", "wMinute"), ("取秒", "wSecond")):
    _F[_n] = ("datetime_" + _code.lower(), '''inline int datetime_%s() {
    SYSTEMTIME st; ::GetLocalTime(&st); return (int)st.%s;
}''' % (_code.lower(), _code))

_F["取星期"] = ("datetime_weekday", '''inline int datetime_weekday() {
    SYSTEMTIME st; ::GetLocalTime(&st); return (int)st.wDayOfWeek + 1;
}''')

_F["取现行时间"] = ("unix_time", '''inline long long unix_time() { return (long long)std::time(nullptr); }''')

_F["取启动毫秒"] = ("uptime_ms", '''inline long long uptime_ms() {
    static const auto start = std::chrono::steady_clock::now();
    auto d = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start);
    return (long long)d.count();
}''')

_F["延时"] = ("sleep_ms", '''inline void sleep_ms(long long ms) {
    if (ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}''')

_F["文件是否存在"] = ("file_exists", '''inline bool file_exists(const std::string& path) {
    DWORD a = ::GetFileAttributesW(to_wide(path).c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}''')

_F["目录是否存在"] = ("dir_exists", '''inline bool dir_exists(const std::string& path) {
    DWORD a = ::GetFileAttributesW(to_wide(path).c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) != 0;
}''')

_F["取文件长度"] = ("file_size", '''inline long long file_size(const std::string& path) {
    WIN32_FILE_ATTRIBUTE_DATA d;
    if (!::GetFileAttributesExW(to_wide(path).c_str(), GetFileExInfoStandard, &d)) return -1;
    if (d.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) return -1;
    return ((long long)d.nFileSizeHigh << 32) | (long long)d.nFileSizeLow;
}''')

_F["读入文件"] = ("read_file", '''inline std::string read_file(const std::string& path) {
    FILE* f = ::_wfopen(to_wide(path).c_str(), L"rb");
    if (!f) return "";
    std::string out;
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    fclose(f);
    return out;
}''')

_F["写到文件"] = ("write_file", '''inline bool write_file(const std::string& path, const std::string& content, bool append = false) {
    FILE* f = ::_wfopen(to_wide(path).c_str(), append ? L"ab" : L"wb");
    if (!f) return false;
    if (!content.empty()) fwrite(content.data(), 1, content.size(), f);
    fclose(f);
    return true;
}''')

_F["删除文件"] = ("delete_file", '''inline bool delete_file(const std::string& path) {
    return ::_wunlink(to_wide(path).c_str()) == 0;
}''')

_F["复制文件"] = ("copy_file", '''inline bool copy_file(const std::string& src, const std::string& dst) {
    return ::CopyFileW(to_wide(src).c_str(), to_wide(dst).c_str(), FALSE) != 0;
}''')

_F["移动文件"] = ("move_file", '''inline bool move_file(const std::string& src, const std::string& dst) {
    return ::MoveFileW(to_wide(src).c_str(), to_wide(dst).c_str()) != 0;
}''')

_F["创建目录"] = ("make_dir", '''inline bool make_dir(const std::string& path) {
    std::wstring p = to_wide(path);
    if (p.empty()) return false;
    for (auto& c : p) if (c == L'/') c = L'\\\\';
    size_t pos = 0;
    if (p.size() >= 2 && p[1] == L':') pos = 3;
    else if (p[0] == L'\\\\') pos = 1;
    size_t found;
    while ((found = p.find(L'\\\\', pos)) != std::wstring::npos) {
        std::wstring part = p.substr(0, found);
        if (!part.empty()) ::CreateDirectoryW(part.c_str(), nullptr);
        pos = found + 1;
    }
    DWORD a = ::GetFileAttributesW(p.c_str());
    if (a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY)) return true;
    return ::CreateDirectoryW(p.c_str(), nullptr) != 0;
}''')

_F["删除目录"] = ("remove_dir", '''inline bool remove_dir(const std::string& path) {
    return ::_wrmdir(to_wide(path).c_str()) == 0;
}''')

_F["取文件列表"] = ("list_files", '''inline std::string list_files(const std::string& dir, const std::string& pattern = "*") {
    std::wstring spec = to_wide(dir);
    if (!spec.empty() && spec.back() != L'\\\\' && spec.back() != L'/') spec += L'\\\\';
    spec += to_wide(pattern);
    WIN32_FIND_DATAW fd;
    HANDLE h = ::FindFirstFileW(spec.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return "";
    std::string out;
    do {
        const wchar_t* n = fd.cFileName;
        if (n[0] == L'.' && (n[1] == L'\\0' || (n[1] == L'.' && n[2] == L'\\0'))) continue;
        if (!out.empty()) out += "\\n";
        out += to_narrow(n);
    } while (::FindNextFileW(h, &fd));
    ::FindClose(h);
    return out;
}''')

_F["取当前目录"] = ("current_dir", '''inline std::string current_dir() {
    wchar_t buf[MAX_PATH];
    if (!::GetCurrentDirectoryW(MAX_PATH, buf)) return "";
    return to_narrow(buf);
}''')

_F["置当前目录"] = ("set_current_dir", '''inline bool set_current_dir(const std::string& path) {
    return ::SetCurrentDirectoryW(to_wide(path).c_str()) != 0;
}''')

_F["取运行目录"] = ("app_dir", '''inline std::string app_dir() {
    wchar_t buf[MAX_PATH];
    if (!::GetModuleFileNameW(nullptr, buf, MAX_PATH)) return "";
    std::wstring p(buf);
    size_t pos = p.find_last_of(L"\\\\/");
    return to_narrow(pos == std::wstring::npos ? L"" : p.substr(0, pos));
}''')

_F["取临时目录"] = ("temp_dir", '''inline std::string temp_dir() {
    wchar_t buf[MAX_PATH + 1];
    if (!::GetTempPathW(MAX_PATH + 1, buf)) return "";
    return to_narrow(buf);
}''')

_F["执行程序"] = ("run_program", '''inline int run_program(const std::string& cmdline, bool wait = true) {
    std::wstring w = to_wide(cmdline);
    std::vector<wchar_t> buf(w.begin(), w.end());
    buf.push_back(L'\\0');
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!::CreateProcessW(nullptr, buf.data(), nullptr, nullptr, FALSE, 0,
                          nullptr, nullptr, &si, &pi))
        return -1;
    if (!wait) { ::CloseHandle(pi.hThread); ::CloseHandle(pi.hProcess); return 0; }
    ::WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD code = 0;
    ::GetExitCodeProcess(pi.hProcess, &code);
    ::CloseHandle(pi.hThread);
    ::CloseHandle(pi.hProcess);
    return (int)code;
}''')

_F["取命令行"] = ("command_line", '''inline std::string command_line() { return to_narrow(::GetCommandLineW()); }''')

_F["取环境变量"] = ("get_env", '''inline std::string get_env(const std::string& name) {
    const char* v = std::getenv(name.c_str());
    return v ? std::string(v) : "";
}''')

_F["结束程序"] = ("exit_program", '''inline void exit_program(int code = 0) { std::cout.flush(); std::exit(code); }''')

_F["取屏幕宽度"] = ("screen_width", '''inline int screen_width() { return (int)::GetSystemMetrics(SM_CXSCREEN); }''')

_F["取屏幕高度"] = ("screen_height", '''inline int screen_height() { return (int)::GetSystemMetrics(SM_CYSCREEN); }''')

_F["置控制台标题"] = ("set_console_title", '''inline void set_console_title(const std::string& title) {
    ::SetConsoleTitleW(to_wide(title).c_str());
}''')

_F["位与"] = ("bit_and", '''inline long long bit_and(long long a, long long b) { return a & b; }''')

_F["位或"] = ("bit_or", '''inline long long bit_or(long long a, long long b) { return a | b; }''')

_F["位异或"] = ("bit_xor", '''inline long long bit_xor(long long a, long long b) { return a ^ b; }''')

_F["位取反"] = ("bit_not", '''inline long long bit_not(long long a) { return ~a; }''')

_F["左移"] = ("shift_left", '''inline long long shift_left(long long a, long long n) {
    return n >= 0 ? (a << (n & 63)) : (a >> ((-n) & 63));
}''')

_F["右移"] = ("shift_right", '''inline long long shift_right(long long a, long long n) {
    return n >= 0 ? (a >> (n & 63)) : (a << ((-n) & 63));
}''')

_F["断言"] = ("assert_true", '''inline long long assert_total_count = 0;
inline long long assert_failed_count = 0;
inline void assert_reset() { assert_total_count = 0; assert_failed_count = 0; }
inline long long assert_total() { return assert_total_count; }
inline long long assert_failed() { return assert_failed_count; }
inline void assert_true(bool cond, const std::string& note = "") {
    ++assert_total_count;
    if (!cond) { ++assert_failed_count; std::cout << "[assert failed] " << note << std::endl; }
}''')

_F["调用子程序"] = ("call_sub", '''// 按地址动态调用一个子程序（等同 C/C++ 的函数指针调用）；返回值按 long long 取回，
// 被调用的子程序应当返回整数 / 地址这类结果；地址为 0 时不调用，直接返回 0
template <typename... A>
inline long long call_sub(long long addr, A... args) {
    if (addr == 0) return 0;
    typedef long long (*FnType)(A...);
    return reinterpret_cast<FnType>(static_cast<uintptr_t>(addr))(args...);
}''')

# 测试框架内部：4 个中文名都指向上面同一组实现
_F["_yy断言重置"] = ("assert_reset", _F["断言"][1])
_F["_yy取总数"] = ("assert_total", _F["断言"][1])
_F["_yy取失败"] = ("assert_failed", _F["断言"][1])

NATIVE_FUNCS = _F

# 中文调用名 → 英文函数名（用于替换生成代码里的内置函数调用）
NATIVE_NAME = {zh: en for zh, (en, _code) in _F.items()}

# 需要整块在一起的依赖（出现任意一个就把整组实现都注入）
NATIVE_GROUPS = [
    ["断言", "_yy断言重置", "_yy取总数", "_yy取失败"],
    ["取随机数", "取随机小数", "置随机数种子"],
    ["到文本", "调试输出", "输出"],
    ["输入整数", "输入小数", "输入文本"],
]


def impl_for(zh_name: str) -> str:
    """返回某个内置函数的实现代码（同组的重复调用只输出一次）。"""
    return _F.get(zh_name, (zh_name, ""))[1]


def impls_for(names) -> str:
    """给定用到的中文内置函数名集合，返回需要注入的实现代码块（同组成员整组注入）。"""
    out, emitted = [], set()
    for zh in names:
        if zh not in _F:
            continue
        group = next((g for g in NATIVE_GROUPS if zh in g), [zh])
        for member in group:
            impl = impl_for(member)
            # 按实现文本去重：组内多个中文名可能共用同一份实现（如 断言 四件套），
            # 若按各自 C++ 名去重会把同一份代码注入多次 → 重定义编译错误
            if not impl or impl in emitted:
                continue
            emitted.add(impl)
            out.append(impl)
    return "\n\n".join(out)


def used_impls(cpp_text: str) -> str:
    """扫描文本里出现过的中文内置函数名，返回需要注入的实现代码块。"""
    return impls_for([zh for zh in _F if zh in cpp_text])
