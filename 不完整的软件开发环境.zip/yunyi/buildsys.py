# -*- coding: utf-8 -*-
"""第 7 项：构建系统 —— 生成 Makefile / CMakeLists.txt / 构建脚本，并可用内置 make 构建。"""
from __future__ import annotations
import os
import re
import sys

from . import builder as B
from . import codec
from . import project as project_mod
from . import toolchain

IDE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    # 打包成 exe（PyInstaller）：代码在 exe 内部，而 config / lib / docs / 工作区
    # / tools 都在 **exe 旁边** —— 所以取 exe 所在目录，而不是 __file__ 的解压目录。
    IDE_ROOT = os.path.dirname(os.path.abspath(sys.executable))
CLI = os.path.join(IDE_ROOT, "server", "yunyi_cli.py")


def exe_basename(cfg: dict, arch: str = "") -> str:
    """产物（exe/dll）主名 —— 与 builder 保持一致：x86 追加 _x86 后缀便于区分架构。"""
    name = re.sub(r'[^\w\u4e00-\u9fff.-]', "_", cfg.get("target") or "程序")
    if (arch or "").strip().lower() == "x86":
        name += "_x86"
    return name


def _posix(p: str) -> str:
    return p.replace("\\", "/")


def makefile_text(proj_dir: str, cfg: dict, mode: str = "debug") -> str:
    """生成 Makefile。

    ★ 两条硬约束（都有实测依据，不要改成「看起来更统一」的写法）：
      · 本文件必须按本机代码页（中文 Windows = GBK）写出：mingw32-make 在 Windows 上把
        Makefile 里的字节按 ANSI 代码页（GetACP）转成命令行参数，UTF-8 会被转坏 ——
        实测 UTF-8 版报「工程目录不存在：…宸ヤ綔鍖?zzUTF8」，GBK 版正常。
      · 编译/链接交给云易 CLI（内部用 Python 调 g++）：中文产物名只有经 Python 传递才
        正确；make/cmd 直接把中文路径交给 g++，g++ 会写成乱码（实测 zzU8²âÊÔ.exe）。
        CLI 走的就是 IDE 点「编译」同一条流水线，工程设置里的额外编译/链接参数、库也会生效。
    """
    gxx = _posix(toolchain.find_gxx() or "g++")
    name = exe_basename(cfg, project_mod.resolve_arch(proj_dir, cfg))
    ext = "dll" if project_mod.resolve_subsystem(proj_dir, cfg) == "dll" else "exe"
    py = _posix(sys.executable)
    cli = _posix(CLI)
    return f"""# 云易IDE 自动生成的 Makefile（重新生成会覆盖手工修改）
# 用法：mingw32-make            构建
#       mingw32-make MODE=release  发布版构建
#       mingw32-make clean       清理构建产物
# 说明：翻译与编译/链接都由云易 CLI 完成 —— 与 IDE 里点「编译」是同一条流水线，
#       编译/链接参数取自「工程设置」（额外编译参数 / 额外链接参数 / 库 / SDK）
MODE     ?= {mode}
CXX       = "{gxx}"        # 可用 make CXX=其他编译器 覆盖
PYTHON    = "{py}"
CLI       = "{cli}"
PROJ      = "{_posix(proj_dir)}"
BUILDDIR  = build/$(MODE)
GEN       = $(BUILDDIR)/main_gen.cpp
TARGET    = $(BUILDDIR)/{name}.{ext}

.PHONY: all run test clean translate

all: $(TARGET)

$(BUILDDIR):
\t@"$(PYTHON)" -c "import os,sys;os.makedirs(sys.argv[1],exist_ok=True)" $(BUILDDIR)

# 自动把 .yy 源码翻译为 C++（依赖任一 .yy 源文件）
$(GEN): $(wildcard *.yy) | $(BUILDDIR)
\t@"$(PYTHON)" "$(CLI)" translate "$(PROJ)" --mode $(MODE)

# 链接：交给云易 CLI（Python → g++），中文产物名才不会乱码
$(TARGET): $(GEN) | $(BUILDDIR)
\t@"$(PYTHON)" "$(CLI)" build "$(PROJ)" --mode $(MODE) --gxx $(CXX)

translate: $(GEN)

run: $(TARGET)
\t"$(TARGET)"

test:
\t@"$(PYTHON)" "$(CLI)" test "$(PROJ)" --mode $(MODE)

clean:
\t-@"$(PYTHON)" -c "import shutil;shutil.rmtree('build',ignore_errors=True)"
"""


def _flag_values(flags: list, key: str) -> list:
    out = []
    for i, v in enumerate(flags):
        if v == key and i + 1 < len(flags):
            out.append(flags[i + 1])
    return out


def cmake_text(proj_dir: str, cfg: dict, mode: str = "debug") -> str:
    runtime = _posix(B.RUNTIME_DIR)
    name = exe_basename(cfg, project_mod.resolve_arch(proj_dir, cfg))
    inc, link = B.lib_flags(cfg, proj_dir)
    inc_dirs = "\n".join('    "%s"' % _posix(d) for d in _flag_values(inc, "-I"))
    libs = " ".join(l[2:] if l.startswith("-l") else l for l in link)
    subsys = project_mod.resolve_subsystem(proj_dir, cfg)
    win_exe = "TRUE" if subsys == "window" else "FALSE"
    if subsys == "dll":
        add_target = f"add_library({name} SHARED ${{GEN_CPP}})"
        # 不加 --kill-at：i386 保留 @参数字节数 装饰（Add@8），x64 无装饰
        extra_props = '  PREFIX ""\n'
    else:
        add_target = f"add_executable({name} ${{GEN_CPP}})"
        extra_props = f"  WIN32_EXECUTABLE {win_exe}\n"
    py = _posix(sys.executable)
    return f"""# 云易IDE 自动生成的 CMake 工程（重新生成会覆盖手工修改）
cmake_minimum_required(VERSION 3.10)
project({name} CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE {mode.capitalize()})
endif()

set(YUNYI_RUNTIME "{runtime}")
set(YUNYI_PYTHON "{py}")
set(YUNYI_CLI "{_posix(CLI)}")
set(YUNYI_PROJ "{_posix(proj_dir)}")
set(GEN_CPP "${{CMAKE_CURRENT_SOURCE_DIR}}/build/{mode}/main_gen.cpp")

# 第一步：把 .yy 源码翻译为 C++
file(GLOB YY_SOURCES "${{CMAKE_CURRENT_SOURCE_DIR}}/*.yy")
add_custom_command(
  OUTPUT ${{GEN_CPP}}
  COMMAND ${{YUNYI_PYTHON}} ${{YUNYI_CLI}} translate ${{YUNYI_PROJ}} --mode {mode}
  DEPENDS ${{YY_SOURCES}}
  COMMENT "云易：翻译 .yy -> C++"
  VERBATIM)

{add_target}
target_include_directories({name} PRIVATE ${{YUNYI_RUNTIME}}
{inc_dirs})
target_link_libraries({name} PRIVATE user32 {libs})
set_target_properties({name} PROPERTIES
{extra_props}  RUNTIME_OUTPUT_DIRECTORY "${{CMAKE_CURRENT_SOURCE_DIR}}/build/{mode}")
"""


def gitignore_text() -> str:
    return ("build/\n发布/\n导出C++/\n导出Python/\n*.exe\n*.o\n*.obj\n*.a\n*.zip\n*.user\n"
            "__pycache__/\n.idea/\n.vscode/\n")


def build_bat_text(proj_dir: str, cfg: dict, mode: str = "debug") -> str:
    make = toolchain.find_make() or "mingw32-make"
    return ("@echo off\r\n"
            "chcp 65001 >nul\r\n"
            f"pushd \"{proj_dir}\"\r\n"
            f"\"{make}\" -f Makefile MODE={mode}\r\n"
            "if errorlevel 1 ( echo 构建失败 & pause & exit /b 1 )\r\n"
            "echo 构建完成\r\n"
            "popd\r\n"
            "pause\r\n")


def generate_build_scripts(proj_dir: str, cfg: dict = None,
                           mode: str = "") -> dict:
    """在工程中生成 Makefile、CMakeLists.txt、构建.bat、.gitignore。

    mode 留空则取「本工程的编译模式」；架构 / 程序类型同样取自工程标记
    （生成前先套用工程标记，Makefile 里记录的 g++ 才会对应 x64 / x86）。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    try:
        project_mod.apply_project_env(proj_dir, cfg)
    except Exception:
        pass
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    files = {}
    files["Makefile"] = os.path.join(proj_dir, "Makefile")
    files["CMakeLists.txt"] = os.path.join(proj_dir, "CMakeLists.txt")
    files["构建.bat"] = os.path.join(proj_dir, "构建.bat")
    files[".gitignore"] = os.path.join(proj_dir, ".gitignore")
    # 生成物编码（全工程统一 UTF-8；只有 Makefile 例外，逐条都有实测依据）：
    #  · Makefile 必须是本机代码页（中文 Windows = GBK）：mingw32-make 在 Windows 上把
    #    Makefile 里的字节按 ANSI 代码页（GetACP）转换成命令行参数，UTF-8 会被转坏 ——
    #    实测 UTF-8 版报「工程目录不存在：…宸ヤ綔鍖?zzUTF8」，GBK 版正常。
    #  · CMakeLists.txt 是 UTF-8（CMake 全程 Unicode，中文路径无问题）。
    #  · 构建.bat 是 UTF-8，且自身开头就 `chcp 65001`：实测在 936 / 65001 两种起始代码页
    #    下都能正确 pushd 中文路径并完成构建。原先「GBK 内容 + chcp 65001」两者打架，
    #    会让 pushd 拿到乱码路径（报 The system cannot find the path specified）并让 popd 失败。
    #  · newline="" 直写：模板里已经是 \r\n，若再走文本模式换行转换会得到 \r\r\n（双回车）。
    # 这几条规则现在统一登记在 yunyi/codec.py 的通道表（makefile / cmake / build_script
    # / repo），这里一律走 codec.write，不再各自写 encoding= —— 要改编码只改通道表或
    # config/encoding.json 一处即可。
    codec.write("makefile", files["Makefile"], makefile_text(proj_dir, cfg, mode))
    codec.write("cmake", files["CMakeLists.txt"], cmake_text(proj_dir, cfg, mode))
    codec.write("build_script", files["构建.bat"], build_bat_text(proj_dir, cfg, mode))
    gi = files[".gitignore"]
    if not os.path.isfile(gi):
        codec.write("repo", gi, gitignore_text())
    return {"ok": True, "dir": proj_dir, "files": list(files.values()),
            "make": toolchain.find_make()}


def _decode_make_output(raw: bytes) -> str:
    """make 输出是混合编码：mingw32-make 自身消息按本机代码页（GBK），
    而它调用的 CLI 子进程输出 UTF-8。走 make 通道（逐行解码，规则见 yunyi/codec.py）。"""
    return codec.decode("make", raw)


def run_make(proj_dir: str, cfg: dict = None, mode: str = "",
             target: str = "all") -> dict:
    """用内置 make 依据 Makefile 构建工程。"""
    cfg = cfg or project_mod.load_project(proj_dir)
    try:
        project_mod.apply_project_env(proj_dir, cfg)
    except Exception:
        pass
    mode = mode or project_mod.resolve_mode(proj_dir, cfg)
    arch = project_mod.resolve_arch(proj_dir, cfg)
    ext = "dll" if project_mod.resolve_subsystem(proj_dir, cfg) == "dll" else "exe"
    out = os.path.join(proj_dir, "build", mode, exe_basename(cfg, arch) + "." + ext)
    make = toolchain.find_make()
    if not make:
        return {"ok": False, "log": "未找到 make（mingw32-make）。请在设置中填写 make 路径。",
                "messages": [{"kind": "error", "text": "未找到 make（mingw32-make）",
                              "file": "", "line": 0, "col": 0}], "exe": ""}
    generate_build_scripts(proj_dir, cfg, mode)
    # 构建前清理：输出文件若被上次运行/测试的残留进程占用，链接会失败
    kill_note = toolchain.kill_locked_process(out)
    pre_log = (kill_note + "\n") if kill_note else ""
    cmd = [make, "-f", "Makefile", "MODE=" + mode, target]
    code, so, se = toolchain.run(cmd, cwd=proj_dir, timeout=600)
    raw = (so or b"") + (se or b"")
    log = pre_log + _decode_make_output(raw)
    exe = out
    ok = code == 0 and os.path.isfile(exe)
    msgs = B._parse_gcc_log(log, proj_dir)
    if kill_note:
        kind = "warning" if kill_note.startswith("已") else "error"
        msgs.append({"kind": kind, "text": kill_note, "file": "", "line": 0, "col": 0})
    return {"ok": ok, "log": log, "exe": exe if ok else "",
            "messages": msgs}
